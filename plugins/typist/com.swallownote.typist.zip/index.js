// @swallow-manifest {"id":"com.swallownote.typist","name":"公众号排版","description":"将 Markdown 文档按微信公众号等平台主题排版，一键复制带样式的富文本到公众号编辑器","version":"0.1.2","author":"SwallowNote","published_at":"2026-06-16T05:35:58Z","icon_position":"editorToolbar","content_position":"rightPanel","order":40,"enabled":true,"has_backend":true}
import { useState as I, useEffect as ee, useCallback as $, useRef as O, useMemo as De } from "react";
import { jsxs as N, jsx as S } from "react/jsx-runtime";
import { toast as x } from "sonner";
import { useTranslation as $e } from "react-i18next";
class Fe {
  constructor() {
    this.target = new EventTarget();
  }
  on(t, r) {
    const n = (a) => r(a.detail);
    return this.target.addEventListener(t, n), () => this.target.removeEventListener(t, n);
  }
  // Event bus is best-effort: identity of the wrapped handler is not
  // exposed. Callers should keep the unsubscribe returned by `on()`.
  // The args are kept for API symmetry with the host implementation.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  off(t, r) {
  }
  emit(t, r) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: r }));
  }
}
const A = new Fe();
A.on.bind(A), A.off.bind(A);
A.emit.bind(A);
const L = [];
let Ue = 0;
function Be() {
  const e = L[L.length - 1];
  return e ? e.overrides : He;
}
const He = Object.freeze({});
function mr(e) {
  const t = Ue++, r = { ...Be(), ...e };
  return L.push({ overrides: r, token: t }), () => {
    for (let n = L.length - 1; n >= 0; n--)
      if (L[n].token === t) {
        L.splice(n, 1);
        return;
      }
  };
}
function z(e, t, r) {
  const { store: n } = e, [a, s] = I(r);
  ee(() => {
    let o = !1;
    return n.get(t).then((c) => {
      o || c !== null && s(c);
    }), () => {
      o = !0;
    };
  }, [t, n]);
  const i = $(
    (o) => {
      if (o === null) {
        s(r), n.delete(t);
        return;
      }
      const c = typeof o == "function" ? o(a) : o;
      s(c), n.set(t, c);
    },
    // `value` is captured so the function-form update has the latest
    // state. `initialValue` is included for the same reason – if a
    // parent ever swaps the hook's initial value, we honour that.
    [t, n, a, r]
  );
  return [a, i];
}
async function W(e, t = {}, r) {
  return window.__TAURI_INTERNALS__.invoke(e, t, r);
}
async function te(e = {}) {
  return typeof e == "object" && Object.freeze(e), await W("plugin:dialog|save", { options: e });
}
const Oe = [
  { id: "wechat-default", name: "公众号默认", platform: "wechat" },
  { id: "wechat-rose", name: "蔷薇紫", platform: "wechat" },
  { id: "wechat-geek", name: "极客黑", platform: "wechat" },
  { id: "wechat-tech", name: "科技蓝", platform: "wechat" },
  { id: "wechat-minimal", name: "简约白", platform: "wechat" }
], he = "wechat-default", ge = "wechat", pe = "[modern-screenshot]", P = typeof window < "u", ze = P && "Worker" in window;
var me;
const re = P ? (me = window.navigator) == null ? void 0 : me.userAgent : "", we = re.includes("Chrome"), j = re.includes("AppleWebKit") && !we, ne = re.includes("Firefox"), je = (e) => e && "__CONTEXT__" in e, We = (e) => e.constructor.name === "CSSFontFaceRule", qe = (e) => e.constructor.name === "CSSImportRule", Ve = (e) => e.constructor.name === "CSSLayerBlockRule", R = (e) => e.nodeType === 1, H = (e) => typeof e.className == "object", ye = (e) => e.tagName === "image", Xe = (e) => e.tagName === "use", F = (e) => R(e) && typeof e.style < "u" && !H(e), Ge = (e) => e.nodeType === 8, Ye = (e) => e.nodeType === 3, D = (e) => e.tagName === "IMG", q = (e) => e.tagName === "VIDEO", Ke = (e) => e.tagName === "CANVAS", Je = (e) => e.tagName === "TEXTAREA", Qe = (e) => e.tagName === "INPUT", Ze = (e) => e.tagName === "STYLE", et = (e) => e.tagName === "SCRIPT", tt = (e) => e.tagName === "SELECT", rt = (e) => e.tagName === "SLOT", nt = (e) => e.tagName === "IFRAME", ot = (...e) => console.warn(pe, ...e);
function at(e) {
  var r;
  const t = (r = e == null ? void 0 : e.createElement) == null ? void 0 : r.call(e, "canvas");
  return t && (t.height = t.width = 1), !!t && "toDataURL" in t && !!t.toDataURL("image/webp").includes("image/webp");
}
const K = (e) => e.startsWith("data:");
function be(e, t) {
  if (e.match(/^[a-z]+:\/\//i))
    return e;
  if (P && e.match(/^\/\//))
    return window.location.protocol + e;
  if (e.match(/^[a-z]+:/i) || !P)
    return e;
  const r = V().implementation.createHTMLDocument(), n = r.createElement("base"), a = r.createElement("a");
  return r.head.appendChild(n), r.body.appendChild(a), t && (n.href = t), a.href = e, a.href;
}
function V(e) {
  return (e && R(e) ? e == null ? void 0 : e.ownerDocument : e) ?? window.document;
}
const X = "http://www.w3.org/2000/svg";
function st(e, t, r) {
  const n = V(r).createElementNS(X, "svg");
  return n.setAttributeNS(null, "width", e.toString()), n.setAttributeNS(null, "height", t.toString()), n.setAttributeNS(null, "viewBox", `0 0 ${e} ${t}`), n;
}
function it(e, t) {
  let r = new XMLSerializer().serializeToString(e);
  return t && (r = r.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu, "")), `data:image/svg+xml;charset=utf-8,${encodeURIComponent(r)}`;
}
function lt(e, t) {
  return new Promise((r, n) => {
    const a = new FileReader();
    a.onload = () => r(a.result), a.onerror = () => n(a.error), a.onabort = () => n(new Error(`Failed read blob to ${t}`)), a.readAsDataURL(e);
  });
}
const ct = (e) => lt(e, "dataUrl");
function M(e, t) {
  const r = V(t).createElement("img");
  return r.decoding = "sync", r.loading = "eager", r.src = e, r;
}
function U(e, t) {
  return new Promise((r) => {
    const { timeout: n, ownerDocument: a, onError: s, onWarn: i } = t ?? {}, o = typeof e == "string" ? M(e, V(a)) : e;
    let c = null, u = null;
    function l() {
      r(o), c && clearTimeout(c), u == null || u();
    }
    if (n && (c = setTimeout(l, n)), q(o)) {
      const p = o.currentSrc || o.src;
      if (!p)
        return o.poster ? U(o.poster, t).then(r) : l();
      if (o.readyState >= 2)
        return l();
      const h = l, f = (m) => {
        i == null || i(
          "Failed video load",
          p,
          m
        ), s == null || s(m), l();
      };
      u = () => {
        o.removeEventListener("loadeddata", h), o.removeEventListener("error", f);
      }, o.addEventListener("loadeddata", h, { once: !0 }), o.addEventListener("error", f, { once: !0 });
    } else {
      const p = ye(o) ? o.href.baseVal : o.currentSrc || o.src;
      if (!p)
        return l();
      const h = async () => {
        if (D(o) && "decode" in o)
          try {
            await o.decode();
          } catch (m) {
            i == null || i(
              "Failed to decode image, trying to render anyway",
              o.dataset.originalSrc || p,
              m
            );
          }
        l();
      }, f = (m) => {
        i == null || i(
          "Failed image load",
          o.dataset.originalSrc || p,
          m
        ), l();
      };
      if (D(o) && o.complete)
        return h();
      u = () => {
        o.removeEventListener("load", h), o.removeEventListener("error", f);
      }, o.addEventListener("load", h, { once: !0 }), o.addEventListener("error", f, { once: !0 });
    }
  });
}
async function ut(e, t) {
  F(e) && (D(e) || q(e) ? await U(e, t) : await Promise.all(
    ["img", "video"].flatMap((r) => Array.from(e.querySelectorAll(r)).map((n) => U(n, t)))
  ));
}
const Se = /* @__PURE__ */ function() {
  let t = 0;
  const r = () => `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4);
  return () => (t += 1, `u${r()}${t}`);
}();
function ve(e) {
  return e == null ? void 0 : e.split(",").map((t) => t.trim().replace(/"|'/g, "").toLowerCase()).filter(Boolean);
}
let ae = 0;
function ft(e) {
  const t = `${pe}[#${ae}]`;
  return ae++, {
    // eslint-disable-next-line no-console
    time: (r) => e && console.time(`${t} ${r}`),
    // eslint-disable-next-line no-console
    timeEnd: (r) => e && console.timeEnd(`${t} ${r}`),
    warn: (...r) => e && ot(...r)
  };
}
function dt(e) {
  return {
    cache: e ? "no-cache" : "force-cache"
  };
}
async function Ee(e, t) {
  return je(e) ? e : mt(e, { ...t, autoDestruct: !0 });
}
async function mt(e, t) {
  var f, m;
  const { scale: r = 1, workerUrl: n, workerNumber: a = 1 } = t || {}, s = !!(t != null && t.debug), i = (t == null ? void 0 : t.features) ?? !0, o = e.ownerDocument ?? (P ? window.document : void 0), c = ((f = e.ownerDocument) == null ? void 0 : f.defaultView) ?? (P ? window : void 0), u = /* @__PURE__ */ new Map(), l = {
    // Options
    width: 0,
    height: 0,
    quality: 1,
    type: "image/png",
    scale: r,
    backgroundColor: null,
    style: null,
    filter: null,
    maximumCanvasSize: 0,
    timeout: 3e4,
    progress: null,
    debug: s,
    fetch: {
      requestInit: dt((m = t == null ? void 0 : t.fetch) == null ? void 0 : m.bypassingCache),
      placeholderImage: "data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
      bypassingCache: !1,
      ...t == null ? void 0 : t.fetch
    },
    fetchFn: null,
    font: {},
    drawImageInterval: 100,
    workerUrl: null,
    workerNumber: a,
    onCloneEachNode: null,
    onCloneNode: null,
    onEmbedNode: null,
    onCreateForeignObjectSvg: null,
    includeStyleProperties: null,
    autoDestruct: !1,
    ...t,
    // InternalContext
    __CONTEXT__: !0,
    log: ft(s),
    node: e,
    ownerDocument: o,
    ownerWindow: c,
    dpi: r === 1 ? null : 96 * r,
    svgStyleElement: Ce(o),
    svgDefsElement: o == null ? void 0 : o.createElementNS(X, "defs"),
    svgStyles: /* @__PURE__ */ new Map(),
    defaultComputedStyles: /* @__PURE__ */ new Map(),
    workers: [
      ...Array.from({
        length: ze && n && a ? a : 0
      })
    ].map(() => {
      try {
        const d = new Worker(n);
        return d.onmessage = async (w) => {
          var g, v, E, C;
          const { url: y, result: b } = w.data;
          b ? (v = (g = u.get(y)) == null ? void 0 : g.resolve) == null || v.call(g, b) : (C = (E = u.get(y)) == null ? void 0 : E.reject) == null || C.call(E, new Error(`Error receiving message from worker: ${y}`));
        }, d.onmessageerror = (w) => {
          var b, g;
          const { url: y } = w.data;
          (g = (b = u.get(y)) == null ? void 0 : b.reject) == null || g.call(b, new Error(`Error receiving message from worker: ${y}`));
        }, d;
      } catch (d) {
        return l.log.warn("Failed to new Worker", d), null;
      }
    }).filter(Boolean),
    fontFamilies: /* @__PURE__ */ new Map(),
    fontCssTexts: /* @__PURE__ */ new Map(),
    acceptOfImage: `${[
      at(o) && "image/webp",
      "image/svg+xml",
      "image/*",
      "*/*"
    ].filter(Boolean).join(",")};q=0.8`,
    requests: u,
    drawImageCount: 0,
    tasks: [],
    features: i,
    isEnable: (d) => d === "restoreScrollPosition" ? typeof i == "boolean" ? !1 : i[d] ?? !1 : typeof i == "boolean" ? i : i[d] ?? !0,
    shadowRoots: []
  };
  l.log.time("wait until load"), await ut(e, { timeout: l.timeout, onWarn: l.log.warn }), l.log.timeEnd("wait until load");
  const { width: p, height: h } = ht(e, l);
  return l.width = p, l.height = h, l;
}
function Ce(e) {
  if (!e)
    return;
  const t = e.createElement("style"), r = t.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);
  return t.appendChild(r), t;
}
function ht(e, t) {
  let { width: r, height: n } = t;
  if (R(e) && (!r || !n)) {
    const a = e.getBoundingClientRect();
    r = r || a.width || Number(e.getAttribute("width")) || 0, n = n || a.height || Number(e.getAttribute("height")) || 0;
  }
  return { width: r, height: n };
}
async function gt(e, t) {
  const {
    log: r,
    timeout: n,
    drawImageCount: a,
    drawImageInterval: s
  } = t;
  r.time("image to canvas");
  const i = await U(e, { timeout: n, onWarn: t.log.warn }), { canvas: o, context2d: c } = pt(e.ownerDocument, t), u = () => {
    try {
      c == null || c.drawImage(i, 0, 0, o.width, o.height);
    } catch (l) {
      t.log.warn("Failed to drawImage", l);
    }
  };
  if (u(), t.isEnable("fixSvgXmlDecode"))
    for (let l = 0; l < a; l++)
      await new Promise((p) => {
        setTimeout(() => {
          c == null || c.clearRect(0, 0, o.width, o.height), u(), p();
        }, l + s);
      });
  return t.drawImageCount = 0, r.timeEnd("image to canvas"), o;
}
function pt(e, t) {
  const { width: r, height: n, scale: a, backgroundColor: s, maximumCanvasSize: i } = t, o = e.createElement("canvas");
  o.width = Math.floor(r * a), o.height = Math.floor(n * a), o.style.width = `${r}px`, o.style.height = `${n}px`, i && (o.width > i || o.height > i) && (o.width > i && o.height > i ? o.width > o.height ? (o.height *= i / o.width, o.width = i) : (o.width *= i / o.height, o.height = i) : o.width > i ? (o.height *= i / o.width, o.width = i) : (o.width *= i / o.height, o.height = i));
  const c = o.getContext("2d");
  return c && s && (c.fillStyle = s, c.fillRect(0, 0, o.width, o.height)), { canvas: o, context2d: c };
}
function Te(e, t) {
  if (e.ownerDocument)
    try {
      const s = e.toDataURL();
      if (s !== "data:,")
        return M(s, e.ownerDocument);
    } catch (s) {
      t.log.warn("Failed to clone canvas", s);
    }
  const r = e.cloneNode(!1), n = e.getContext("2d"), a = r.getContext("2d");
  try {
    return n && a && a.putImageData(
      n.getImageData(0, 0, e.width, e.height),
      0,
      0
    ), r;
  } catch (s) {
    t.log.warn("Failed to clone canvas", s);
  }
  return r;
}
function wt(e, t) {
  var r;
  try {
    if ((r = e == null ? void 0 : e.contentDocument) != null && r.documentElement)
      return oe(e.contentDocument.documentElement, t);
  } catch (n) {
    t.log.warn("Failed to clone iframe", n);
  }
  return e.cloneNode(!1);
}
function yt(e) {
  const t = e.cloneNode(!1);
  return e.currentSrc && e.currentSrc !== e.src && (t.src = e.currentSrc, t.srcset = ""), t.loading === "lazy" && (t.loading = "eager"), t;
}
async function bt(e, t) {
  if (e.ownerDocument && !e.currentSrc && e.poster)
    return M(e.poster, e.ownerDocument);
  const r = e.cloneNode(!1);
  r.crossOrigin = "anonymous", e.currentSrc && e.currentSrc !== e.src && (r.src = e.currentSrc);
  const n = r.ownerDocument;
  if (n) {
    let a = !0;
    if (await U(r, { onError: () => a = !1, onWarn: t.log.warn }), !a)
      return e.poster ? M(e.poster, e.ownerDocument) : r;
    r.currentTime = e.currentTime, await new Promise((i) => {
      r.addEventListener("seeked", i, { once: !0 });
    });
    const s = n.createElement("canvas");
    s.width = e.offsetWidth, s.height = e.offsetHeight;
    try {
      const i = s.getContext("2d");
      i && i.drawImage(r, 0, 0, s.width, s.height);
    } catch (i) {
      return t.log.warn("Failed to clone video", i), e.poster ? M(e.poster, e.ownerDocument) : r;
    }
    return Te(s, t);
  }
  return r;
}
function St(e, t) {
  return Ke(e) ? Te(e, t) : nt(e) ? wt(e, t) : D(e) ? yt(e) : q(e) ? bt(e, t) : e.cloneNode(!1);
}
function vt(e) {
  let t = e.sandbox;
  if (!t) {
    const { ownerDocument: r } = e;
    try {
      r && (t = r.createElement("iframe"), t.id = `__SANDBOX__${Se()}`, t.width = "0", t.height = "0", t.style.visibility = "hidden", t.style.position = "fixed", r.body.appendChild(t), t.srcdoc = '<!DOCTYPE html><meta charset="UTF-8"><title></title><body>', e.sandbox = t);
    } catch (n) {
      e.log.warn("Failed to getSandBox", n);
    }
  }
  return t;
}
const Et = [
  "width",
  "height",
  "-webkit-text-fill-color"
], Ct = [
  "stroke",
  "fill"
];
function ke(e, t, r) {
  const { defaultComputedStyles: n } = r, a = e.nodeName.toLowerCase(), s = H(e) && a !== "svg", i = s ? Ct.map((d) => [d, e.getAttribute(d)]).filter(([, d]) => d !== null) : [], o = [
    s && "svg",
    a,
    i.map((d, w) => `${d}=${w}`).join(","),
    t
  ].filter(Boolean).join(":");
  if (n.has(o))
    return n.get(o);
  const c = vt(r), u = c == null ? void 0 : c.contentWindow;
  if (!u)
    return /* @__PURE__ */ new Map();
  const l = u == null ? void 0 : u.document;
  let p, h;
  s ? (p = l.createElementNS(X, "svg"), h = p.ownerDocument.createElementNS(p.namespaceURI, a), i.forEach(([d, w]) => {
    h.setAttributeNS(null, d, w);
  }), p.appendChild(h)) : p = h = l.createElement(a), h.textContent = " ", l.body.appendChild(p);
  const f = u.getComputedStyle(h, t), m = /* @__PURE__ */ new Map();
  for (let d = f.length, w = 0; w < d; w++) {
    const y = f.item(w);
    Et.includes(y) || m.set(y, f.getPropertyValue(y));
  }
  return l.body.removeChild(p), n.set(o, m), m;
}
function xe(e, t, r) {
  var o;
  const n = /* @__PURE__ */ new Map(), a = [], s = /* @__PURE__ */ new Map();
  if (r)
    for (const c of r)
      i(c);
  else
    for (let c = e.length, u = 0; u < c; u++) {
      const l = e.item(u);
      i(l);
    }
  for (let c = a.length, u = 0; u < c; u++)
    (o = s.get(a[u])) == null || o.forEach((l, p) => n.set(p, l));
  function i(c) {
    const u = e.getPropertyValue(c), l = e.getPropertyPriority(c), p = c.lastIndexOf("-"), h = p > -1 ? c.substring(0, p) : void 0;
    if (h) {
      let f = s.get(h);
      f || (f = /* @__PURE__ */ new Map(), s.set(h, f)), f.set(c, [u, l]);
    }
    t.get(c) === u && !l || (h ? a.push(h) : n.set(c, [u, l]));
  }
  return n;
}
function Tt(e, t, r, n) {
  var p, h, f, m;
  const { ownerWindow: a, includeStyleProperties: s, currentParentNodeStyle: i } = n, o = t.style, c = a.getComputedStyle(e), u = ke(e, null, n);
  i == null || i.forEach((d, w) => {
    u.delete(w);
  });
  const l = xe(c, u, s);
  l.delete("transition-property"), l.delete("all"), l.delete("d"), l.delete("content"), r && (l.delete("position"), l.delete("margin-top"), l.delete("margin-right"), l.delete("margin-bottom"), l.delete("margin-left"), l.delete("margin-block-start"), l.delete("margin-block-end"), l.delete("margin-inline-start"), l.delete("margin-inline-end"), l.set("box-sizing", ["border-box", ""])), ((p = l.get("background-clip")) == null ? void 0 : p[0]) === "text" && t.classList.add("______background-clip--text"), we && (l.has("font-kerning") || l.set("font-kerning", ["normal", ""]), (((h = l.get("overflow-x")) == null ? void 0 : h[0]) === "hidden" || ((f = l.get("overflow-y")) == null ? void 0 : f[0]) === "hidden") && ((m = l.get("text-overflow")) == null ? void 0 : m[0]) === "ellipsis" && e.scrollWidth === e.clientWidth && l.set("text-overflow", ["clip", ""]));
  for (let d = o.length, w = 0; w < d; w++)
    o.removeProperty(o.item(w));
  return l.forEach(([d, w], y) => {
    o.setProperty(y, d, w);
  }), l;
}
function kt(e, t) {
  (Je(e) || Qe(e) || tt(e)) && t.setAttribute("value", e.value);
}
const xt = [
  "::before",
  "::after"
  // '::placeholder', TODO
], Nt = [
  "::-webkit-scrollbar",
  "::-webkit-scrollbar-button",
  // '::-webkit-scrollbar:horizontal', TODO
  "::-webkit-scrollbar-thumb",
  "::-webkit-scrollbar-track",
  "::-webkit-scrollbar-track-piece",
  // '::-webkit-scrollbar:vertical', TODO
  "::-webkit-scrollbar-corner",
  "::-webkit-resizer"
];
function Rt(e, t, r, n, a) {
  const { ownerWindow: s, svgStyleElement: i, svgStyles: o, currentNodeStyle: c } = n;
  if (!i || !s)
    return;
  function u(l) {
    var g;
    const p = s.getComputedStyle(e, l);
    let h = p.getPropertyValue("content");
    if (!h || h === "none")
      return;
    a == null || a(h), h = h.replace(/(')|(")|(counter\(.+\))/g, "");
    const f = [Se()], m = ke(e, l, n);
    c == null || c.forEach((v, E) => {
      m.delete(E);
    });
    const d = xe(p, m, n.includeStyleProperties);
    d.delete("content"), d.delete("-webkit-locale"), ((g = d.get("background-clip")) == null ? void 0 : g[0]) === "text" && t.classList.add("______background-clip--text");
    const w = [
      `content: '${h}';`
    ];
    if (d.forEach(([v, E], C) => {
      w.push(`${C}: ${v}${E ? " !important" : ""};`);
    }), w.length === 1)
      return;
    try {
      t.className = [t.className, ...f].join(" ");
    } catch (v) {
      n.log.warn("Failed to copyPseudoClass", v);
      return;
    }
    const y = w.join(`
  `);
    let b = o.get(y);
    b || (b = [], o.set(y, b)), b.push(`.${f[0]}${l}`);
  }
  xt.forEach(u), r && Nt.forEach(u);
}
const se = /* @__PURE__ */ new Set([
  "symbol"
  // test/fixtures/svg.symbol.html
]);
async function ie(e, t, r, n, a) {
  if (R(r) && (Ze(r) || et(r)) || n.filter && !n.filter(r))
    return;
  se.has(t.nodeName) || se.has(r.nodeName) ? n.currentParentNodeStyle = void 0 : n.currentParentNodeStyle = n.currentNodeStyle;
  const s = await oe(r, n, !1, a);
  n.isEnable("restoreScrollPosition") && It(e, s), t.appendChild(s);
}
async function le(e, t, r, n) {
  var s;
  let a = e.firstChild;
  R(e) && e.shadowRoot && (a = (s = e.shadowRoot) == null ? void 0 : s.firstChild, r.shadowRoots.push(e.shadowRoot));
  for (let i = a; i; i = i.nextSibling)
    if (!Ge(i))
      if (R(i) && rt(i) && typeof i.assignedNodes == "function") {
        const o = i.assignedNodes();
        for (let c = 0; c < o.length; c++)
          await ie(e, t, o[c], r, n);
      } else
        await ie(e, t, i, r, n);
}
function It(e, t) {
  if (!F(e) || !F(t))
    return;
  const { scrollTop: r, scrollLeft: n } = e;
  if (!r && !n)
    return;
  const { transform: a } = t.style, s = new DOMMatrix(a), { a: i, b: o, c, d: u } = s;
  s.a = 1, s.b = 0, s.c = 0, s.d = 1, s.translateSelf(-n, -r), s.a = i, s.b = o, s.c = c, s.d = u, t.style.transform = s.toString();
}
function _t(e, t) {
  const { backgroundColor: r, width: n, height: a, style: s } = t, i = e.style;
  if (r && i.setProperty("background-color", r, "important"), n && i.setProperty("width", `${n}px`, "important"), a && i.setProperty("height", `${a}px`, "important"), s)
    for (const o in s) i[o] = s[o];
}
const At = /^[\w-:]+$/;
async function oe(e, t, r = !1, n) {
  var u, l, p, h;
  const { ownerDocument: a, ownerWindow: s, fontFamilies: i, onCloneEachNode: o } = t;
  if (a && Ye(e))
    return n && /\S/.test(e.data) && n(e.data), a.createTextNode(e.data);
  if (a && s && R(e) && (F(e) || H(e))) {
    const f = await St(e, t);
    if (t.isEnable("removeAbnormalAttributes")) {
      const g = f.getAttributeNames();
      for (let v = g.length, E = 0; E < v; E++) {
        const C = g[E];
        At.test(C) || f.removeAttribute(C);
      }
    }
    const m = t.currentNodeStyle = Tt(e, f, r, t);
    r && _t(f, t);
    let d = !1;
    if (t.isEnable("copyScrollbar")) {
      const g = [
        (u = m.get("overflow-x")) == null ? void 0 : u[0],
        (l = m.get("overflow-y")) == null ? void 0 : l[0]
      ];
      d = g.includes("scroll") || (g.includes("auto") || g.includes("overlay")) && (e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth);
    }
    const w = (p = m.get("text-transform")) == null ? void 0 : p[0], y = ve((h = m.get("font-family")) == null ? void 0 : h[0]), b = y ? (g) => {
      w === "uppercase" ? g = g.toUpperCase() : w === "lowercase" ? g = g.toLowerCase() : w === "capitalize" && (g = g[0].toUpperCase() + g.substring(1)), y.forEach((v) => {
        let E = i.get(v);
        E || i.set(v, E = /* @__PURE__ */ new Set()), g.split("").forEach((C) => E.add(C));
      });
    } : void 0;
    return Rt(
      e,
      f,
      d,
      t,
      b
    ), kt(e, f), q(e) || await le(
      e,
      f,
      t,
      b
    ), await (o == null ? void 0 : o(f)), f;
  }
  const c = e.cloneNode(!1);
  return await le(e, c, t), await (o == null ? void 0 : o(c)), c;
}
function Lt(e) {
  if (e.ownerDocument = void 0, e.ownerWindow = void 0, e.svgStyleElement = void 0, e.svgDefsElement = void 0, e.svgStyles.clear(), e.defaultComputedStyles.clear(), e.sandbox) {
    try {
      e.sandbox.remove();
    } catch (t) {
      e.log.warn("Failed to destroyContext", t);
    }
    e.sandbox = void 0;
  }
  e.workers = [], e.fontFamilies.clear(), e.fontCssTexts.clear(), e.requests.clear(), e.tasks = [], e.shadowRoots = [];
}
function Mt(e) {
  const { url: t, timeout: r, responseType: n, ...a } = e, s = new AbortController(), i = r ? setTimeout(() => s.abort(), r) : void 0;
  return fetch(t, { signal: s.signal, ...a }).then((o) => {
    if (!o.ok)
      throw new Error("Failed fetch, not 2xx response", { cause: o });
    switch (n) {
      case "arrayBuffer":
        return o.arrayBuffer();
      case "dataUrl":
        return o.blob().then(ct);
      case "text":
      default:
        return o.text();
    }
  }).finally(() => clearTimeout(i));
}
function B(e, t) {
  const { url: r, requestType: n = "text", responseType: a = "text", imageDom: s } = t;
  let i = r;
  const {
    timeout: o,
    acceptOfImage: c,
    requests: u,
    fetchFn: l,
    fetch: {
      requestInit: p,
      bypassingCache: h,
      placeholderImage: f
    },
    font: m,
    workers: d,
    fontFamilies: w
  } = e;
  n === "image" && (j || ne) && e.drawImageCount++;
  let y = u.get(r);
  if (!y) {
    h && h instanceof RegExp && h.test(i) && (i += (/\?/.test(i) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime());
    const b = n.startsWith("font") && m && m.minify, g = /* @__PURE__ */ new Set();
    b && n.split(";")[1].split(",").forEach((T) => {
      w.has(T) && w.get(T).forEach((k) => g.add(k));
    });
    const v = b && g.size, E = {
      url: i,
      timeout: o,
      responseType: v ? "arrayBuffer" : a,
      headers: n === "image" ? { accept: c } : void 0,
      ...p
    };
    y = {
      type: n,
      resolve: void 0,
      reject: void 0,
      response: null
    }, y.response = (async () => {
      if (l && n === "image") {
        const C = await l(r);
        if (C)
          return C;
      }
      return !j && r.startsWith("http") && d.length ? new Promise((C, T) => {
        d[u.size & d.length - 1].postMessage({ rawUrl: r, ...E }), y.resolve = C, y.reject = T;
      }) : Mt(E);
    })().catch((C) => {
      if (u.delete(r), n === "image" && f)
        return e.log.warn("Failed to fetch image base64, trying to use placeholder image", i), typeof f == "string" ? f : f(s);
      throw C;
    }), u.set(r, y);
  }
  return y.response;
}
async function Ne(e, t, r, n) {
  if (!Re(e))
    return e;
  for (const [a, s] of Pt(e, t))
    try {
      const i = await B(
        r,
        {
          url: s,
          requestType: n ? "image" : "text",
          responseType: "dataUrl"
        }
      );
      e = e.replace(Dt(a), `$1${i}$3`);
    } catch (i) {
      r.log.warn("Failed to fetch css data url", a, i);
    }
  return e;
}
function Re(e) {
  return /url\((['"]?)([^'"]+?)\1\)/.test(e);
}
const Ie = /url\((['"]?)([^'"]+?)\1\)/g;
function Pt(e, t) {
  const r = [];
  return e.replace(Ie, (n, a, s) => (r.push([s, be(s, t)]), n)), r.filter(([n]) => !K(n));
}
function Dt(e) {
  const t = e.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
  return new RegExp(`(url\\(['"]?)(${t})(['"]?\\))`, "g");
}
const $t = [
  "background-image",
  "border-image-source",
  "-webkit-border-image",
  "-webkit-mask-image",
  "list-style-image"
];
function Ft(e, t) {
  return $t.map((r) => {
    const n = e.getPropertyValue(r);
    return !n || n === "none" ? null : ((j || ne) && t.drawImageCount++, Ne(n, null, t, !0).then((a) => {
      !a || n === a || e.setProperty(
        r,
        a,
        e.getPropertyPriority(r)
      );
    }));
  }).filter(Boolean);
}
function Ut(e, t) {
  if (D(e)) {
    const r = e.currentSrc || e.src;
    if (!K(r))
      return [
        B(t, {
          url: r,
          imageDom: e,
          requestType: "image",
          responseType: "dataUrl"
        }).then((n) => {
          n && (e.srcset = "", e.dataset.originalSrc = r, e.src = n || "");
        })
      ];
    (j || ne) && t.drawImageCount++;
  } else if (H(e) && !K(e.href.baseVal)) {
    const r = e.href.baseVal;
    return [
      B(t, {
        url: r,
        imageDom: e,
        requestType: "image",
        responseType: "dataUrl"
      }).then((n) => {
        n && (e.dataset.originalSrc = r, e.href.baseVal = n || "");
      })
    ];
  }
  return [];
}
function Bt(e, t) {
  const { ownerDocument: r, svgDefsElement: n } = t, a = e.getAttribute("href") ?? e.getAttribute("xlink:href");
  if (!a)
    return [];
  const [s, i] = a.split("#");
  if (i) {
    const o = `#${i}`, c = t.shadowRoots.reduce(
      (u, l) => u ?? l.querySelector(`svg ${o}`),
      r == null ? void 0 : r.querySelector(`svg ${o}`)
    );
    if (s && e.setAttribute("href", o), n != null && n.querySelector(o))
      return [];
    if (c)
      return n == null || n.appendChild(c.cloneNode(!0)), [];
    if (s)
      return [
        B(t, {
          url: s,
          responseType: "text"
        }).then((u) => {
          n == null || n.insertAdjacentHTML("beforeend", u);
        })
      ];
  }
  return [];
}
function _e(e, t) {
  const { tasks: r } = t;
  R(e) && ((D(e) || ye(e)) && r.push(...Ut(e, t)), Xe(e) && r.push(...Bt(e, t))), F(e) && r.push(...Ft(e.style, t)), e.childNodes.forEach((n) => {
    _e(n, t);
  });
}
async function Ht(e, t) {
  const {
    ownerDocument: r,
    svgStyleElement: n,
    fontFamilies: a,
    fontCssTexts: s,
    tasks: i,
    font: o
  } = t;
  if (!(!r || !n || !a.size))
    if (o && o.cssText) {
      const c = ue(o.cssText, t);
      n.appendChild(r.createTextNode(`${c}
`));
    } else {
      const c = Array.from(r.styleSheets).filter((f) => {
        try {
          return "cssRules" in f && !!f.cssRules.length;
        } catch (m) {
          return t.log.warn(`Error while reading CSS rules from ${f.href}`, m), !1;
        }
      }), u = r.implementation.createHTMLDocument(""), l = u.createElement("style");
      u.head.appendChild(l);
      const p = l.sheet;
      await Promise.all(
        c.flatMap((f) => Array.from(f.cssRules).map(async (m) => {
          if (qe(m)) {
            const d = m.href;
            let w = "";
            try {
              w = await B(t, {
                url: d,
                requestType: "text",
                responseType: "text"
              });
            } catch (b) {
              t.log.warn(`Error fetch remote css import from ${d}`, b);
            }
            const y = w.replace(
              Ie,
              (b, g, v) => b.replace(v, be(v, d))
            );
            for (const b of zt(y))
              try {
                p.insertRule(b, p.cssRules.length);
              } catch (g) {
                t.log.warn("Error inserting rule from remote css import", { rule: b, error: g });
              }
          }
        }))
      ), p.cssRules.length && c.push(p);
      const h = [];
      c.forEach((f) => {
        J(f.cssRules, h);
      }), h.filter((f) => {
        var m;
        return We(f) && Re(f.style.getPropertyValue("src")) && ((m = ve(f.style.getPropertyValue("font-family"))) == null ? void 0 : m.some((d) => a.has(d)));
      }).forEach((f) => {
        const m = f, d = s.get(m.cssText);
        d ? n.appendChild(r.createTextNode(`${d}
`)) : i.push(
          Ne(
            m.cssText,
            m.parentStyleSheet ? m.parentStyleSheet.href : null,
            t
          ).then((w) => {
            w = ue(w, t), s.set(m.cssText, w), n.appendChild(r.createTextNode(`${w}
`));
          })
        );
      });
    }
}
const Ot = /(\/\*[\s\S]*?\*\/)/g, ce = /((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;
function zt(e) {
  if (e == null)
    return [];
  const t = [];
  let r = e.replace(Ot, "");
  for (; ; ) {
    const s = ce.exec(r);
    if (!s)
      break;
    t.push(s[0]);
  }
  r = r.replace(ce, "");
  const n = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi, a = new RegExp(
    // eslint-disable-next-line
    "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})",
    "gi"
  );
  for (; ; ) {
    let s = n.exec(r);
    if (s)
      a.lastIndex = n.lastIndex;
    else if (s = a.exec(r), s)
      n.lastIndex = a.lastIndex;
    else
      break;
    t.push(s[0]);
  }
  return t;
}
const jt = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g, Wt = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
function ue(e, t) {
  const { font: r } = t, n = r ? r == null ? void 0 : r.preferredFormat : void 0;
  return n ? e.replace(Wt, (a) => {
    for (; ; ) {
      const [s, , i] = jt.exec(a) || [];
      if (!i)
        return "";
      if (i === n)
        return `src: ${s};`;
    }
  }) : e;
}
function J(e, t = []) {
  for (const r of Array.from(e))
    Ve(r) ? t.push(...J(r.cssRules)) : "cssRules" in r ? J(r.cssRules, t) : t.push(r);
  return t;
}
const qt = /\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;
function Vt(e) {
  return qt.test(e.innerHTML);
}
async function Xt(e, t) {
  const r = await Ee(e, t);
  if (R(r.node) && H(r.node) && !Vt(r.node))
    return r.node;
  const {
    ownerDocument: n,
    log: a,
    tasks: s,
    svgStyleElement: i,
    svgDefsElement: o,
    svgStyles: c,
    font: u,
    progress: l,
    autoDestruct: p,
    onCloneNode: h,
    onEmbedNode: f,
    onCreateForeignObjectSvg: m
  } = r;
  a.time("clone node");
  const d = await oe(r.node, r, !0);
  if (i && n) {
    let v = "";
    c.forEach((E, C) => {
      v += `${E.join(`,
`)} {
  ${C}
}
`;
    }), i.appendChild(n.createTextNode(v));
  }
  a.timeEnd("clone node"), await (h == null ? void 0 : h(d)), u !== !1 && R(d) && (a.time("embed web font"), await Ht(d, r), a.timeEnd("embed web font")), a.time("embed node"), _e(d, r);
  const w = s.length;
  let y = 0;
  const b = async () => {
    for (; ; ) {
      const v = s.pop();
      if (!v)
        break;
      try {
        await v;
      } catch (E) {
        r.log.warn("Failed to run task", E);
      }
      l == null || l(++y, w);
    }
  };
  l == null || l(y, w), await Promise.all([...Array.from({ length: 4 })].map(b)), a.timeEnd("embed node"), await (f == null ? void 0 : f(d));
  const g = Gt(d, r);
  return o && g.insertBefore(o, g.children[0]), i && g.insertBefore(i, g.children[0]), p && Lt(r), await (m == null ? void 0 : m(g)), g;
}
function Gt(e, t) {
  const { width: r, height: n } = t, a = st(r, n, e.ownerDocument), s = a.ownerDocument.createElementNS(a.namespaceURI, "foreignObject");
  return s.setAttributeNS(null, "x", "0%"), s.setAttributeNS(null, "y", "0%"), s.setAttributeNS(null, "width", "100%"), s.setAttributeNS(null, "height", "100%"), s.append(e), a.appendChild(s), a;
}
async function Yt(e, t) {
  var i;
  const r = await Ee(e, t), n = await Xt(r), a = it(n, r.isEnable("removeControlCharacter"));
  r.autoDestruct || (r.svgStyleElement = Ce(r.ownerDocument), r.svgDefsElement = (i = r.ownerDocument) == null ? void 0 : i.createElementNS(X, "defs"), r.svgStyles.clear());
  const s = M(a, n.ownerDocument);
  return await gt(s, r);
}
const Kt = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, Jt = /<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, Qt = /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, Zt = /<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, er = /<embed\b[^>]*>/gi, tr = /\son[a-z]+\s*=\s*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[^\s>"']+)/gi, rr = /\s(href|src|formaction)\s*=\s*(?:"\s*(?:(?:javascript|vbscript)\s*:[^"]*|data\s*:\s*text\/html[^"]*)"|'\s*(?:(?:javascript|vbscript)\s*:[^']*|data\s*:\s*text\/html[^']*)'|(?:javascript|vbscript)\s*:[^\s>]+|data\s*:\s*text\/html[^\s>]+)/gi;
function Q(e) {
  return e.replace(Kt, "").replace(Jt, "").replace(Qt, "").replace(Zt, "").replace(er, "").replace(tr, "").replace(rr, "");
}
function fe(e) {
  return e.replace(/<br\s*\/?>/gi, `
`).replace(/<\/p>/gi, `

`).replace(/<\/h[1-6]>/gi, `

`).replace(/<\/li>/gi, `
`).replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, `

`).trim();
}
async function Ae(e, t) {
  var r, n;
  try {
    if (typeof ClipboardItem < "u" && ((r = navigator.clipboard) != null && r.write)) {
      const a = new Blob([e], { type: "text/html" }), s = new Blob([fe(e)], { type: "text/plain" }), i = new ClipboardItem({
        "text/html": a,
        "text/plain": s
      });
      return await navigator.clipboard.write([i]), { ok: !0, method: "clipboard-html" };
    }
  } catch (a) {
    console.warn("[typist] ClipboardItem.write failed:", a);
  }
  try {
    if ((n = navigator.clipboard) != null && n.writeText)
      return await navigator.clipboard.writeText(fe(e)), {
        ok: !0,
        method: "clipboard-text",
        warning: "当前环境不支持富文本剪贴板，已写入纯文本。请在公众号编辑器中先用纯文本模式粘贴，再用格式刷修复样式。"
      };
  } catch (a) {
    console.warn("[typist] clipboard.writeText failed:", a);
  }
  if (t)
    try {
      return { ok: !0, method: "image", dataUrl: (await Yt(t, {
        scale: 2,
        backgroundColor: "#ffffff"
      })).toDataURL("image/png") };
    } catch (a) {
      console.warn("[typist] domToCanvas failed:", a);
    }
  return {
    ok: !1,
    error: "所有复制方式均不可用：请检查浏览器权限或尝试保存为 HTML 文件。"
  };
}
function Z({ size: e = 18 }) {
  return /* @__PURE__ */ N(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ S("path", { d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }),
        /* @__PURE__ */ S("polyline", { points: "14 2 14 8 20 8" }),
        /* @__PURE__ */ S("path", { d: "M9 13h6M9 17h4" }),
        /* @__PURE__ */ S("circle", { cx: "17", cy: "17", r: "2.5", fill: "currentColor", stroke: "none" })
      ]
    }
  );
}
function Le({ size: e = 14 }) {
  return /* @__PURE__ */ N(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ S("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2" }),
        /* @__PURE__ */ S("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
      ]
    }
  );
}
function Me({ size: e = 14 }) {
  return /* @__PURE__ */ N(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ S("path", { d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" }),
        /* @__PURE__ */ S("polyline", { points: "17 21 17 13 7 13 7 21" }),
        /* @__PURE__ */ S("polyline", { points: "7 3 7 8 15 8" })
      ]
    }
  );
}
function nr({ size: e = 14 }) {
  return /* @__PURE__ */ N(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ S("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
        /* @__PURE__ */ S("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
      ]
    }
  );
}
function or(e) {
  const { activeNoteContent: t, activeNotePath: r, close: n, invokeBackend: a } = e, { t: s } = $e(), [i, o] = z(e, "theme", he), [c] = z(e, "platform", ge), [u, l] = I(""), [p, h] = I(!1), [f, m] = I(!1), [d, w] = I(0), y = O(null), b = O(null), g = O(0);
  ee(() => {
    if (!t) {
      l("");
      return;
    }
    b.current && clearTimeout(b.current);
    const T = ++g.current;
    return b.current = setTimeout(() => {
      ar(
        t,
        i,
        c,
        a,
        (k, _) => {
          T === g.current && (l(k), w(_));
        },
        (k) => {
          T === g.current && h(k);
        }
      );
    }, 800), () => {
      b.current && clearTimeout(b.current);
    };
  }, [t, i, c, a]);
  const v = $(async () => {
    if (!(f || !u)) {
      m(!0);
      try {
        const T = Q(u), k = await Ae(T, y.current);
        k.ok ? k.method === "clipboard-html" ? x.success("已复制到剪贴板（带样式）") : k.method === "clipboard-text" ? x.warning(k.warning) : (await ir(k.dataUrl, de(r)), x.success("已保存为 PNG，请拖入公众号编辑器")) : x.error(k.error);
      } catch (T) {
        x.error(`复制失败: ${String(T)}`);
      } finally {
        m(!1);
      }
    }
  }, [f, u, r]), E = $(async () => {
    if (u)
      try {
        const T = de(r), k = sr(u, i), _ = await te({
          defaultPath: `${T}.html`,
          filters: [{ name: "HTML", extensions: ["html"] }]
        });
        if (!_) return;
        const Pe = _.replace(/\\/g, "/");
        await W("write_text_file", { path: Pe, content: k }), x.success("已保存为 HTML");
      } catch (T) {
        x.error(`保存失败: ${String(T)}`);
      }
  }, [u, r, i]), C = De(
    () => u ? Q(u) : "",
    [u]
  );
  return /* @__PURE__ */ N(
    "div",
    {
      style: {
        borderRadius: 8,
        display: "flex",
        flexDirection: "column",
        fontSize: 12,
        color: "var(--text-primary)",
        overflow: "hidden"
      },
      children: [
        /* @__PURE__ */ N(
          "div",
          {
            style: {
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "8px 12px"
            },
            children: [
              /* @__PURE__ */ S("span", { style: { fontSize: 12, fontWeight: 600 }, children: "排版" }),
              /* @__PURE__ */ S("span", { style: { color: "var(--text-muted)", fontSize: 11 }, children: "平台: 公众号" }),
              /* @__PURE__ */ N("label", { style: { display: "flex", alignItems: "center", gap: 4, fontSize: 11 }, children: [
                "主题",
                /* @__PURE__ */ S(
                  "select",
                  {
                    value: i,
                    onChange: (T) => o(T.target.value),
                    style: {
                      fontSize: 11,
                      padding: "2px 4px",
                      border: "1px solid var(--border-color)",
                      borderRadius: 4,
                      background: "var(--bg-primary)",
                      color: "var(--text-primary)"
                    },
                    children: Oe.map((T) => /* @__PURE__ */ S("option", { value: T.id, children: T.name }, T.id))
                  }
                )
              ] }),
              /* @__PURE__ */ S("span", { style: { flex: 1 } }),
              d > 0 && /* @__PURE__ */ N("span", { style: { color: "var(--text-muted)", fontSize: 10 }, children: [
                d,
                "ms"
              ] }),
              /* @__PURE__ */ N(
                "button",
                {
                  type: "button",
                  onClick: v,
                  disabled: f || !u,
                  style: G,
                  children: [
                    /* @__PURE__ */ S(Le, { size: 12 }),
                    "复制到公众号"
                  ]
                }
              ),
              /* @__PURE__ */ N("button", { type: "button", onClick: E, disabled: !u, style: G, children: [
                /* @__PURE__ */ S(Me, { size: 12 }),
                "保存 HTML"
              ] }),
              /* @__PURE__ */ S("button", { type: "button", onClick: n, style: G, title: "关闭", children: /* @__PURE__ */ S(nr, { size: 12 }) })
            ]
          }
        ),
        /* @__PURE__ */ S(
          "div",
          {
            ref: y,
            style: {
              background: "#ffffff",
              color: "#000",
              width: "100%",
              flex: 1,
              minHeight: 0,
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
              boxSizing: "border-box"
            },
            children: p && !u ? /* @__PURE__ */ S("div", { style: { color: "#999", padding: "20px 24px" }, children: "渲染中…" }) : u ? /* @__PURE__ */ S(
              "div",
              {
                style: {
                  flex: 1,
                  minHeight: 0,
                  overflow: "auto",
                  overflowY: "scroll",
                  overflowX: "hidden",
                  width: "100%",
                  boxSizing: "border-box",
                  padding: "0 20px"
                },
                dangerouslySetInnerHTML: { __html: C }
              }
            ) : /* @__PURE__ */ S("div", { style: { color: "#999", padding: "20px 24px" }, children: "预览将出现在这里" })
          }
        )
      ]
    }
  );
}
const G = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  fontSize: 11,
  padding: "4px 8px",
  border: "1px solid var(--border-color)",
  borderRadius: 4,
  background: "var(--bg-primary)",
  color: "var(--text-primary)",
  cursor: "pointer"
};
async function ar(e, t, r, n, a, s) {
  s(!0);
  const i = performance.now();
  try {
    const o = await n("markdown_to_themed_html", {
      markdown: e,
      theme: t,
      platform: r
    });
    a(o, Math.round(performance.now() - i));
  } catch (o) {
    console.error("[typist] render failed:", o), a(`<p style="color:#c00">渲染失败: ${String(o)}</p>`, 0);
  } finally {
    s(!1);
  }
}
function de(e) {
  return e && (e.split("/").pop() || e).replace(/\.(md|markdown)$/i, "") || "untitled";
}
function sr(e, t) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${t} export</title>
<style>
body { font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
       max-width: 720px; margin: 40px auto; padding: 0 16px; color: #333; }
</style>
</head>
<body>
${e}
</body>
</html>`;
}
async function ir(e, t) {
  const r = await te({
    defaultPath: `${t}.png`,
    filters: [{ name: "PNG Image", extensions: ["png"] }]
  });
  if (!r) return;
  const n = r.replace(/\\/g, "/"), a = e.replace(/^data:image\/png;base64,/, "");
  await W("write_binary_file", { path: n, data: a });
}
function lr(e) {
  const { size: t, activate: r, activeNoteContent: n, activeNotePath: a, invokeBackend: s, store: i } = e, [o, c] = I(!1), [u, l] = I(!1), p = O(null), h = {
    pluginId: e.pluginId,
    store: i
  }, [f] = z(h, "theme", he), [m] = z(h, "platform", ge);
  ee(() => {
    if (!o) return;
    const y = (b) => {
      p.current && !p.current.contains(b.target) && c(!1);
    };
    return document.addEventListener("mousedown", y), () => document.removeEventListener("mousedown", y);
  }, [o]);
  const d = $(async () => {
    if (c(!1), !(u || !n)) {
      l(!0);
      try {
        const y = await s("markdown_to_themed_html", {
          markdown: n,
          theme: f,
          platform: m
        }), b = Q(y), g = await Ae(b, null);
        g.ok ? g.method === "clipboard-html" ? x.success("已复制到剪贴板（带样式）") : g.method === "clipboard-text" ? x.warning(g.warning) : x.error("请打开排版面板后再试「复制为图片」") : x.error("所有复制方式均不可用，请打开排版面板后再试或保存为 HTML");
      } catch (y) {
        x.error(`复制失败: ${String(y)}`);
      } finally {
        l(!1);
      }
    }
  }, [u, n, f, m, s]), w = $(async () => {
    if (c(!1), !(u || !n)) {
      l(!0);
      try {
        const y = await s("markdown_to_themed_html", {
          markdown: n,
          theme: f,
          platform: m
        }), b = (a.split("/").pop() || "untitled").replace(
          /\.(md|markdown)$/i,
          ""
        ), g = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${b}</title>
<style>body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;max-width:720px;margin:40px auto;padding:0 16px;color:#333;}</style>
</head>
<body>
${y}
</body>
</html>`, v = await te({
          defaultPath: `${b}.html`,
          filters: [{ name: "HTML", extensions: ["html"] }]
        });
        if (!v) {
          l(!1);
          return;
        }
        const E = v.replace(/\\/g, "/");
        await W("write_text_file", { path: E, content: g }), x.success("已保存为 HTML");
      } catch (y) {
        x.error(`保存失败: ${String(y)}`);
      } finally {
        l(!1);
      }
    }
  }, [u, n, a, f, m, s]);
  return /* @__PURE__ */ N("div", { ref: p, className: "relative", children: [
    /* @__PURE__ */ S(
      "button",
      {
        type: "button",
        onClick: () => c(!o),
        className: "flex items-center justify-center w-6 h-6 rounded hover:bg-[var(--bg-hover)] cursor-pointer",
        style: {
          color: o ? "var(--theme-color)" : "var(--text-primary)"
        },
        title: "公众号排版",
        children: /* @__PURE__ */ S(Z, { size: t })
      }
    ),
    o && /* @__PURE__ */ N(
      "div",
      {
        className: "absolute right-0 top-full mt-1 z-50 rounded-lg py-1 min-w-[160px]",
        style: {
          background: "var(--bg-secondary)",
          border: "1px solid var(--border-color)",
          boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
        },
        children: [
          /* @__PURE__ */ S(
            Y,
            {
              icon: /* @__PURE__ */ S(Z, { size: 12 }),
              label: "打开排版面板",
              onClick: () => {
                c(!1), r();
              }
            }
          ),
          /* @__PURE__ */ S(
            Y,
            {
              icon: /* @__PURE__ */ S(Le, { size: 12 }),
              label: "复制到公众号",
              onClick: d,
              disabled: u || !n
            }
          ),
          /* @__PURE__ */ S(
            Y,
            {
              icon: /* @__PURE__ */ S(Me, { size: 12 }),
              label: "保存为 HTML",
              onClick: w,
              disabled: u || !n
            }
          )
        ]
      }
    )
  ] });
}
function Y(e) {
  return /* @__PURE__ */ N(
    "button",
    {
      type: "button",
      onClick: e.onClick,
      disabled: e.disabled,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        width: "100%",
        padding: "5px 12px",
        fontSize: 11,
        textAlign: "left",
        background: "transparent",
        border: "none",
        color: "var(--text-primary)",
        cursor: e.disabled ? "not-allowed" : "pointer",
        opacity: e.disabled ? 0.5 : 1
      },
      onMouseEnter: (t) => {
        e.disabled || (t.currentTarget.style.background = "var(--bg-hover)");
      },
      onMouseLeave: (t) => {
        t.currentTarget.style.background = "transparent";
      },
      children: [
        e.icon,
        e.label
      ]
    }
  );
}
const hr = {
  id: "com.swallownote.typist",
  name: "公众号排版",
  description: "将 Markdown 文档按微信公众号等平台主题排版，一键复制带样式的富文本",
  version: "0.1.2",
  author: "SwallowNote",
  publishedAt: "2026-06-14",
  iconPosition: "editorToolbar",
  contentPosition: "rightPanel",
  order: 40,
  enabled: !0,
  // Note: `hasBackend` is read from `manifest.json` on disk by the host;
  // it is intentionally not part of the SDK's PluginManifest type, so
  // we omit it from the in-memory manifest. See `manifest.json`.
  icon: Z,
  // The host renders this inside the editorArea floating container
  // when the user activates the plugin via the toolbar dropdown.
  panel: or,
  toolbarButton: lr,
  permissions: ["storage", "events", "backend", "clipboard"]
};
export {
  hr as default,
  mr as setHost
};
