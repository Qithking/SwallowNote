// @swallow-manifest {"id":"com.swallownote.typist","name":"公众号排版","description":"将 Markdown 文档按微信公众号等平台主题排版，一键复制带样式的富文本到公众号编辑器","version":"0.1.0","author":"SwallowNote","published_at":"2026-06-14","icon_position":"editorToolbar","content_position":"rightPanel","order":40,"enabled":true,"has_backend":true}
import { useState as I, useEffect as ne, useCallback as $, useRef as W, useMemo as j } from "react";
import { jsxs as T, jsx as v } from "react/jsx-runtime";
import { toast as x } from "sonner";
import { useTranslation as Ue } from "react-i18next";
class He {
  constructor() {
    this.target = new EventTarget();
  }
  on(t, r) {
    const n = (a) => r(a.detail);
    return this.target.addEventListener(t, n), () => this.target.removeEventListener(t, n);
  }
  // Event bus is best-effort: identity of the wrapped handler is not
  // exposed. Callers should keep the unsubscribe returned by `on()`.
  // The args are kept for API symmetry with the host implementation.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  off(t, r) {
  }
  emit(t, r) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: r }));
  }
}
const L = new He();
L.on.bind(L), L.off.bind(L);
L.emit.bind(L);
const M = [];
let Oe = 0;
function ze() {
  const e = M[M.length - 1];
  return e ? e.overrides : je;
}
const je = Object.freeze({});
function wr(e) {
  const t = Oe++, r = { ...ze(), ...e };
  return M.push({ overrides: r, token: t }), () => {
    for (let n = M.length - 1; n >= 0; n--)
      if (M[n].token === t) {
        M.splice(n, 1);
        return;
      }
  };
}
function q(e, t, r) {
  const { store: n } = e, [a, s] = I(r);
  ne(() => {
    let o = !1;
    return n.get(t).then((c) => {
      o || c !== null && s(c);
    }), () => {
      o = !0;
    };
  }, [t, n]);
  const i = $(
    (o) => {
      if (o === null) {
        s(r), n.delete(t);
        return;
      }
      const c = typeof o == "function" ? o(a) : o;
      s(c), n.set(t, c);
    },
    // `value` is captured so the function-form update has the latest
    // state. `initialValue` is included for the same reason – if a
    // parent ever swaps the hook's initial value, we honour that.
    [t, n, a, r]
  );
  return [a, i];
}
async function G(e, t = {}, r) {
  return window.__TAURI_INTERNALS__.invoke(e, t, r);
}
async function oe(e = {}) {
  return typeof e == "object" && Object.freeze(e), await G("plugin:dialog|save", { options: e });
}
const We = [
  { id: "wechat-default", name: "公众号默认", platform: "wechat" },
  { id: "wechat-rose", name: "蔷薇紫", platform: "wechat" },
  { id: "wechat-geek", name: "极客黑", platform: "wechat" },
  { id: "wechat-tech", name: "科技蓝", platform: "wechat" },
  { id: "wechat-minimal", name: "简约白", platform: "wechat" }
], we = "wechat-default", ye = "wechat", be = "[modern-screenshot]", D = typeof window < "u", qe = D && "Worker" in window;
var pe;
const ae = D ? (pe = window.navigator) == null ? void 0 : pe.userAgent : "", ve = ae.includes("Chrome"), V = ae.includes("AppleWebKit") && !ve, se = ae.includes("Firefox"), Ve = (e) => e && "__CONTEXT__" in e, Ge = (e) => e.constructor.name === "CSSFontFaceRule", Xe = (e) => e.constructor.name === "CSSImportRule", Ye = (e) => e.constructor.name === "CSSLayerBlockRule", R = (e) => e.nodeType === 1, O = (e) => typeof e.className == "object", Se = (e) => e.tagName === "image", Ke = (e) => e.tagName === "use", B = (e) => R(e) && typeof e.style < "u" && !O(e), Je = (e) => e.nodeType === 8, Qe = (e) => e.nodeType === 3, F = (e) => e.tagName === "IMG", X = (e) => e.tagName === "VIDEO", Ze = (e) => e.tagName === "CANVAS", et = (e) => e.tagName === "TEXTAREA", tt = (e) => e.tagName === "INPUT", rt = (e) => e.tagName === "STYLE", nt = (e) => e.tagName === "SCRIPT", ot = (e) => e.tagName === "SELECT", at = (e) => e.tagName === "SLOT", st = (e) => e.tagName === "IFRAME", it = (...e) => console.warn(be, ...e);
function lt(e) {
  var r;
  const t = (r = e == null ? void 0 : e.createElement) == null ? void 0 : r.call(e, "canvas");
  return t && (t.height = t.width = 1), !!t && "toDataURL" in t && !!t.toDataURL("image/webp").includes("image/webp");
}
const Z = (e) => e.startsWith("data:");
function Ee(e, t) {
  if (e.match(/^[a-z]+:\/\//i))
    return e;
  if (D && e.match(/^\/\//))
    return window.location.protocol + e;
  if (e.match(/^[a-z]+:/i) || !D)
    return e;
  const r = Y().implementation.createHTMLDocument(), n = r.createElement("base"), a = r.createElement("a");
  return r.head.appendChild(n), r.body.appendChild(a), t && (n.href = t), a.href = e, a.href;
}
function Y(e) {
  return (e && R(e) ? e == null ? void 0 : e.ownerDocument : e) ?? window.document;
}
const K = "http://www.w3.org/2000/svg";
function ct(e, t, r) {
  const n = Y(r).createElementNS(K, "svg");
  return n.setAttributeNS(null, "width", e.toString()), n.setAttributeNS(null, "height", t.toString()), n.setAttributeNS(null, "viewBox", `0 0 ${e} ${t}`), n;
}
function ut(e, t) {
  let r = new XMLSerializer().serializeToString(e);
  return t && (r = r.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu, "")), `data:image/svg+xml;charset=utf-8,${encodeURIComponent(r)}`;
}
function dt(e, t) {
  return new Promise((r, n) => {
    const a = new FileReader();
    a.onload = () => r(a.result), a.onerror = () => n(a.error), a.onabort = () => n(new Error(`Failed read blob to ${t}`)), a.readAsDataURL(e);
  });
}
const ft = (e) => dt(e, "dataUrl");
function P(e, t) {
  const r = Y(t).createElement("img");
  return r.decoding = "sync", r.loading = "eager", r.src = e, r;
}
function U(e, t) {
  return new Promise((r) => {
    const { timeout: n, ownerDocument: a, onError: s, onWarn: i } = t ?? {}, o = typeof e == "string" ? P(e, Y(a)) : e;
    let c = null, u = null;
    function l() {
      r(o), c && clearTimeout(c), u == null || u();
    }
    if (n && (c = setTimeout(l, n)), X(o)) {
      const p = o.currentSrc || o.src;
      if (!p)
        return o.poster ? U(o.poster, t).then(r) : l();
      if (o.readyState >= 2)
        return l();
      const g = l, d = (m) => {
        i == null || i(
          "Failed video load",
          p,
          m
        ), s == null || s(m), l();
      };
      u = () => {
        o.removeEventListener("loadeddata", g), o.removeEventListener("error", d);
      }, o.addEventListener("loadeddata", g, { once: !0 }), o.addEventListener("error", d, { once: !0 });
    } else {
      const p = Se(o) ? o.href.baseVal : o.currentSrc || o.src;
      if (!p)
        return l();
      const g = async () => {
        if (F(o) && "decode" in o)
          try {
            await o.decode();
          } catch (m) {
            i == null || i(
              "Failed to decode image, trying to render anyway",
              o.dataset.originalSrc || p,
              m
            );
          }
        l();
      }, d = (m) => {
        i == null || i(
          "Failed image load",
          o.dataset.originalSrc || p,
          m
        ), l();
      };
      if (F(o) && o.complete)
        return g();
      u = () => {
        o.removeEventListener("load", g), o.removeEventListener("error", d);
      }, o.addEventListener("load", g, { once: !0 }), o.addEventListener("error", d, { once: !0 });
    }
  });
}
async function mt(e, t) {
  B(e) && (F(e) || X(e) ? await U(e, t) : await Promise.all(
    ["img", "video"].flatMap((r) => Array.from(e.querySelectorAll(r)).map((n) => U(n, t)))
  ));
}
const Ce = /* @__PURE__ */ function() {
  let t = 0;
  const r = () => `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4);
  return () => (t += 1, `u${r()}${t}`);
}();
function ke(e) {
  return e == null ? void 0 : e.split(",").map((t) => t.trim().replace(/"|'/g, "").toLowerCase()).filter(Boolean);
}
let le = 0;
function gt(e) {
  const t = `${be}[#${le}]`;
  return le++, {
    // eslint-disable-next-line no-console
    time: (r) => e && console.time(`${t} ${r}`),
    // eslint-disable-next-line no-console
    timeEnd: (r) => e && console.timeEnd(`${t} ${r}`),
    warn: (...r) => e && it(...r)
  };
}
function ht(e) {
  return {
    cache: e ? "no-cache" : "force-cache"
  };
}
async function Te(e, t) {
  return Ve(e) ? e : pt(e, { ...t, autoDestruct: !0 });
}
async function pt(e, t) {
  var d, m;
  const { scale: r = 1, workerUrl: n, workerNumber: a = 1 } = t || {}, s = !!(t != null && t.debug), i = (t == null ? void 0 : t.features) ?? !0, o = e.ownerDocument ?? (D ? window.document : void 0), c = ((d = e.ownerDocument) == null ? void 0 : d.defaultView) ?? (D ? window : void 0), u = /* @__PURE__ */ new Map(), l = {
    // Options
    width: 0,
    height: 0,
    quality: 1,
    type: "image/png",
    scale: r,
    backgroundColor: null,
    style: null,
    filter: null,
    maximumCanvasSize: 0,
    timeout: 3e4,
    progress: null,
    debug: s,
    fetch: {
      requestInit: ht((m = t == null ? void 0 : t.fetch) == null ? void 0 : m.bypassingCache),
      placeholderImage: "data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
      bypassingCache: !1,
      ...t == null ? void 0 : t.fetch
    },
    fetchFn: null,
    font: {},
    drawImageInterval: 100,
    workerUrl: null,
    workerNumber: a,
    onCloneEachNode: null,
    onCloneNode: null,
    onEmbedNode: null,
    onCreateForeignObjectSvg: null,
    includeStyleProperties: null,
    autoDestruct: !1,
    ...t,
    // InternalContext
    __CONTEXT__: !0,
    log: gt(s),
    node: e,
    ownerDocument: o,
    ownerWindow: c,
    dpi: r === 1 ? null : 96 * r,
    svgStyleElement: xe(o),
    svgDefsElement: o == null ? void 0 : o.createElementNS(K, "defs"),
    svgStyles: /* @__PURE__ */ new Map(),
    defaultComputedStyles: /* @__PURE__ */ new Map(),
    workers: [
      ...Array.from({
        length: qe && n && a ? a : 0
      })
    ].map(() => {
      try {
        const f = new Worker(n);
        return f.onmessage = async (w) => {
          var h, S, E, k;
          const { url: y, result: b } = w.data;
          b ? (S = (h = u.get(y)) == null ? void 0 : h.resolve) == null || S.call(h, b) : (k = (E = u.get(y)) == null ? void 0 : E.reject) == null || k.call(E, new Error(`Error receiving message from worker: ${y}`));
        }, f.onmessageerror = (w) => {
          var b, h;
          const { url: y } = w.data;
          (h = (b = u.get(y)) == null ? void 0 : b.reject) == null || h.call(b, new Error(`Error receiving message from worker: ${y}`));
        }, f;
      } catch (f) {
        return l.log.warn("Failed to new Worker", f), null;
      }
    }).filter(Boolean),
    fontFamilies: /* @__PURE__ */ new Map(),
    fontCssTexts: /* @__PURE__ */ new Map(),
    acceptOfImage: `${[
      lt(o) && "image/webp",
      "image/svg+xml",
      "image/*",
      "*/*"
    ].filter(Boolean).join(",")};q=0.8`,
    requests: u,
    drawImageCount: 0,
    tasks: [],
    features: i,
    isEnable: (f) => f === "restoreScrollPosition" ? typeof i == "boolean" ? !1 : i[f] ?? !1 : typeof i == "boolean" ? i : i[f] ?? !0,
    shadowRoots: []
  };
  l.log.time("wait until load"), await mt(e, { timeout: l.timeout, onWarn: l.log.warn }), l.log.timeEnd("wait until load");
  const { width: p, height: g } = wt(e, l);
  return l.width = p, l.height = g, l;
}
function xe(e) {
  if (!e)
    return;
  const t = e.createElement("style"), r = t.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);
  return t.appendChild(r), t;
}
function wt(e, t) {
  let { width: r, height: n } = t;
  if (R(e) && (!r || !n)) {
    const a = e.getBoundingClientRect();
    r = r || a.width || Number(e.getAttribute("width")) || 0, n = n || a.height || Number(e.getAttribute("height")) || 0;
  }
  return { width: r, height: n };
}
async function yt(e, t) {
  const {
    log: r,
    timeout: n,
    drawImageCount: a,
    drawImageInterval: s
  } = t;
  r.time("image to canvas");
  const i = await U(e, { timeout: n, onWarn: t.log.warn }), { canvas: o, context2d: c } = bt(e.ownerDocument, t), u = () => {
    try {
      c == null || c.drawImage(i, 0, 0, o.width, o.height);
    } catch (l) {
      t.log.warn("Failed to drawImage", l);
    }
  };
  if (u(), t.isEnable("fixSvgXmlDecode"))
    for (let l = 0; l < a; l++)
      await new Promise((p) => {
        setTimeout(() => {
          c == null || c.clearRect(0, 0, o.width, o.height), u(), p();
        }, l + s);
      });
  return t.drawImageCount = 0, r.timeEnd("image to canvas"), o;
}
function bt(e, t) {
  const { width: r, height: n, scale: a, backgroundColor: s, maximumCanvasSize: i } = t, o = e.createElement("canvas");
  o.width = Math.floor(r * a), o.height = Math.floor(n * a), o.style.width = `${r}px`, o.style.height = `${n}px`, i && (o.width > i || o.height > i) && (o.width > i && o.height > i ? o.width > o.height ? (o.height *= i / o.width, o.width = i) : (o.width *= i / o.height, o.height = i) : o.width > i ? (o.height *= i / o.width, o.width = i) : (o.width *= i / o.height, o.height = i));
  const c = o.getContext("2d");
  return c && s && (c.fillStyle = s, c.fillRect(0, 0, o.width, o.height)), { canvas: o, context2d: c };
}
function Ne(e, t) {
  if (e.ownerDocument)
    try {
      const s = e.toDataURL();
      if (s !== "data:,")
        return P(s, e.ownerDocument);
    } catch (s) {
      t.log.warn("Failed to clone canvas", s);
    }
  const r = e.cloneNode(!1), n = e.getContext("2d"), a = r.getContext("2d");
  try {
    return n && a && a.putImageData(
      n.getImageData(0, 0, e.width, e.height),
      0,
      0
    ), r;
  } catch (s) {
    t.log.warn("Failed to clone canvas", s);
  }
  return r;
}
function vt(e, t) {
  var r;
  try {
    if ((r = e == null ? void 0 : e.contentDocument) != null && r.documentElement)
      return ie(e.contentDocument.documentElement, t);
  } catch (n) {
    t.log.warn("Failed to clone iframe", n);
  }
  return e.cloneNode(!1);
}
function St(e) {
  const t = e.cloneNode(!1);
  return e.currentSrc && e.currentSrc !== e.src && (t.src = e.currentSrc, t.srcset = ""), t.loading === "lazy" && (t.loading = "eager"), t;
}
async function Et(e, t) {
  if (e.ownerDocument && !e.currentSrc && e.poster)
    return P(e.poster, e.ownerDocument);
  const r = e.cloneNode(!1);
  r.crossOrigin = "anonymous", e.currentSrc && e.currentSrc !== e.src && (r.src = e.currentSrc);
  const n = r.ownerDocument;
  if (n) {
    let a = !0;
    if (await U(r, { onError: () => a = !1, onWarn: t.log.warn }), !a)
      return e.poster ? P(e.poster, e.ownerDocument) : r;
    r.currentTime = e.currentTime, await new Promise((i) => {
      r.addEventListener("seeked", i, { once: !0 });
    });
    const s = n.createElement("canvas");
    s.width = e.offsetWidth, s.height = e.offsetHeight;
    try {
      const i = s.getContext("2d");
      i && i.drawImage(r, 0, 0, s.width, s.height);
    } catch (i) {
      return t.log.warn("Failed to clone video", i), e.poster ? P(e.poster, e.ownerDocument) : r;
    }
    return Ne(s, t);
  }
  return r;
}
function Ct(e, t) {
  return Ze(e) ? Ne(e, t) : st(e) ? vt(e, t) : F(e) ? St(e) : X(e) ? Et(e, t) : e.cloneNode(!1);
}
function kt(e) {
  let t = e.sandbox;
  if (!t) {
    const { ownerDocument: r } = e;
    try {
      r && (t = r.createElement("iframe"), t.id = `__SANDBOX__${Ce()}`, t.width = "0", t.height = "0", t.style.visibility = "hidden", t.style.position = "fixed", r.body.appendChild(t), t.srcdoc = '<!DOCTYPE html><meta charset="UTF-8"><title></title><body>', e.sandbox = t);
    } catch (n) {
      e.log.warn("Failed to getSandBox", n);
    }
  }
  return t;
}
const Tt = [
  "width",
  "height",
  "-webkit-text-fill-color"
], xt = [
  "stroke",
  "fill"
];
function Re(e, t, r) {
  const { defaultComputedStyles: n } = r, a = e.nodeName.toLowerCase(), s = O(e) && a !== "svg", i = s ? xt.map((f) => [f, e.getAttribute(f)]).filter(([, f]) => f !== null) : [], o = [
    s && "svg",
    a,
    i.map((f, w) => `${f}=${w}`).join(","),
    t
  ].filter(Boolean).join(":");
  if (n.has(o))
    return n.get(o);
  const c = kt(r), u = c == null ? void 0 : c.contentWindow;
  if (!u)
    return /* @__PURE__ */ new Map();
  const l = u == null ? void 0 : u.document;
  let p, g;
  s ? (p = l.createElementNS(K, "svg"), g = p.ownerDocument.createElementNS(p.namespaceURI, a), i.forEach(([f, w]) => {
    g.setAttributeNS(null, f, w);
  }), p.appendChild(g)) : p = g = l.createElement(a), g.textContent = " ", l.body.appendChild(p);
  const d = u.getComputedStyle(g, t), m = /* @__PURE__ */ new Map();
  for (let f = d.length, w = 0; w < f; w++) {
    const y = d.item(w);
    Tt.includes(y) || m.set(y, d.getPropertyValue(y));
  }
  return l.body.removeChild(p), n.set(o, m), m;
}
function Ie(e, t, r) {
  var o;
  const n = /* @__PURE__ */ new Map(), a = [], s = /* @__PURE__ */ new Map();
  if (r)
    for (const c of r)
      i(c);
  else
    for (let c = e.length, u = 0; u < c; u++) {
      const l = e.item(u);
      i(l);
    }
  for (let c = a.length, u = 0; u < c; u++)
    (o = s.get(a[u])) == null || o.forEach((l, p) => n.set(p, l));
  function i(c) {
    const u = e.getPropertyValue(c), l = e.getPropertyPriority(c), p = c.lastIndexOf("-"), g = p > -1 ? c.substring(0, p) : void 0;
    if (g) {
      let d = s.get(g);
      d || (d = /* @__PURE__ */ new Map(), s.set(g, d)), d.set(c, [u, l]);
    }
    t.get(c) === u && !l || (g ? a.push(g) : n.set(c, [u, l]));
  }
  return n;
}
function Nt(e, t, r, n) {
  var p, g, d, m;
  const { ownerWindow: a, includeStyleProperties: s, currentParentNodeStyle: i } = n, o = t.style, c = a.getComputedStyle(e), u = Re(e, null, n);
  i == null || i.forEach((f, w) => {
    u.delete(w);
  });
  const l = Ie(c, u, s);
  l.delete("transition-property"), l.delete("all"), l.delete("d"), l.delete("content"), r && (l.delete("position"), l.delete("margin-top"), l.delete("margin-right"), l.delete("margin-bottom"), l.delete("margin-left"), l.delete("margin-block-start"), l.delete("margin-block-end"), l.delete("margin-inline-start"), l.delete("margin-inline-end"), l.set("box-sizing", ["border-box", ""])), ((p = l.get("background-clip")) == null ? void 0 : p[0]) === "text" && t.classList.add("______background-clip--text"), ve && (l.has("font-kerning") || l.set("font-kerning", ["normal", ""]), (((g = l.get("overflow-x")) == null ? void 0 : g[0]) === "hidden" || ((d = l.get("overflow-y")) == null ? void 0 : d[0]) === "hidden") && ((m = l.get("text-overflow")) == null ? void 0 : m[0]) === "ellipsis" && e.scrollWidth === e.clientWidth && l.set("text-overflow", ["clip", ""]));
  for (let f = o.length, w = 0; w < f; w++)
    o.removeProperty(o.item(w));
  return l.forEach(([f, w], y) => {
    o.setProperty(y, f, w);
  }), l;
}
function Rt(e, t) {
  (et(e) || tt(e) || ot(e)) && t.setAttribute("value", e.value);
}
const It = [
  "::before",
  "::after"
  // '::placeholder', TODO
], _t = [
  "::-webkit-scrollbar",
  "::-webkit-scrollbar-button",
  // '::-webkit-scrollbar:horizontal', TODO
  "::-webkit-scrollbar-thumb",
  "::-webkit-scrollbar-track",
  "::-webkit-scrollbar-track-piece",
  // '::-webkit-scrollbar:vertical', TODO
  "::-webkit-scrollbar-corner",
  "::-webkit-resizer"
];
function At(e, t, r, n, a) {
  const { ownerWindow: s, svgStyleElement: i, svgStyles: o, currentNodeStyle: c } = n;
  if (!i || !s)
    return;
  function u(l) {
    var h;
    const p = s.getComputedStyle(e, l);
    let g = p.getPropertyValue("content");
    if (!g || g === "none")
      return;
    a == null || a(g), g = g.replace(/(')|(")|(counter\(.+\))/g, "");
    const d = [Ce()], m = Re(e, l, n);
    c == null || c.forEach((S, E) => {
      m.delete(E);
    });
    const f = Ie(p, m, n.includeStyleProperties);
    f.delete("content"), f.delete("-webkit-locale"), ((h = f.get("background-clip")) == null ? void 0 : h[0]) === "text" && t.classList.add("______background-clip--text");
    const w = [
      `content: '${g}';`
    ];
    if (f.forEach(([S, E], k) => {
      w.push(`${k}: ${S}${E ? " !important" : ""};`);
    }), w.length === 1)
      return;
    try {
      t.className = [t.className, ...d].join(" ");
    } catch (S) {
      n.log.warn("Failed to copyPseudoClass", S);
      return;
    }
    const y = w.join(`
  `);
    let b = o.get(y);
    b || (b = [], o.set(y, b)), b.push(`.${d[0]}${l}`);
  }
  It.forEach(u), r && _t.forEach(u);
}
const ce = /* @__PURE__ */ new Set([
  "symbol"
  // test/fixtures/svg.symbol.html
]);
async function ue(e, t, r, n, a) {
  if (R(r) && (rt(r) || nt(r)) || n.filter && !n.filter(r))
    return;
  ce.has(t.nodeName) || ce.has(r.nodeName) ? n.currentParentNodeStyle = void 0 : n.currentParentNodeStyle = n.currentNodeStyle;
  const s = await ie(r, n, !1, a);
  n.isEnable("restoreScrollPosition") && Lt(e, s), t.appendChild(s);
}
async function de(e, t, r, n) {
  var s;
  let a = e.firstChild;
  R(e) && e.shadowRoot && (a = (s = e.shadowRoot) == null ? void 0 : s.firstChild, r.shadowRoots.push(e.shadowRoot));
  for (let i = a; i; i = i.nextSibling)
    if (!Je(i))
      if (R(i) && at(i) && typeof i.assignedNodes == "function") {
        const o = i.assignedNodes();
        for (let c = 0; c < o.length; c++)
          await ue(e, t, o[c], r, n);
      } else
        await ue(e, t, i, r, n);
}
function Lt(e, t) {
  if (!B(e) || !B(t))
    return;
  const { scrollTop: r, scrollLeft: n } = e;
  if (!r && !n)
    return;
  const { transform: a } = t.style, s = new DOMMatrix(a), { a: i, b: o, c, d: u } = s;
  s.a = 1, s.b = 0, s.c = 0, s.d = 1, s.translateSelf(-n, -r), s.a = i, s.b = o, s.c = c, s.d = u, t.style.transform = s.toString();
}
function Mt(e, t) {
  const { backgroundColor: r, width: n, height: a, style: s } = t, i = e.style;
  if (r && i.setProperty("background-color", r, "important"), n && i.setProperty("width", `${n}px`, "important"), a && i.setProperty("height", `${a}px`, "important"), s)
    for (const o in s) i[o] = s[o];
}
const Pt = /^[\w-:]+$/;
async function ie(e, t, r = !1, n) {
  var u, l, p, g;
  const { ownerDocument: a, ownerWindow: s, fontFamilies: i, onCloneEachNode: o } = t;
  if (a && Qe(e))
    return n && /\S/.test(e.data) && n(e.data), a.createTextNode(e.data);
  if (a && s && R(e) && (B(e) || O(e))) {
    const d = await Ct(e, t);
    if (t.isEnable("removeAbnormalAttributes")) {
      const h = d.getAttributeNames();
      for (let S = h.length, E = 0; E < S; E++) {
        const k = h[E];
        Pt.test(k) || d.removeAttribute(k);
      }
    }
    const m = t.currentNodeStyle = Nt(e, d, r, t);
    r && Mt(d, t);
    let f = !1;
    if (t.isEnable("copyScrollbar")) {
      const h = [
        (u = m.get("overflow-x")) == null ? void 0 : u[0],
        (l = m.get("overflow-y")) == null ? void 0 : l[0]
      ];
      f = h.includes("scroll") || (h.includes("auto") || h.includes("overlay")) && (e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth);
    }
    const w = (p = m.get("text-transform")) == null ? void 0 : p[0], y = ke((g = m.get("font-family")) == null ? void 0 : g[0]), b = y ? (h) => {
      w === "uppercase" ? h = h.toUpperCase() : w === "lowercase" ? h = h.toLowerCase() : w === "capitalize" && (h = h[0].toUpperCase() + h.substring(1)), y.forEach((S) => {
        let E = i.get(S);
        E || i.set(S, E = /* @__PURE__ */ new Set()), h.split("").forEach((k) => E.add(k));
      });
    } : void 0;
    return At(
      e,
      d,
      f,
      t,
      b
    ), Rt(e, d), X(e) || await de(
      e,
      d,
      t,
      b
    ), await (o == null ? void 0 : o(d)), d;
  }
  const c = e.cloneNode(!1);
  return await de(e, c, t), await (o == null ? void 0 : o(c)), c;
}
function Dt(e) {
  if (e.ownerDocument = void 0, e.ownerWindow = void 0, e.svgStyleElement = void 0, e.svgDefsElement = void 0, e.svgStyles.clear(), e.defaultComputedStyles.clear(), e.sandbox) {
    try {
      e.sandbox.remove();
    } catch (t) {
      e.log.warn("Failed to destroyContext", t);
    }
    e.sandbox = void 0;
  }
  e.workers = [], e.fontFamilies.clear(), e.fontCssTexts.clear(), e.requests.clear(), e.tasks = [], e.shadowRoots = [];
}
function Ft(e) {
  const { url: t, timeout: r, responseType: n, ...a } = e, s = new AbortController(), i = r ? setTimeout(() => s.abort(), r) : void 0;
  return fetch(t, { signal: s.signal, ...a }).then((o) => {
    if (!o.ok)
      throw new Error("Failed fetch, not 2xx response", { cause: o });
    switch (n) {
      case "arrayBuffer":
        return o.arrayBuffer();
      case "dataUrl":
        return o.blob().then(ft);
      case "text":
      default:
        return o.text();
    }
  }).finally(() => clearTimeout(i));
}
function H(e, t) {
  const { url: r, requestType: n = "text", responseType: a = "text", imageDom: s } = t;
  let i = r;
  const {
    timeout: o,
    acceptOfImage: c,
    requests: u,
    fetchFn: l,
    fetch: {
      requestInit: p,
      bypassingCache: g,
      placeholderImage: d
    },
    font: m,
    workers: f,
    fontFamilies: w
  } = e;
  n === "image" && (V || se) && e.drawImageCount++;
  let y = u.get(r);
  if (!y) {
    g && g instanceof RegExp && g.test(i) && (i += (/\?/.test(i) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime());
    const b = n.startsWith("font") && m && m.minify, h = /* @__PURE__ */ new Set();
    b && n.split(";")[1].split(",").forEach((_) => {
      w.has(_) && w.get(_).forEach((z) => h.add(z));
    });
    const S = b && h.size, E = {
      url: i,
      timeout: o,
      responseType: S ? "arrayBuffer" : a,
      headers: n === "image" ? { accept: c } : void 0,
      ...p
    };
    y = {
      type: n,
      resolve: void 0,
      reject: void 0,
      response: null
    }, y.response = (async () => {
      if (l && n === "image") {
        const k = await l(r);
        if (k)
          return k;
      }
      return !V && r.startsWith("http") && f.length ? new Promise((k, _) => {
        f[u.size & f.length - 1].postMessage({ rawUrl: r, ...E }), y.resolve = k, y.reject = _;
      }) : Ft(E);
    })().catch((k) => {
      if (u.delete(r), n === "image" && d)
        return e.log.warn("Failed to fetch image base64, trying to use placeholder image", i), typeof d == "string" ? d : d(s);
      throw k;
    }), u.set(r, y);
  }
  return y.response;
}
async function _e(e, t, r, n) {
  if (!Ae(e))
    return e;
  for (const [a, s] of $t(e, t))
    try {
      const i = await H(
        r,
        {
          url: s,
          requestType: n ? "image" : "text",
          responseType: "dataUrl"
        }
      );
      e = e.replace(Bt(a), `$1${i}$3`);
    } catch (i) {
      r.log.warn("Failed to fetch css data url", a, i);
    }
  return e;
}
function Ae(e) {
  return /url\((['"]?)([^'"]+?)\1\)/.test(e);
}
const Le = /url\((['"]?)([^'"]+?)\1\)/g;
function $t(e, t) {
  const r = [];
  return e.replace(Le, (n, a, s) => (r.push([s, Ee(s, t)]), n)), r.filter(([n]) => !Z(n));
}
function Bt(e) {
  const t = e.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
  return new RegExp(`(url\\(['"]?)(${t})(['"]?\\))`, "g");
}
const Ut = [
  "background-image",
  "border-image-source",
  "-webkit-border-image",
  "-webkit-mask-image",
  "list-style-image"
];
function Ht(e, t) {
  return Ut.map((r) => {
    const n = e.getPropertyValue(r);
    return !n || n === "none" ? null : ((V || se) && t.drawImageCount++, _e(n, null, t, !0).then((a) => {
      !a || n === a || e.setProperty(
        r,
        a,
        e.getPropertyPriority(r)
      );
    }));
  }).filter(Boolean);
}
function Ot(e, t) {
  if (F(e)) {
    const r = e.currentSrc || e.src;
    if (!Z(r))
      return [
        H(t, {
          url: r,
          imageDom: e,
          requestType: "image",
          responseType: "dataUrl"
        }).then((n) => {
          n && (e.srcset = "", e.dataset.originalSrc = r, e.src = n || "");
        })
      ];
    (V || se) && t.drawImageCount++;
  } else if (O(e) && !Z(e.href.baseVal)) {
    const r = e.href.baseVal;
    return [
      H(t, {
        url: r,
        imageDom: e,
        requestType: "image",
        responseType: "dataUrl"
      }).then((n) => {
        n && (e.dataset.originalSrc = r, e.href.baseVal = n || "");
      })
    ];
  }
  return [];
}
function zt(e, t) {
  const { ownerDocument: r, svgDefsElement: n } = t, a = e.getAttribute("href") ?? e.getAttribute("xlink:href");
  if (!a)
    return [];
  const [s, i] = a.split("#");
  if (i) {
    const o = `#${i}`, c = t.shadowRoots.reduce(
      (u, l) => u ?? l.querySelector(`svg ${o}`),
      r == null ? void 0 : r.querySelector(`svg ${o}`)
    );
    if (s && e.setAttribute("href", o), n != null && n.querySelector(o))
      return [];
    if (c)
      return n == null || n.appendChild(c.cloneNode(!0)), [];
    if (s)
      return [
        H(t, {
          url: s,
          responseType: "text"
        }).then((u) => {
          n == null || n.insertAdjacentHTML("beforeend", u);
        })
      ];
  }
  return [];
}
function Me(e, t) {
  const { tasks: r } = t;
  R(e) && ((F(e) || Se(e)) && r.push(...Ot(e, t)), Ke(e) && r.push(...zt(e, t))), B(e) && r.push(...Ht(e.style, t)), e.childNodes.forEach((n) => {
    Me(n, t);
  });
}
async function jt(e, t) {
  const {
    ownerDocument: r,
    svgStyleElement: n,
    fontFamilies: a,
    fontCssTexts: s,
    tasks: i,
    font: o
  } = t;
  if (!(!r || !n || !a.size))
    if (o && o.cssText) {
      const c = me(o.cssText, t);
      n.appendChild(r.createTextNode(`${c}
`));
    } else {
      const c = Array.from(r.styleSheets).filter((d) => {
        try {
          return "cssRules" in d && !!d.cssRules.length;
        } catch (m) {
          return t.log.warn(`Error while reading CSS rules from ${d.href}`, m), !1;
        }
      }), u = r.implementation.createHTMLDocument(""), l = u.createElement("style");
      u.head.appendChild(l);
      const p = l.sheet;
      await Promise.all(
        c.flatMap((d) => Array.from(d.cssRules).map(async (m) => {
          if (Xe(m)) {
            const f = m.href;
            let w = "";
            try {
              w = await H(t, {
                url: f,
                requestType: "text",
                responseType: "text"
              });
            } catch (b) {
              t.log.warn(`Error fetch remote css import from ${f}`, b);
            }
            const y = w.replace(
              Le,
              (b, h, S) => b.replace(S, Ee(S, f))
            );
            for (const b of qt(y))
              try {
                p.insertRule(b, p.cssRules.length);
              } catch (h) {
                t.log.warn("Error inserting rule from remote css import", { rule: b, error: h });
              }
          }
        }))
      ), p.cssRules.length && c.push(p);
      const g = [];
      c.forEach((d) => {
        ee(d.cssRules, g);
      }), g.filter((d) => {
        var m;
        return Ge(d) && Ae(d.style.getPropertyValue("src")) && ((m = ke(d.style.getPropertyValue("font-family"))) == null ? void 0 : m.some((f) => a.has(f)));
      }).forEach((d) => {
        const m = d, f = s.get(m.cssText);
        f ? n.appendChild(r.createTextNode(`${f}
`)) : i.push(
          _e(
            m.cssText,
            m.parentStyleSheet ? m.parentStyleSheet.href : null,
            t
          ).then((w) => {
            w = me(w, t), s.set(m.cssText, w), n.appendChild(r.createTextNode(`${w}
`));
          })
        );
      });
    }
}
const Wt = /(\/\*[\s\S]*?\*\/)/g, fe = /((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;
function qt(e) {
  if (e == null)
    return [];
  const t = [];
  let r = e.replace(Wt, "");
  for (; ; ) {
    const s = fe.exec(r);
    if (!s)
      break;
    t.push(s[0]);
  }
  r = r.replace(fe, "");
  const n = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi, a = new RegExp(
    // eslint-disable-next-line
    "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})",
    "gi"
  );
  for (; ; ) {
    let s = n.exec(r);
    if (s)
      a.lastIndex = n.lastIndex;
    else if (s = a.exec(r), s)
      n.lastIndex = a.lastIndex;
    else
      break;
    t.push(s[0]);
  }
  return t;
}
const Vt = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g, Gt = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
function me(e, t) {
  const { font: r } = t, n = r ? r == null ? void 0 : r.preferredFormat : void 0;
  return n ? e.replace(Gt, (a) => {
    for (; ; ) {
      const [s, , i] = Vt.exec(a) || [];
      if (!i)
        return "";
      if (i === n)
        return `src: ${s};`;
    }
  }) : e;
}
function ee(e, t = []) {
  for (const r of Array.from(e))
    Ye(r) ? t.push(...ee(r.cssRules)) : "cssRules" in r ? ee(r.cssRules, t) : t.push(r);
  return t;
}
const Xt = /\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;
function Yt(e) {
  return Xt.test(e.innerHTML);
}
async function Kt(e, t) {
  const r = await Te(e, t);
  if (R(r.node) && O(r.node) && !Yt(r.node))
    return r.node;
  const {
    ownerDocument: n,
    log: a,
    tasks: s,
    svgStyleElement: i,
    svgDefsElement: o,
    svgStyles: c,
    font: u,
    progress: l,
    autoDestruct: p,
    onCloneNode: g,
    onEmbedNode: d,
    onCreateForeignObjectSvg: m
  } = r;
  a.time("clone node");
  const f = await ie(r.node, r, !0);
  if (i && n) {
    let S = "";
    c.forEach((E, k) => {
      S += `${E.join(`,
`)} {
  ${k}
}
`;
    }), i.appendChild(n.createTextNode(S));
  }
  a.timeEnd("clone node"), await (g == null ? void 0 : g(f)), u !== !1 && R(f) && (a.time("embed web font"), await jt(f, r), a.timeEnd("embed web font")), a.time("embed node"), Me(f, r);
  const w = s.length;
  let y = 0;
  const b = async () => {
    for (; ; ) {
      const S = s.pop();
      if (!S)
        break;
      try {
        await S;
      } catch (E) {
        r.log.warn("Failed to run task", E);
      }
      l == null || l(++y, w);
    }
  };
  l == null || l(y, w), await Promise.all([...Array.from({ length: 4 })].map(b)), a.timeEnd("embed node"), await (d == null ? void 0 : d(f));
  const h = Jt(f, r);
  return o && h.insertBefore(o, h.children[0]), i && h.insertBefore(i, h.children[0]), p && Dt(r), await (m == null ? void 0 : m(h)), h;
}
function Jt(e, t) {
  const { width: r, height: n } = t, a = ct(r, n, e.ownerDocument), s = a.ownerDocument.createElementNS(a.namespaceURI, "foreignObject");
  return s.setAttributeNS(null, "x", "0%"), s.setAttributeNS(null, "y", "0%"), s.setAttributeNS(null, "width", "100%"), s.setAttributeNS(null, "height", "100%"), s.append(e), a.appendChild(s), a;
}
async function Qt(e, t) {
  var i;
  const r = await Te(e, t), n = await Kt(r), a = ut(n, r.isEnable("removeControlCharacter"));
  r.autoDestruct || (r.svgStyleElement = xe(r.ownerDocument), r.svgDefsElement = (i = r.ownerDocument) == null ? void 0 : i.createElementNS(K, "defs"), r.svgStyles.clear());
  const s = P(a, n.ownerDocument);
  return await yt(s, r);
}
const Zt = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, er = /<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, tr = /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, rr = /<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, nr = /<embed\b[^>]*>/gi, or = /\son[a-z]+\s*=\s*(?:"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[^\s>"']+)/gi, ar = /\s(href|src|formaction)\s*=\s*(?:"\s*(?:(?:javascript|vbscript)\s*:[^"]*|data\s*:\s*text\/html[^"]*)"|'\s*(?:(?:javascript|vbscript)\s*:[^']*|data\s*:\s*text\/html[^']*)'|(?:javascript|vbscript)\s*:[^\s>]+|data\s*:\s*text\/html[^\s>]+)/gi;
function te(e) {
  return e.replace(Zt, "").replace(er, "").replace(tr, "").replace(rr, "").replace(nr, "").replace(or, "").replace(ar, "");
}
function ge(e) {
  return e.replace(/<br\s*\/?>/gi, `
`).replace(/<\/p>/gi, `

`).replace(/<\/h[1-6]>/gi, `

`).replace(/<\/li>/gi, `
`).replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\n{3,}/g, `

`).trim();
}
async function Pe(e, t) {
  var r, n;
  try {
    if (typeof ClipboardItem < "u" && ((r = navigator.clipboard) != null && r.write)) {
      const a = new Blob([e], { type: "text/html" }), s = new Blob([ge(e)], { type: "text/plain" }), i = new ClipboardItem({
        "text/html": a,
        "text/plain": s
      });
      return await navigator.clipboard.write([i]), { ok: !0, method: "clipboard-html" };
    }
  } catch (a) {
    console.warn("[typist] ClipboardItem.write failed:", a);
  }
  try {
    if ((n = navigator.clipboard) != null && n.writeText)
      return await navigator.clipboard.writeText(ge(e)), {
        ok: !0,
        method: "clipboard-text",
        warning: "当前环境不支持富文本剪贴板，已写入纯文本。请在公众号编辑器中先用纯文本模式粘贴，再用格式刷修复样式。"
      };
  } catch (a) {
    console.warn("[typist] clipboard.writeText failed:", a);
  }
  if (t)
    try {
      return { ok: !0, method: "image", dataUrl: (await Qt(t, {
        scale: 2,
        backgroundColor: "#ffffff"
      })).toDataURL("image/png") };
    } catch (a) {
      console.warn("[typist] domToCanvas failed:", a);
    }
  return {
    ok: !1,
    error: "所有复制方式均不可用：请检查浏览器权限或尝试保存为 HTML 文件。"
  };
}
function re({ size: e = 18 }) {
  return /* @__PURE__ */ T(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ v("path", { d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }),
        /* @__PURE__ */ v("polyline", { points: "14 2 14 8 20 8" }),
        /* @__PURE__ */ v("path", { d: "M9 13h6M9 17h4" }),
        /* @__PURE__ */ v("circle", { cx: "17", cy: "17", r: "2.5", fill: "currentColor", stroke: "none" })
      ]
    }
  );
}
function De({ size: e = 14 }) {
  return /* @__PURE__ */ T(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ v("rect", { x: "9", y: "9", width: "13", height: "13", rx: "2" }),
        /* @__PURE__ */ v("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })
      ]
    }
  );
}
function Fe({ size: e = 14 }) {
  return /* @__PURE__ */ T(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ v("path", { d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" }),
        /* @__PURE__ */ v("polyline", { points: "17 21 17 13 7 13 7 21" }),
        /* @__PURE__ */ v("polyline", { points: "7 3 7 8 15 8" })
      ]
    }
  );
}
function sr({ size: e = 14 }) {
  return /* @__PURE__ */ T(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      children: [
        /* @__PURE__ */ v("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
        /* @__PURE__ */ v("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
      ]
    }
  );
}
function ir(e) {
  const { activeNoteContent: t, activeNotePath: r, close: n, invokeBackend: a } = e, { t: s } = Ue(), [i, o] = q(e, "theme", we), [c] = q(e, "platform", ye), [u, l] = I(""), [p, g] = I(!1), [d, m] = I(!1), [f, w] = I(0), y = W(null), b = W(null), h = W(0);
  ne(() => {
    if (!t) {
      l("");
      return;
    }
    b.current && clearTimeout(b.current);
    const C = ++h.current;
    return b.current = setTimeout(() => {
      lr(
        t,
        i,
        c,
        a,
        (N, A) => {
          C === h.current && (l(N), w(A));
        },
        (N) => {
          C === h.current && g(N);
        }
      );
    }, 800), () => {
      b.current && clearTimeout(b.current);
    };
  }, [t, i, c, a]);
  const S = $(async () => {
    if (!(d || !u)) {
      m(!0);
      try {
        const C = te(u), N = await Pe(C, y.current);
        N.ok ? N.method === "clipboard-html" ? x.success("已复制到剪贴板（带样式）") : N.method === "clipboard-text" ? x.warning(N.warning) : (await dr(N.dataUrl, he(r)), x.success("已保存为 PNG，请拖入公众号编辑器")) : x.error(N.error);
      } catch (C) {
        x.error(`复制失败: ${String(C)}`);
      } finally {
        m(!1);
      }
    }
  }, [d, u, r]), E = $(async () => {
    if (u)
      try {
        const C = he(r), N = ur(u, i), A = await oe({
          defaultPath: `${C}.html`,
          filters: [{ name: "HTML", extensions: ["html"] }]
        });
        if (!A) return;
        const Be = A.replace(/\\/g, "/");
        await G("write_text_file", { path: Be, content: N }), x.success("已保存为 HTML");
      } catch (C) {
        x.error(`保存失败: ${String(C)}`);
      }
  }, [u, r, i]), k = j(() => cr(t), [t]), _ = j(() => {
    var C;
    return (((C = t.match(/```/g)) == null ? void 0 : C.length) ?? 0) / 2;
  }, [t]), z = j(() => {
    var C;
    return ((C = t.match(/!\[[^\]]*\]\([^)]+\)/g)) == null ? void 0 : C.length) ?? 0;
  }, [t]), $e = j(
    () => u ? te(u) : "",
    [u]
  );
  return /* @__PURE__ */ T(
    "div",
    {
      style: {
        width: "min(960px, 92vw)",
        maxHeight: "80vh",
        background: "var(--bg-primary)",
        border: "1px solid var(--border-color)",
        borderRadius: 8,
        boxShadow: "0 8px 32px rgba(0,0,0,0.18)",
        display: "flex",
        flexDirection: "column",
        fontSize: 12,
        color: "var(--text-primary)",
        overflow: "hidden"
      },
      children: [
        /* @__PURE__ */ T(
          "div",
          {
            style: {
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "8px 12px",
              borderBottom: "1px solid var(--border-color)",
              background: "var(--bg-secondary)"
            },
            children: [
              /* @__PURE__ */ v("span", { style: { fontSize: 12, fontWeight: 600 }, children: "排版" }),
              /* @__PURE__ */ v("span", { style: { color: "var(--text-muted)", fontSize: 11 }, children: "平台: 公众号" }),
              /* @__PURE__ */ T("label", { style: { display: "flex", alignItems: "center", gap: 4, fontSize: 11 }, children: [
                "主题",
                /* @__PURE__ */ v(
                  "select",
                  {
                    value: i,
                    onChange: (C) => o(C.target.value),
                    style: {
                      fontSize: 11,
                      padding: "2px 4px",
                      border: "1px solid var(--border-color)",
                      borderRadius: 4,
                      background: "var(--bg-primary)",
                      color: "var(--text-primary)"
                    },
                    children: We.map((C) => /* @__PURE__ */ v("option", { value: C.id, children: C.name }, C.id))
                  }
                )
              ] }),
              /* @__PURE__ */ v("span", { style: { flex: 1 } }),
              f > 0 && /* @__PURE__ */ T("span", { style: { color: "var(--text-muted)", fontSize: 10 }, children: [
                f,
                "ms"
              ] }),
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  onClick: S,
                  disabled: d || !u,
                  style: J,
                  children: [
                    /* @__PURE__ */ v(De, { size: 12 }),
                    "复制到公众号"
                  ]
                }
              ),
              /* @__PURE__ */ T("button", { type: "button", onClick: E, disabled: !u, style: J, children: [
                /* @__PURE__ */ v(Fe, { size: 12 }),
                "保存 HTML"
              ] }),
              /* @__PURE__ */ v("button", { type: "button", onClick: n, style: J, title: "关闭", children: /* @__PURE__ */ v(sr, { size: 12 }) })
            ]
          }
        ),
        /* @__PURE__ */ T(
          "div",
          {
            style: {
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 1,
              background: "var(--border-color)",
              minHeight: 320,
              flex: 1
            },
            children: [
              /* @__PURE__ */ v(
                "div",
                {
                  style: {
                    background: "var(--bg-primary)",
                    padding: 12,
                    overflow: "auto",
                    fontFamily: "SF Mono, Menlo, Monaco, Consolas, monospace",
                    fontSize: 12,
                    lineHeight: 1.6,
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word",
                    color: "var(--text-secondary)"
                  },
                  children: t || /* @__PURE__ */ v("span", { style: { color: "var(--text-muted)" }, children: "（当前笔记为空）" })
                }
              ),
              /* @__PURE__ */ v(
                "div",
                {
                  ref: y,
                  style: {
                    background: "#ffffff",
                    padding: "20px 24px",
                    overflow: "auto",
                    color: "#000",
                    fontSize: 14,
                    lineHeight: 1.75
                  },
                  children: p && !u ? /* @__PURE__ */ v("div", { style: { color: "#999" }, children: "渲染中…" }) : u ? /* @__PURE__ */ v("div", { dangerouslySetInnerHTML: { __html: $e } }) : /* @__PURE__ */ v("div", { style: { color: "#999" }, children: "预览将出现在这里" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ T(
          "div",
          {
            style: {
              display: "flex",
              gap: 16,
              padding: "6px 12px",
              borderTop: "1px solid var(--border-color)",
              background: "var(--bg-secondary)",
              fontSize: 10,
              color: "var(--text-muted)"
            },
            children: [
              /* @__PURE__ */ T("span", { children: [
                "字数: ",
                k.toLocaleString()
              ] }),
              /* @__PURE__ */ T("span", { children: [
                "代码块: ",
                _
              ] }),
              /* @__PURE__ */ T("span", { children: [
                "图片: ",
                z
              ] })
            ]
          }
        )
      ]
    }
  );
}
const J = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  fontSize: 11,
  padding: "4px 8px",
  border: "1px solid var(--border-color)",
  borderRadius: 4,
  background: "var(--bg-primary)",
  color: "var(--text-primary)",
  cursor: "pointer"
};
async function lr(e, t, r, n, a, s) {
  s(!0);
  const i = performance.now();
  try {
    const o = await n("markdown_to_themed_html", {
      markdown: e,
      theme: t,
      platform: r
    });
    a(o, Math.round(performance.now() - i));
  } catch (o) {
    console.error("[typist] render failed:", o), a(`<p style="color:#c00">渲染失败: ${String(o)}</p>`, 0);
  } finally {
    s(!1);
  }
}
function cr(e) {
  return e.replace(/\s+/g, "").length;
}
function he(e) {
  return e && (e.split("/").pop() || e).replace(/\.(md|markdown)$/i, "") || "untitled";
}
function ur(e, t) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${t} export</title>
<style>
body { font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
       max-width: 720px; margin: 40px auto; padding: 0 16px; color: #333; }
</style>
</head>
<body>
${e}
</body>
</html>`;
}
async function dr(e, t) {
  const r = await oe({
    defaultPath: `${t}.png`,
    filters: [{ name: "PNG Image", extensions: ["png"] }]
  });
  if (!r) return;
  const n = r.replace(/\\/g, "/"), a = e.replace(/^data:image\/png;base64,/, "");
  await G("write_binary_file", { path: n, data: a });
}
function fr(e) {
  const { size: t, activate: r, activeNoteContent: n, activeNotePath: a, invokeBackend: s, store: i } = e, [o, c] = I(!1), [u, l] = I(!1), p = W(null), g = {
    pluginId: e.pluginId,
    store: i
  }, [d] = q(g, "theme", we), [m] = q(g, "platform", ye);
  ne(() => {
    if (!o) return;
    const y = (b) => {
      p.current && !p.current.contains(b.target) && c(!1);
    };
    return document.addEventListener("mousedown", y), () => document.removeEventListener("mousedown", y);
  }, [o]);
  const f = $(async () => {
    if (c(!1), !(u || !n)) {
      l(!0);
      try {
        const y = await s("markdown_to_themed_html", {
          markdown: n,
          theme: d,
          platform: m
        }), b = te(y), h = await Pe(b, null);
        h.ok ? h.method === "clipboard-html" ? x.success("已复制到剪贴板（带样式）") : h.method === "clipboard-text" ? x.warning(h.warning) : x.error("请打开排版面板后再试「复制为图片」") : x.error("所有复制方式均不可用，请打开排版面板后再试或保存为 HTML");
      } catch (y) {
        x.error(`复制失败: ${String(y)}`);
      } finally {
        l(!1);
      }
    }
  }, [u, n, d, m, s]), w = $(async () => {
    if (c(!1), !(u || !n)) {
      l(!0);
      try {
        const y = await s("markdown_to_themed_html", {
          markdown: n,
          theme: d,
          platform: m
        }), b = (a.split("/").pop() || "untitled").replace(
          /\.(md|markdown)$/i,
          ""
        ), h = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${b}</title>
<style>body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;max-width:720px;margin:40px auto;padding:0 16px;color:#333;}</style>
</head>
<body>
${y}
</body>
</html>`, S = await oe({
          defaultPath: `${b}.html`,
          filters: [{ name: "HTML", extensions: ["html"] }]
        });
        if (!S) {
          l(!1);
          return;
        }
        const E = S.replace(/\\/g, "/");
        await G("write_text_file", { path: E, content: h }), x.success("已保存为 HTML");
      } catch (y) {
        x.error(`保存失败: ${String(y)}`);
      } finally {
        l(!1);
      }
    }
  }, [u, n, a, d, m, s]);
  return /* @__PURE__ */ T("div", { ref: p, className: "relative", children: [
    /* @__PURE__ */ v(
      "button",
      {
        type: "button",
        onClick: () => c(!o),
        className: "flex items-center justify-center w-6 h-6 rounded hover:bg-[var(--bg-hover)] cursor-pointer",
        style: {
          color: o ? "var(--theme-color)" : "var(--text-primary)"
        },
        title: "公众号排版",
        children: /* @__PURE__ */ v(re, { size: t })
      }
    ),
    o && /* @__PURE__ */ T(
      "div",
      {
        className: "absolute right-0 top-full mt-1 z-50 rounded-lg py-1 min-w-[160px]",
        style: {
          background: "var(--bg-secondary)",
          border: "1px solid var(--border-color)",
          boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
        },
        children: [
          /* @__PURE__ */ v(
            Q,
            {
              icon: /* @__PURE__ */ v(re, { size: 12 }),
              label: "打开排版面板",
              onClick: () => {
                c(!1), r();
              }
            }
          ),
          /* @__PURE__ */ v(
            Q,
            {
              icon: /* @__PURE__ */ v(De, { size: 12 }),
              label: "复制到公众号",
              onClick: f,
              disabled: u || !n
            }
          ),
          /* @__PURE__ */ v(
            Q,
            {
              icon: /* @__PURE__ */ v(Fe, { size: 12 }),
              label: "保存为 HTML",
              onClick: w,
              disabled: u || !n
            }
          )
        ]
      }
    )
  ] });
}
function Q(e) {
  return /* @__PURE__ */ T(
    "button",
    {
      type: "button",
      onClick: e.onClick,
      disabled: e.disabled,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        width: "100%",
        padding: "5px 12px",
        fontSize: 11,
        textAlign: "left",
        background: "transparent",
        border: "none",
        color: "var(--text-primary)",
        cursor: e.disabled ? "not-allowed" : "pointer",
        opacity: e.disabled ? 0.5 : 1
      },
      onMouseEnter: (t) => {
        e.disabled || (t.currentTarget.style.background = "var(--bg-hover)");
      },
      onMouseLeave: (t) => {
        t.currentTarget.style.background = "transparent";
      },
      children: [
        e.icon,
        e.label
      ]
    }
  );
}
const yr = {
  id: "com.swallownote.typist",
  name: "公众号排版",
  description: "将 Markdown 文档按微信公众号等平台主题排版，一键复制带样式的富文本",
  version: "0.1.0",
  author: "SwallowNote",
  publishedAt: "2026-06-14",
  iconPosition: "editorToolbar",
  contentPosition: "rightPanel",
  order: 40,
  enabled: !0,
  // Note: `hasBackend` is read from `manifest.json` on disk by the host;
  // it is intentionally not part of the SDK's PluginManifest type, so
  // we omit it from the in-memory manifest. See `manifest.json`.
  icon: re,
  // The host renders this inside the editorArea floating container
  // when the user activates the plugin via the toolbar dropdown.
  panel: ir,
  toolbarButton: fr,
  permissions: ["storage", "events", "backend", "clipboard"]
};
export {
  yr as default,
  wr as setHost
};
