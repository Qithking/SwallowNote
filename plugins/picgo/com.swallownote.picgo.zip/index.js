// @swallow-manifest {"id":"com.swallownote.picgo","name":"图床","description":"将本地/剪贴板图片一键上传到云端图床（SM.MS / Imgur / GitHub / 自定义端点），并插入到当前笔记。","version":"0.1.2","author":"SwallowNote","published_at":"2026-10-20T13:16:46Z","icon_position":"titleBar","content_position":"rightPanel","order":50,"enabled":true,"has_backend":false}
import { useState as M, useRef as Z, useEffect as A, useCallback as U, useMemo as oe } from "react";
import { jsxs as f, jsx as a, Fragment as q } from "react/jsx-runtime";
import { toast as I } from "sonner";
class ce {
  constructor() {
    this.target = new EventTarget(), this.wrapperMap = /* @__PURE__ */ new Map();
  }
  on(t, r) {
    const o = (s) => r(s.detail);
    this.target.addEventListener(t, o);
    let n = this.wrapperMap.get(r);
    return n || (n = /* @__PURE__ */ new Map(), this.wrapperMap.set(r, n)), n.set(t, o), () => {
      this.target.removeEventListener(t, o), n.delete(t), n.size === 0 && this.wrapperMap.delete(r);
    };
  }
  off(t, r) {
    const o = this.wrapperMap.get(r), n = o == null ? void 0 : o.get(t);
    n && (this.target.removeEventListener(t, n), o.delete(t), o.size === 0 && this.wrapperMap.delete(r));
  }
  removeAllListenersForPlugin(t) {
  }
  emit(t, r) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: r }));
  }
}
const K = new ce();
K.emit.bind(K);
const F = [];
let le = 0;
function de() {
  const e = F[F.length - 1];
  return e ? e.overrides : ue;
}
const ue = Object.freeze({});
function Rt(e) {
  const t = le++, r = { ...de(), ...e };
  return F.push({ overrides: r, token: t }), () => {
    for (let o = F.length - 1; o >= 0; o--)
      if (F[o].token === t) {
        F.splice(o, 1);
        return;
      }
  };
}
const me = "com.swallownote.picgo", pe = "图床", fe = "将本地/剪贴板图片一键上传到云端图床（SM.MS / Imgur / GitHub / 自定义端点），并插入到当前笔记。", he = "0.1.2", be = 1, ge = "SwallowNote", ye = "2026-10-20T13:16:46Z", ve = "titleBar", xe = "rightPanel", we = 50, Ne = !0, ke = !1, Te = "src/index.tsx", Ee = [
  "network",
  "clipboard",
  "storage",
  "events"
], $e = {
  id: me,
  name: pe,
  description: fe,
  version: he,
  manifestVersion: be,
  author: ge,
  publishedAt: ye,
  iconPosition: ve,
  contentPosition: xe,
  order: we,
  enabled: Ne,
  hasBackend: ke,
  entry: Te,
  permissions: Ee
};
function ne({ size: e = 18 }) {
  return /* @__PURE__ */ f(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      children: [
        /* @__PURE__ */ a("path", { d: "M17.5 19a4.5 4.5 0 1 0-1.41-8.775 6 6 0 0 0-11.59 1.95A4.5 4.5 0 0 0 6 19h11.5z" }),
        /* @__PURE__ */ a("path", { d: "M12 12v9" }),
        /* @__PURE__ */ a("path", { d: "m9 15 3-3 3 3" })
      ]
    }
  );
}
const k = {
  defaultProvider: "smms",
  uploadFormat: "original",
  maxFileSizeMB: 10,
  filenameStrategy: "original",
  linkFormat: "markdown",
  enableHistory: !0,
  historyRetention: 200,
  smmsToken: "",
  imgurClientId: "",
  githubToken: "",
  githubOwner: "",
  githubRepo: "",
  githubBranch: "main",
  githubPathPrefix: "images/",
  customEndpoint: "",
  customMethod: "POST",
  customHeaders: "",
  customBodyTemplate: "",
  customResponseUrlPath: "data.url"
};
function S(e, t) {
  return typeof e == "string" ? e : t;
}
function Q(e, t) {
  if (typeof e == "number" && Number.isFinite(e)) return e;
  if (typeof e == "string" && e.trim() !== "") {
    const r = Number(e);
    if (Number.isFinite(r)) return r;
  }
  return t;
}
function Se(e, t) {
  return typeof e == "boolean" ? e : t;
}
function Ce(e, t) {
  const r = S(e, t);
  return r === "smms" || r === "imgur" || r === "github" || r === "custom" ? r : t;
}
function Ue(e, t) {
  const r = S(e, t);
  return r === "original" || r === "webp" || r === "jpg" || r === "png" ? r : t;
}
function Ie(e, t) {
  const r = S(e, t);
  return r === "original" || r === "uuid" || r === "timestamp" ? r : t;
}
function Me(e, t) {
  const r = S(e, t);
  return r === "markdown" || r === "html" || r === "url" ? r : t;
}
function Pe(e, t) {
  const r = String(e ?? t).toUpperCase();
  return r === "POST" || r === "PUT" ? r : t;
}
function L(e) {
  const t = e ?? {};
  return {
    defaultProvider: Ce(t.defaultProvider, k.defaultProvider),
    uploadFormat: Ue(t.uploadFormat, k.uploadFormat),
    maxFileSizeMB: Q(t.maxFileSizeMB, k.maxFileSizeMB),
    filenameStrategy: Ie(
      t.filenameStrategy,
      k.filenameStrategy
    ),
    linkFormat: Me(t.linkFormat, k.linkFormat),
    enableHistory: Se(t.enableHistory, k.enableHistory),
    historyRetention: Q(t.historyRetention, k.historyRetention),
    smmsToken: S(t.smmsToken, k.smmsToken),
    imgurClientId: S(t.imgurClientId, k.imgurClientId),
    githubToken: S(t.githubToken, k.githubToken),
    githubOwner: S(t.githubOwner, k.githubOwner),
    githubRepo: S(t.githubRepo, k.githubRepo),
    githubBranch: S(t.githubBranch, k.githubBranch),
    githubPathPrefix: S(
      t.githubPathPrefix,
      k.githubPathPrefix
    ),
    customEndpoint: S(t.customEndpoint, k.customEndpoint),
    customMethod: Pe(t.customMethod, k.customMethod),
    customHeaders: S(t.customHeaders, k.customHeaders),
    customBodyTemplate: S(
      t.customBodyTemplate,
      k.customBodyTemplate
    ),
    customResponseUrlPath: S(
      t.customResponseUrlPath,
      k.customResponseUrlPath
    )
  };
}
function V(e, t) {
  switch (e) {
    case "smms":
      return !0;
    case "imgur":
      return t.imgurClientId.trim().length > 0;
    case "github":
      return t.githubToken.trim().length > 0 && t.githubOwner.trim().length > 0 && t.githubRepo.trim().length > 0;
    case "custom":
      return t.customEndpoint.trim().length > 0 && t.customBodyTemplate.trim().length > 0;
    default:
      return !1;
  }
}
async function Re(e, t = {}, r) {
  return window.__TAURI_INTERNALS__.invoke(e, t, r);
}
async function Be(e = {}) {
  return typeof e == "object" && Object.freeze(e), await Re("plugin:dialog|open", { options: e });
}
const ae = {
  webp: "image/webp",
  jpg: "image/jpeg",
  png: "image/png"
}, Oe = {
  webp: "webp",
  jpg: "jpg",
  png: "png"
}, je = {
  webp: 0.92,
  jpg: 0.85
};
class H extends Error {
  constructor() {
    super(...arguments), this.name = "ImageValidationError";
  }
}
function Fe(e, t) {
  const r = e.lastIndexOf(".");
  return `${r >= 0 ? e.slice(0, r) : e}.${t}`;
}
function Le(e) {
  return !!e.type && e.type.startsWith("image/");
}
function ze(e) {
  return new Promise((t, r) => {
    const o = URL.createObjectURL(e), n = new Image();
    n.onload = () => {
      setTimeout(() => URL.revokeObjectURL(o), 0), t(n);
    }, n.onerror = () => {
      URL.revokeObjectURL(o), r(new Error("图片解码失败"));
    }, n.src = o;
  });
}
async function Ae(e, t, r) {
  return new Promise((o, n) => {
    e.toBlob(
      (s) => {
        if (!s) {
          n(new Error(`canvas 转码失败 (${t})`));
          return;
        }
        o(s);
      },
      t,
      r
    );
  });
}
async function He(e, t) {
  const r = await ze(e), o = document.createElement("canvas");
  o.width = r.naturalWidth, o.height = r.naturalHeight;
  const n = o.getContext("2d");
  if (!n)
    throw new H("浏览器不支持 canvas 2d，无法转码");
  n.drawImage(r, 0, 0);
  const s = ae[t], d = t === "png" ? void 0 : je[t];
  return Ae(o, s, d);
}
async function De(e) {
  const { file: t, filename: r, uploadFormat: o, maxFileSizeMB: n } = e;
  if (!Le(t))
    throw new H("仅支持图片文件");
  const s = Math.max(1, n) * 1024 * 1024;
  if (t.size > s)
    throw new H(
      `文件大小 ${(t.size / 1024 / 1024).toFixed(2)} MB 超过限制 ${n} MB`
    );
  if (o === "original")
    return { file: t, filename: r, mime: t.type };
  const d = ae[o];
  return t.type === d ? { file: t, filename: r, mime: d } : {
    file: await He(t, o),
    filename: Fe(r, Oe[o]),
    mime: d
  };
}
function _e(e) {
  const t = e.lastIndexOf(".");
  return t >= 0 ? e.slice(t + 1).toLowerCase() : "";
}
function X() {
  const e = /* @__PURE__ */ new Date(), t = (r) => String(r).padStart(2, "0");
  return `${e.getUTCFullYear()}-${t(e.getUTCMonth() + 1)}-${t(e.getUTCDate())}T${t(e.getUTCHours())}${t(e.getUTCMinutes())}${t(e.getUTCSeconds())}Z`;
}
function ee() {
  return typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e) => {
    const t = Math.random() * 16 | 0;
    return (e === "x" ? t : t & 3 | 8).toString(16);
  });
}
function Ge(e, t) {
  e || (e = `image-${Date.now()}.png`);
  const r = _e(e), o = r ? e.slice(0, -(r.length + 1)) : e;
  switch (t) {
    case "original":
      return e;
    case "uuid":
      return r ? `${ee()}.${r}` : ee();
    case "timestamp":
      return r ? `${X()}-${o}.${r}` : `${X()}-${o}`;
    default:
      return e;
  }
}
const D = "picgo-history";
async function J(e) {
  try {
    const t = await e.get(D);
    return Array.isArray(t) ? t.filter(
      (r) => r && typeof r == "object" && typeof r.url == "string"
    ) : [];
  } catch (t) {
    return console.warn("[picgo] loadHistory failed:", t), [];
  }
}
function se(e, t) {
  const r = Math.max(1, Math.floor(t));
  return e.length <= r ? e : e.slice(e.length - r);
}
async function We(e, t, r) {
  const o = await J(e), n = se([...o, t], r);
  return await e.set(D, n), n;
}
async function Ve(e, t, r) {
  const o = await J(e), n = se(
    o.filter((s) => s.url !== t),
    r
  );
  return await e.set(D, n), n;
}
async function Je(e) {
  await e.set(D, []);
}
const Ye = "https://sm.ms/api/v2/upload", Ze = {
  id: "smms",
  displayName: "SM.MS",
  async upload(e, t, r, o, n) {
    var v, l;
    const s = new FormData();
    s.append("smfile", e, t);
    const d = {}, u = (v = r.smmsToken) == null ? void 0 : v.trim();
    u && (d.Authorization = u);
    let y;
    try {
      y = await fetch(Ye, {
        method: "POST",
        body: s,
        headers: d,
        signal: o
      });
    } catch (x) {
      throw (x == null ? void 0 : x.name) === "AbortError" ? x : new Error(`SM.MS: 网络错误：${x.message || "fetch 失败"}`);
    }
    let p;
    try {
      p = await y.json();
    } catch (x) {
      throw new Error(`SM.MS: 响应解析失败：${x.message}`);
    }
    if (y.status === 401 || y.status === 403)
      throw new Error("SM.MS: 鉴权失败，请检查 Token 设置");
    if (!y.ok)
      throw new Error(`SM.MS: HTTP ${y.status}${p.message ? ` ${p.message}` : ""}`);
    if (!p.success) {
      const x = p.code || "unknown_error", h = p.message || x;
      throw new Error(`SM.MS: ${h}`);
    }
    const g = (l = p.data) == null ? void 0 : l.url;
    if (!g)
      throw new Error("SM.MS: 响应中未包含 data.url");
    return n == null || n({ loaded: e.size, total: e.size, percent: 100 }), {
      url: g,
      provider: "smms",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
}, qe = "https://api.imgur.com/3/image";
async function Ke(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), n = 32768;
  for (let s = 0; s < o.length; s += n)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(s, s + n))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
const Qe = {
  id: "imgur",
  displayName: "Imgur",
  async upload(e, t, r, o, n) {
    var g, v;
    if (!r.imgurClientId)
      throw new Error("Imgur: 缺少 Client-ID");
    const s = await Ke(e), d = JSON.stringify({
      image: s,
      name: t,
      type: e.type || "image/*"
    });
    let u;
    try {
      u = await fetch(qe, {
        method: "POST",
        headers: {
          Authorization: `Client-ID ${r.imgurClientId}`,
          "Content-Type": "application/json"
        },
        body: d,
        signal: o
      });
    } catch (l) {
      throw (l == null ? void 0 : l.name) === "AbortError" ? l : new Error(`Imgur: 网络错误：${l.message || "fetch 失败"}`);
    }
    let y;
    try {
      y = await u.json();
    } catch (l) {
      throw new Error(`Imgur: 响应解析失败：${l.message}`);
    }
    if (u.status === 401 || u.status === 403)
      throw new Error("Imgur: 鉴权失败，请检查 Client-ID");
    if (!u.ok || !y.success) {
      const l = ((g = y.data) == null ? void 0 : g.error) || `HTTP ${u.status}`;
      throw new Error(`Imgur: ${l}`);
    }
    const p = (v = y.data) == null ? void 0 : v.link;
    if (!p)
      throw new Error("Imgur: 响应中未包含 data.link");
    return n == null || n({ loaded: e.size, total: e.size, percent: 100 }), {
      url: p,
      provider: "imgur",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
};
async function Xe(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), n = 32768;
  for (let s = 0; s < o.length; s += n)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(s, s + n))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
function et(e) {
  return e.replace(/^\/+|\/+$/g, "");
}
function tt(e, t) {
  const r = et(e || "");
  return r ? `${r}/${t}` : t;
}
const rt = {
  id: "github",
  displayName: "GitHub",
  async upload(e, t, r, o, n) {
    var x, h, T;
    if (!r.githubToken)
      throw new Error("GitHub: 缺少 Personal Access Token");
    if (!r.githubOwner || !r.githubRepo)
      throw new Error("GitHub: 缺少 Owner / Repo");
    const s = ((x = r.githubBranch) == null ? void 0 : x.trim()) || "main", d = tt(r.githubPathPrefix || "", t), u = `https://api.github.com/repos/${encodeURIComponent(
      r.githubOwner
    )}/${encodeURIComponent(
      r.githubRepo
    )}/contents/${d.split("/").map(encodeURIComponent).join("/")}`, y = await Xe(e), p = JSON.stringify({
      message: `upload ${t} via SwallowNote PicGo plugin`,
      content: y,
      branch: s
    });
    let g;
    try {
      g = await fetch(u, {
        method: "PUT",
        headers: {
          Authorization: `token ${r.githubToken}`,
          "Content-Type": "application/json",
          Accept: "application/vnd.github+json"
        },
        body: p,
        signal: o
      });
    } catch (w) {
      throw (w == null ? void 0 : w.name) === "AbortError" ? w : new Error(`GitHub: 网络错误：${w.message || "fetch 失败"}`);
    }
    if (g.status === 401 || g.status === 403)
      throw new Error("GitHub: 鉴权失败，请检查 Token 权限（需要 repo）");
    let v;
    try {
      v = await g.json();
    } catch (w) {
      throw new Error(`GitHub: 响应解析失败：${w.message}`);
    }
    if (!g.ok) {
      const w = v.message || v.errors && ((h = v.errors[0]) == null ? void 0 : h.message) || `HTTP ${g.status}`;
      throw new Error(`GitHub: ${w}`);
    }
    const l = (T = v.content) == null ? void 0 : T.download_url;
    if (!l)
      throw new Error("GitHub: 响应中未包含 content.download_url");
    return n == null || n({ loaded: e.size, total: e.size, percent: 100 }), {
      url: l,
      provider: "github",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
};
async function ot(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), n = 32768;
  for (let s = 0; s < o.length; s += n)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(s, s + n))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
function nt(e) {
  const t = {};
  if (!e) return t;
  for (const r of e.split(/\r?\n/)) {
    const o = r.trim();
    if (!o) continue;
    const n = o.indexOf(":");
    if (n < 0) continue;
    const s = o.slice(0, n).trim(), d = o.slice(n + 1).trim();
    s && (t[s] = d);
  }
  return t;
}
function at(e, t) {
  if (!t) return e;
  const r = t.split(".").map((n) => n.trim()).filter(Boolean);
  let o = e;
  for (const n of r)
    if (o && typeof o == "object" && n in o)
      o = o[n];
    else
      return;
  return o;
}
function st(e) {
  return /\{base64\}/.test(e);
}
const it = {
  id: "custom",
  displayName: "Custom",
  async upload(e, t, r, o, n) {
    var w, j;
    const s = (w = r.customEndpoint) == null ? void 0 : w.trim();
    if (!s)
      throw new Error("Custom: 缺少端点 URL (customEndpoint)");
    const d = (r.customMethod || "POST").toUpperCase(), u = r.customBodyTemplate;
    if (!u)
      throw new Error("Custom: 缺少请求体模板 (customBodyTemplate)");
    const y = ((j = r.customResponseUrlPath) == null ? void 0 : j.trim()) || "", p = await ot(e), g = u.replace(/\{filename\}/g, t).replace(/\{base64\}/g, p).replace(/\{mime\}/g, e.type || "application/octet-stream").replace(/\{size\}/g, String(e.size)), v = nt(r.customHeaders);
    !v["Content-Type"] && !v["content-type"] && st(u) && (v["Content-Type"] = "application/json");
    let l;
    try {
      l = await fetch(s, {
        method: d,
        headers: v,
        body: g,
        signal: o
      });
    } catch (c) {
      throw (c == null ? void 0 : c.name) === "AbortError" ? c : new Error(`Custom: 网络错误：${c.message || "fetch 失败"}`);
    }
    if (l.status === 401 || l.status === 403)
      throw new Error("Custom: 鉴权失败，请检查请求头配置");
    let x;
    try {
      x = await l.text();
    } catch (c) {
      throw new Error(`Custom: 响应读取失败：${c.message}`);
    }
    let h = x;
    try {
      h = JSON.parse(x);
    } catch {
    }
    if (!l.ok) {
      const c = typeof h == "string" ? h.slice(0, 200) : `HTTP ${l.status}`;
      throw new Error(`Custom: ${c}`);
    }
    let T;
    if (y ? T = at(h, y) : typeof h == "string" && (T = h), typeof T != "string" || !T)
      throw new Error(
        `Custom: 响应中未找到 URL（路径：${y || "(none)"}）`
      );
    return n == null || n({ loaded: e.size, total: e.size, percent: 100 }), {
      url: T,
      provider: "custom",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
}, Y = {
  smms: Ze,
  imgur: Qe,
  github: rt,
  custom: it
};
function O(e) {
  var t;
  return ((t = Y[e]) == null ? void 0 : t.displayName) ?? e;
}
function ct(e) {
  const t = Y[e];
  if (!t)
    throw new Error(`PicGo: 未知的图床类型 "${e}"`);
  return t;
}
const lt = 3e4;
class dt extends Error {
  constructor(t) {
    super(`${t}: 上传已取消`), this.provider = t, this.name = "UploadCancelledError";
  }
}
async function ut(e) {
  try {
    const t = await e();
    return L(t);
  } catch (t) {
    return console.warn("[picgo] fetchSettings failed, using defaults:", t), L({});
  }
}
function mt(e, t) {
  const r = new AbortController(), o = setTimeout(
    () => r.abort(new Error("timeout")),
    t
  ), n = () => r.abort(e == null ? void 0 : e.reason);
  e && (e.aborted ? n() : e.addEventListener("abort", n, { once: !0 }));
  const s = () => {
    clearTimeout(o), e && e.removeEventListener("abort", n);
  };
  return { signal: r.signal, dispose: s };
}
function pt(e) {
  if (!e || typeof e != "object") return !1;
  const t = e.name;
  return t === "AbortError" || t === "UploadCancelledError";
}
async function ft(e, t) {
  const r = e.settings ?? await ut(t.getAllSettings), o = e.providerId ?? r.defaultProvider, n = ct(o), s = O(o), d = await De({
    file: e.file,
    filename: e.filename,
    uploadFormat: r.uploadFormat,
    maxFileSizeMB: r.maxFileSizeMB
  }).catch((l) => {
    throw l instanceof H ? new Error(`PicGo: ${l.message}`) : new Error(`PicGo: 预处理失败：${l.message}`);
  }), u = Ge(d.filename, r.filenameStrategy), y = e.timeoutMs ?? lt, { signal: p, dispose: g } = mt(e.signal, y);
  let v;
  try {
    v = await n.upload(
      d.file,
      u,
      r,
      p,
      e.onProgress
    );
  } catch (l) {
    throw pt(l) ? new dt(s) : l instanceof Error ? l.message.startsWith(s) ? l : new Error(`${s}: ${l.message}`) : new Error(`${s}: ${String(l)}`);
  } finally {
    g();
  }
  if (r.enableHistory && t.store)
    try {
      await We(t.store, v, r.historyRetention);
    } catch (l) {
      console.warn("[picgo] appendHistory failed:", l);
    }
  return v;
}
async function ht() {
  if (typeof navigator > "u" || !navigator.clipboard || typeof navigator.clipboard.read != "function")
    return null;
  try {
    const e = await navigator.clipboard.read();
    for (const t of e) {
      const r = t.types.find((n) => n.startsWith("image/"));
      if (!r) continue;
      const o = await t.getType(r);
      if (o) return o;
    }
    return null;
  } catch (e) {
    return console.warn("[picgo] readClipboardImage failed:", e), null;
  }
}
function bt(e) {
  const t = e.includes("png") ? "png" : e.includes("jpeg") || e.includes("jpg") ? "jpg" : e.includes("webp") ? "webp" : e.includes("gif") ? "gif" : "png";
  return `clipboard-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").replace(/-\d{3}Z$/, "Z")}.${t}`;
}
function gt({
  result: e,
  compact: t,
  onInsert: r
}) {
  const [o, n] = M(!1), s = async () => {
    try {
      await navigator.clipboard.writeText(e.url), n(!0), setTimeout(() => n(!1), 1500);
    } catch (d) {
      console.warn("[picgo] copy failed:", d);
    }
  };
  return /* @__PURE__ */ f(
    "div",
    {
      className: `rounded border border-[var(--border-color)] bg-[var(--bg-primary)] ${t ? "p-1.5" : "p-2"}`,
      children: [
        /* @__PURE__ */ f("div", { className: "flex gap-2 items-start", children: [
          /* @__PURE__ */ a(
            "img",
            {
              src: e.url,
              alt: e.filename,
              className: `${t ? "w-8 h-8" : "w-14 h-14"} object-cover rounded border border-[var(--border-color)]`,
              loading: "lazy",
              onError: (d) => {
                d.currentTarget.style.visibility = "hidden";
              }
            }
          ),
          /* @__PURE__ */ f("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ a("div", { className: "text-xs font-medium truncate", title: e.filename, children: e.filename }),
            /* @__PURE__ */ a(
              "a",
              {
                href: e.url,
                target: "_blank",
                rel: "noreferrer",
                className: "text-xs text-[var(--text-secondary)] truncate block hover:underline",
                title: e.url,
                children: e.url
              }
            ),
            /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)] mt-0.5", children: O(e.provider) })
          ] })
        ] }),
        /* @__PURE__ */ f("div", { className: "flex gap-1 mt-1.5", children: [
          /* @__PURE__ */ a(
            "button",
            {
              type: "button",
              onClick: s,
              className: "text-xs rounded border border-[var(--border-color)] px-2 py-0.5 hover:bg-[var(--bg-hover)]",
              children: o ? "已复制" : "复制 URL"
            }
          ),
          r && /* @__PURE__ */ a(
            "button",
            {
              type: "button",
              onClick: r,
              className: "text-xs rounded border border-[var(--border-color)] px-2 py-0.5 hover:bg-[var(--bg-hover)]",
              children: "插入到笔记"
            }
          )
        ] })
      ]
    }
  );
}
function yt(e, t) {
  const r = (e.filename || "image").replace(/[[\]]/g, "");
  switch (t) {
    case "markdown":
      return `![${r}](${e.url})`;
    case "html":
      return `<img src="${e.url}" alt="${r}" />`;
    case "url":
      return e.url;
    default:
      return e.url;
  }
}
function W(e, t, r) {
  const o = yt(e, t), n = typeof r == "string" ? r : "", s = n.length === 0 ? "" : n.endsWith(`
`) ? `
` : `

`;
  return {
    text: o,
    nextContent: `${n}${s}${o}
`,
    cursorInserted: !1
  };
}
function te() {
  return typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `f-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function vt(e) {
  return e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1024 / 1024).toFixed(2)} MB`;
}
function xt({
  getAllSettings: e,
  store: t,
  activeNoteContent: r,
  activeProvider: o,
  onProviderChange: n,
  refreshTick: s
}) {
  const [d, u] = M([]), [y, p] = M(!1), [g, v] = M(null), l = Z(null), x = Z(/* @__PURE__ */ new Map());
  A(() => {
    let i = !1;
    return e().then((m) => {
      i || v(L(m));
    }), () => {
      i = !0;
    };
  }, [e, s]), A(() => {
    const i = d.map((m) => m.previewUrl);
    return () => {
      for (const m of i) URL.revokeObjectURL(m);
    };
  }, [d]);
  const h = U((i) => {
    i.length !== 0 && u((m) => {
      const N = [...m];
      for (const b of i) {
        if (!b.type.startsWith("image/")) {
          I.error(`仅支持图片文件：${b.name}`);
          continue;
        }
        N.push({
          id: te(),
          file: b,
          filename: b.name,
          size: b.size,
          previewUrl: URL.createObjectURL(b),
          status: "idle",
          progress: 0
        });
      }
      return N;
    });
  }, []), T = U(
    (i) => {
      i.preventDefault(), p(!1);
      const m = [];
      if (i.dataTransfer.files)
        for (let N = 0; N < i.dataTransfer.files.length; N++) {
          const b = i.dataTransfer.files[N];
          b && m.push(b);
        }
      h(m);
    },
    [h]
  ), w = U(async () => {
    var i;
    try {
      const m = await Be({
        multiple: !0,
        filters: [{ name: "Image", extensions: ["png", "jpg", "jpeg", "gif", "webp", "bmp"] }]
      });
      if (!m) return;
      const N = Array.isArray(m) ? m : [m], b = [];
      for (const $ of N)
        try {
          const B = await fetch(`file://${$}`);
          if (!B.ok) throw new Error(`HTTP ${B.status}`);
          const P = await B.blob(), z = $.split(/[\\/]/).pop() || `image-${Date.now()}.png`;
          b.push(new File([P], z, { type: P.type || "image/*" }));
        } catch (B) {
          console.warn("[picgo] failed to read picked file:", B), I.error(`读取文件失败：${$}`);
        }
      h(b);
    } catch (m) {
      console.warn("[picgo] tauri dialog failed, falling back:", m), (i = l.current) == null || i.click();
    }
  }, [h]), j = U(async () => {
    const i = await ht();
    if (!i) {
      I.error("剪贴板中没有图片");
      return;
    }
    const m = bt(i.type || "image/png");
    u((N) => [
      ...N,
      {
        id: te(),
        file: i,
        filename: m,
        size: i.size,
        previewUrl: URL.createObjectURL(i),
        status: "idle",
        progress: 0
      }
    ]);
  }, []), c = U(
    async (i) => {
      if (!g) {
        I.error("设置尚未加载，请稍后重试");
        return;
      }
      const m = d.find((b) => b.id === i);
      if (!m) return;
      if (!V(o, g)) {
        I.error(`${O(o)} 未配置完整，请到设置中填写`);
        return;
      }
      const N = new AbortController();
      x.current.set(i, N), u(
        (b) => b.map(($) => $.id === i ? { ...$, status: "uploading", progress: 5, error: void 0 } : $)
      );
      try {
        const b = await ft(
          {
            file: m.file,
            filename: m.filename,
            providerId: o,
            settings: g,
            signal: N.signal,
            onProgress: (B) => {
              u(
                (P) => P.map((z) => z.id === i ? { ...z, progress: B.percent } : z)
              );
            }
          },
          { getAllSettings: e, store: t }
        );
        u(
          (B) => B.map(
            (P) => P.id === i ? { ...P, status: "done", progress: 100, result: b } : P
          )
        );
        const { text: $ } = W(b, g.linkFormat, r);
        I.success(`已上传：${b.filename}`, {
          description: $
        });
      } catch (b) {
        const $ = b instanceof Error ? b.message : String(b);
        u(
          (B) => B.map(
            (P) => P.id === i ? { ...P, status: "error", error: $ } : P
          )
        ), I.error($);
      } finally {
        x.current.delete(i);
      }
    },
    [d, g, o, e, t, r]
  ), E = U((i) => {
    const m = x.current.get(i);
    m && m.abort(new Error("cancelled by user"));
  }, []), R = U((i) => {
    u((m) => {
      const N = m.find((b) => b.id === i);
      return N && URL.revokeObjectURL(N.previewUrl), m.filter((b) => b.id !== i);
    });
  }, []), _ = U(() => {
    for (const i of d) URL.revokeObjectURL(i.previewUrl);
    u([]);
  }, [d]), ie = oe(
    () => O(o),
    [o]
  );
  return /* @__PURE__ */ f("div", { className: "flex flex-col gap-3 p-3 h-full overflow-auto", children: [
    /* @__PURE__ */ f("div", { className: "flex items-center justify-between rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm", children: [
      /* @__PURE__ */ f("div", { children: [
        /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)]", children: "当前图床" }),
        /* @__PURE__ */ a("div", { className: "font-medium", children: ie })
      ] }),
      /* @__PURE__ */ a(
        "select",
        {
          className: "rounded border border-[var(--border-color)] bg-[var(--bg-primary)] px-2 py-1 text-xs",
          value: o,
          onChange: (i) => n(i.target.value),
          children: Object.values(Y).map((i) => /* @__PURE__ */ a("option", { value: i.id, children: i.displayName }, i.id))
        }
      )
    ] }),
    /* @__PURE__ */ f(
      "div",
      {
        onDragOver: (i) => {
          i.preventDefault(), p(!0);
        },
        onDragLeave: () => p(!1),
        onDrop: T,
        onClick: w,
        className: `flex flex-col items-center justify-center rounded border-2 border-dashed cursor-pointer transition-colors ${y ? "border-[var(--theme-color)] bg-[var(--bg-hover)]" : "border-[var(--border-color)] hover:border-[var(--theme-color)]"}`,
        style: { minHeight: 120 },
        children: [
          /* @__PURE__ */ a("div", { className: "text-sm font-medium", children: "点击或拖入图片上传" }),
          /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)] mt-1", children: "支持 PNG / JPG / WebP / GIF" })
        ]
      }
    ),
    /* @__PURE__ */ f("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: j,
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm hover:bg-[var(--bg-hover)]",
          children: "从剪贴板粘贴"
        }
      ),
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: w,
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm hover:bg-[var(--bg-hover)]",
          children: "选择本地文件"
        }
      )
    ] }),
    /* @__PURE__ */ a(
      "input",
      {
        ref: l,
        type: "file",
        accept: "image/*",
        multiple: !0,
        className: "hidden",
        onChange: (i) => {
          const m = i.target.files;
          if (!m) return;
          const N = [];
          for (let b = 0; b < m.length; b++) {
            const $ = m[b];
            $ && N.push($);
          }
          h(N), i.target.value = "";
        }
      }
    ),
    d.length > 0 && /* @__PURE__ */ f("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ f("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ f("div", { className: "text-sm font-medium", children: [
          "待上传 (",
          d.length,
          ")"
        ] }),
        /* @__PURE__ */ a(
          "button",
          {
            type: "button",
            onClick: _,
            className: "text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)]",
            children: "清空"
          }
        )
      ] }),
      d.map((i) => /* @__PURE__ */ a(
        wt,
        {
          item: i,
          onUpload: () => c(i.id),
          onCancel: () => E(i.id),
          onRemove: () => R(i.id),
          onInsert: () => {
            if (!i.result || !g) return;
            const { text: m } = W(
              i.result,
              g.linkFormat,
              r
            );
            I.success("已复制插入文本", { description: m });
          },
          formatBytes: vt
        },
        i.id
      ))
    ] })
  ] });
}
function wt({ item: e, onUpload: t, onCancel: r, onRemove: o, onInsert: n, formatBytes: s }) {
  return /* @__PURE__ */ f("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-2 flex gap-2", children: [
    /* @__PURE__ */ a(
      "img",
      {
        src: e.previewUrl,
        alt: e.filename,
        className: "w-14 h-14 object-cover rounded border border-[var(--border-color)]"
      }
    ),
    /* @__PURE__ */ f("div", { className: "flex-1 min-w-0 flex flex-col", children: [
      /* @__PURE__ */ a("div", { className: "text-xs font-medium truncate", title: e.filename, children: e.filename }),
      /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)]", children: s(e.size) }),
      e.status === "uploading" && /* @__PURE__ */ f("div", { className: "mt-1", children: [
        /* @__PURE__ */ a("div", { className: "h-1.5 w-full rounded bg-[var(--bg-primary)] overflow-hidden", children: /* @__PURE__ */ a(
          "div",
          {
            className: "h-full bg-[var(--theme-color)] transition-all",
            style: { width: `${e.progress}%` }
          }
        ) }),
        /* @__PURE__ */ f("div", { className: "text-xs text-[var(--text-secondary)] mt-1", children: [
          e.progress,
          "%"
        ] })
      ] }),
      e.status === "error" && /* @__PURE__ */ a("div", { className: "text-xs text-red-500 mt-1 truncate", title: e.error, children: e.error }),
      e.status === "done" && e.result && /* @__PURE__ */ a("div", { className: "mt-1", children: /* @__PURE__ */ a(gt, { result: e.result, compact: !0, onInsert: n }) }),
      /* @__PURE__ */ f("div", { className: "flex gap-1 mt-1", children: [
        e.status === "idle" && /* @__PURE__ */ a(
          "button",
          {
            type: "button",
            onClick: t,
            className: "text-xs rounded px-2 py-0.5 bg-[var(--theme-color)] text-white hover:opacity-90",
            children: "上传"
          }
        ),
        e.status === "uploading" && /* @__PURE__ */ a(
          "button",
          {
            type: "button",
            onClick: r,
            className: "text-xs rounded px-2 py-0.5 border border-[var(--border-color)] hover:bg-[var(--bg-hover)]",
            children: "取消"
          }
        ),
        (e.status === "idle" || e.status === "error" || e.status === "done") && /* @__PURE__ */ a(
          "button",
          {
            type: "button",
            onClick: o,
            className: "text-xs rounded px-2 py-0.5 border border-[var(--border-color)] hover:bg-[var(--bg-hover)]",
            children: "移除"
          }
        )
      ] })
    ] })
  ] });
}
function Nt(e) {
  try {
    const t = new Date(e);
    return Number.isNaN(t.getTime()) ? e : t.toLocaleString();
  } catch {
    return e;
  }
}
function kt(e) {
  return e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1024 / 1024).toFixed(2)} MB`;
}
function Tt({
  getAllSettings: e,
  store: t,
  activeNoteContent: r,
  refreshTick: o,
  onAfterChange: n
}) {
  const [s, d] = M([]), [u, y] = M(""), [p, g] = M(null), [v, l] = M(!0);
  A(() => {
    let c = !1;
    return l(!0), Promise.all([J(t), e()]).then(([E, R]) => {
      c || (d(E), g(L(R)));
    }).catch((E) => {
      console.warn("[picgo] history reload failed:", E);
    }).finally(() => {
      c || l(!1);
    }), () => {
      c = !0;
    };
  }, [t, e, o]);
  const x = oe(() => {
    const c = u.trim().toLowerCase(), E = [...s].sort((R, _) => R.uploadedAt < _.uploadedAt ? 1 : -1);
    return c ? E.filter(
      (R) => R.filename.toLowerCase().includes(c) || R.url.toLowerCase().includes(c) || (R.provider || "").toLowerCase().includes(c)
    ) : E;
  }, [s, u]), h = U(async (c) => {
    try {
      await navigator.clipboard.writeText(c), I.success("URL 已复制");
    } catch (E) {
      console.warn("[picgo] clipboard write failed:", E), I.error("复制失败");
    }
  }, []), T = U(
    (c) => {
      if (!p) return;
      const { text: E } = W(
        c,
        p.linkFormat,
        r
      );
      I.success("已生成插入文本", { description: E });
    },
    [p, r]
  ), w = U(
    async (c) => {
      if (p)
        try {
          await Ve(t, c, p.historyRetention), d((E) => E.filter((R) => R.url !== c)), n();
        } catch (E) {
          I.error(`删除失败：${E.message}`);
        }
    },
    [t, p, n]
  ), j = U(async () => {
    try {
      await Je(t), d([]), n(), I.success("历史已清空");
    } catch (c) {
      I.error(`清空失败：${c.message}`);
    }
  }, [t, n]);
  return /* @__PURE__ */ f("div", { className: "flex flex-col gap-3 p-3 h-full overflow-hidden", children: [
    /* @__PURE__ */ f("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ a(
        "input",
        {
          type: "text",
          value: u,
          onChange: (c) => y(c.target.value),
          placeholder: "按文件名/URL 过滤",
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-2 py-1 text-sm"
        }
      ),
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: j,
          disabled: s.length === 0,
          className: "text-xs rounded border border-[var(--border-color)] px-2 py-1 hover:bg-[var(--bg-hover)] disabled:opacity-50",
          children: "清空"
        }
      )
    ] }),
    /* @__PURE__ */ a("div", { className: "flex-1 overflow-auto rounded border border-[var(--border-color)]", children: v ? /* @__PURE__ */ a(re, { text: "加载中…" }) : x.length === 0 ? /* @__PURE__ */ a(re, { text: s.length === 0 ? "暂无上传记录" : "没有匹配的记录" }) : /* @__PURE__ */ f("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ a("thead", { className: "bg-[var(--bg-secondary)] text-xs sticky top-0", children: /* @__PURE__ */ f("tr", { children: [
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left w-12", children: "缩略" }),
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left", children: "文件名" }),
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left w-20", children: "图床" }),
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left w-28", children: "时间" }),
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left w-20", children: "大小" }),
        /* @__PURE__ */ a("th", { className: "px-2 py-1 text-left w-32", children: "操作" })
      ] }) }),
      /* @__PURE__ */ a("tbody", { children: x.map((c) => /* @__PURE__ */ f("tr", { className: "border-t border-[var(--border-color)]", children: [
        /* @__PURE__ */ a("td", { className: "px-2 py-1", children: /* @__PURE__ */ a(
          "img",
          {
            src: c.url,
            alt: c.filename,
            className: "w-8 h-8 object-cover rounded border border-[var(--border-color)]",
            loading: "lazy",
            onError: (E) => {
              E.currentTarget.style.visibility = "hidden";
            }
          }
        ) }),
        /* @__PURE__ */ f("td", { className: "px-2 py-1 max-w-[160px]", children: [
          /* @__PURE__ */ a("div", { className: "truncate", title: c.filename, children: c.filename }),
          /* @__PURE__ */ a(
            "a",
            {
              href: c.url,
              target: "_blank",
              rel: "noreferrer",
              className: "text-xs text-[var(--text-secondary)] truncate block hover:underline",
              title: c.url,
              children: c.url
            }
          )
        ] }),
        /* @__PURE__ */ a("td", { className: "px-2 py-1 text-xs", children: O(c.provider) }),
        /* @__PURE__ */ a("td", { className: "px-2 py-1 text-xs", children: Nt(c.uploadedAt) }),
        /* @__PURE__ */ a("td", { className: "px-2 py-1 text-xs", children: kt(c.size) }),
        /* @__PURE__ */ a("td", { className: "px-2 py-1", children: /* @__PURE__ */ f("div", { className: "flex gap-1", children: [
          /* @__PURE__ */ a(
            "button",
            {
              type: "button",
              onClick: () => h(c.url),
              className: "text-xs rounded border border-[var(--border-color)] px-1.5 py-0.5 hover:bg-[var(--bg-hover)]",
              title: "复制 URL",
              children: "复制"
            }
          ),
          /* @__PURE__ */ a(
            "button",
            {
              type: "button",
              onClick: () => T(c),
              className: "text-xs rounded border border-[var(--border-color)] px-1.5 py-0.5 hover:bg-[var(--bg-hover)]",
              title: "生成插入文本",
              children: "插入"
            }
          ),
          /* @__PURE__ */ a(
            "button",
            {
              type: "button",
              onClick: () => w(c.url),
              className: "text-xs rounded border border-red-300 text-red-500 px-1.5 py-0.5 hover:bg-red-50",
              title: "从历史中移除（仅本地，不删除远端）",
              children: "删除"
            }
          )
        ] }) })
      ] }, c.url)) })
    ] }) }),
    p && !V(p.defaultProvider, p) && /* @__PURE__ */ f("div", { className: "rounded border border-amber-300 bg-amber-50 text-amber-800 px-2 py-1 text-xs", children: [
      "当前默认图床（",
      O(p.defaultProvider),
      "）尚未配置完整。"
    ] })
  ] });
}
function re({ text: e }) {
  return /* @__PURE__ */ a("div", { className: "flex items-center justify-center h-full text-sm text-[var(--text-secondary)]", children: e });
}
function G(e) {
  return e ? e.length <= 6 ? "******" : `${e.slice(0, 3)}…${e.slice(-3)}（已设置）` : "未设置";
}
function Et({ getAllSettings: e, refreshTick: t }) {
  const [r, o] = M(null);
  if (A(() => {
    let d = !1;
    return e().then((u) => {
      d || o(L(u));
    }), () => {
      d = !0;
    };
  }, [e, t]), !r)
    return /* @__PURE__ */ a("div", { className: "p-3 text-sm text-[var(--text-secondary)]", children: "加载中…" });
  const n = r.defaultProvider, s = V(n, r);
  return /* @__PURE__ */ f("div", { className: "flex flex-col gap-3 p-3 text-sm", children: [
    /* @__PURE__ */ f("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3", children: [
      /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)] mb-1", children: "当前默认图床" }),
      /* @__PURE__ */ a("div", { className: "font-medium mb-2", children: O(n) }),
      /* @__PURE__ */ a($t, { settings: r }),
      /* @__PURE__ */ a(
        "div",
        {
          className: `mt-2 text-xs ${s ? "text-green-600" : "text-amber-600"}`,
          children: s ? "已配置完成" : "配置不完整，请打开设置补充"
        }
      )
    ] }),
    /* @__PURE__ */ f("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3", children: [
      /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)] mb-1", children: "通用选项" }),
      /* @__PURE__ */ a(C, { k: "转码格式", v: r.uploadFormat }),
      /* @__PURE__ */ a(C, { k: "最大文件大小", v: `${r.maxFileSizeMB} MB` }),
      /* @__PURE__ */ a(C, { k: "文件名策略", v: r.filenameStrategy }),
      /* @__PURE__ */ a(C, { k: "插入格式", v: r.linkFormat }),
      /* @__PURE__ */ a(C, { k: "历史缓存", v: r.enableHistory ? `开（${r.historyRetention} 条）` : "关" })
    ] }),
    /* @__PURE__ */ a(
      "button",
      {
        type: "button",
        onClick: () => {
          alert("请通过插件卡片的 ⚙ 按钮打开完整设置面板。");
        },
        className: "rounded border border-[var(--border-color)] bg-[var(--theme-color)] text-white px-3 py-2 hover:opacity-90",
        children: "打开设置"
      }
    ),
    /* @__PURE__ */ a("div", { className: "text-xs text-[var(--text-secondary)]", children: "完整设置项（含自定义端点 Body 模板）请通过插件卡片的 ⚙ 按钮打开。" })
  ] });
}
function C({ k: e, v: t }) {
  return /* @__PURE__ */ f("div", { className: "flex justify-between py-0.5", children: [
    /* @__PURE__ */ a("span", { className: "text-[var(--text-secondary)]", children: e }),
    /* @__PURE__ */ a("span", { className: "font-mono text-xs", children: t })
  ] });
}
function $t({ settings: e }) {
  switch (e.defaultProvider) {
    case "smms":
      return /* @__PURE__ */ a(C, { k: "Token", v: G(e.smmsToken) });
    case "imgur":
      return /* @__PURE__ */ a(C, { k: "Client-ID", v: G(e.imgurClientId) });
    case "github":
      return /* @__PURE__ */ f(q, { children: [
        /* @__PURE__ */ a(C, { k: "Token", v: G(e.githubToken) }),
        /* @__PURE__ */ a(C, { k: "Owner", v: e.githubOwner || "未设置" }),
        /* @__PURE__ */ a(C, { k: "Repo", v: e.githubRepo || "未设置" }),
        /* @__PURE__ */ a(C, { k: "Branch", v: e.githubBranch || "main" }),
        /* @__PURE__ */ a(C, { k: "Path", v: e.githubPathPrefix || "" })
      ] });
    case "custom":
      return /* @__PURE__ */ f(q, { children: [
        /* @__PURE__ */ a(C, { k: "Endpoint", v: e.customEndpoint || "未设置" }),
        /* @__PURE__ */ a(C, { k: "Method", v: e.customMethod }),
        /* @__PURE__ */ a(C, { k: "URL 路径", v: e.customResponseUrlPath || "未设置" })
      ] });
    default:
      return null;
  }
}
const St = [
  { key: "upload", label: "上传" },
  { key: "history", label: "图床历史" },
  { key: "settings", label: "设置" }
];
function Ct(e) {
  const { getAllSettings: t, setSetting: r, isActive: o } = e, [n, s] = M("upload"), [d, u] = M("smms"), [y, p] = M(0), [g, v] = M(null);
  A(() => {
    let h = !1;
    return t().then((T) => {
      if (h) return;
      const w = L(T);
      v(w), u(w.defaultProvider);
    }), () => {
      h = !0;
    };
  }, [t]);
  const l = U(
    async (h) => {
      u(h);
      try {
        await r("defaultProvider", h), p((T) => T + 1);
      } catch (T) {
        console.warn("[picgo] failed to persist defaultProvider:", T);
      }
    },
    [r]
  ), x = U(() => {
    p((h) => h + 1);
  }, []);
  return o ? /* @__PURE__ */ f("div", { className: "flex flex-col h-full text-[var(--text-primary)]", children: [
    /* @__PURE__ */ a("div", { className: "flex border-b border-[var(--border-color)] bg-[var(--bg-secondary)]", children: St.map((h) => /* @__PURE__ */ a(
      "button",
      {
        type: "button",
        onClick: () => s(h.key),
        className: `flex-1 px-3 py-2 text-sm transition-colors ${n === h.key ? "border-b-2 border-[var(--theme-color)] text-[var(--theme-color)] font-medium" : "text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`,
        children: h.label
      },
      h.key
    )) }),
    /* @__PURE__ */ f("div", { className: "flex-1 min-h-0 overflow-hidden", children: [
      n === "upload" && /* @__PURE__ */ a(
        xt,
        {
          getAllSettings: t,
          store: e.store,
          activeNoteContent: e.activeNoteContent,
          activeProvider: d,
          onProviderChange: l,
          refreshTick: y
        }
      ),
      n === "history" && /* @__PURE__ */ a(
        Tt,
        {
          getAllSettings: t,
          store: e.store,
          activeNoteContent: e.activeNoteContent,
          refreshTick: y,
          onAfterChange: x
        }
      ),
      n === "settings" && /* @__PURE__ */ a(Et, { getAllSettings: t, refreshTick: y })
    ] }),
    null
  ] }) : null;
}
function Ut(e) {
  const { size: t, isActive: r, activate: o, deactivate: n } = e, s = U(() => {
    r ? n() : o();
  }, [r, o, n]);
  return /* @__PURE__ */ a(
    "button",
    {
      type: "button",
      onClick: s,
      className: "flex items-center justify-center w-6 h-6 rounded hover:bg-[var(--bg-hover)] cursor-pointer",
      style: {
        color: r ? "var(--theme-color)" : "var(--text-primary)"
      },
      title: "图床",
      "aria-label": "图床",
      "aria-pressed": r,
      children: /* @__PURE__ */ a(ne, { size: t })
    }
  );
}
const Bt = {
  ...$e,
  icon: ne,
  panel: Ct,
  toolbarButton: Ut
};
export {
  Bt as default,
  Rt as setHost
};
