// @swallow-manifest {"id":"com.swallownote.picgo","name":"图床","description":"将本地/剪贴板图片一键上传到云端图床（SM.MS / Imgur / GitHub / 腾讯云 COS / 阿里云 OSS / 七牛云 / 又拍云 / MinIO / 自定义端点），并插入到当前笔记。","version":"0.1.2","author":"SwallowNote","published_at":"2026-06-18T07:45:57Z","icon_position":"titleBar","content_position":"rightPanel","order":50,"enabled":true,"has_backend":false}
import { useState as I, useRef as Q, useEffect as q, useCallback as B, useMemo as oe } from "react";
import { jsxs as h, jsx as n, Fragment as O } from "react/jsx-runtime";
import { toast as C } from "sonner";
class le {
  constructor() {
    this.target = new EventTarget();
  }
  on(t, r) {
    const o = (i) => r(i.detail);
    return this.target.addEventListener(t, o), () => this.target.removeEventListener(t, o);
  }
  // Event bus is best-effort: identity of the wrapped handler is not
  // exposed. Callers should keep the unsubscribe returned by `on()`.
  // The args are kept for API symmetry with the host implementation.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  off(t, r) {
  }
  emit(t, r) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: r }));
  }
}
const j = new le();
j.on.bind(j), j.off.bind(j);
j.emit.bind(j);
const z = [];
let ue = 0;
function de() {
  const e = z[z.length - 1];
  return e ? e.overrides : me;
}
const me = Object.freeze({});
function Ut(e) {
  const t = ue++, r = { ...de(), ...e };
  return z.push({ overrides: r, token: t }), () => {
    for (let o = z.length - 1; o >= 0; o--)
      if (z[o].token === t) {
        z.splice(o, 1);
        return;
      }
  };
}
const pe = "com.swallownote.picgo", he = "图床", fe = "将本地/剪贴板图片一键上传到云端图床（SM.MS / Imgur / GitHub / 腾讯云 COS / 阿里云 OSS / 七牛云 / 又拍云 / MinIO / 自定义端点），并插入到当前笔记。", ye = "0.1.2", be = "SwallowNote", ge = "2026-06-18T07:45:57Z", ve = "titleBar", xe = "rightPanel", we = 50, ke = !0, Se = !1, Ne = "src/index.tsx", Pe = [
  "network",
  "clipboard",
  "storage",
  "events"
], Ee = {
  id: pe,
  name: he,
  description: fe,
  version: ye,
  author: be,
  publishedAt: ge,
  iconPosition: ve,
  contentPosition: xe,
  order: we,
  enabled: ke,
  hasBackend: Se,
  entry: Ne,
  permissions: Pe
};
function ie({ size: e = 18 }) {
  return /* @__PURE__ */ h(
    "svg",
    {
      width: e,
      height: e,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      children: [
        /* @__PURE__ */ n("path", { d: "M17.5 19a4.5 4.5 0 1 0-1.41-8.775 6 6 0 0 0-11.59 1.95A4.5 4.5 0 0 0 6 19h11.5z" }),
        /* @__PURE__ */ n("path", { d: "M12 12v9" }),
        /* @__PURE__ */ n("path", { d: "m9 15 3-3 3 3" })
      ]
    }
  );
}
const s = {
  defaultProvider: "smms",
  uploadFormat: "original",
  maxFileSizeMB: 10,
  filenameStrategy: "original",
  linkFormat: "markdown",
  enableHistory: !0,
  historyRetention: 200,
  smmsToken: "",
  imgurClientId: "",
  githubToken: "",
  githubOwner: "",
  githubRepo: "",
  githubBranch: "main",
  githubPathPrefix: "images/",
  // Tencent COS
  tencentSecretId: "",
  tencentSecretKey: "",
  tencentRegion: "ap-guangzhou",
  tencentBucket: "",
  tencentProtocol: "https",
  tencentKeyPrefix: "images/",
  // Aliyun OSS
  aliyunAccessKeyId: "",
  aliyunAccessKeySecret: "",
  aliyunRegion: "oss-cn-hangzhou",
  aliyunBucket: "",
  aliyunEndpoint: "",
  aliyunKeyPrefix: "images/",
  // Qiniu
  qiniuAccessKey: "",
  qiniuSecretKey: "",
  qiniuBucket: "",
  qiniuZone: "z0",
  qiniuDomain: "",
  qiniuKeyPrefix: "images/",
  // UPYUN
  upyunOperator: "",
  upyunPassword: "",
  upyunBucket: "",
  upyunDomain: "",
  upyunKeyPrefix: "",
  // MinIO
  minioEndpoint: "",
  minioAccessKey: "",
  minioSecretKey: "",
  minioBucket: "",
  minioRegion: "us-east-1",
  minioUseSsl: !1,
  minioPathStyle: !0,
  minioKeyPrefix: "images/",
  customEndpoint: "",
  customMethod: "POST",
  customHeaders: "",
  customBodyTemplate: "",
  customResponseUrlPath: "data.url"
};
function d(e, t) {
  return typeof e == "string" ? e : t;
}
function X(e, t) {
  if (typeof e == "number" && Number.isFinite(e)) return e;
  if (typeof e == "string" && e.trim() !== "") {
    const r = Number(e);
    if (Number.isFinite(r)) return r;
  }
  return t;
}
function Z(e, t) {
  return typeof e == "boolean" ? e : t;
}
function Te(e, t) {
  const r = d(e, t);
  return r === "smms" || r === "imgur" || r === "github" || r === "tencent" || r === "aliyun" || r === "qiniu" || r === "upyun" || r === "minio" || r === "custom" ? r : t;
}
function $e(e, t) {
  const r = d(e, t);
  return r === "original" || r === "webp" || r === "jpg" || r === "png" ? r : t;
}
function Be(e, t) {
  const r = d(e, t);
  return r === "original" || r === "uuid" || r === "timestamp" ? r : t;
}
function Ce(e, t) {
  const r = d(e, t);
  return r === "markdown" || r === "html" || r === "url" ? r : t;
}
function Ie(e, t) {
  const r = String(e ?? t).toUpperCase();
  return r === "POST" || r === "PUT" ? r : t;
}
function F(e) {
  const t = e ?? {};
  return {
    defaultProvider: Te(t.defaultProvider, s.defaultProvider),
    uploadFormat: $e(t.uploadFormat, s.uploadFormat),
    maxFileSizeMB: X(t.maxFileSizeMB, s.maxFileSizeMB),
    filenameStrategy: Be(
      t.filenameStrategy,
      s.filenameStrategy
    ),
    linkFormat: Ce(t.linkFormat, s.linkFormat),
    enableHistory: Z(t.enableHistory, s.enableHistory),
    historyRetention: X(t.historyRetention, s.historyRetention),
    smmsToken: d(t.smmsToken, s.smmsToken),
    imgurClientId: d(t.imgurClientId, s.imgurClientId),
    githubToken: d(t.githubToken, s.githubToken),
    githubOwner: d(t.githubOwner, s.githubOwner),
    githubRepo: d(t.githubRepo, s.githubRepo),
    githubBranch: d(t.githubBranch, s.githubBranch),
    githubPathPrefix: d(
      t.githubPathPrefix,
      s.githubPathPrefix
    ),
    customEndpoint: d(t.customEndpoint, s.customEndpoint),
    customMethod: Ie(t.customMethod, s.customMethod),
    customHeaders: d(t.customHeaders, s.customHeaders),
    customBodyTemplate: d(
      t.customBodyTemplate,
      s.customBodyTemplate
    ),
    customResponseUrlPath: d(
      t.customResponseUrlPath,
      s.customResponseUrlPath
    ),
    // Tencent COS
    tencentSecretId: d(t.tencentSecretId, s.tencentSecretId),
    tencentSecretKey: d(t.tencentSecretKey, s.tencentSecretKey),
    tencentRegion: d(t.tencentRegion, s.tencentRegion),
    tencentBucket: d(t.tencentBucket, s.tencentBucket),
    tencentProtocol: d(t.tencentProtocol, s.tencentProtocol) === "http" ? "http" : "https",
    tencentKeyPrefix: d(t.tencentKeyPrefix, s.tencentKeyPrefix),
    // Aliyun OSS
    aliyunAccessKeyId: d(t.aliyunAccessKeyId, s.aliyunAccessKeyId),
    aliyunAccessKeySecret: d(
      t.aliyunAccessKeySecret,
      s.aliyunAccessKeySecret
    ),
    aliyunRegion: d(t.aliyunRegion, s.aliyunRegion),
    aliyunBucket: d(t.aliyunBucket, s.aliyunBucket),
    aliyunEndpoint: d(t.aliyunEndpoint, s.aliyunEndpoint),
    aliyunKeyPrefix: d(t.aliyunKeyPrefix, s.aliyunKeyPrefix),
    // Qiniu
    qiniuAccessKey: d(t.qiniuAccessKey, s.qiniuAccessKey),
    qiniuSecretKey: d(t.qiniuSecretKey, s.qiniuSecretKey),
    qiniuBucket: d(t.qiniuBucket, s.qiniuBucket),
    qiniuZone: (() => {
      const r = d(t.qiniuZone, s.qiniuZone);
      return r === "z0" || r === "z1" || r === "z2" || r === "na0" || r === "as0" ? r : s.qiniuZone;
    })(),
    qiniuDomain: d(t.qiniuDomain, s.qiniuDomain),
    qiniuKeyPrefix: d(t.qiniuKeyPrefix, s.qiniuKeyPrefix),
    // UPYUN
    upyunOperator: d(t.upyunOperator, s.upyunOperator),
    upyunPassword: d(t.upyunPassword, s.upyunPassword),
    upyunBucket: d(t.upyunBucket, s.upyunBucket),
    upyunDomain: d(t.upyunDomain, s.upyunDomain),
    upyunKeyPrefix: d(t.upyunKeyPrefix, s.upyunKeyPrefix),
    // MinIO
    minioEndpoint: d(t.minioEndpoint, s.minioEndpoint),
    minioAccessKey: d(t.minioAccessKey, s.minioAccessKey),
    minioSecretKey: d(t.minioSecretKey, s.minioSecretKey),
    minioBucket: d(t.minioBucket, s.minioBucket),
    minioRegion: d(t.minioRegion, s.minioRegion),
    minioUseSsl: Z(t.minioUseSsl, s.minioUseSsl),
    minioPathStyle: Z(t.minioPathStyle, s.minioPathStyle),
    minioKeyPrefix: d(t.minioKeyPrefix, s.minioKeyPrefix)
  };
}
function Y(e, t) {
  switch (e) {
    case "smms":
      return !0;
    case "imgur":
      return t.imgurClientId.trim().length > 0;
    case "github":
      return t.githubToken.trim().length > 0 && t.githubOwner.trim().length > 0 && t.githubRepo.trim().length > 0;
    case "tencent":
      return t.tencentSecretId.trim().length > 0 && t.tencentSecretKey.trim().length > 0 && t.tencentRegion.trim().length > 0 && t.tencentBucket.trim().length > 0;
    case "aliyun":
      return t.aliyunAccessKeyId.trim().length > 0 && t.aliyunAccessKeySecret.trim().length > 0 && t.aliyunRegion.trim().length > 0 && t.aliyunBucket.trim().length > 0;
    case "qiniu":
      return t.qiniuAccessKey.trim().length > 0 && t.qiniuSecretKey.trim().length > 0 && t.qiniuBucket.trim().length > 0 && t.qiniuDomain.trim().length > 0;
    case "upyun":
      return t.upyunOperator.trim().length > 0 && t.upyunPassword.trim().length > 0 && t.upyunBucket.trim().length > 0 && t.upyunDomain.trim().length > 0;
    case "minio":
      return t.minioEndpoint.trim().length > 0 && t.minioAccessKey.trim().length > 0 && t.minioSecretKey.trim().length > 0 && t.minioBucket.trim().length > 0;
    case "custom":
      return t.customEndpoint.trim().length > 0 && t.customBodyTemplate.trim().length > 0;
    default:
      return !1;
  }
}
async function Re(e, t = {}, r) {
  return window.__TAURI_INTERNALS__.invoke(e, t, r);
}
async function Ue(e = {}) {
  return typeof e == "object" && Object.freeze(e), await Re("plugin:dialog|open", { options: e });
}
const ae = {
  webp: "image/webp",
  jpg: "image/jpeg",
  png: "image/png"
}, Ke = {
  webp: "webp",
  jpg: "jpg",
  png: "png"
}, Ae = {
  webp: 0.92,
  jpg: 0.85
};
class H extends Error {
  constructor() {
    super(...arguments), this.name = "ImageValidationError";
  }
}
function Oe(e, t) {
  const r = e.lastIndexOf(".");
  return `${r >= 0 ? e.slice(0, r) : e}.${t}`;
}
function Me(e) {
  return !!e.type && e.type.startsWith("image/");
}
function De(e) {
  return new Promise((t, r) => {
    const o = URL.createObjectURL(e), i = new Image();
    i.onload = () => {
      setTimeout(() => URL.revokeObjectURL(o), 0), t(i);
    }, i.onerror = () => {
      URL.revokeObjectURL(o), r(new Error("图片解码失败"));
    }, i.src = o;
  });
}
async function je(e, t, r) {
  return new Promise((o, i) => {
    e.toBlob(
      (a) => {
        if (!a) {
          i(new Error(`canvas 转码失败 (${t})`));
          return;
        }
        o(a);
      },
      t,
      r
    );
  });
}
async function ze(e, t) {
  const r = await De(e), o = document.createElement("canvas");
  o.width = r.naturalWidth, o.height = r.naturalHeight;
  const i = o.getContext("2d");
  if (!i)
    throw new H("浏览器不支持 canvas 2d，无法转码");
  i.drawImage(r, 0, 0);
  const a = ae[t], p = t === "png" ? void 0 : Ae[t];
  return je(o, a, p);
}
async function Fe(e) {
  const { file: t, filename: r, uploadFormat: o, maxFileSizeMB: i } = e;
  if (!Me(t))
    throw new H("仅支持图片文件");
  const a = Math.max(1, i) * 1024 * 1024;
  if (t.size > a)
    throw new H(
      `文件大小 ${(t.size / 1024 / 1024).toFixed(2)} MB 超过限制 ${i} MB`
    );
  if (o === "original")
    return { file: t, filename: r, mime: t.type };
  const p = ae[o];
  return t.type === p ? { file: t, filename: r, mime: p } : {
    file: await ze(t, o),
    filename: Oe(r, Ke[o]),
    mime: p
  };
}
function Le(e) {
  const t = e.lastIndexOf(".");
  return t >= 0 ? e.slice(t + 1).toLowerCase() : "";
}
function ee() {
  const e = /* @__PURE__ */ new Date(), t = (r) => String(r).padStart(2, "0");
  return `${e.getUTCFullYear()}-${t(e.getUTCMonth() + 1)}-${t(e.getUTCDate())}T${t(e.getUTCHours())}${t(e.getUTCMinutes())}${t(e.getUTCSeconds())}Z`;
}
function te() {
  return typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e) => {
    const t = Math.random() * 16 | 0;
    return (e === "x" ? t : t & 3 | 8).toString(16);
  });
}
function qe(e, t) {
  e || (e = `image-${Date.now()}.png`);
  const r = Le(e), o = r ? e.slice(0, -(r.length + 1)) : e;
  switch (t) {
    case "original":
      return e;
    case "uuid":
      return r ? `${te()}.${r}` : te();
    case "timestamp":
      return r ? `${ee()}-${o}.${r}` : `${ee()}-${o}`;
    default:
      return e;
  }
}
const _ = "picgo-history";
async function J(e) {
  try {
    const t = await e.get(_);
    return Array.isArray(t) ? t.filter(
      (r) => r && typeof r == "object" && typeof r.url == "string"
    ) : [];
  } catch (t) {
    return console.warn("[picgo] loadHistory failed:", t), [];
  }
}
function ce(e, t) {
  const r = Math.max(1, Math.floor(t));
  return e.length <= r ? e : e.slice(e.length - r);
}
async function He(e, t, r) {
  const o = await J(e), i = ce([...o, t], r);
  return await e.set(_, i), i;
}
async function _e(e, t, r) {
  const o = await J(e), i = ce(
    o.filter((a) => a.url !== t),
    r
  );
  return await e.set(_, i), i;
}
async function Ge(e) {
  await e.set(_, []);
}
const Ze = "https://sm.ms/api/v2/upload", We = {
  id: "smms",
  displayName: "SM.MS",
  async upload(e, t, r, o, i) {
    var k, m;
    const a = new FormData();
    a.append("smfile", e, t);
    const p = {}, f = (k = r.smmsToken) == null ? void 0 : k.trim();
    f && (p.Authorization = f);
    let w;
    try {
      w = await fetch(Ze, {
        method: "POST",
        body: a,
        headers: p,
        signal: o
      });
    } catch (S) {
      throw (S == null ? void 0 : S.name) === "AbortError" ? S : new Error(`SM.MS: 网络错误：${S.message || "fetch 失败"}`);
    }
    let b;
    try {
      b = await w.json();
    } catch (S) {
      throw new Error(`SM.MS: 响应解析失败：${S.message}`);
    }
    if (w.status === 401 || w.status === 403)
      throw new Error("SM.MS: 鉴权失败，请检查 Token 设置");
    if (!w.ok)
      throw new Error(`SM.MS: HTTP ${w.status}${b.message ? ` ${b.message}` : ""}`);
    if (!b.success) {
      const S = b.code || "unknown_error", g = b.message || S;
      throw new Error(`SM.MS: ${g}`);
    }
    const x = (m = b.data) == null ? void 0 : m.url;
    if (!x)
      throw new Error("SM.MS: 响应中未包含 data.url");
    return i == null || i({ loaded: e.size, total: e.size, percent: 100 }), {
      url: x,
      provider: "smms",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
}, Ye = "https://api.imgur.com/3/image";
async function Je(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), i = 32768;
  for (let a = 0; a < o.length; a += i)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(a, a + i))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
const Ve = {
  id: "imgur",
  displayName: "Imgur",
  async upload(e, t, r, o, i) {
    var x, k;
    if (!r.imgurClientId)
      throw new Error("Imgur: 缺少 Client-ID");
    const a = await Je(e), p = JSON.stringify({
      image: a,
      name: t,
      type: e.type || "image/*"
    });
    let f;
    try {
      f = await fetch(Ye, {
        method: "POST",
        headers: {
          Authorization: `Client-ID ${r.imgurClientId}`,
          "Content-Type": "application/json"
        },
        body: p,
        signal: o
      });
    } catch (m) {
      throw (m == null ? void 0 : m.name) === "AbortError" ? m : new Error(`Imgur: 网络错误：${m.message || "fetch 失败"}`);
    }
    let w;
    try {
      w = await f.json();
    } catch (m) {
      throw new Error(`Imgur: 响应解析失败：${m.message}`);
    }
    if (f.status === 401 || f.status === 403)
      throw new Error("Imgur: 鉴权失败，请检查 Client-ID");
    if (!f.ok || !w.success) {
      const m = ((x = w.data) == null ? void 0 : x.error) || `HTTP ${f.status}`;
      throw new Error(`Imgur: ${m}`);
    }
    const b = (k = w.data) == null ? void 0 : k.link;
    if (!b)
      throw new Error("Imgur: 响应中未包含 data.link");
    return i == null || i({ loaded: e.size, total: e.size, percent: 100 }), {
      url: b,
      provider: "imgur",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
};
async function Qe(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), i = 32768;
  for (let a = 0; a < o.length; a += i)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(a, a + i))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
function Xe(e) {
  return e.replace(/^\/+|\/+$/g, "");
}
function et(e, t) {
  const r = Xe(e || "");
  return r ? `${r}/${t}` : t;
}
const tt = {
  id: "github",
  displayName: "GitHub",
  async upload(e, t, r, o, i) {
    var S, g, E;
    if (!r.githubToken)
      throw new Error("GitHub: 缺少 Personal Access Token");
    if (!r.githubOwner || !r.githubRepo)
      throw new Error("GitHub: 缺少 Owner / Repo");
    const a = ((S = r.githubBranch) == null ? void 0 : S.trim()) || "main", p = et(r.githubPathPrefix || "", t), f = `https://api.github.com/repos/${encodeURIComponent(
      r.githubOwner
    )}/${encodeURIComponent(
      r.githubRepo
    )}/contents/${p.split("/").map(encodeURIComponent).join("/")}`, w = await Qe(e), b = JSON.stringify({
      message: `upload ${t} via SwallowNote PicGo plugin`,
      content: w,
      branch: a
    });
    let x;
    try {
      x = await fetch(f, {
        method: "PUT",
        headers: {
          Authorization: `token ${r.githubToken}`,
          "Content-Type": "application/json",
          Accept: "application/vnd.github+json"
        },
        body: b,
        signal: o
      });
    } catch (N) {
      throw (N == null ? void 0 : N.name) === "AbortError" ? N : new Error(`GitHub: 网络错误：${N.message || "fetch 失败"}`);
    }
    if (x.status === 401 || x.status === 403)
      throw new Error("GitHub: 鉴权失败，请检查 Token 权限（需要 repo）");
    let k;
    try {
      k = await x.json();
    } catch (N) {
      throw new Error(`GitHub: 响应解析失败：${N.message}`);
    }
    if (!x.ok) {
      const N = k.message || k.errors && ((g = k.errors[0]) == null ? void 0 : g.message) || `HTTP ${x.status}`;
      throw new Error(`GitHub: ${N}`);
    }
    const m = (E = k.content) == null ? void 0 : E.download_url;
    if (!m)
      throw new Error("GitHub: 响应中未包含 content.download_url");
    return i == null || i({ loaded: e.size, total: e.size, percent: 100 }), {
      url: m,
      provider: "github",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
};
async function rt(e) {
  const t = await e.arrayBuffer();
  let r = "";
  const o = new Uint8Array(t), i = 32768;
  for (let a = 0; a < o.length; a += i)
    r += String.fromCharCode.apply(
      null,
      Array.from(o.subarray(a, a + i))
    );
  return typeof btoa == "function" ? btoa(r) : r;
}
function nt(e) {
  const t = {};
  if (!e) return t;
  for (const r of e.split(/\r?\n/)) {
    const o = r.trim();
    if (!o) continue;
    const i = o.indexOf(":");
    if (i < 0) continue;
    const a = o.slice(0, i).trim(), p = o.slice(i + 1).trim();
    a && (t[a] = p);
  }
  return t;
}
function ot(e, t) {
  if (!t) return e;
  const r = t.split(".").map((i) => i.trim()).filter(Boolean);
  let o = e;
  for (const i of r)
    if (o && typeof o == "object" && i in o)
      o = o[i];
    else
      return;
  return o;
}
function it(e) {
  return /\{base64\}/.test(e);
}
const at = {
  id: "custom",
  displayName: "Custom",
  async upload(e, t, r, o, i) {
    var N, D;
    const a = (N = r.customEndpoint) == null ? void 0 : N.trim();
    if (!a)
      throw new Error("Custom: 缺少端点 URL (customEndpoint)");
    const p = (r.customMethod || "POST").toUpperCase(), f = r.customBodyTemplate;
    if (!f)
      throw new Error("Custom: 缺少请求体模板 (customBodyTemplate)");
    const w = ((D = r.customResponseUrlPath) == null ? void 0 : D.trim()) || "", b = await rt(e), x = f.replace(/\{filename\}/g, t).replace(/\{base64\}/g, b).replace(/\{mime\}/g, e.type || "application/octet-stream").replace(/\{size\}/g, String(e.size)), k = nt(r.customHeaders);
    !k["Content-Type"] && !k["content-type"] && it(f) && (k["Content-Type"] = "application/json");
    let m;
    try {
      m = await fetch(a, {
        method: p,
        headers: k,
        body: x,
        signal: o
      });
    } catch (l) {
      throw (l == null ? void 0 : l.name) === "AbortError" ? l : new Error(`Custom: 网络错误：${l.message || "fetch 失败"}`);
    }
    if (m.status === 401 || m.status === 403)
      throw new Error("Custom: 鉴权失败，请检查请求头配置");
    let S;
    try {
      S = await m.text();
    } catch (l) {
      throw new Error(`Custom: 响应读取失败：${l.message}`);
    }
    let g = S;
    try {
      g = JSON.parse(S);
    } catch {
    }
    if (!m.ok) {
      const l = typeof g == "string" ? g.slice(0, 200) : `HTTP ${m.status}`;
      throw new Error(`Custom: ${l}`);
    }
    let E;
    if (w ? E = ot(g, w) : typeof g == "string" && (E = g), typeof E != "string" || !E)
      throw new Error(
        `Custom: 响应中未找到 URL（路径：${w || "(none)"}）`
      );
    return i == null || i({ loaded: e.size, total: e.size, percent: 100 }), {
      url: E,
      provider: "custom",
      filename: t,
      size: e.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
      mime: e.type || void 0
    };
  }
}, V = {
  smms: We,
  imgur: Ve,
  github: tt,
  custom: at
}, ct = {
  tencent: "腾讯云 COS",
  aliyun: "阿里云 OSS",
  qiniu: "七牛云",
  upyun: "又拍云",
  minio: "MinIO"
};
function M(e) {
  var t;
  return ((t = V[e]) == null ? void 0 : t.displayName) ?? ct[e] ?? e;
}
function st(e) {
  const t = V[e];
  if (!t)
    throw new Error(`PicGo: 未知的图床类型 "${e}"`);
  return t;
}
const lt = 3e4;
class ut extends Error {
  constructor(t) {
    super(`${t}: 上传已取消`), this.provider = t, this.name = "UploadCancelledError";
  }
}
async function dt(e) {
  try {
    const t = await e();
    return F(t);
  } catch (t) {
    return console.warn("[picgo] fetchSettings failed, using defaults:", t), F({});
  }
}
function mt(e, t) {
  const r = new AbortController(), o = setTimeout(
    () => r.abort(new Error("timeout")),
    t
  ), i = () => r.abort(e == null ? void 0 : e.reason);
  e && (e.aborted ? i() : e.addEventListener("abort", i, { once: !0 }));
  const a = () => {
    clearTimeout(o), e && e.removeEventListener("abort", i);
  };
  return { signal: r.signal, dispose: a };
}
function pt(e) {
  if (!e || typeof e != "object") return !1;
  const t = e.name;
  return t === "AbortError" || t === "UploadCancelledError";
}
async function ht(e, t) {
  const r = e.settings ?? await dt(t.getAllSettings), o = e.providerId ?? r.defaultProvider, i = st(o), a = M(o), p = await Fe({
    file: e.file,
    filename: e.filename,
    uploadFormat: r.uploadFormat,
    maxFileSizeMB: r.maxFileSizeMB
  }).catch((m) => {
    throw m instanceof H ? new Error(`PicGo: ${m.message}`) : new Error(`PicGo: 预处理失败：${m.message}`);
  }), f = qe(p.filename, r.filenameStrategy), w = e.timeoutMs ?? lt, { signal: b, dispose: x } = mt(e.signal, w);
  let k;
  try {
    k = await i.upload(
      p.file,
      f,
      r,
      b,
      e.onProgress
    );
  } catch (m) {
    throw pt(m) ? new ut(a) : m instanceof Error ? m.message.startsWith(a) ? m : new Error(`${a}: ${m.message}`) : new Error(`${a}: ${String(m)}`);
  } finally {
    x();
  }
  if (r.enableHistory && t.store)
    try {
      await He(t.store, k, r.historyRetention);
    } catch (m) {
      console.warn("[picgo] appendHistory failed:", m);
    }
  return k;
}
async function ft() {
  if (typeof navigator > "u" || !navigator.clipboard || typeof navigator.clipboard.read != "function")
    return null;
  try {
    const e = await navigator.clipboard.read();
    for (const t of e) {
      const r = t.types.find((i) => i.startsWith("image/"));
      if (!r) continue;
      const o = await t.getType(r);
      if (o) return o;
    }
    return null;
  } catch (e) {
    return console.warn("[picgo] readClipboardImage failed:", e), null;
  }
}
function yt(e) {
  const t = e.includes("png") ? "png" : e.includes("jpeg") || e.includes("jpg") ? "jpg" : e.includes("webp") ? "webp" : e.includes("gif") ? "gif" : "png";
  return `clipboard-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").replace(/-\d{3}Z$/, "Z")}.${t}`;
}
function bt({
  result: e,
  compact: t,
  onInsert: r
}) {
  const [o, i] = I(!1), a = async () => {
    try {
      await navigator.clipboard.writeText(e.url), i(!0), setTimeout(() => i(!1), 1500);
    } catch (p) {
      console.warn("[picgo] copy failed:", p);
    }
  };
  return /* @__PURE__ */ h(
    "div",
    {
      className: `rounded border border-[var(--border-color)] bg-[var(--bg-primary)] ${t ? "p-1.5" : "p-2"}`,
      children: [
        /* @__PURE__ */ h("div", { className: "flex gap-2 items-start", children: [
          /* @__PURE__ */ n(
            "img",
            {
              src: e.url,
              alt: e.filename,
              className: `${t ? "w-8 h-8" : "w-14 h-14"} object-cover rounded border border-[var(--border-color)]`,
              loading: "lazy",
              onError: (p) => {
                p.currentTarget.style.visibility = "hidden";
              }
            }
          ),
          /* @__PURE__ */ h("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ n("div", { className: "text-xs font-medium truncate", title: e.filename, children: e.filename }),
            /* @__PURE__ */ n(
              "a",
              {
                href: e.url,
                target: "_blank",
                rel: "noreferrer",
                className: "text-xs text-[var(--text-secondary)] truncate block hover:underline",
                title: e.url,
                children: e.url
              }
            ),
            /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)] mt-0.5", children: M(e.provider) })
          ] })
        ] }),
        /* @__PURE__ */ h("div", { className: "flex gap-1 mt-1.5", children: [
          /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: a,
              className: "text-xs rounded border border-[var(--border-color)] px-2 py-0.5 hover:bg-[var(--bg-hover)]",
              children: o ? "已复制" : "复制 URL"
            }
          ),
          r && /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: r,
              className: "text-xs rounded border border-[var(--border-color)] px-2 py-0.5 hover:bg-[var(--bg-hover)]",
              children: "插入到笔记"
            }
          )
        ] })
      ]
    }
  );
}
function gt(e, t) {
  const r = (e.filename || "image").replace(/[[\]]/g, "");
  switch (t) {
    case "markdown":
      return `![${r}](${e.url})`;
    case "html":
      return `<img src="${e.url}" alt="${r}" />`;
    case "url":
      return e.url;
    default:
      return e.url;
  }
}
function W(e, t, r) {
  const o = gt(e, t), i = typeof r == "string" ? r : "", a = i.length === 0 ? "" : i.endsWith(`
`) ? `
` : `

`;
  return {
    text: o,
    nextContent: `${i}${a}${o}
`,
    cursorInserted: !1
  };
}
function re() {
  return typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `f-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function vt(e) {
  return e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1024 / 1024).toFixed(2)} MB`;
}
function xt({
  getAllSettings: e,
  store: t,
  activeNoteContent: r,
  activeProvider: o,
  onProviderChange: i,
  refreshTick: a
}) {
  const [p, f] = I([]), [w, b] = I(!1), [x, k] = I(null), m = Q(null), S = Q(/* @__PURE__ */ new Map());
  q(() => {
    let c = !1;
    return e().then((y) => {
      c || k(F(y));
    }), () => {
      c = !0;
    };
  }, [e, a]), q(() => {
    const c = p.map((y) => y.previewUrl);
    return () => {
      for (const y of c) URL.revokeObjectURL(y);
    };
  }, [p]);
  const g = B((c) => {
    c.length !== 0 && f((y) => {
      const P = [...y];
      for (const v of c) {
        if (!v.type.startsWith("image/")) {
          C.error(`仅支持图片文件：${v.name}`);
          continue;
        }
        P.push({
          id: re(),
          file: v,
          filename: v.name,
          size: v.size,
          previewUrl: URL.createObjectURL(v),
          status: "idle",
          progress: 0
        });
      }
      return P;
    });
  }, []), E = B(
    (c) => {
      c.preventDefault(), b(!1);
      const y = [];
      if (c.dataTransfer.files)
        for (let P = 0; P < c.dataTransfer.files.length; P++) {
          const v = c.dataTransfer.files[P];
          v && y.push(v);
        }
      g(y);
    },
    [g]
  ), N = B(async () => {
    var c;
    try {
      const y = await Ue({
        multiple: !0,
        filters: [{ name: "Image", extensions: ["png", "jpg", "jpeg", "gif", "webp", "bmp"] }]
      });
      if (!y) return;
      const P = Array.isArray(y) ? y : [y], v = [];
      for (const $ of P)
        try {
          const A = await fetch(`file://${$}`);
          if (!A.ok) throw new Error(`HTTP ${A.status}`);
          const R = await A.blob(), L = $.split(/[\\/]/).pop() || `image-${Date.now()}.png`;
          v.push(new File([R], L, { type: R.type || "image/*" }));
        } catch (A) {
          console.warn("[picgo] failed to read picked file:", A), C.error(`读取文件失败：${$}`);
        }
      g(v);
    } catch (y) {
      console.warn("[picgo] tauri dialog failed, falling back:", y), (c = m.current) == null || c.click();
    }
  }, [g]), D = B(async () => {
    const c = await ft();
    if (!c) {
      C.error("剪贴板中没有图片");
      return;
    }
    const y = yt(c.type || "image/png");
    f((P) => [
      ...P,
      {
        id: re(),
        file: c,
        filename: y,
        size: c.size,
        previewUrl: URL.createObjectURL(c),
        status: "idle",
        progress: 0
      }
    ]);
  }, []), l = B(
    async (c) => {
      if (!x) {
        C.error("设置尚未加载，请稍后重试");
        return;
      }
      const y = p.find((v) => v.id === c);
      if (!y) return;
      if (!Y(o, x)) {
        C.error(`${M(o)} 未配置完整，请到设置中填写`);
        return;
      }
      const P = new AbortController();
      S.current.set(c, P), f(
        (v) => v.map(($) => $.id === c ? { ...$, status: "uploading", progress: 5, error: void 0 } : $)
      );
      try {
        const v = await ht(
          {
            file: y.file,
            filename: y.filename,
            providerId: o,
            settings: x,
            signal: P.signal,
            onProgress: (A) => {
              f(
                (R) => R.map((L) => L.id === c ? { ...L, progress: A.percent } : L)
              );
            }
          },
          { getAllSettings: e, store: t }
        );
        f(
          (A) => A.map(
            (R) => R.id === c ? { ...R, status: "done", progress: 100, result: v } : R
          )
        );
        const { text: $ } = W(v, x.linkFormat, r);
        C.success(`已上传：${v.filename}`, {
          description: $
        });
      } catch (v) {
        const $ = v instanceof Error ? v.message : String(v);
        f(
          (A) => A.map(
            (R) => R.id === c ? { ...R, status: "error", error: $ } : R
          )
        ), C.error($);
      } finally {
        S.current.delete(c);
      }
    },
    [p, x, o, e, t, r]
  ), T = B((c) => {
    const y = S.current.get(c);
    y && y.abort(new Error("cancelled by user"));
  }, []), K = B((c) => {
    f((y) => {
      const P = y.find((v) => v.id === c);
      return P && URL.revokeObjectURL(P.previewUrl), y.filter((v) => v.id !== c);
    });
  }, []), G = B(() => {
    for (const c of p) URL.revokeObjectURL(c.previewUrl);
    f([]);
  }, [p]), se = oe(
    () => M(o),
    [o]
  );
  return /* @__PURE__ */ h("div", { className: "flex flex-col gap-3 p-3 h-full overflow-auto", children: [
    /* @__PURE__ */ h("div", { className: "flex items-center justify-between rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm", children: [
      /* @__PURE__ */ h("div", { children: [
        /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)]", children: "当前图床" }),
        /* @__PURE__ */ n("div", { className: "font-medium", children: se })
      ] }),
      /* @__PURE__ */ n(
        "select",
        {
          className: "rounded border border-[var(--border-color)] bg-[var(--bg-primary)] px-2 py-1 text-xs",
          value: o,
          onChange: (c) => i(c.target.value),
          children: Object.values(V).map((c) => /* @__PURE__ */ n("option", { value: c.id, children: c.displayName }, c.id))
        }
      )
    ] }),
    /* @__PURE__ */ h(
      "div",
      {
        onDragOver: (c) => {
          c.preventDefault(), b(!0);
        },
        onDragLeave: () => b(!1),
        onDrop: E,
        onClick: N,
        className: `flex flex-col items-center justify-center rounded border-2 border-dashed cursor-pointer transition-colors ${w ? "border-[var(--theme-color)] bg-[var(--bg-hover)]" : "border-[var(--border-color)] hover:border-[var(--theme-color)]"}`,
        style: { minHeight: 120 },
        children: [
          /* @__PURE__ */ n("div", { className: "text-sm font-medium", children: "点击或拖入图片上传" }),
          /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)] mt-1", children: "支持 PNG / JPG / WebP / GIF" })
        ]
      }
    ),
    /* @__PURE__ */ h("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: D,
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm hover:bg-[var(--bg-hover)]",
          children: "从剪贴板粘贴"
        }
      ),
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: N,
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm hover:bg-[var(--bg-hover)]",
          children: "选择本地文件"
        }
      )
    ] }),
    /* @__PURE__ */ n(
      "input",
      {
        ref: m,
        type: "file",
        accept: "image/*",
        multiple: !0,
        className: "hidden",
        onChange: (c) => {
          const y = c.target.files;
          if (!y) return;
          const P = [];
          for (let v = 0; v < y.length; v++) {
            const $ = y[v];
            $ && P.push($);
          }
          g(P), c.target.value = "";
        }
      }
    ),
    p.length > 0 && /* @__PURE__ */ h("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ h("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ h("div", { className: "text-sm font-medium", children: [
          "待上传 (",
          p.length,
          ")"
        ] }),
        /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: G,
            className: "text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)]",
            children: "清空"
          }
        )
      ] }),
      p.map((c) => /* @__PURE__ */ n(
        wt,
        {
          item: c,
          onUpload: () => l(c.id),
          onCancel: () => T(c.id),
          onRemove: () => K(c.id),
          onInsert: () => {
            if (!c.result || !x) return;
            const { text: y } = W(
              c.result,
              x.linkFormat,
              r
            );
            C.success("已复制插入文本", { description: y });
          },
          formatBytes: vt
        },
        c.id
      ))
    ] })
  ] });
}
function wt({ item: e, onUpload: t, onCancel: r, onRemove: o, onInsert: i, formatBytes: a }) {
  return /* @__PURE__ */ h("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-2 flex gap-2", children: [
    /* @__PURE__ */ n(
      "img",
      {
        src: e.previewUrl,
        alt: e.filename,
        className: "w-14 h-14 object-cover rounded border border-[var(--border-color)]"
      }
    ),
    /* @__PURE__ */ h("div", { className: "flex-1 min-w-0 flex flex-col", children: [
      /* @__PURE__ */ n("div", { className: "text-xs font-medium truncate", title: e.filename, children: e.filename }),
      /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)]", children: a(e.size) }),
      e.status === "uploading" && /* @__PURE__ */ h("div", { className: "mt-1", children: [
        /* @__PURE__ */ n("div", { className: "h-1.5 w-full rounded bg-[var(--bg-primary)] overflow-hidden", children: /* @__PURE__ */ n(
          "div",
          {
            className: "h-full bg-[var(--theme-color)] transition-all",
            style: { width: `${e.progress}%` }
          }
        ) }),
        /* @__PURE__ */ h("div", { className: "text-xs text-[var(--text-secondary)] mt-1", children: [
          e.progress,
          "%"
        ] })
      ] }),
      e.status === "error" && /* @__PURE__ */ n("div", { className: "text-xs text-red-500 mt-1 truncate", title: e.error, children: e.error }),
      e.status === "done" && e.result && /* @__PURE__ */ n("div", { className: "mt-1", children: /* @__PURE__ */ n(bt, { result: e.result, compact: !0, onInsert: i }) }),
      /* @__PURE__ */ h("div", { className: "flex gap-1 mt-1", children: [
        e.status === "idle" && /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: t,
            className: "text-xs rounded px-2 py-0.5 bg-[var(--theme-color)] text-white hover:opacity-90",
            children: "上传"
          }
        ),
        e.status === "uploading" && /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: r,
            className: "text-xs rounded px-2 py-0.5 border border-[var(--border-color)] hover:bg-[var(--bg-hover)]",
            children: "取消"
          }
        ),
        (e.status === "idle" || e.status === "error" || e.status === "done") && /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: o,
            className: "text-xs rounded px-2 py-0.5 border border-[var(--border-color)] hover:bg-[var(--bg-hover)]",
            children: "移除"
          }
        )
      ] })
    ] })
  ] });
}
function kt(e) {
  try {
    const t = new Date(e);
    return Number.isNaN(t.getTime()) ? e : t.toLocaleString();
  } catch {
    return e;
  }
}
function St(e) {
  return e < 1024 ? `${e} B` : e < 1024 * 1024 ? `${(e / 1024).toFixed(1)} KB` : `${(e / 1024 / 1024).toFixed(2)} MB`;
}
function Nt({
  getAllSettings: e,
  store: t,
  activeNoteContent: r,
  refreshTick: o,
  onAfterChange: i
}) {
  const [a, p] = I([]), [f, w] = I(""), [b, x] = I(null), [k, m] = I(!0);
  q(() => {
    let l = !1;
    return m(!0), Promise.all([J(t), e()]).then(([T, K]) => {
      l || (p(T), x(F(K)));
    }).catch((T) => {
      console.warn("[picgo] history reload failed:", T);
    }).finally(() => {
      l || m(!1);
    }), () => {
      l = !0;
    };
  }, [t, e, o]);
  const S = oe(() => {
    const l = f.trim().toLowerCase(), T = [...a].sort((K, G) => K.uploadedAt < G.uploadedAt ? 1 : -1);
    return l ? T.filter(
      (K) => K.filename.toLowerCase().includes(l) || K.url.toLowerCase().includes(l) || (K.provider || "").toLowerCase().includes(l)
    ) : T;
  }, [a, f]), g = B(async (l) => {
    try {
      await navigator.clipboard.writeText(l), C.success("URL 已复制");
    } catch (T) {
      console.warn("[picgo] clipboard write failed:", T), C.error("复制失败");
    }
  }, []), E = B(
    (l) => {
      if (!b) return;
      const { text: T } = W(
        l,
        b.linkFormat,
        r
      );
      C.success("已生成插入文本", { description: T });
    },
    [b, r]
  ), N = B(
    async (l) => {
      if (b)
        try {
          await _e(t, l, b.historyRetention), p((T) => T.filter((K) => K.url !== l)), i();
        } catch (T) {
          C.error(`删除失败：${T.message}`);
        }
    },
    [t, b, i]
  ), D = B(async () => {
    try {
      await Ge(t), p([]), i(), C.success("历史已清空");
    } catch (l) {
      C.error(`清空失败：${l.message}`);
    }
  }, [t, i]);
  return /* @__PURE__ */ h("div", { className: "flex flex-col gap-3 p-3 h-full overflow-hidden", children: [
    /* @__PURE__ */ h("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ n(
        "input",
        {
          type: "text",
          value: f,
          onChange: (l) => w(l.target.value),
          placeholder: "按文件名/URL 过滤",
          className: "flex-1 rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] px-2 py-1 text-sm"
        }
      ),
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: D,
          disabled: a.length === 0,
          className: "text-xs rounded border border-[var(--border-color)] px-2 py-1 hover:bg-[var(--bg-hover)] disabled:opacity-50",
          children: "清空"
        }
      )
    ] }),
    /* @__PURE__ */ n("div", { className: "flex-1 overflow-auto rounded border border-[var(--border-color)]", children: k ? /* @__PURE__ */ n(ne, { text: "加载中…" }) : S.length === 0 ? /* @__PURE__ */ n(ne, { text: a.length === 0 ? "暂无上传记录" : "没有匹配的记录" }) : /* @__PURE__ */ h("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ n("thead", { className: "bg-[var(--bg-secondary)] text-xs sticky top-0", children: /* @__PURE__ */ h("tr", { children: [
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left w-12", children: "缩略" }),
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left", children: "文件名" }),
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left w-20", children: "图床" }),
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left w-28", children: "时间" }),
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left w-20", children: "大小" }),
        /* @__PURE__ */ n("th", { className: "px-2 py-1 text-left w-32", children: "操作" })
      ] }) }),
      /* @__PURE__ */ n("tbody", { children: S.map((l) => /* @__PURE__ */ h("tr", { className: "border-t border-[var(--border-color)]", children: [
        /* @__PURE__ */ n("td", { className: "px-2 py-1", children: /* @__PURE__ */ n(
          "img",
          {
            src: l.url,
            alt: l.filename,
            className: "w-8 h-8 object-cover rounded border border-[var(--border-color)]",
            loading: "lazy",
            onError: (T) => {
              T.currentTarget.style.visibility = "hidden";
            }
          }
        ) }),
        /* @__PURE__ */ h("td", { className: "px-2 py-1 max-w-[160px]", children: [
          /* @__PURE__ */ n("div", { className: "truncate", title: l.filename, children: l.filename }),
          /* @__PURE__ */ n(
            "a",
            {
              href: l.url,
              target: "_blank",
              rel: "noreferrer",
              className: "text-xs text-[var(--text-secondary)] truncate block hover:underline",
              title: l.url,
              children: l.url
            }
          )
        ] }),
        /* @__PURE__ */ n("td", { className: "px-2 py-1 text-xs", children: M(l.provider) }),
        /* @__PURE__ */ n("td", { className: "px-2 py-1 text-xs", children: kt(l.uploadedAt) }),
        /* @__PURE__ */ n("td", { className: "px-2 py-1 text-xs", children: St(l.size) }),
        /* @__PURE__ */ n("td", { className: "px-2 py-1", children: /* @__PURE__ */ h("div", { className: "flex gap-1", children: [
          /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: () => g(l.url),
              className: "text-xs rounded border border-[var(--border-color)] px-1.5 py-0.5 hover:bg-[var(--bg-hover)]",
              title: "复制 URL",
              children: "复制"
            }
          ),
          /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: () => E(l),
              className: "text-xs rounded border border-[var(--border-color)] px-1.5 py-0.5 hover:bg-[var(--bg-hover)]",
              title: "生成插入文本",
              children: "插入"
            }
          ),
          /* @__PURE__ */ n(
            "button",
            {
              type: "button",
              onClick: () => N(l.url),
              className: "text-xs rounded border border-red-300 text-red-500 px-1.5 py-0.5 hover:bg-red-50",
              title: "从历史中移除（仅本地，不删除远端）",
              children: "删除"
            }
          )
        ] }) })
      ] }, l.url)) })
    ] }) }),
    b && !Y(b.defaultProvider, b) && /* @__PURE__ */ h("div", { className: "rounded border border-amber-300 bg-amber-50 text-amber-800 px-2 py-1 text-xs", children: [
      "当前默认图床（",
      M(b.defaultProvider),
      "）尚未配置完整。"
    ] })
  ] });
}
function ne({ text: e }) {
  return /* @__PURE__ */ n("div", { className: "flex items-center justify-center h-full text-sm text-[var(--text-secondary)]", children: e });
}
function U(e) {
  return e ? e.length <= 6 ? "******" : `${e.slice(0, 3)}…${e.slice(-3)}（已设置）` : "未设置";
}
function Pt({ getAllSettings: e, refreshTick: t }) {
  const [r, o] = I(null);
  if (q(() => {
    let p = !1;
    return e().then((f) => {
      p || o(F(f));
    }), () => {
      p = !0;
    };
  }, [e, t]), !r)
    return /* @__PURE__ */ n("div", { className: "p-3 text-sm text-[var(--text-secondary)]", children: "加载中…" });
  const i = r.defaultProvider, a = Y(i, r);
  return /* @__PURE__ */ h("div", { className: "flex flex-col gap-3 p-3 text-sm", children: [
    /* @__PURE__ */ h("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3", children: [
      /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)] mb-1", children: "当前默认图床" }),
      /* @__PURE__ */ n("div", { className: "font-medium mb-2", children: M(i) }),
      /* @__PURE__ */ n(Et, { settings: r }),
      /* @__PURE__ */ n(
        "div",
        {
          className: `mt-2 text-xs ${a ? "text-green-600" : "text-amber-600"}`,
          children: a ? "已配置完成" : "配置不完整，请打开设置补充"
        }
      )
    ] }),
    /* @__PURE__ */ h("div", { className: "rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3", children: [
      /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)] mb-1", children: "通用选项" }),
      /* @__PURE__ */ n(u, { k: "转码格式", v: r.uploadFormat }),
      /* @__PURE__ */ n(u, { k: "最大文件大小", v: `${r.maxFileSizeMB} MB` }),
      /* @__PURE__ */ n(u, { k: "文件名策略", v: r.filenameStrategy }),
      /* @__PURE__ */ n(u, { k: "插入格式", v: r.linkFormat }),
      /* @__PURE__ */ n(u, { k: "历史缓存", v: r.enableHistory ? `开（${r.historyRetention} 条）` : "关" })
    ] }),
    /* @__PURE__ */ n(
      "button",
      {
        type: "button",
        onClick: () => {
          alert("请通过插件卡片的 ⚙ 按钮打开完整设置面板。");
        },
        className: "rounded border border-[var(--border-color)] bg-[var(--theme-color)] text-white px-3 py-2 hover:opacity-90",
        children: "打开设置"
      }
    ),
    /* @__PURE__ */ n("div", { className: "text-xs text-[var(--text-secondary)]", children: "完整设置项（含自定义端点 Body 模板）请通过插件卡片的 ⚙ 按钮打开。" })
  ] });
}
function u({ k: e, v: t }) {
  return /* @__PURE__ */ h("div", { className: "flex justify-between py-0.5", children: [
    /* @__PURE__ */ n("span", { className: "text-[var(--text-secondary)]", children: e }),
    /* @__PURE__ */ n("span", { className: "font-mono text-xs", children: t })
  ] });
}
function Et({ settings: e }) {
  switch (e.defaultProvider) {
    case "smms":
      return /* @__PURE__ */ n(u, { k: "Token", v: U(e.smmsToken) });
    case "imgur":
      return /* @__PURE__ */ n(u, { k: "Client-ID", v: U(e.imgurClientId) });
    case "github":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "Token", v: U(e.githubToken) }),
        /* @__PURE__ */ n(u, { k: "Owner", v: e.githubOwner || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Repo", v: e.githubRepo || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Branch", v: e.githubBranch || "main" }),
        /* @__PURE__ */ n(u, { k: "Path", v: e.githubPathPrefix || "" })
      ] });
    case "tencent":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "SecretId", v: U(e.tencentSecretId) }),
        /* @__PURE__ */ n(u, { k: "SecretKey", v: U(e.tencentSecretKey) }),
        /* @__PURE__ */ n(u, { k: "Region", v: e.tencentRegion || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Bucket", v: e.tencentBucket || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Protocol", v: e.tencentProtocol }),
        /* @__PURE__ */ n(u, { k: "Path", v: e.tencentKeyPrefix || "" })
      ] });
    case "aliyun":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "AccessKey ID", v: U(e.aliyunAccessKeyId) }),
        /* @__PURE__ */ n(u, { k: "AccessKey Secret", v: U(e.aliyunAccessKeySecret) }),
        /* @__PURE__ */ n(u, { k: "Region", v: e.aliyunRegion || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Bucket", v: e.aliyunBucket || "未设置" }),
        e.aliyunEndpoint ? /* @__PURE__ */ n(u, { k: "Endpoint", v: e.aliyunEndpoint }) : null,
        /* @__PURE__ */ n(u, { k: "Path", v: e.aliyunKeyPrefix || "" })
      ] });
    case "qiniu":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "AccessKey", v: U(e.qiniuAccessKey) }),
        /* @__PURE__ */ n(u, { k: "SecretKey", v: U(e.qiniuSecretKey) }),
        /* @__PURE__ */ n(u, { k: "Bucket", v: e.qiniuBucket || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Zone", v: e.qiniuZone }),
        /* @__PURE__ */ n(u, { k: "Domain", v: e.qiniuDomain || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Path", v: e.qiniuKeyPrefix || "" })
      ] });
    case "upyun":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "Operator", v: e.upyunOperator || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Password", v: U(e.upyunPassword) }),
        /* @__PURE__ */ n(u, { k: "Service", v: e.upyunBucket || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Domain", v: e.upyunDomain || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Path", v: e.upyunKeyPrefix || "" })
      ] });
    case "minio":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "Endpoint", v: e.minioEndpoint || "未设置" }),
        /* @__PURE__ */ n(u, { k: "AccessKey", v: U(e.minioAccessKey) }),
        /* @__PURE__ */ n(u, { k: "SecretKey", v: U(e.minioSecretKey) }),
        /* @__PURE__ */ n(u, { k: "Bucket", v: e.minioBucket || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Region", v: e.minioRegion || "us-east-1" }),
        /* @__PURE__ */ n(u, { k: "HTTPS", v: e.minioUseSsl ? "开" : "关" }),
        /* @__PURE__ */ n(u, { k: "Path-Style", v: e.minioPathStyle ? "开" : "关" }),
        /* @__PURE__ */ n(u, { k: "Path", v: e.minioKeyPrefix || "" })
      ] });
    case "custom":
      return /* @__PURE__ */ h(O, { children: [
        /* @__PURE__ */ n(u, { k: "Endpoint", v: e.customEndpoint || "未设置" }),
        /* @__PURE__ */ n(u, { k: "Method", v: e.customMethod }),
        /* @__PURE__ */ n(u, { k: "URL 路径", v: e.customResponseUrlPath || "未设置" })
      ] });
    default:
      return null;
  }
}
const Tt = [
  { key: "upload", label: "上传" },
  { key: "history", label: "图床历史" },
  { key: "settings", label: "设置" }
];
function $t(e) {
  const { getAllSettings: t, setSetting: r, isActive: o } = e, [i, a] = I("upload"), [p, f] = I("smms"), [w, b] = I(0), [x, k] = I(null);
  q(() => {
    let g = !1;
    return t().then((E) => {
      if (g) return;
      const N = F(E);
      k(N), f(N.defaultProvider);
    }), () => {
      g = !0;
    };
  }, [t]);
  const m = B(
    async (g) => {
      f(g);
      try {
        await r("defaultProvider", g), b((E) => E + 1);
      } catch (E) {
        console.warn("[picgo] failed to persist defaultProvider:", E);
      }
    },
    [r]
  ), S = B(() => {
    b((g) => g + 1);
  }, []);
  return o ? /* @__PURE__ */ h("div", { className: "flex flex-col h-full text-[var(--text-primary)]", children: [
    /* @__PURE__ */ n("div", { className: "flex border-b border-[var(--border-color)] bg-[var(--bg-secondary)]", children: Tt.map((g) => /* @__PURE__ */ n(
      "button",
      {
        type: "button",
        onClick: () => a(g.key),
        className: `flex-1 px-3 py-2 text-sm transition-colors ${i === g.key ? "border-b-2 border-[var(--theme-color)] text-[var(--theme-color)] font-medium" : "text-[var(--text-secondary)] hover:text-[var(--text-primary)]"}`,
        children: g.label
      },
      g.key
    )) }),
    /* @__PURE__ */ h("div", { className: "flex-1 min-h-0 overflow-hidden", children: [
      i === "upload" && /* @__PURE__ */ n(
        xt,
        {
          getAllSettings: t,
          store: e.store,
          activeNoteContent: e.activeNoteContent,
          activeProvider: p,
          onProviderChange: m,
          refreshTick: w
        }
      ),
      i === "history" && /* @__PURE__ */ n(
        Nt,
        {
          getAllSettings: t,
          store: e.store,
          activeNoteContent: e.activeNoteContent,
          refreshTick: w,
          onAfterChange: S
        }
      ),
      i === "settings" && /* @__PURE__ */ n(Pt, { getAllSettings: t, refreshTick: w })
    ] }),
    null
  ] }) : null;
}
function Bt(e) {
  const { size: t, isActive: r, activate: o, deactivate: i } = e, a = B(() => {
    r ? i() : o();
  }, [r, o, i]);
  return /* @__PURE__ */ n(
    "button",
    {
      type: "button",
      onClick: a,
      className: "flex items-center justify-center w-6 h-6 rounded hover:bg-[var(--bg-hover)] cursor-pointer",
      style: {
        color: r ? "var(--theme-color)" : "var(--text-primary)"
      },
      title: "图床",
      "aria-label": "图床",
      "aria-pressed": r,
      children: /* @__PURE__ */ n(ie, { size: t })
    }
  );
}
const Kt = {
  ...Ee,
  icon: ie,
  panel: $t,
  toolbarButton: Bt
};
export {
  Kt as default,
  Ut as setHost
};
