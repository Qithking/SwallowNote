// @swallow-manifest {"id":"com.swallownote.ai","name":"AI 助手","description":"与 AI 对话并操作笔记：智能问答、内容生成、笔记整理。","version":"0.1.5","author":"SwallowNote","published_at":"2026-11-12T08:18:59Z","icon_position":"titleBar","content_position":"rightPanel","order":40,"enabled":true,"has_backend":true,"min_host_version":"0.1.0"}
import { jsxs as Q, jsx as T, Fragment as Nn } from "react/jsx-runtime";
import { forwardRef as qs, createElement as mi, useRef as Ve, useCallback as be, useSyncExternalStore as Zr, useEffect as qe, useState as ye, useMemo as Gt } from "react";
function pf(e, t) {
  return { ...e, ...t };
}
class hf {
  constructor() {
    this.target = new EventTarget(), this.wrapperMap = /* @__PURE__ */ new Map();
  }
  on(t, n) {
    const r = (o) => n(o.detail);
    this.target.addEventListener(t, r);
    let i = this.wrapperMap.get(n);
    return i || (i = /* @__PURE__ */ new Map(), this.wrapperMap.set(n, i)), i.set(t, r), () => {
      this.target.removeEventListener(t, r), i.delete(t), i.size === 0 && this.wrapperMap.delete(n);
    };
  }
  off(t, n) {
    const r = this.wrapperMap.get(n), i = r == null ? void 0 : r.get(t);
    i && (this.target.removeEventListener(t, i), r.delete(t), r.size === 0 && this.wrapperMap.delete(n));
  }
  removeAllListenersForPlugin(t) {
  }
  emit(t, n) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: n }));
  }
}
const Bo = new hf();
Bo.emit.bind(Bo);
class mf {
  constructor() {
    this.byPlugin = /* @__PURE__ */ new Map(), this.byLocation = {
      fileTree: [],
      fileTreeEmpty: [],
      editor: [],
      tab: [],
      tabBarEmpty: []
    };
  }
  register(t, n) {
    this.unregister(t, n.id);
    let r = this.byPlugin.get(t);
    r || (r = [], this.byPlugin.set(t, r)), r.push(n), this.indexItem(n);
  }
  unregister(t, n) {
    const r = this.byPlugin.get(t);
    if (!r)
      return;
    const i = r.findIndex((o) => o.id === n);
    i < 0 || (r.splice(i, 1), r.length === 0 && this.byPlugin.delete(t), this.rebuildIndex());
  }
  clearPlugin(t) {
    this.byPlugin.has(t) && (this.byPlugin.delete(t), this.rebuildIndex());
  }
  query(t, n) {
    const r = this.byLocation[t];
    return !r || r.length === 0 ? [] : r.filter((i) => !(i.locations && !i.locations.includes(t) || i.when && !i.when(n)));
  }
  getByLocation(t) {
    return this.byLocation[t];
  }
  indexItem(t) {
    const n = t.locations ?? [
      "fileTree",
      "fileTreeEmpty",
      "editor",
      "tab",
      "tabBarEmpty"
    ];
    for (const r of n)
      this.byLocation[r].push(t);
  }
  rebuildIndex() {
    for (const t of Object.keys(this.byLocation))
      this.byLocation[t] = [];
    for (const t of this.byPlugin.values())
      for (const n of t)
        this.indexItem(n);
  }
}
const gf = new mf();
function Js(e, t) {
  var n, r;
  ((r = (n = Xe()).registerContextMenu) == null ? void 0 : r.call(n, e, t)) ?? gf.register(e, t);
}
function Ws(e) {
  var t, n;
  (n = (t = Xe()).__openPluginPanel) == null || n.call(t, e);
}
function xt(e, t) {
  console.warn(`[plugin-sdk] ${e} called but no host override is installed — ${t}. This is expected in standalone preview mode (npm run dev); in host mode the host installs the override via setHost() and enforces permissions there.`);
}
const kt = {
  insertAtCursor: async (e) => {
    const t = Xe().__editor_insertAtCursor;
    return t ? t(e) : (xt("editor.insertAtCursor", "the insert was dropped and returns false"), !1);
  },
  replaceSelection: async (e) => {
    const t = Xe().__editor_replaceSelection;
    return t ? t(e) : (xt("editor.replaceSelection", "the replace was dropped and returns false"), !1);
  },
  replaceContent: async (e) => {
    const t = Xe().__editor_replaceContent;
    if (t)
      return t(e);
    xt("editor.replaceContent", "the content replacement was dropped");
  },
  getSelection: async () => {
    const e = Xe().__editor_getSelection;
    return e ? e() : (xt("editor.getSelection", "returning null"), null);
  },
  getActiveContent: async () => {
    const e = Xe().__editor_getActiveContent;
    return e ? e() : (xt("editor.getActiveContent", "returning null"), null);
  }
}, Hs = {
  createNote: async (e, t) => {
    const n = Xe().__files_createNote;
    if (n)
      return n(e, t);
    xt("files.createNote", `the note "${e}" was not created`);
  },
  listWorkspace: async (e) => {
    const t = Xe().__files_listWorkspace;
    return t ? t(e) : (xt("files.listWorkspace", "returning an empty list"), []);
  },
  read: async (e) => {
    const t = Xe().__files_read;
    return t ? t(e) : (xt("files.read", "returning an empty string"), "");
  }
}, Kt = [];
let yf = 0;
function Xe() {
  const e = Kt[Kt.length - 1];
  return e ? e.overrides : bf;
}
const bf = Object.freeze({});
function TI(e, t) {
  const n = yf++, r = { ...Xe(), ...e };
  return Kt.push({ overrides: r, token: n, pluginId: t }), () => {
    for (let i = Kt.length - 1; i >= 0; i--)
      if (Kt[i].token === n) {
        Kt.splice(i, 1);
        return;
      }
  };
}
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const vf = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Ks = (...e) => e.filter((t, n, r) => !!t && t.trim() !== "" && r.indexOf(t) === n).join(" ").trim();
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var kf = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const wf = qs(
  ({
    color: e = "currentColor",
    size: t = 24,
    strokeWidth: n = 2,
    absoluteStrokeWidth: r,
    className: i = "",
    children: o,
    iconNode: a,
    ...s
  }, u) => mi(
    "svg",
    {
      ref: u,
      ...kf,
      width: t,
      height: t,
      stroke: e,
      strokeWidth: r ? Number(n) * 24 / Number(t) : n,
      className: Ks("lucide", i),
      ...s
    },
    [
      ...a.map(([c, l]) => mi(c, l)),
      ...Array.isArray(o) ? o : [o]
    ]
  )
);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Se = (e, t) => {
  const n = qs(
    ({ className: r, ...i }, o) => mi(wf, {
      ref: o,
      iconNode: t,
      className: Ks(`lucide-${vf(e)}`, r),
      ...i
    })
  );
  return n.displayName = `${e}`, n;
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const gi = Se("Bot", [
  ["path", { d: "M12 8V4H8", key: "hb8ula" }],
  ["rect", { width: "16", height: "12", x: "4", y: "8", rx: "2", key: "enze0r" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M15 13v2", key: "1xurst" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const xf = Se("Check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const _f = Se("ChevronDown", [
  ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Sf = Se("Copy", [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const If = Se("CornerDownRight", [
  ["polyline", { points: "15 10 20 15 15 20", key: "1q7qjw" }],
  ["path", { d: "M4 4v7a4 4 0 0 0 4 4h12", key: "z08zvw" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ef = Se("FilePlus2", [
  ["path", { d: "M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4", key: "1pf5j1" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M3 15h6", key: "4e2qda" }],
  ["path", { d: "M6 12v6", key: "1u72j0" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Cf = Se("MessageSquarePlus", [
  ["path", { d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z", key: "1lielz" }],
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ys = Se("Pencil", [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Af = Se("Plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const zf = Se("Replace", [
  ["path", { d: "M14 4a2 2 0 0 1 2-2", key: "1w2hp7" }],
  ["path", { d: "M16 10a2 2 0 0 1-2-2", key: "shjach" }],
  ["path", { d: "M20 2a2 2 0 0 1 2 2", key: "188mtx" }],
  ["path", { d: "M22 8a2 2 0 0 1-2 2", key: "ddf4tu" }],
  ["path", { d: "m3 7 3 3 3-3", key: "x25e72" }],
  ["path", { d: "M6 10V5a3 3 0 0 1 3-3h1", key: "3y3t5z" }],
  ["rect", { x: "2", y: "14", width: "8", height: "8", rx: "2", key: "4rksxw" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Tf = Se("Settings", [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Of = Se("Sparkles", [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Pf = Se("Square", [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Mf = Se("Star", [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Gs = Se("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const yi = Se("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]);
var Xs = "vercel.ai.error", Rf = Symbol.for(Xs), Uo, Vo, We = class Qs extends (Vo = Error, Uo = Rf, Vo) {
  /**
   * Creates an AI SDK Error.
   *
   * @param {Object} params - The parameters for creating the error.
   * @param {string} params.name - The name of the error.
   * @param {string} params.message - The error message.
   * @param {unknown} [params.cause] - The underlying cause of the error.
   */
  constructor({
    name: t,
    message: n,
    cause: r
  }) {
    super(n), this[Uo] = !0, this.name = t, this.cause = r;
  }
  /**
   * Checks if the given error is an AI SDK Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is an AI SDK Error, false otherwise.
   */
  static isInstance(t) {
    return Qs.hasMarker(t, Xs);
  }
  static hasMarker(t, n) {
    const r = Symbol.for(n);
    return t != null && typeof t == "object" && r in t && typeof t[r] == "boolean" && t[r] === !0;
  }
};
function el(e) {
  return e == null ? "unknown error" : typeof e == "string" ? e : e instanceof Error ? e.message : JSON.stringify(e);
}
var tl = "AI_InvalidArgumentError", nl = `vercel.ai.error.${tl}`, $f = Symbol.for(nl), qo, Jo, Df = class extends (Jo = We, qo = $f, Jo) {
  constructor({
    message: t,
    cause: n,
    argument: r
  }) {
    super({ name: tl, message: t, cause: n }), this[qo] = !0, this.argument = r;
  }
  static isInstance(t) {
    return We.hasMarker(t, nl);
  }
}, rl = "AI_JSONParseError", il = `vercel.ai.error.${rl}`, Nf = Symbol.for(il), Wo, Ho, Ko = class extends (Ho = We, Wo = Nf, Ho) {
  constructor({ text: e, cause: t }) {
    super({
      name: rl,
      message: `JSON parsing failed: Text: ${e}.
Error message: ${el(t)}`,
      cause: t
    }), this[Wo] = !0, this.text = e;
  }
  static isInstance(e) {
    return We.hasMarker(e, il);
  }
}, ol = "AI_TypeValidationError", al = `vercel.ai.error.${ol}`, Lf = Symbol.for(al), Yo, Go, Xt = class bi extends (Go = We, Yo = Lf, Go) {
  constructor({
    value: t,
    cause: n,
    context: r
  }) {
    let i = "Type validation failed";
    if (r != null && r.field && (i += ` for ${r.field}`), r != null && r.entityName || r != null && r.entityId) {
      i += " (";
      const o = [];
      r.entityName && o.push(r.entityName), r.entityId && o.push(`id: "${r.entityId}"`), i += o.join(", "), i += ")";
    }
    super({
      name: ol,
      message: `${i}: Value: ${JSON.stringify(t)}.
Error message: ${el(n)}`,
      cause: n
    }), this[Yo] = !0, this.value = t, this.context = r;
  }
  static isInstance(t) {
    return We.hasMarker(t, al);
  }
  /**
   * Wraps an error into a TypeValidationError.
   * If the cause is already a TypeValidationError with the same value and context, it returns the cause.
   * Otherwise, it creates a new TypeValidationError.
   *
   * @param {Object} params - The parameters for wrapping the error.
   * @param {unknown} params.value - The value that failed validation.
   * @param {unknown} params.cause - The original error or cause of the validation failure.
   * @param {TypeValidationContext} params.context - Optional context about what is being validated.
   * @returns {TypeValidationError} A TypeValidationError instance.
   */
  static wrap({
    value: t,
    cause: n,
    context: r
  }) {
    var i, o, a;
    return bi.isInstance(n) && n.value === t && ((i = n.context) == null ? void 0 : i.field) === (r == null ? void 0 : r.field) && ((o = n.context) == null ? void 0 : o.entityName) === (r == null ? void 0 : r.entityName) && ((a = n.context) == null ? void 0 : a.entityId) === (r == null ? void 0 : r.entityId) ? n : new bi({ value: t, cause: n, context: r });
  }
};
function vi(e) {
  const t = Object.values(e).filter((r) => typeof r == "number");
  return Object.entries(e).filter(([r, i]) => t.indexOf(+r) === -1).map(([r, i]) => i);
}
function Xo(e, t = "|") {
  return e.map((n) => fl(n)).join(t);
}
function ki(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
class Ff {
  constructor(t) {
    this._getter = t, this._value = void 0;
  }
  get value() {
    const t = this._getter;
    return t !== void 0 && (this._value = t(), this._getter = void 0), this._value;
  }
}
function Sr(e) {
  return new Ff(e);
}
function jf(e) {
  return e == null;
}
function Xi(e) {
  const t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
function Zf(e, t) {
  const n = e / t, r = Math.round(n), i = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - r) < i ? 0 : n - r;
}
const Qo = /* @__PURE__ */ Symbol("evaluating");
function Bf(e, t, n) {
  let r;
  Object.defineProperty(e, t, {
    get() {
      if (r !== Qo)
        return r === void 0 && (r = Qo, r = n()), r;
    },
    set(i) {
      Object.defineProperty(e, t, {
        value: i
        // configurable: true,
      });
    },
    configurable: !0
  });
}
function ut(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function Qi(e) {
  const t = Object.getOwnPropertyDescriptor(e, "shape");
  return t != null && t.get ? t.get.raw : t == null ? void 0 : t.value;
}
function pt(e) {
  return Qi(e._zod.def) ?? e._zod.def.shape;
}
function sl(e, t, n) {
  Object.defineProperty(e, t, {
    get() {
      const r = n();
      return ut(this, t, r), r;
    },
    enumerable: !0,
    configurable: !0
  });
}
function ll(e, t, n) {
  t in e ? ut(e, t, n) : e[t] = n;
}
function Dt(e, t, n, r) {
  const i = pt(t);
  for (const o of n) {
    const a = Object.getOwnPropertyDescriptor(i, o);
    a.enumerable && (a.get ? sl(e, o, () => {
      const s = t._zod.def.shape[o];
      return r ? r(s, o) : s;
    }) : ll(e, o, r ? r(a.value, o) : a.value));
  }
}
function Uf(e, t) {
  for (const n of Reflect.ownKeys(t)) {
    const r = Object.getOwnPropertyDescriptor(t, n);
    r.enumerable && (r.get ? sl(e, n, () => t[n]) : ll(e, n, r.value));
  }
}
function Le(...e) {
  const t = {};
  for (const n of e) {
    const r = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, r);
  }
  return Object.defineProperties({}, t);
}
function Vf(e) {
  return JSON.stringify(e);
}
function qf(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const ul = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Pn(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const Jf = /* @__PURE__ */ Sr(() => {
  var e;
  if (tt.jitless || typeof navigator < "u" && ((e = navigator == null ? void 0 : navigator.userAgent) != null && e.includes("Cloudflare")))
    return !1;
  try {
    const t = Function;
    return new t(""), !0;
  } catch {
    return !1;
  }
});
function Qt(e) {
  if (Pn(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  const n = t.prototype;
  return !(Pn(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function cl(e) {
  return Qt(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
const Wf = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function en(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ct(e, t, n) {
  const r = new e._zod.constr(t ?? e._zod.def);
  return (!t || n != null && n.parent) && (r._zod.parent = e), r;
}
function j(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if ((t == null ? void 0 : t.message) !== void 0) {
    if ((t == null ? void 0 : t.error) !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function fl(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function Hf(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
const dl = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Kf = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Yf(e, t) {
  const n = e._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const o = {};
  return Dt(o, e, Ir(e, t)), Ct(e, Le(n, { shape: o, checks: [] }));
}
function Ir(e, t) {
  var i;
  const n = pt(e), r = [];
  for (const o of Reflect.ownKeys(t)) {
    if (!((i = Object.getOwnPropertyDescriptor(n, o)) != null && i.enumerable))
      throw new Error(`Unrecognized key: "${String(o)}"`);
    t[o] && r.push(o);
  }
  return r;
}
function Gf(e, t) {
  const n = e._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const o = new Set(Ir(e, t)), a = {};
  return Dt(a, e, Reflect.ownKeys(pt(e)).filter((s) => !o.has(s))), Ct(e, Le(n, { shape: a, checks: [] }));
}
function Xf(e, t) {
  if (!Qt(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = e._zod.def.checks;
  if (n && n.length > 0) {
    const i = pt(e);
    for (const o of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(i, o) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return Ct(e, Le(e._zod.def, { shape: pl(e, t) }));
}
function pl(e, t) {
  const n = {};
  return Dt(n, e, Reflect.ownKeys(pt(e))), Uf(n, t), n;
}
function Qf(e, t) {
  if (!Qt(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return Ct(e, Le(e._zod.def, { shape: pl(e, t) }));
}
function ed(e, t) {
  var i, o;
  if (!((i = t == null ? void 0 : t._zod) != null && i.def))
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if ((o = e._zod.def.checks) != null && o.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  Dt(n, e, Reflect.ownKeys(pt(e))), Dt(n, t, Reflect.ownKeys(pt(t)));
  const r = Le(e._zod.def, {
    shape: n,
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return Ct(e, r);
}
function ea(e, t, n, r = "partial") {
  const o = t._zod.def.checks;
  if (o && o.length > 0)
    throw new Error(`.${r}() cannot be used on object schemas containing refinements`);
  const s = n ? new Set(Ir(t, n)) : void 0, u = {};
  return Dt(u, t, Reflect.ownKeys(pt(t)), e && ((c, l) => s && !s.has(l) ? c : new e({ type: "optional", innerType: c }))), Ct(t, Le(t._zod.def, { shape: u, checks: [] }));
}
function td(e, t, n) {
  const r = n ? new Set(Ir(t, n)) : void 0, i = {};
  return Dt(i, t, Reflect.ownKeys(pt(t)), (o, a) => (
    // overwrite with non-optional
    r && !r.has(a) ? o : new e({ type: "nonoptional", innerType: o })
  )), Ct(t, Le(t._zod.def, { shape: i }));
}
function dt(e, t = 0) {
  var n;
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (((n = e.issues[r]) == null ? void 0 : n.continue) !== !0)
      return !0;
  return !1;
}
function nd(e, t = 0) {
  var n;
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (((n = e.issues[r]) == null ? void 0 : n.continue) === !1)
      return !0;
  return !1;
}
function Mt(e, t) {
  return t.map((n) => {
    var r;
    return (r = n).path ?? (r.path = []), n.path.unshift(e), n;
  });
}
function pn(e) {
  return typeof e == "string" ? e : e == null ? void 0 : e.message;
}
function ta(e) {
  const t = [];
  for (const n of e ?? []) {
    const r = n._zod.def;
    if (!/_(length|size)$|_equals$/.test(r.check))
      break;
    const i = r.maximum ?? r.length ?? r.size;
    i >= 0 && t.push([i, n]);
  }
  return t;
}
function wi(e, t, n) {
  var r;
  for (let i = t; i < e.length; i++)
    (r = e[i]).schema ?? (r.schema = n);
}
function St(e, t, n) {
  var u, c, l, f, p, d, h, m, v, g;
  var r;
  const i = (c = (u = e.inst) == null ? void 0 : u._zod) == null ? void 0 : c.traits;
  i != null && i.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
  const o = e.schema !== e.inst ? (f = (l = e.schema) == null ? void 0 : l._zod.def) == null ? void 0 : f.error : void 0, a = e.message ? e.message : pn((h = (d = (p = e.inst) == null ? void 0 : p._zod.def) == null ? void 0 : d.error) == null ? void 0 : h.call(d, e)) ?? pn(o == null ? void 0 : o(e)) ?? pn((m = t == null ? void 0 : t.error) == null ? void 0 : m.call(t, e)) ?? pn((v = n.customError) == null ? void 0 : v.call(n, e)) ?? pn((g = n.localeError) == null ? void 0 : g.call(n, e)) ?? "Invalid input", s = {};
  for (const w of Object.keys(e))
    w === "inst" || w === "schema" || w === "continue" || w === "input" || w === "__proto__" || (s[w] = e[w]);
  return s.path ?? (s.path = []), s.message = a, t != null && t.reportInput && (s.input = e.input), s;
}
const rd = /[\uD800-\uDBFF]/;
function eo(e) {
  const t = e.length;
  if (!rd.test(e))
    return t;
  let n = t;
  for (let r = 0; r < t - 1; r++)
    (e.charCodeAt(r) & 64512) === 55296 && (e.charCodeAt(r + 1) & 64512) === 56320 && (n--, r++);
  return n;
}
function to(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function id(e) {
  const t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      const n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
function Mn(...e) {
  const [t, n, r] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: r
  } : { ...t };
}
function od(e, t) {
  for (const n in t) {
    const r = Object.getOwnPropertyDescriptor(t, n);
    r.get ? Object.defineProperty(e, n, { ...r, enumerable: !1 }) : ad(e, n, r.value);
  }
}
function It(e, t, n, r = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: r, value: n }), n;
}
function no(e, t, n) {
  return It(e, t, n, !1);
}
function hl(e, t) {
  for (const n in e) {
    const r = e[n];
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return It(this, n, r(this));
      },
      set(i) {
        It(this, n, i);
      }
    });
  }
  return t;
}
function ad(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : It(this, t, n.bind(this));
    },
    set(r) {
      It(this, t, r);
    }
  });
}
function sd(e, t) {
  const n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
let Br, bt = !1;
const ld = {
  configurable: !0,
  get() {
    bt = !0;
  }
};
function te(e, t, n) {
  const r = Object.getPrototypeOf(e._zod);
  if (t in r && Br !== e._zod) {
    Br = void 0;
    return;
  }
  Br = e._zod, Object.defineProperty(r, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, ld);
      const i = bt;
      bt = !1;
      try {
        const o = n(this);
        return bt ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: o }), bt = bt || i, o;
      } catch (o) {
        throw delete this[t], bt = bt || i, o;
      }
    },
    set(i) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: i });
    }
  });
}
function ud(e, t, n, r) {
  const i = sd(e, t);
  i && Object.defineProperty(i, t, {
    configurable: !0,
    get() {
      const o = { configurable: !0, writable: !0, enumerable: r, value: void 0 };
      return Object.defineProperty(this, t, o), o.value = n(this), Object.defineProperty(this, t, o), o.value;
    },
    set(o) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: r, value: o });
    }
  });
}
const cd = "~constantCatch";
function fd(e) {
  const t = () => e;
  return t[cd] = !0, t;
}
var na;
const Ur = { value: void 0, enumerable: !1 };
let ra = "captureStackTrace" in Error ? Error : null;
function dd(e) {
  const t = ra;
  if (t) {
    const n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return ra = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
function z(e, t, n, r) {
  const i = {};
  function o(p) {
    this.def = p, this.constr = f, this.traits = /* @__PURE__ */ new Set();
  }
  o.prototype = i;
  const a = n, s = a && /* @__PURE__ */ new WeakSet();
  function u(p, d) {
    if (p._zod) {
      if (p._zod.traits.has(e))
        return;
    } else {
      Ur.value = new o(d);
      try {
        Object.defineProperty(p, "_zod", Ur);
      } finally {
        Ur.value = void 0;
      }
    }
    if (p._zod.traits.add(e), t(p, d), s) {
      const m = Object.getPrototypeOf(p), v = p._zod.constr.prototype;
      let g = m;
      for (; g && g !== v; )
        g = Object.getPrototypeOf(g);
      const w = g ?? m;
      s.has(w) || (s.add(w), od(w, a));
    }
    const h = f.prototype;
    for (const m in h)
      Object.prototype.hasOwnProperty.call(h, m) && (m in p || (p[m] = h[m].bind(p)));
  }
  const c = (r == null ? void 0 : r.Parent) ?? Object;
  class l extends c {
  }
  Object.defineProperty(l, "name", { value: e });
  function f(p) {
    var v;
    const d = r != null && r.Parent ? dd(l) : this;
    u(d, p);
    const h = d._zod.deferred;
    if (h) {
      for (const g of h)
        g();
      d._zod.deferred = void 0;
    }
    const m = (v = globalThis.__zod_globalConfig) == null ? void 0 : v.postProcessor;
    return m && m(d), d;
  }
  return Object.defineProperty(f, "init", { value: u }), Object.defineProperty(f, Symbol.hasInstance, {
    value: (p) => {
      var d, h;
      return r != null && r.Parent && p instanceof r.Parent ? !0 : (h = (d = p == null ? void 0 : p._zod) == null ? void 0 : d.traits) == null ? void 0 : h.has(e);
    }
  }), Object.defineProperty(f, "name", { value: e }), f;
}
class Rt extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class ml extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
(na = globalThis).__zod_globalConfig ?? (na.__zod_globalConfig = {});
const tt = globalThis.__zod_globalConfig;
function lt(e) {
  return e && Object.assign(tt, e), tt;
}
function pd() {
  const e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, ki, 2)), e.message;
}
function hd(e) {
  this._zod.message = e;
}
const md = {
  get: pd,
  set: hd,
  enumerable: !0,
  configurable: !0
}, Vr = { value: void 0, enumerable: !1 }, ia = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), gd = (e, t) => {
  e.name = "$ZodError", Vr.value = t, Object.defineProperty(e, "issues", Vr), Vr.value = void 0, Object.defineProperty(e, "message", md);
  const n = Object.getPrototypeOf(e);
  ia.has(n) || (ia.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = () => this.message;
      return Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 });
    }
  }));
}, yd = z("$ZodError", gd);
function bd(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
function vd(e, t = (n) => n.message) {
  const n = {}, r = [];
  for (const i of e.issues)
    i.path.length > 0 ? bd(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
  return { formErrors: r, fieldErrors: n };
}
function kd(e, t = (n) => n.message) {
  const n = { _errors: [] }, r = (i, o = []) => {
    for (const a of i.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((s) => r({ issues: s }, [...o, ...a.path]));
      else if (a.code === "invalid_key")
        r({ issues: a.issues }, [...o, ...a.path]);
      else if (a.code === "invalid_element")
        r({ issues: a.issues }, [...o, ...a.path]);
      else {
        const s = [...o, ...a.path];
        if (s.length === 0)
          n._errors.push(t(a));
        else {
          let u = n, c = 0;
          for (; c < s.length; ) {
            const l = s[c], f = c === s.length - 1;
            if (l === "_errors") {
              f && u._errors.push(t(a)), c++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(u, l) || Object.defineProperty(u, l, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const p = u[l];
            f && p._errors.push(t(a)), u = p, c++;
          }
        }
      }
  };
  return r(e), n;
}
function Er(e, t) {
  return { callee: (t == null ? void 0 : t.callee) ?? e, Err: t == null ? void 0 : t.Err };
}
const ro = (e) => {
  const t = (n, r, i, o) => {
    const a = i ? { ...i, async: !1 } : { async: !1 }, s = n._zod.run({ value: r, issues: [] }, a);
    if (s instanceof Promise)
      throw new Rt();
    if (s.issues.length) {
      const u = new ((o == null ? void 0 : o.Err) ?? e)(s.issues.map((c) => St(c, a, lt())));
      throw ul(u, (o == null ? void 0 : o.callee) ?? t), u;
    }
    return s.value;
  };
  return t;
}, io = (e) => {
  const t = async (n, r, i, o) => {
    const a = i ? { ...i, async: !0 } : { async: !0 };
    let s = n._zod.run({ value: r, issues: [] }, a);
    if (s instanceof Promise && (s = await s), s.issues.length) {
      const u = new ((o == null ? void 0 : o.Err) ?? e)(s.issues.map((c) => St(c, a, lt())));
      throw ul(u, (o == null ? void 0 : o.callee) ?? t), u;
    }
    return s.value;
  };
  return t;
}, oo = (e) => (t, n, r) => {
  const i = r ? { ...r, async: !1 } : { async: !1 }, o = t._zod.run({ value: n, issues: [] }, i);
  if (o instanceof Promise)
    throw new Rt();
  return o.issues.length ? gl(e, o.issues, i) : { success: !0, data: o.value };
};
function gl(e, t, n) {
  let r;
  return {
    success: !1,
    get error() {
      return r || (r = new e(t.map((i) => St(i, n, lt()))), t = void 0, n = void 0), r;
    },
    set error(i) {
      r = i, t = void 0, n = void 0;
    }
  };
}
const ao = (e) => async (t, n, r) => {
  const i = r ? { ...r, async: !0 } : { async: !0 };
  let o = t._zod.run({ value: n, issues: [] }, i);
  return o instanceof Promise && (o = await o), o.issues.length ? gl(e, o.issues, i) : { success: !0, data: o.value };
}, wd = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), xd = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), _d = (e, t, n) => {
  const r = e._zod.bag.validator;
  if (r !== void 0) {
    if (r(t) !== wd)
      return !0;
    if (r.definite === !0 && n === void 0)
      return !1;
  }
  return Sd(e, t, n);
};
function Sd(e, t, n) {
  const r = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, i = e._zod.bag.fallbackRun;
  let o;
  if (i ? (r[xd] = !0, o = i({ value: t, issues: [] }, r)) : o = e._zod.run({ value: t, issues: [] }, r), o instanceof Promise)
    throw new Rt();
  return o.issues.length === 0;
}
const Id = async (e, t, n) => {
  const r = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let i = e._zod.run({ value: t, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length === 0;
}, Ed = (e) => {
  const t = ro(e), n = (r, i, o, a) => {
    const s = o ? { ...o, direction: "backward" } : { direction: "backward" };
    return t(r, i, s, Er(n, a));
  };
  return n;
}, Cd = (e) => {
  const t = ro(e), n = (r, i, o, a) => t(r, i, o, Er(n, a));
  return n;
}, Ad = (e) => {
  const t = io(e), n = async (r, i, o, a) => {
    const s = o ? { ...o, direction: "backward" } : { direction: "backward" };
    return await t(r, i, s, Er(n, a));
  };
  return n;
}, zd = (e) => {
  const t = io(e), n = async (r, i, o, a) => await t(r, i, o, Er(n, a));
  return n;
}, Td = (e) => (t, n, r) => {
  const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return oo(e)(t, n, i);
}, Od = (e) => (t, n, r) => oo(e)(t, n, r), Pd = (e) => async (t, n, r) => {
  const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return ao(e)(t, n, i);
}, Md = (e) => async (t, n, r) => ao(e)(t, n, r), Rd = /^[cC][0-9a-z]{6,}$/, $d = /^[0-9a-z]+$/, Dd = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Nd = /^[0-9a-vA-V]{20}$/, Ld = /^[A-Za-z0-9]{27}$/, Fd = /^[a-zA-Z0-9_-]{21}$/;
function jd(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
const Zd = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Bd = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, oa = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Ud = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Vd = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function qd() {
  return new RegExp(Vd, "u");
}
const Jd = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Wd = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Hd = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Kd = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Yd = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Gd = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, Xd = /^https?$/, Qd = /^\+[1-9]\d{6,14}$/, yl = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function ep(e) {
  return new RegExp(`^${e}$`);
}
const tp = /* @__PURE__ */ ep(yl);
function xi(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function np(e) {
  return new RegExp(`^${xi(e)}$`);
}
function rp(e) {
  const t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${xi({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, r = e.local ? `${n}|${xi({ precision: e.precision })}` : n;
  return new RegExp(`^${yl}T(?:${r})$`);
}
const ip = /^[\s\S]{0,}$/, op = /^-?\d+$/, so = /^-?\d+(?:\.\d+)?$/, ap = /^(?:true|false)$/i, sp = /^null$/i, lp = /^[^A-Z]*$/, up = /^[^a-z]*$/, ze = /* @__PURE__ */ z("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), lo = (e) => {
  const t = e.value;
  return !jf(t) && t.length !== void 0;
}, cr = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, bl = /* @__PURE__ */ z("$ZodCheckLessThan", (e, t) => {
  ze.init(e, t);
  const n = cr[typeof t.value];
  e._zod.check = (r) => {
    (t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
      origin: cr[typeof r.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: r.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), vl = /* @__PURE__ */ z("$ZodCheckGreaterThan", (e, t) => {
  ze.init(e, t);
  const n = cr[typeof t.value];
  e._zod.check = (r) => {
    (t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
      origin: cr[typeof r.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: r.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), cp = /* @__PURE__ */ z("$ZodCheckMultipleOf", (e, t) => {
  ze.init(e, t), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : Zf(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), fp = /* @__PURE__ */ z("$ZodCheckNumberFormat", (e, t) => {
  var a;
  ze.init(e, t), t.format = t.format || "float64";
  const n = (a = t.format) == null ? void 0 : a.includes("int"), r = n ? "int" : "number", [i, o] = dl[t.format];
  e._zod.check = (s) => {
    const u = s.value;
    if (n) {
      if (!Number.isInteger(u)) {
        s.issues.push({
          expected: r,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? s.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: r,
          inclusive: !0,
          continue: !t.abort
        }) : s.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: r,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < i && s.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > o && s.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), dp = /* @__PURE__ */ z("$ZodCheckMaxLength", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length;
    if ((typeof i == "string" && o > t.maximum ? eo(i) : o) <= t.maximum)
      return;
    const s = to(i);
    r.issues.push({
      origin: s,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: i,
      inst: e,
      continue: !t.abort
    });
  };
}), pp = /* @__PURE__ */ z("$ZodCheckMinLength", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length;
    if ((typeof i == "string" && o >= t.minimum && o < t.minimum * 2 ? eo(i) : o) >= t.minimum)
      return;
    const s = to(i);
    r.issues.push({
      origin: s,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: i,
      inst: e,
      continue: !t.abort
    });
  };
}), hp = /* @__PURE__ */ z("$ZodCheckLengthEquals", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length, a = typeof i == "string" && o >= t.length && o <= t.length * 2 ? eo(i) : o;
    if (a === t.length)
      return;
    const s = to(i), u = a > t.length;
    r.issues.push({
      origin: s,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Cr = /* @__PURE__ */ z("$ZodCheckStringFormat", (e, t) => {
  var n, r;
  ze.init(e, t), t.pattern ? (n = e._zod).check ?? (n.check = (i) => {
    t.pattern.lastIndex = 0, !t.pattern.test(i.value) && i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: i.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (r = e._zod).check ?? (r.check = () => {
  });
}), mp = /* @__PURE__ */ z("$ZodCheckRegex", (e, t) => {
  Cr.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), gp = /* @__PURE__ */ z("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = lp), Cr.init(e, t);
}), yp = /* @__PURE__ */ z("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = up), Cr.init(e, t);
}), bp = /* @__PURE__ */ z("$ZodCheckIncludes", (e, t) => {
  ze.init(e, t);
  const n = en(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = r, e._zod.check = (i) => {
    i.value.includes(t.includes, t.position) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), vp = /* @__PURE__ */ z("$ZodCheckStartsWith", (e, t) => {
  ze.init(e, t);
  const n = new RegExp(`^${en(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.check = (r) => {
    r.value.startsWith(t.prefix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), kp = /* @__PURE__ */ z("$ZodCheckEndsWith", (e, t) => {
  ze.init(e, t);
  const n = new RegExp(`.*${en(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.check = (r) => {
    r.value.endsWith(t.suffix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function aa(e, t, n) {
  e.issues.length && t.issues.push(...Mt(n, e.issues));
}
const wp = /* @__PURE__ */ z("$ZodCheckProperties", (e, t) => {
  ze.init(e, t), no(e, Symbol.iterator, function* () {
    yield e;
  });
  let n;
  e._zod.check = (r) => {
    if (r.value == null) {
      r.issues.push({ expected: "object", code: "invalid_type", input: r.value, inst: e });
      return;
    }
    n ?? (n = Reflect.ownKeys(t.shape).map((a) => [a, t.shape[a]]));
    const i = r.value;
    let o;
    for (const [a, s] of n) {
      const u = s._zod.run({ value: i[a], issues: [] }, {});
      u instanceof Promise ? (o ?? (o = []), o.push(u.then((c) => aa(c, r, a)))) : aa(u, r, a);
    }
    if (o)
      return Promise.all(o).then(() => {
      });
  };
}), xp = /* @__PURE__ */ z("$ZodCheckOverwrite", (e, t) => {
  ze.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});
class _p {
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(t) {
    this.indent += 1;
    try {
      t(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const r = t.split(`
`).filter((a) => a), i = Math.min(...r.map((a) => a.length - a.trimStart().length)), o = r.map((a) => a.slice(i)).map((a) => " ".repeat(this.indent * 2) + a);
    for (const a of o)
      this.content.push(a);
  }
  compile() {
    const t = Function, n = (this == null ? void 0 : this.content) ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const Sp = {
  major: 4,
  minor: 6,
  patch: 7
}, de = /* @__PURE__ */ z("$ZodType", (e, t) => {
  var o;
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Sp;
  const r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r != null && r.length ? [...r] : [];
  for (const a of i)
    for (const s of a._zod.onattach)
      s(e);
  if (i.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), (o = e._zod.deferred) == null || o.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const a = (u, c, l) => {
      if (u.memo)
        return u;
      let f = dt(u), p;
      for (const d of c) {
        if (d._zod.def.when) {
          if (nd(u) || !d._zod.def.when(u))
            continue;
        } else if (f)
          continue;
        const h = u.issues.length, m = d._zod.check(u);
        if (m instanceof Promise && (l == null ? void 0 : l.async) === !1)
          throw new Rt();
        if (p || m instanceof Promise)
          p = (p ?? Promise.resolve()).then(async () => {
            await m, u.issues.length !== h && (wi(u.issues, h, e), f || (f = dt(u, h)));
          });
        else {
          if (u.issues.length === h)
            continue;
          wi(u.issues, h, e), f || (f = dt(u, h));
        }
      }
      return p ? p.then(() => u) : u;
    }, s = (u, c, l) => {
      if (dt(u))
        return u.aborted = !0, u;
      const f = a(c, i, l);
      if (f instanceof Promise) {
        if (l.async === !1)
          throw new Rt();
        return f.then((p) => e._zod.parse(p, l));
      }
      return e._zod.parse(f, l);
    };
    e._zod.run = (u, c) => {
      if (c.skipChecks)
        return e._zod.parse(u, c);
      if (c.direction === "backward") {
        const f = e._zod.parse({ value: u.value, issues: [] }, { ...c, skipChecks: !0 });
        return f instanceof Promise ? f.then((p) => s(p, u, c)) : s(f, u, c);
      }
      const l = e._zod.parse(u, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new Rt();
        return l.then((f) => a(f, i, c));
      }
      return a(l, i, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return no(this, "~standard", wl(this));
  },
  set "~standard"(e) {
    It(this, "~standard", e);
  }
}), kl = (e, t) => e.issues.length ? { issues: e.issues.map((n) => St(n, t, lt())) } : { value: e.value };
async function Ip(e, t) {
  const n = { async: !0 };
  return kl(await e._zod.run({ value: t, issues: [] }, n), n);
}
function wl(e) {
  return {
    validate: (t) => {
      const n = { async: !1 };
      try {
        const r = e._zod.run({ value: t, issues: [] }, n);
        if (!(r instanceof Promise))
          return kl(r, n);
      } catch {
      }
      return Ip(e, t);
    },
    vendor: "zod",
    version: 1
  };
}
const uo = /* @__PURE__ */ z("$ZodString", (e, t) => {
  de.init(e, t), e._zod.pattern = t.pattern ?? ip, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), he = /* @__PURE__ */ z("$ZodStringFormat", (e, t) => {
  Cr.init(e, t), uo.init(e, t);
}), Ep = /* @__PURE__ */ z("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Bd), he.init(e, t);
}), Cp = /* @__PURE__ */ z("$ZodUUID", (e, t) => {
  if (t.version) {
    const r = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (r === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = oa(r));
  } else
    t.pattern ?? (t.pattern = oa());
  he.init(e, t);
}), Ap = /* @__PURE__ */ z("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Ud), he.init(e, t);
}), xl = 1, fr = 2;
function _l(e) {
  try {
    return typeof URL < "u" && typeof URL.canParse == "function" ? URL.canParse(e) : (new URL(e), !0);
  } catch {
    return !1;
  }
}
function zp(e, t) {
  return !("normalize" in t) && !("hostname" in t) && !("protocol" in t) ? _l(e) || fr : Tp(e, t);
}
function Tp(e, t) {
  var n;
  if (!t.normalize && ((n = t.protocol) == null ? void 0 : n.source) === Xd.source && !/^https?:\/\//i.test(e))
    return xl;
  try {
    if (typeof URL < "u") {
      const r = URL;
      if (typeof r.parse == "function")
        return r.parse(e) ?? fr;
    }
    return new URL(e);
  } catch {
    return fr;
  }
}
const Op = /[\t\n\r]/g;
function sa(e) {
  return e.replace(Op, "");
}
function Pp(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
function Mp(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
const Rp = /* @__PURE__ */ z("$ZodURL", (e, t) => {
  he.init(e, t), e._zod.check = (n) => {
    try {
      const r = n.value.trim(), i = zp(r, t);
      if (i === xl) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (i === fr) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (i === !0) {
        n.value = sa(r);
        return;
      }
      t.hostname && !Pp(i, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !Mp(i, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? i.href : sa(r);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), $p = /* @__PURE__ */ z("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = qd()), he.init(e, t);
}), Dp = /* @__PURE__ */ z("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? Fd : jd(t.length)), he.init(e, t);
}), Np = /* @__PURE__ */ z("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Rd), he.init(e, t);
}), Lp = /* @__PURE__ */ z("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = $d), he.init(e, t);
}), Fp = /* @__PURE__ */ z("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Dd), he.init(e, t);
}), jp = /* @__PURE__ */ z("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Nd), he.init(e, t);
}), Zp = /* @__PURE__ */ z("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Ld), he.init(e, t);
}), Bp = /* @__PURE__ */ z("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = rp(t)), he.init(e, t);
}), Up = /* @__PURE__ */ z("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = tp), he.init(e, t);
}), Vp = /* @__PURE__ */ z("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = np(t)), he.init(e, t);
}), qp = /* @__PURE__ */ z("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Zd), he.init(e, t);
}), Jp = /* @__PURE__ */ z("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Jd), he.init(e, t);
}), Wp = /^[0-9a-fA-F:.]+$/;
function Sl(e) {
  return Wp.test(e) ? _l(`http://[${e}]`) : !1;
}
const Hp = /* @__PURE__ */ z("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Wd), he.init(e, t), e._zod.check = (n) => {
    Sl(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Kp = /* @__PURE__ */ z("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Hd), he.init(e, t);
});
function Yp(e) {
  const t = e.split("/");
  if (t.length !== 2)
    return !1;
  const [n, r] = t;
  if (!r)
    return !1;
  const i = Number(r);
  return `${i}` !== r || i < 0 || i > 128 ? !1 : Sl(n);
}
const Gp = /* @__PURE__ */ z("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Kd), he.init(e, t), e._zod.check = (n) => {
    Yp(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Il(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const El = /^[0-9a-zA-Z+/]*={0,2}$/, Xp = /* @__PURE__ */ z("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = El), he.init(e, t), e._zod.check = (n) => {
    Il(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), co = /^[A-Za-z0-9_-]*$/;
function Qp(e) {
  if (!co.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (r) => r === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Il(n);
}
const eh = /* @__PURE__ */ z("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = co), he.init(e, t), e._zod.check = (n) => {
    Qp(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), th = /* @__PURE__ */ z("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Qd), he.init(e, t);
});
function nh(e, t = null) {
  try {
    const n = e.split(".");
    if (n.length !== 3)
      return !1;
    const [r] = n;
    if (!r)
      return !1;
    const i = JSON.parse(atob(r));
    return !("typ" in i && (i == null ? void 0 : i.typ) !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
  } catch {
    return !1;
  }
}
const rh = /* @__PURE__ */ z("$ZodJWT", (e, t) => {
  he.init(e, t), e._zod.check = (n) => {
    nh(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Cl = /* @__PURE__ */ z("$ZodNumber", (e, t) => {
  de.init(e, t), e._zod.pattern = so, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const i = n.value;
    if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i))
      return n;
    const o = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: i,
      inst: e,
      ...o ? { received: o } : {}
    }), n;
  };
}), ih = /* @__PURE__ */ z("$ZodNumberFormat", (e, t) => {
  fp.init(e, t), Cl.init(e, t);
}), oh = /* @__PURE__ */ z("$ZodBoolean", (e, t) => {
  de.init(e, t), e._zod.pattern = ap, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const i = n.value;
    return typeof i == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: i,
      inst: e
    }), n;
  };
}), ah = /* @__PURE__ */ z("$ZodNull", (e, t) => {
  de.init(e, t), e._zod.pattern = sp, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, r) => {
    const i = n.value;
    return i === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: i,
      inst: e
    }), n;
  };
}), sh = /* @__PURE__ */ z("$ZodUnknown", (e, t) => {
  de.init(e, t), e._zod.parse = (n) => n;
}), lh = /* @__PURE__ */ z("$ZodNever", (e, t) => {
  de.init(e, t), e._zod.parse = (n, r) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
});
function uh(e, t) {
  const n = ta(e._zod.def.checks);
  if (!n.length)
    return;
  const r = Math.min(...n.map((o) => o[0])), i = e._zod.parse;
  e._zod.parse = (o, a) => {
    const s = t(o.value);
    if (s > r && !(a != null && a.skipChecks) && (a == null ? void 0 : a.direction) !== "backward") {
      for (const [u, c] of ta(e._zod.def.checks))
        if (s > u && c._zod.def.when(o)) {
          const l = o.issues.length;
          return c._zod.check(o), o.issues[l].continue = !1, wi(o.issues, l, e), o;
        }
    }
    return i(o, a);
  };
}
const ch = (e) => Array.isArray(e) ? e.length : -1;
function la(e, t, n) {
  e.issues.length && t.issues.push(...Mt(n, e.issues)), t.value[n] = e.value;
}
const fh = /* @__PURE__ */ z("$ZodArray", (e, t) => {
  de.init(e, t);
  const n = tt.memoizer;
  n == null || n.attach(e), e._zod.parse = (r, i) => {
    const o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    r.value = n ? n.alloc(e, r, Array(o.length), i) : Array(o.length);
    const a = [], s = i == null ? void 0 : i.abortEarly;
    for (let u = 0; u < o.length; u++) {
      const c = o[u], l = t.element._zod.run({
        value: c,
        issues: []
      }, i);
      if (l instanceof Promise)
        a.push(l.then((f) => la(f, r, u)));
      else if (la(l, r, u), s && l.issues.length !== 0 && dt(l))
        break;
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  }, uh(e, ch);
});
function dr(e, t, n, r, i, o) {
  const a = n in r, s = o === "optional";
  if (!(!a && s && i === "optional")) {
    if (e.issues.length) {
      if (i !== void 0 && s && !a)
        return;
      t.issues.push(...Mt(n, e.issues));
    }
    if (!a && i === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? (a || i === "defaulted" && !s) && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
const dh = [];
function Al(e) {
  var a, s, u, c;
  const t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : dh, i = r.length ? [...t, ...r] : t;
  for (const l of i)
    if (!((c = (u = (s = (a = e.shape) == null ? void 0 : a[l]) == null ? void 0 : s._zod) == null ? void 0 : u.traits) != null && c.has("$ZodType")))
      throw new Error(`Invalid element at key "${String(l)}": expected a Zod schema`);
  const o = Hf(e.shape);
  return {
    ...e,
    allKeys: i,
    symbolKeys: r,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(o)
  };
}
function zl(e, t, n, r, i, o, a) {
  const s = [], u = i.keySet, c = i.catchall._zod, l = c.def.type, f = c.optin, p = c.optout;
  let d = 0;
  for (const h in t) {
    if (a && n.issues.length !== d) {
      if (dt(n, d))
        break;
      d = n.issues.length;
    }
    if (u.has(h))
      continue;
    if (h === "__proto__") {
      l === "never" && s.push(h);
      continue;
    }
    if (l === "never") {
      s.push(h);
      continue;
    }
    const m = c.run({ value: t[h], issues: [] }, r);
    m instanceof Promise ? e.push(m.then((v) => dr(v, n, h, t, f, p))) : dr(m, n, h, t, f, p);
  }
  return s.length && n.issues.push({
    code: "unrecognized_keys",
    keys: s,
    input: t,
    inst: o,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
const ph = /* @__PURE__ */ z("$ZodObject", (e, t) => {
  de.init(e, t);
  const n = Object.getOwnPropertyDescriptor(t, "shape"), r = n != null && n.get ? n.get.raw : t.shape ?? {};
  if (r) {
    const c = () => {
      const l = { ...r };
      return Object.defineProperty(t, "shape", { value: l }), c.raw = l, l;
    };
    c.raw = r, Object.defineProperty(t, "shape", { get: c });
  }
  const i = Sr(() => Al(t));
  te(e, "propValues", (c) => {
    const l = c.def.shape, f = {};
    for (const p in l) {
      const d = l[p]._zod;
      if (d.values) {
        Object.prototype.hasOwnProperty.call(f, p) || ut(f, p, /* @__PURE__ */ new Set());
        for (const h of d.values)
          f[p].add(h);
        d.optin !== void 0 && f[p].add(void 0);
      }
    }
    return f;
  });
  const o = Pn, a = t.catchall;
  let s;
  const u = tt.memoizer;
  u == null || u.attach(e), e._zod.parse = (c, l) => {
    s ?? (s = i.value);
    const f = c.value;
    if (!o(f))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: f,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, l) : {};
    const p = [], d = s.shape, h = l == null ? void 0 : l.abortEarly;
    let m = c.issues.length;
    for (const v of s.allKeys) {
      if (h && c.issues.length !== m) {
        if (dt(c, m))
          break;
        m = c.issues.length;
      }
      if (v === "__proto__")
        continue;
      const g = d[v], w = g._zod.optin, I = g._zod.optout, S = g._zod.run({ value: f[v], issues: [] }, l);
      S instanceof Promise ? p.push(S.then((_) => dr(_, c, v, f, w, I))) : dr(S, c, v, f, w, I);
    }
    return a ? zl(p, f, c, l, i.value, e, h === !0) : p.length ? Promise.all(p).then(() => c) : c;
  };
}), hh = /* @__PURE__ */ z("$ZodObjectJIT", (e, t) => {
  ph.init(e, t);
  const n = e._zod.parse, r = Sr(() => Al(t)), i = tt.memoizer, o = (d) => {
    var _, y;
    const h = r.value, m = h.symbolKeys, v = new _p(["payload", "ctx"], { shape: d, inst: e, memo: i, syms: m }), g = (C) => `shape[${C}]._zod.run({ value: input[${C}], issues: [] }, ctx)`, w = (C, R) => `
          let ${C}_ab = false;
          for (let i = 0; i < ${C}.issues.length; i++) {
            const iss = ${C}.issues[i];
            iss.path = iss.path ? [${R}, ...iss.path] : [${R}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${C}_ab = true;
          }
          if (${C}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    v.write("const input = payload.value;");
    const I = /* @__PURE__ */ Object.create(null);
    let S = 0;
    for (const C of h.allKeys)
      I[C] = `key_${S++}`;
    v.write(i ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const C of h.allKeys) {
      if (C === "__proto__")
        continue;
      const R = I[C], F = typeof C == "symbol" ? `syms[${m.indexOf(C)}]` : Vf(C), E = `${F} in input`, M = d[C], L = (_ = M == null ? void 0 : M._zod) == null ? void 0 : _.optin, x = L !== void 0, Z = ((y = M == null ? void 0 : M._zod) == null ? void 0 : y.optout) === "optional";
      if (v.write(`const ${R} = ${g(F)};`), x && Z) {
        const B = L === "optional" ? `${R}_present` : `${R}.value !== undefined || ${R}_present`;
        v.write(`
        const ${R}_present = ${E};
        if (!${R}.issues.length || ${R}_present) {
          if (${R}.issues.length) {${w(R, F)}
          }

          if (${B}) {
            newResult[${F}] = ${R}.value;
          }
        }

      `);
      } else x ? (v.write(`
        if (${R}.issues.length) {${w(R, F)}
        }
      `), L === "defaulted" ? v.write(`newResult[${F}] = ${R}.value;`) : v.write(`
        if (${R}.value !== undefined || ${E}) {
          newResult[${F}] = ${R}.value;
        }
      `)) : v.write(`
        const ${R}_present = ${E};
        if (${R}.issues.length) {${w(R, F)}
        }
        if (!${R}_present && !${R}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${F}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${R}_present) {
          newResult[${F}] = ${R}.value;
        }

      `);
    }
    return v.write("payload.value = newResult;"), v.write("return payload;"), v.compile();
  };
  let a;
  const s = Pn, u = !tt.jitless, l = u && Jf.value, f = t.catchall;
  let p;
  e._zod.parse = (d, h) => {
    p ?? (p = r.value);
    const m = d.value;
    return s(m) ? u && l && (h == null ? void 0 : h.async) === !1 && h.jitless !== !0 ? (a || (a = o(t.shape)), d = a(d, h), f ? zl([], m, d, h, p, e, (h == null ? void 0 : h.abortEarly) === !0) : d) : n(d, h) : (d.issues.push({
      expected: "object",
      code: "invalid_type",
      input: m,
      inst: e
    }), d);
  };
});
function ua(e, t, n, r) {
  for (const o of e)
    if (o.issues.length === 0)
      return t.value = o.value, t;
  const i = e.filter((o) => !dt(o));
  return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((o) => o.issues.map((a) => St(a, r, lt())))
  }), t);
}
const Tl = /* @__PURE__ */ z("$ZodUnion", (e, t) => {
  de.init(e, t), te(e, "optin", (r) => r.def.options.some((i) => i._zod.optin === "defaulted") ? "defaulted" : r.def.options.some((i) => i._zod.optin !== void 0) ? "optional" : void 0), te(e, "optout", (r) => r.def.options.some((i) => i._zod.optout === "optional") ? "optional" : void 0), te(e, "values", (r) => {
    if (r.def.options.every((i) => i._zod.values))
      return new Set(r.def.options.flatMap((i) => Array.from(i._zod.values)));
  }), te(e, "pattern", (r) => {
    if (r.def.options.every((i) => i._zod.pattern)) {
      const i = r.def.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${i.map((o) => Xi(o.source)).join("|")})$`);
    }
  });
  const n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (r, i) => {
    if (n)
      return n(r, i);
    let o = !1;
    const a = [];
    for (const s of t.options) {
      const u = s._zod.run({
        value: r.value,
        issues: []
      }, i);
      if (u instanceof Promise)
        a.push(u), o = !0;
      else {
        if (u.issues.length === 0)
          return u;
        a.push(u);
      }
    }
    return o ? Promise.all(a).then((s) => ua(s, r, e, i)) : ua(a, r, e, i);
  };
});
function mh(e) {
  var n;
  const t = /* @__PURE__ */ new Map();
  for (const r of e.options) {
    const i = (n = r._zod.propValues) == null ? void 0 : n[e.discriminator];
    if (!i || i.size === 0)
      throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(r)}"`);
    for (const o of i)
      if (t.has(o)) {
        if (o !== void 0)
          throw new Error(`Duplicate discriminator value "${String(o)}"`);
        t.set(o, null);
      } else
        t.set(o, r);
  }
  return t;
}
const gh = /* @__PURE__ */ z("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, Tl.init(e, t);
  const n = e._zod.parse;
  te(e, "propValues", (i) => {
    var s, u;
    const o = {};
    let a = 0;
    for (const c of i.def.options) {
      const l = c._zod.propValues;
      if (!l || Object.keys(l).length === 0)
        throw new Error(`Invalid discriminated union option at index "${i.def.options.indexOf(c)}"`);
      (s = l[i.def.discriminator]) != null && s.has(void 0) && a++;
      for (const [f, p] of Object.entries(l)) {
        Object.prototype.hasOwnProperty.call(o, f) || ut(o, f, /* @__PURE__ */ new Set());
        for (const d of p)
          o[f].add(d);
      }
    }
    return !i.def.unionFallback && a > 1 && ((u = o[i.def.discriminator]) == null || u.delete(void 0)), o;
  }), t.options.forEach((i, o) => {
    const a = Qi(i._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${o}"`);
  });
  const r = Sr(() => mh(t));
  e._zod.parse = (i, o) => {
    const a = i.value;
    if (!Pn(a))
      return i.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), i;
    const s = a == null ? void 0 : a[t.discriminator], u = r.value.get(s);
    return u && (s !== void 0 || o.direction !== "backward") ? u._zod.run(i, o) : t.unionFallback || o.direction === "backward" ? n(i, o) : (i.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(r.value.keys()).filter((c) => r.value.get(c) !== null),
      input: a,
      path: [t.discriminator],
      inst: e
    }), i);
  };
}), yh = /* @__PURE__ */ z("$ZodIntersection", (e, t) => {
  de.init(e, t), e._zod.parse = (n, r) => {
    const i = n.value, o = t.left._zod.run({ value: i, issues: [] }, r), a = t.right._zod.run({ value: i, issues: [] }, r);
    return o instanceof Promise || a instanceof Promise ? Promise.all([o, a]).then(([u, c]) => ca(n, u, c)) : ca(n, o, a);
  };
});
function _i(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Qt(e) && Qt(t)) {
    const n = Object.keys(t), r = Object.keys(e).filter((o) => n.indexOf(o) !== -1), i = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
    for (const o of r) {
      if (o === "__proto__")
        continue;
      const a = _i(e[o], t[o]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      i[o] = a.data;
    }
    return { valid: !0, data: i };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let r = 0; r < e.length; r++) {
      const i = e[r], o = t[r], a = _i(i, o);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function ca(e, t, n) {
  const r = /* @__PURE__ */ new Map();
  let i;
  const o = /* @__PURE__ */ new Map(), a = (c, l) => {
    var p, d;
    let f;
    if (c.code === "unrecognized_keys" && !((p = c.path) != null && p.length))
      i ?? (i = c), f = c.keys;
    else if (c.code === "invalid_key" && c.origin === "record" && ((d = c.path) == null ? void 0 : d.length) === 1) {
      const h = String(c.path[0]);
      o.has(h) || o.set(h, c), f = [h];
    } else
      return !1;
    for (const h of f)
      r.has(h) || r.set(h, {}), r.get(h)[l] = !0;
    return !0;
  };
  for (const c of t.issues)
    a(c, "l") || e.issues.push(c);
  for (const c of n.issues)
    a(c, "r") || e.issues.push(c);
  const s = [...r].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (s.length) {
    const c = i ? s.filter((l) => i.keys.includes(l)) : [];
    c.length && e.issues.push({ ...i, keys: c });
    for (const l of s)
      !c.includes(l) && o.has(l) && e.issues.push(o.get(l));
  }
  const u = _i(t.value, n.value);
  if (!u.valid) {
    if (dt(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
  }
  return e.value = u.data, e;
}
const bh = /* @__PURE__ */ z("$ZodRecord", (e, t) => {
  de.init(e, t);
  const n = tt.memoizer;
  n == null || n.attach(e), e._zod.parse = (r, i) => {
    const o = r.value;
    if (!Qt(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    const a = [], s = t.keyType._zod.values;
    if (s && !t.partial) {
      r.value = n ? n.alloc(e, r, {}, i) : {};
      const u = /* @__PURE__ */ new Set();
      for (const l of s)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          if (u.add(typeof l == "number" ? l.toString() : l), l === "__proto__")
            continue;
          const f = t.keyType._zod.run({ value: l, issues: [] }, i);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            r.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((h) => St(h, i, lt())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          const p = f.value;
          if (p === "__proto__")
            continue;
          const d = t.valueType._zod.run({ value: o[l], issues: [] }, i);
          d instanceof Promise ? a.push(d.then((h) => {
            h.issues.length && r.issues.push(...Mt(l, h.issues)), r.value[p] = h.value;
          })) : (d.issues.length && r.issues.push(...Mt(l, d.issues)), r.value[p] = d.value);
        }
      let c;
      for (const l in o)
        if (!u.has(l))
          if (t.mode === "loose") {
            if (l === "__proto__")
              continue;
            r.value[l] = o[l];
          } else
            c = c ?? [], c.push(l);
      c && c.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: c,
        continue: !0
      });
    } else {
      r.value = n ? n.alloc(e, r, {}, i) : {};
      let u;
      for (const c of Reflect.ownKeys(o)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(o, c))
          continue;
        let l = t.keyType._zod.run({ value: c, issues: [] }, i);
        if (l instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && so.test(c) && l.issues.length) {
          const h = t.keyType._zod.run({ value: Number(c), issues: [] }, i);
          if (h instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          h.issues.length === 0 && (l = h);
        }
        if (l.issues.length) {
          t.mode === "loose" ? r.value[c] = o[c] : s ? (u = u ?? [], u.push(c)) : r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: l.issues.map((h) => St(h, i, lt())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        const p = l.value;
        if (p === "__proto__")
          continue;
        const d = t.valueType._zod.run({ value: o[c], issues: [] }, i);
        d instanceof Promise ? a.push(d.then((h) => {
          h.issues.length && r.issues.push(...Mt(c, h.issues)), r.value[p] = h.value;
        })) : (d.issues.length && r.issues.push(...Mt(c, d.issues)), r.value[p] = d.value);
      }
      u && u.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: u,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
}), vh = /* @__PURE__ */ z("$ZodEnum", (e, t) => {
  de.init(e, t);
  const n = vi(t.entries), r = new Set(n);
  e._zod.values = r, te(e, "pattern", (i) => {
    const o = vi(i.def.entries).filter((a) => Wf.has(typeof a));
    return new RegExp(o.length ? `^(${o.map((a) => en(a.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (i, o) => {
    const a = i.value;
    return r.has(a) || i.issues.push({
      code: "invalid_value",
      values: n,
      input: a,
      inst: e
    }), i;
  };
}), kh = /* @__PURE__ */ z("$ZodLiteral", (e, t) => {
  de.init(e, t);
  const n = new Set(t.values);
  e._zod.values = n, te(e, "pattern", (r) => {
    const i = r.def.values;
    return new RegExp(i.length ? `^(${i.map((o) => typeof o == "string" ? en(o) : o ? en(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (r, i) => {
    const o = r.value;
    return n.has(o) || r.issues.push({
      code: "invalid_value",
      values: t.values,
      input: o,
      inst: e
    }), r;
  };
}), wh = /* @__PURE__ */ z("$ZodTransform", (e, t) => {
  var n;
  de.init(e, t), e._zod.optin = "optional", (n = tt.memoizer) == null || n.guard(e), e._zod.parse = (r, i) => {
    if (i.direction === "backward")
      throw new ml(e.constructor.name);
    const o = t.transform(r.value, r);
    if (i.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((s) => (r.value = s, r));
    if (o instanceof Promise)
      throw new Rt();
    return r.value = o, r;
  };
});
function fa(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
const Ol = /* @__PURE__ */ z("$ZodOptional", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", te(e, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? /* @__PURE__ */ new Set([...r, void 0]) : void 0;
  }), te(e, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Xi(r.source)})?$`) : void 0;
  }), e._zod.parse = (n, r) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      const i = t.innerType._zod.run({ value: n.value, issues: [] }, r);
      return i instanceof Promise ? i.then((o) => fa(n, o)) : fa(n, i);
    }
    return t.innerType._zod.run(n, r);
  };
}), xh = /* @__PURE__ */ z("$ZodExactOptional", (e, t) => {
  Ol.init(e, t), te(e, "values", (n) => n.def.innerType._zod.values), te(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, r) => t.innerType._zod.run(n, r);
}), _h = /* @__PURE__ */ z("$ZodNullable", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin), te(e, "optout", (n) => n.def.innerType._zod.optout), te(e, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Xi(r.source)}|null)$`) : void 0;
  }), te(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, r) => n.value === null ? n : t.innerType._zod.run(n, r);
}), Sh = /* @__PURE__ */ z("$ZodDefault", (e, t) => {
  de.init(e, t), e._zod.optin = "defaulted", te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => da(o, t)) : da(i, t);
  };
});
function da(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const Ih = /* @__PURE__ */ z("$ZodPrefault", (e, t) => {
  de.init(e, t), e._zod.optin = "defaulted", te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => (r.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, r));
}), Eh = /* @__PURE__ */ z("$ZodNonOptional", (e, t) => {
  de.init(e, t), te(e, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? new Set([...r].filter((i) => i !== void 0)) : void 0;
  }), e._zod.parse = (n, r) => {
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => pa(o, e)) : pa(i, e);
  };
});
function pa(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
function ha(e, t, n, r) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((i) => St(i, r, lt()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
const Ch = /* @__PURE__ */ z("$ZodCatch", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), te(e, "optout", (n) => n.def.innerType._zod.optout), te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    const i = t.innerType._zod.run({ value: n.value, issues: [] }, r);
    return i instanceof Promise ? i.then((o) => ha(n, o, t, r)) : ha(n, i, t, r);
  };
}), Ah = /* @__PURE__ */ z("$ZodPipe", (e, t) => {
  de.init(e, t), te(e, "values", (n) => n.def.in._zod.values), te(e, "optin", (n) => n.def.in._zod.optin), te(e, "optout", (n) => n.def.out._zod.optout), te(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, r) => {
    if (r.direction === "backward") {
      const o = t.out._zod.run(n, r);
      return o instanceof Promise ? o.then((a) => qn(a, t.in, r)) : qn(o, t.in, r);
    }
    const i = t.in._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => qn(o, t.out, r)) : qn(i, t.out, r);
  };
});
function qn(e, t, n) {
  return e.issues.some((r) => r.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
const zh = /* @__PURE__ */ z("$ZodReadonly", (e, t) => {
  de.init(e, t), te(e, "propValues", (n) => n.def.innerType._zod.propValues), te(e, "values", (n) => n.def.innerType._zod.values), te(e, "optin", (n) => {
    var r, i;
    return (i = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optin;
  }), te(e, "optout", (n) => {
    var r, i;
    return (i = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optout;
  }), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then(ma) : ma(i);
  };
});
function ma(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
const Th = /* @__PURE__ */ z("$ZodLazy", (e, t) => {
  de.init(e, t), Bf(e._zod, "innerType", () => {
    const n = t;
    return n._cachedInner || (n._cachedInner = t.getter()), n._cachedInner;
  }), te(e, "pattern", (n) => {
    var r, i;
    return (i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.pattern;
  }), te(e, "propValues", (n) => {
    var r, i;
    return (i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.propValues;
  }), te(e, "optin", (n) => {
    var r, i;
    return ((i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optin) ?? void 0;
  }), te(e, "optout", (n) => {
    var r, i;
    return ((i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optout) ?? void 0;
  }), e._zod.parse = (n, r) => e._zod.innerType._zod.run(n, r);
}), Oh = /* @__PURE__ */ z("$ZodCustom", (e, t) => {
  ze.init(e, t), de.init(e, t), e._zod.parse = (n, r) => n, e._zod.check = (n) => {
    const r = n.value, i = t.fn(r);
    if (i instanceof Promise)
      return i.then((o) => ga(o, n, r, e));
    ga(i, n, r, e);
  };
});
function ga(e, t, n, r) {
  if (!e) {
    const i = {
      code: "custom",
      input: n,
      inst: r,
      // incorporates params.error into issue reporting
      path: [...r._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !r._zod.def.abort
      // params: inst._zod.def.params,
    };
    r._zod.def.params && (i.params = r._zod.def.params), t.issues.push(Mn(i));
  }
}
class Ph extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const Si = "~memo", ya = [];
function Pl(e) {
  return e !== null && typeof e == "object";
}
function qr(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
const Ml = /* @__PURE__ */ new WeakMap(), kn = 0, nr = 1, In = 2;
function rr(e, t, n) {
  const r = Ml.get(e);
  if (r !== void 0)
    return r ? In : kn;
  if (t.has(e))
    return In;
  t.add(e);
  let i = kn;
  const o = (l) => {
    if (i !== In && (l != null && l._zod)) {
      const f = rr(l, t);
      f > i && (i = f);
    }
  }, a = (l, f) => {
    var d;
    let p = kn;
    for (const h of Reflect.ownKeys(l)) {
      const m = Object.getOwnPropertyDescriptor(l, h);
      if (!m.enumerable)
        continue;
      const v = m.get ? nr : (d = m.value) != null && d._zod ? rr(m.value, t) : kn;
      v > p && (p = v);
    }
    return p;
  }, s = (l) => {
    l > i && (i = l);
  }, u = e._zod.def;
  switch (u.type) {
    case "object": {
      const l = Qi(u);
      s(l ? a(l) : nr), o(u.catchall);
      break;
    }
    case "array":
      o(u.element);
      break;
    case "tuple":
      for (const l of u.items)
        o(l);
      o(u.rest);
      break;
    case "record":
    case "map":
      o(u.keyType), o(u.valueType);
      break;
    case "set":
      o(u.valueType);
      break;
    case "union":
      for (const l of u.options)
        o(l);
      break;
    case "intersection":
      o(u.left), o(u.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      o(u.innerType);
      break;
    case "pipe":
      o(u.in), o(u.out);
      break;
    case "function":
      o(u.input), o(u.output);
      break;
    case "lazy": {
      const l = u._cachedInner ?? void 0;
      s(l ? rr(l, t) : nr);
      break;
    }
    case "template_literal":
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const l in u) {
        const f = Object.getOwnPropertyDescriptor(u, l);
        if (!f || f.get)
          continue;
        const p = f.value;
        if (!(!p || typeof p != "object")) {
          if (p._zod)
            o(p);
          else if (Array.isArray(p))
            for (const d of p)
              o(d);
        }
      }
  }
  return t.delete(e), Mh(e, i);
}
function Mh(e, t) {
  return t !== nr && Ml.set(e, t === In), t;
}
function Rh(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new WeakMap(), e.buckets.set(t, n)), n;
}
let Jn;
const Wn = [], $h = {
  alloc(e, t, n) {
    const r = Jn;
    if (!r)
      return n;
    Jn = void 0;
    const i = { value: n, issues: null };
    return r.set(t.value, i), Wn.push(i), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const n = e._zod.parse, r = (i, o) => {
        if (o.direction !== "backward" && Nh(o, i.value))
          throw new Ph();
        return n(i, o);
      };
      e._zod.parse = r, e._zod.run === n && (e._zod.run = r);
    });
  },
  attach(e) {
    var t;
    let n, r = !1, i, o;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const a = e._zod.parse, s = (u, c) => {
        if (n === void 0) {
          const g = rr(e, /* @__PURE__ */ new Set());
          if (g === kn)
            return e._zod.parse = a, e._zod.run === s && (e._zod.run = a), a(u, c);
          g === In || r ? n = !0 : r = !0;
        }
        const l = u.value;
        if (!Pl(l))
          return a(u, c);
        let f = c[Si];
        f || (f = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, c[Si] = f);
        let p;
        i === c ? p = o : (p = Rh(f, e), i = c, o = p);
        const d = p.get(l);
        if (d)
          return u.value = d.value, d.issues ? d.issues.length && u.issues.push(...qr(d.issues)) : (u.memo = !0, f.backEdges ?? (f.backEdges = /* @__PURE__ */ new WeakSet()), f.backEdges.add(d.value)), u;
        Jn = p;
        const h = Wn.length, m = a(u, c);
        Jn = void 0;
        const v = Wn.length > h ? Wn.pop() : void 0;
        return m instanceof Promise ? m.then((g) => (v && (v.issues = g.issues.length ? qr(g.issues) : ya), g)) : (v && (v.issues = m.issues.length ? qr(m.issues) : ya), m);
      };
      e._zod.parse = s, e._zod.run === a && (e._zod.run = s);
    });
  }
};
function Dh() {
  return $h;
}
function Nh(e, t) {
  var r;
  const n = (r = e[Si]) == null ? void 0 : r.backEdges;
  return n !== void 0 && Pl(t) && n.has(t);
}
const Lh = () => {
  const e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(o) {
    return e[o] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, r = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function i(o, a) {
    return o === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : r[o] ?? o;
  }
  return (o) => {
    switch (o.code) {
      case "invalid_type": {
        const a = i(o.expected), s = id(o.input), u = i(s, o.input);
        return `Invalid input: expected ${a}, received ${u}`;
      }
      case "invalid_value":
        return o.values.length === 1 ? `Invalid input: expected ${fl(o.values[0])}` : `Invalid option: expected one of ${Xo(o.values, "|")}`;
      case "too_big": {
        const a = o.exact ? "exactly " : o.inclusive ? "<=" : "<", s = t(o.origin);
        return s ? `Too big: expected ${o.origin ?? "value"} to have ${a}${o.maximum.toString()} ${s.unit ?? "elements"}` : `Too big: expected ${o.origin ?? "value"} to be ${a}${o.maximum.toString()}`;
      }
      case "too_small": {
        const a = o.exact ? "exactly " : o.inclusive ? ">=" : ">", s = t(o.origin);
        return s ? `Too small: expected ${o.origin} to have ${a}${o.minimum.toString()} ${s.unit}` : `Too small: expected ${o.origin} to be ${a}${o.minimum.toString()}`;
      }
      case "invalid_format": {
        const a = o;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${n[a.format] ?? o.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${o.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${o.keys.length > 1 ? "s" : ""}: ${Xo(o.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${o.origin}`;
      case "invalid_union":
        return o.options && Array.isArray(o.options) && o.options.length > 0 ? `Invalid discriminator value. Expected ${o.options.map((s) => `'${s}'`).join(" | ")}` : o.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${o.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function Fh() {
  return {
    localeError: Lh()
  };
}
var ba;
class jh {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    const r = n[0];
    return this._map.set(t, r), r && typeof r == "object" && "id" in r && this._idmap.set(r.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    const n = t._zod.parent;
    if (n) {
      const r = { ...this.get(n) ?? {} };
      delete r.id;
      const i = { ...r, ...this._map.get(t) };
      return Object.keys(i).length ? i : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function Zh() {
  return new jh();
}
(ba = globalThis).__zod_globalRegistry ?? (ba.__zod_globalRegistry = Zh());
const wn = globalThis.__zod_globalRegistry;
function Rl(e) {
  return e.checks && (e.checks = [...e.checks]), e;
}
// @__NO_SIDE_EFFECTS__
function Bh(e, t) {
  return new e(Rl({ type: "string", ...j(t) }));
}
// @__NO_SIDE_EFFECTS__
function Uh(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Vh(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function qh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Jh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Wh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Hh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Kh(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Yh(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Gh(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Xh(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Qh(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function em(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function tm(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function nm(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function rm(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function im(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function om(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function am(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function sm(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function lm(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function um(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function cm(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function fm(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function dm(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function pm(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function hm(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function mm(e, t) {
  return new e(Rl({ type: "number", checks: [], ...j(t) }));
}
// @__NO_SIDE_EFFECTS__
function gm(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function ym(e, t) {
  return new e({
    type: "boolean",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function bm(e, t) {
  return new e({
    type: "null",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function vm(e) {
  return new e({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function km(e, t) {
  return new e({
    type: "never",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function va(e, t) {
  return new bl({
    check: "less_than",
    ...j(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Jr(e, t) {
  return new bl({
    check: "less_than",
    ...j(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function ka(e, t) {
  return new vl({
    check: "greater_than",
    ...j(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Wr(e, t) {
  return new vl({
    check: "greater_than",
    ...j(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function wa(e, t) {
  return new cp({
    check: "multiple_of",
    ...j(t),
    value: e
  });
}
// @__NO_SIDE_EFFECTS__
function $l(e, t) {
  return new dp({
    check: "max_length",
    ...j(t),
    maximum: e
  });
}
// @__NO_SIDE_EFFECTS__
function pr(e, t) {
  return new pp({
    check: "min_length",
    ...j(t),
    minimum: e
  });
}
// @__NO_SIDE_EFFECTS__
function Dl(e, t) {
  return new hp({
    check: "length_equals",
    ...j(t),
    length: e
  });
}
// @__NO_SIDE_EFFECTS__
function wm(e, t) {
  return new mp({
    check: "string_format",
    format: "regex",
    ...j(t),
    pattern: e
  });
}
// @__NO_SIDE_EFFECTS__
function xm(e) {
  return new gp({
    check: "string_format",
    format: "lowercase",
    ...j(e)
  });
}
// @__NO_SIDE_EFFECTS__
function _m(e) {
  return new yp({
    check: "string_format",
    format: "uppercase",
    ...j(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Sm(e, t) {
  return new bp({
    check: "string_format",
    format: "includes",
    ...j(t),
    includes: e
  });
}
// @__NO_SIDE_EFFECTS__
function Im(e, t) {
  return new vp({
    check: "string_format",
    format: "starts_with",
    ...j(t),
    prefix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Em(e, t) {
  return new kp({
    check: "string_format",
    format: "ends_with",
    ...j(t),
    suffix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Cm(e, t) {
  return new wp({
    check: "properties",
    shape: e,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function rn(e) {
  return new xp({
    check: "overwrite",
    tx: e
  });
}
// @__NO_SIDE_EFFECTS__
function Am(e) {
  return /* @__PURE__ */ rn((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function zm() {
  return /* @__PURE__ */ rn((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function Tm() {
  return /* @__PURE__ */ rn((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function Om() {
  return /* @__PURE__ */ rn((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Pm() {
  return /* @__PURE__ */ rn((e) => qf(e));
}
// @__NO_SIDE_EFFECTS__
function Mm(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...j(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Rm(e, t, n) {
  const r = j(n);
  return r.abort ?? (r.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...r
  });
}
// @__NO_SIDE_EFFECTS__
function $m(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...j(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Dm(e, t) {
  const n = /* @__PURE__ */ Nm((r) => (r.addIssue = (i) => {
    if (typeof i == "string")
      r.issues.push(Mn(i, r.value, n._zod.def));
    else {
      const o = i;
      o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), "input" in o || (o.input = r.value), o.inst ?? (o.inst = n), o.continue ?? (o.continue = !n._zod.def.abort), r.issues.push(Mn(o));
    }
  }, e(r.value, r)), t);
  return n;
}
// @__NO_SIDE_EFFECTS__
function Nm(e, t) {
  const n = new ze({
    check: "custom",
    ...j(t)
  });
  return n._zod.check = e, n;
}
function En(e, ...t) {
  for (const n of t)
    for (const r of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, r) && ut(e, r, n[r]);
  return e;
}
function hr(e) {
  let t = (e == null ? void 0 : e.target) ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: (e == null ? void 0 : e.metadata) ?? wn,
    target: t,
    unrepresentable: (e == null ? void 0 : e.unrepresentable) ?? "throw",
    override: (e == null ? void 0 : e.override) ?? (() => {
    }),
    io: (e == null ? void 0 : e.io) ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: (e == null ? void 0 : e.cycles) ?? "ref",
    reused: (e == null ? void 0 : e.reused) ?? "inline",
    intersections: [],
    deferred: [],
    external: (e == null ? void 0 : e.external) ?? void 0
  };
}
function _e(e, t, n, r, i) {
  const o = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: r.path, message: i }) : t.unrepresentable;
  if (o === "any")
    return !1;
  if (o === void 0 || o === "throw")
    throw new Error(i);
  return Object.assign(n, o), !0;
}
function se(e, t, n = { path: [], schemaPath: [] }) {
  var l, f;
  var r;
  const i = e._zod.def, o = t.seen.get(e);
  if (o)
    return o.count++, n.schemaPath.includes(e) && (o.cycle = n.path), o.schema;
  const a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, a), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  const s = (f = (l = e._zod).toJSONSchema) == null ? void 0 : f.call(l);
  if (s)
    a.schema = s;
  else {
    const p = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, p);
    else {
      const h = a.schema, m = t.processors[i.type];
      if (!m)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
      m(e, t, h, p);
    }
    const d = e._zod.parent;
    d && (a.ref || (a.ref = d), se(d, t, p), t.seen.get(d).isParent = !0);
  }
  const u = t.metadataRegistry.get(e);
  return u && En(a.schema, u), t.io === "input" && Ee(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && "_prefault" in a.schema && ((r = a.schema).default ?? (r.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
function xa(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function mr(e, t) {
  var a, s, u, c;
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  const r = /* @__PURE__ */ new Map();
  for (const l of e.seen.entries()) {
    const f = (a = e.metadataRegistry.get(l[0])) == null ? void 0 : a.id;
    if (f) {
      const p = r.get(f);
      if (p && p !== l[0])
        throw new Error(`Duplicate schema id "${f}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      r.set(f, l[0]);
    }
  }
  const i = (l) => {
    var m;
    const f = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      const v = (m = e.external.registry.get(l[0])) == null ? void 0 : m.id, g = e.external.uri ?? ((I) => I);
      if (v)
        return { ref: g(v) };
      const w = l[1].defId ?? l[1].schema.id ?? `schema${e.counter++}`;
      return l[1].defId = w, { defId: w, ref: `${g("__shared")}#/${f}/${xa(w)}` };
    }
    const p = "#", d = `${p}/${f}/`;
    if (l[1] === n && !l[1].schema.id)
      return { ref: p };
    const h = l[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: h, ref: d + xa(h) };
  }, o = (l) => {
    if (l[1].schema.$ref)
      return;
    const f = l[1], { ref: p, defId: d } = i(l);
    f.def = { ...f.schema }, d && (f.defId = d);
    const h = f.schema;
    for (const m in h)
      delete h[m];
    h.$ref = p;
  };
  if (e.cycles === "throw")
    for (const l of e.seen.entries()) {
      const f = l[1];
      if (f.cycle)
        throw new Error(`Cycle detected: #/${(s = f.cycle) == null ? void 0 : s.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const l of e.seen.entries()) {
    const f = l[1];
    if (t === l[0]) {
      o(l);
      continue;
    }
    if (e.external) {
      const d = (u = e.external.registry.get(l[0])) == null ? void 0 : u.id;
      if (t !== l[0] && d) {
        o(l);
        continue;
      }
    }
    if ((c = e.metadataRegistry.get(l[0])) == null ? void 0 : c.id) {
      o(l);
      continue;
    }
    if (f.cycle) {
      o(l);
      continue;
    }
    f.count > 1 && e.reused === "ref" && o(l);
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
function Nl(e) {
  const t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  const n = [];
  for (const r of t) {
    if (!r || typeof r != "object")
      return;
    Nl(r);
    const i = Object.keys(r);
    if (i.length !== 1 || i[0] !== "type")
      return;
    const o = r.type;
    for (const a of Array.isArray(o) ? o : [o]) {
      if (typeof a != "string")
        return;
      n.includes(a) || n.push(a);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
const Ll = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), _a = ["oneOf", "anyOf"];
function Sa(e) {
  const t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
function Ii(e) {
  var o;
  const t = [];
  for (const a of e) {
    if (typeof a != "object" || a.type !== "object")
      return null;
    for (const s in a)
      if (!Ll.has(s))
        return null;
    t.push(a);
  }
  const n = {}, r = /* @__PURE__ */ new Set();
  for (const a of t) {
    for (const s in a.properties) {
      if (Object.prototype.hasOwnProperty.call(n, s))
        continue;
      const u = [];
      for (const l of t) {
        const f = ((o = l.properties) == null ? void 0 : o[s]) ?? Sa(l);
        f != null && (u.some((p) => JSON.stringify(p) === JSON.stringify(f)) || u.push(f));
      }
      const c = u.length === 1 ? u[0] : Ii(u) ?? { allOf: u };
      ut(n, s, c);
    }
    for (const s of a.required ?? [])
      r.add(s);
  }
  const i = { type: "object", properties: n };
  if (r.size && (i.required = [...r]), t.every((a) => a.additionalProperties === !1))
    i.additionalProperties = !1;
  else {
    const a = [];
    for (const s of t) {
      const u = Sa(s);
      u && !a.some((c) => JSON.stringify(c) === JSON.stringify(u)) && a.push(u);
    }
    a.length === 1 ? i.additionalProperties = a[0] : a.length > 1 && (i.additionalProperties = { allOf: a });
  }
  return i;
}
function Lm(e) {
  const t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (const i of Ll)
    if (i in e)
      return;
  const n = t.filter((i) => _a.some((o) => Array.isArray(i[o])));
  let r = null;
  if (!n.length)
    r = Ii(t);
  else {
    const i = n[0], o = _a.find((u) => Array.isArray(i[u]));
    if (Object.keys(i).length !== 1)
      return;
    const a = t.filter((u) => u !== i), s = i[o].map((u) => Ii([...a, u]));
    if (s.some((u) => !u))
      return;
    r = { [o]: s };
  }
  r && (delete e.allOf, En(e, r));
}
function gr(e, t) {
  var s, u, c, l;
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const r = (f) => {
    const p = e.seen.get(f);
    if (p.ref === null)
      return;
    const d = p.def ?? p.schema, h = { ...d }, m = p.ref;
    if (p.ref = null, m) {
      r(m);
      const g = e.seen.get(m), w = g.schema;
      if (w.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (d.allOf = d.allOf ?? [], d.allOf.push(w)) : En(d, w), En(d, h), f._zod.parent === m)
        for (const S in d)
          S === "$ref" || S === "allOf" || S in h || delete d[S];
      if (w.$ref && g.def)
        for (const S in d)
          S === "$ref" || S === "allOf" || S in g.def && JSON.stringify(d[S]) === JSON.stringify(g.def[S]) && delete d[S];
    }
    const v = f._zod.parent;
    if (v && v !== m) {
      r(v);
      const g = e.seen.get(v);
      if (g != null && g.schema.$ref && (d.$ref = g.schema.$ref, g.def))
        for (const w in d)
          w === "$ref" || w === "allOf" || w in g.def && JSON.stringify(d[w]) === JSON.stringify(g.def[w]) && delete d[w];
    }
    e.override({
      zodSchema: f,
      jsonSchema: d,
      path: p.path ?? []
    });
  };
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (const f of [...e.seen.entries()].reverse())
      r(f[0]);
    if (e.target !== "openapi-3.0")
      for (const f of e.seen.entries())
        Nl(f[1].def ?? f[1].schema);
    for (const f of e.deferred)
      f();
    if (e.intersections.length) {
      const f = /* @__PURE__ */ new Map();
      for (const p of e.seen.values())
        for (const d of [p.schema, p.def]) {
          const h = d == null ? void 0 : d.allOf;
          if (!Array.isArray(h))
            continue;
          const m = f.get(h);
          m ? m.push(d) : f.set(h, [d]);
        }
      for (const p of e.intersections)
        for (const d of f.get(p) ?? [])
          Lm(d);
    }
  }
  const i = {};
  if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, (s = e.external) != null && s.uri) {
    const f = (u = e.external.registry.get(t)) == null ? void 0 : u.id;
    if (!f)
      throw new Error("Schema is missing an `id` property");
    i.$id = e.external.uri(f);
  }
  En(i, n.defId ? n.schema : n.def ?? n.schema);
  const o = (c = e.metadataRegistry.get(t)) == null ? void 0 : c.id;
  o !== void 0 && i.id === o && delete i.id;
  const a = ((l = e.external) == null ? void 0 : l.defs) ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (const f of e.seen.entries()) {
      const p = f[1];
      p.def && p.defId && (p.def.id === p.defId && delete p.def.id, ut(a, p.defId, p.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? i.$defs = a : i.definitions = a);
  try {
    const f = JSON.parse(JSON.stringify(i));
    return Object.defineProperty(f, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: yr(t, "input", e.processors),
          output: yr(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), f;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function Ee(e, t) {
  const n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  const r = e._zod.def;
  if (r.type === "transform")
    return !0;
  if (r.type === "array")
    return Ee(r.element, n);
  if (r.type === "set")
    return Ee(r.valueType, n);
  if (r.type === "lazy")
    return Ee(r.getter(), n);
  if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch")
    return Ee(r.innerType, n);
  if (r.type === "intersection")
    return Ee(r.left, n) || Ee(r.right, n);
  if (r.type === "record" || r.type === "map")
    return Ee(r.keyType, n) || Ee(r.valueType, n);
  if (r.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : Ee(r.in, n) || Ee(r.out, n);
  if (r.type === "object") {
    for (const i in r.shape)
      if (Ee(r.shape[i], n))
        return !0;
    return !1;
  }
  if (r.type === "union") {
    for (const i of r.options)
      if (Ee(i, n))
        return !0;
    return !1;
  }
  if (r.type === "tuple") {
    for (const i of r.items)
      if (Ee(i, n))
        return !0;
    return !!(r.rest && Ee(r.rest, n));
  }
  return !1;
}
const Fm = (e, t = {}) => (n) => {
  const r = hr({ ...n, processors: t });
  return se(e, r), mr(r, e), gr(r, e);
}, yr = (e, t, n = {}) => (r) => {
  const { libraryOptions: i, target: o } = r ?? {}, a = hr({ ...i ?? {}, target: o, io: t, processors: n });
  return se(e, a), mr(a, e), gr(a, e);
}, tn = (e, t, n) => {
  (e[t] === void 0 || n > e[t]) && (e[t] = n);
}, nn = (e, t, n) => {
  (e[t] === void 0 || n < e[t]) && (e[t] = n);
}, Ia = (e, t) => {
  tn(e, "minimum", t), nn(e, "maximum", t);
}, Fl = (e, t) => {
  e.multipleOf ?? (e.multipleOf = []), e.multipleOf.includes(t) || e.multipleOf.push(t);
}, jl = (e, t) => {
  e.patterns ?? (e.patterns = /* @__PURE__ */ new Set()), e.patterns.add(t);
}, Zl = (e, t) => {
  e.mime = e.mime ? e.mime.filter((n) => t.includes(n)) : [...t];
}, Bl = (e, t) => {
  e.format = t, t.includes("int") && (e.isInt = !0);
}, Ea = (e, t) => tn(e, "minimum", t.minimum), Ca = (e, t) => nn(e, "maximum", t.maximum), Aa = (e) => (t, n) => {
  Bl(t, n.format);
  const [r, i] = e[n.format];
  tn(t, "minimum", r), nn(t, "maximum", i);
}, Hr = {
  greater_than: (e, t) => tn(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
  less_than: (e, t) => nn(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
  multiple_of: (e, t) => Fl(e, t.value),
  number_format: Aa(dl),
  bigint_format: Aa(Kf),
  min_length: Ea,
  max_length: Ca,
  length_equals: (e, t) => Ia(e, t.length),
  min_size: Ea,
  max_size: Ca,
  size_equals: (e, t) => Ia(e, t.size),
  string_format: (e, t) => {
    Bl(e, t.format), t.pattern && jl(e, t.pattern), (t.format === "base64" || t.format === "base64url") && (e.contentEncoding = t.format), (t.local || t.precision === -1) && (e.laxFormat = !0);
  },
  mime_type: (e, t) => Zl(e, t.mime)
};
function Fe(e) {
  var o;
  const t = {}, n = e._zod.def, r = e._zod.traits.has("$ZodCheck") ? [e, ...n.checks ?? []] : n.checks ?? [];
  for (const a of r)
    (o = Hr[a._zod.def.check]) == null || o.call(Hr, t, a._zod.def);
  const i = e._zod.bag;
  i.minimum !== void 0 && tn(t, "minimum", i.minimum), i.exclusiveMinimum !== void 0 && tn(t, "exclusiveMinimum", i.exclusiveMinimum), i.maximum !== void 0 && nn(t, "maximum", i.maximum), i.exclusiveMaximum !== void 0 && nn(t, "exclusiveMaximum", i.exclusiveMaximum), i.multipleOf !== void 0 && Fl(t, i.multipleOf), i.format !== void 0 && (t.format ?? (t.format = i.format), i.format.includes("int") && (t.isInt = !0)), i.mime && Zl(t, i.mime);
  for (const a of i.patterns ?? [])
    jl(t, a);
  return t;
}
const jm = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Zm = /* @__PURE__ */ new Map([
  [El, Yd],
  [co, Gd]
]), Ul = (e) => Zm.get(e) ?? e, Vl = (e, t, n, r) => {
  const i = n;
  i.type = "string";
  const { minimum: o, maximum: a, format: s, patterns: u, contentEncoding: c, laxFormat: l } = Fe(e);
  if (typeof o == "number" && (i.minLength = o), typeof a == "number" && (i.maxLength = a), s && (i.format = jm[s] ?? s, i.format === "" && delete i.format, (s === "time" || l) && delete i.format), c && (i.contentEncoding = c), u && u.size > 0) {
    const f = [...u].map(Ul);
    f.length === 1 ? i.pattern = f[0].source : f.length > 1 && (i.allOf = [
      ...f.map((p) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: p.source
      }))
    ]);
  }
}, ql = (e, t, n, r) => {
  const i = n, { minimum: o, maximum: a, multipleOf: s, exclusiveMaximum: u, exclusiveMinimum: c, isInt: l } = Fe(e);
  i.type = l ? "integer" : "number";
  const f = typeof c == "number" && c >= (o ?? Number.NEGATIVE_INFINITY), p = typeof u == "number" && u <= (a ?? Number.POSITIVE_INFINITY), d = t.target === "draft-04" || t.target === "openapi-3.0";
  if (f ? d ? (i.minimum = c, i.exclusiveMinimum = !0) : i.exclusiveMinimum = c : typeof o == "number" && (i.minimum = o), p ? d ? (i.maximum = u, i.exclusiveMaximum = !0) : i.exclusiveMaximum = u : typeof a == "number" && (i.maximum = a), s) {
    const h = /* @__PURE__ */ new Set();
    for (const g of s)
      Number.isFinite(g) && g !== 0 ? h.add(Math.abs(g)) : _e(e, t, i, r, `A multipleOf divisor of ${g} cannot be represented in JSON Schema`);
    const [m, ...v] = h;
    m !== void 0 && (i.multipleOf = m), v.length && (i.allOf = [...i.allOf ?? [], ...v.map((g) => ({ multipleOf: g }))]);
  }
}, Jl = (e, t, n, r) => {
  n.type = "boolean";
}, Bm = (e, t, n, r) => {
  _e(e, t, n, r, "BigInt cannot be represented in JSON Schema");
}, Um = (e, t, n, r) => {
  _e(e, t, n, r, "Symbols cannot be represented in JSON Schema");
}, Wl = (e, t, n, r) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, Vm = (e, t, n, r) => {
  _e(e, t, n, r, "Undefined cannot be represented in JSON Schema");
}, qm = (e, t, n, r) => {
  _e(e, t, n, r, "Void cannot be represented in JSON Schema");
}, Hl = (e, t, n, r) => {
  n.not = {};
}, Jm = (e, t, n, r) => {
}, Kl = (e, t, n, r) => {
}, Wm = (e, t, n, r) => {
  _e(e, t, n, r, "Date cannot be represented in JSON Schema");
}, Yl = (e, t, n, r) => {
  const i = e._zod.def, o = vi(i.entries);
  if (o.length === 0) {
    n.not = {};
    return;
  }
  o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), n.enum = o;
}, Gl = (e, t, n, r) => {
  const i = e._zod.def;
  if (i.values.length === 0) {
    n.not = {};
    return;
  }
  const o = [];
  for (const a of i.values)
    if (a === void 0) {
      if (_e(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (_e(e, t, n, r, "BigInt literals cannot be represented in JSON Schema"))
        return;
      o.push(Number(a));
    } else
      o.push(a);
  if (o.length !== 0) if (o.length === 1) {
    const a = o[0];
    n.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
  } else
    o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), o.every((a) => typeof a == "boolean") && (n.type = "boolean"), o.every((a) => a === null) && (n.type = "null"), n.enum = o;
}, Hm = (e, t, n, r) => {
  _e(e, t, n, r, "NaN cannot be represented in JSON Schema");
}, Km = (e, t, n, r) => {
  const i = n, o = e._zod.pattern;
  if (!o)
    throw new Error("Pattern not found in template literal");
  i.type = "string", i.pattern = o.source;
}, Ym = (e, t, n, r) => {
  const i = n;
  i.type = "string", i.format = "binary", i.contentEncoding = "binary";
  const { minimum: o, maximum: a, mime: s } = Fe(e);
  o !== void 0 && (i.minLength = o), a !== void 0 && (i.maxLength = a), s && (s.length === 0 ? i.not = {} : s.length === 1 ? i.contentMediaType = s[0] : i.anyOf = s.map((u) => ({ contentMediaType: u })));
}, Gm = (e, t, n, r) => {
  n.type = "boolean";
}, Xl = (e, t, n, r) => {
  _e(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, Xm = (e, t, n, r) => {
  _e(e, t, n, r, "Function types cannot be represented in JSON Schema");
}, Ql = (e, t, n, r) => {
  _e(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, Qm = (e, t, n, r) => {
  _e(e, t, n, r, "Map cannot be represented in JSON Schema");
}, eg = (e, t, n, r) => {
  _e(e, t, n, r, "Set cannot be represented in JSON Schema");
}, eu = (e, t, n, r) => {
  const i = n, o = e._zod.def, { minimum: a, maximum: s } = Fe(e);
  typeof a == "number" && (i.minItems = a), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = se(o.element, t, {
    ...r,
    path: [...r.path, "items"]
  });
};
function Rn(e) {
  const t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? Rn(t.out) : t.type === "catch" ? Rn(t.innerType) : e._zod.optin;
}
const tu = (e, t, n, r) => {
  var c;
  const i = n, o = e._zod.def, a = o.shape;
  if (Object.getOwnPropertySymbols(a).length && _e(e, t, i, r, "Symbol keys cannot be represented in JSON Schema"))
    return;
  i.type = "object", i.properties = {};
  for (const l in a)
    ut(i.properties, l, se(a[l], t, {
      ...r,
      path: [...r.path, "properties", l]
    }));
  const u = [];
  for (const l of Object.keys(a)) {
    const f = o.shape[l];
    (t.io === "input" ? Rn(f) === void 0 : f._zod.optout === void 0) && u.push(l);
  }
  u.length > 0 && (i.required = u), ((c = o.catchall) == null ? void 0 : c._zod.def.type) === "never" ? i.additionalProperties = !1 : o.catchall ? o.catchall && (i.additionalProperties = se(o.catchall, t, {
    ...r,
    path: [...r.path, "additionalProperties"]
  })) : t.io === "output" && (i.additionalProperties = !1);
}, nu = (e, t, n, r) => {
  const i = e._zod.def, o = i.inclusive === !1, a = i.options.map((s, u) => se(s, t, {
    ...r,
    path: [...r.path, o ? "oneOf" : "anyOf", u]
  }));
  o ? n.oneOf = a : n.anyOf = a;
}, ru = (e, t, n, r) => {
  const i = e._zod.def, o = se(i.left, t, {
    ...r,
    path: [...r.path, "allOf", 0]
  }), a = se(i.right, t, {
    ...r,
    path: [...r.path, "allOf", 1]
  }), s = (c) => "allOf" in c && Object.keys(c).length === 1, u = [
    ...s(o) ? o.allOf : [o],
    ...s(a) ? a.allOf : [a]
  ];
  n.allOf = u, t.intersections.push(u);
}, tg = (e, t, n, r) => {
  const i = n, o = e._zod.def;
  i.type = "array";
  const a = t.target === "draft-2020-12" ? "prefixItems" : "items", s = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = o.items.map((m, v) => se(m, t, {
    ...r,
    path: [...r.path, a, v]
  })), c = o.rest ? se(o.rest, t, {
    ...r,
    path: [...r.path, s, ...t.target === "openapi-3.0" ? [o.items.length] : []]
  }) : null;
  let l = o.items.length;
  for (; l > 0; ) {
    const m = o.items[l - 1];
    if (!(t.io === "input" ? Rn(m) !== void 0 : m._zod.optout === "optional"))
      break;
    l--;
  }
  const f = o.items.length, p = !o.rest;
  t.target === "draft-2020-12" ? (i.prefixItems = u, p ? i.items = !1 : c && (i.items = c), l > 0 && (i.minItems = l), p && (i.maxItems = f)) : t.target === "openapi-3.0" ? (i.items = {
    anyOf: u
  }, c && i.items.anyOf.push(c), l > 0 && (i.minItems = l), p && (i.maxItems = f)) : (i.items = u, p ? i.additionalItems = !1 : c && (i.additionalItems = c), l > 0 && (i.minItems = l), p && (i.maxItems = f));
  const { minimum: d, maximum: h } = Fe(e);
  typeof d == "number" && (i.minItems = d), typeof h == "number" && (i.maxItems = h);
};
function Ei(e, t, n) {
  var h;
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    const m = (h = e.get(t)) == null ? void 0 : h.def;
    if (!m)
      return t;
    const v = Ei(e, m, n);
    return v === m ? t : v;
  }
  for (const m of ["anyOf", "oneOf"]) {
    const v = t[m];
    if (!Array.isArray(v))
      continue;
    const g = v.map((w) => Ei(e, w, n));
    g.some((w, I) => w !== v[I]) && (t = { ...t, [m]: g });
  }
  const r = Array.isArray(t.type) ? t.type : [t.type], i = !r.includes("string") && r.some((m) => m === "number" || m === "integer"), o = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!i && !(o != null && o.some((m) => typeof m == "number")))
    return t;
  const { minimum: a, maximum: s, exclusiveMinimum: u, exclusiveMaximum: c, multipleOf: l, format: f, id: p, ...d } = t;
  return d.enum ? d.enum = d.enum.map((m) => typeof m == "number" ? String(m) : m) : typeof d.const == "number" && (d.const = String(d.const)), i && (d.type = "string", o || (d.pattern = (r.includes("number") ? so : op).source)), d;
}
const Ci = /* @__PURE__ */ new WeakMap();
function ng(e) {
  var r;
  const t = /* @__PURE__ */ new Map();
  for (const i of e.seen.values())
    i.def && !t.has(i.schema) && t.set(i.schema, i);
  const n = /* @__PURE__ */ new Map();
  for (const i of Ci.get(e) ?? []) {
    const o = e.seen.get(i), a = (r = (o == null ? void 0 : o.def) ?? (o == null ? void 0 : o.schema)) == null ? void 0 : r.propertyNames;
    if (!a || a === !0 || n.has(a))
      continue;
    const s = Ei(t, a, /* @__PURE__ */ new Set());
    s !== a && n.set(a, s);
  }
  if (n.size)
    for (const i of e.seen.values())
      for (const o of [i.schema, i.def]) {
        const a = o && n.get(o.propertyNames);
        a && (o.propertyNames = a);
      }
}
const iu = (e, t, n, r) => {
  const i = n, o = e._zod.def;
  i.type = "object";
  const a = o.keyType, s = Fe(a).patterns;
  if (o.mode === "loose" && s && s.size > 0) {
    const l = se(o.valueType, t, {
      ...r,
      path: [...r.path, "patternProperties", "*"]
    });
    i.patternProperties = {};
    for (const f of s)
      ut(i.patternProperties, Ul(f).source, l);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      i.propertyNames = se(o.keyType, t, {
        ...r,
        path: [...r.path, "propertyNames"]
      });
      let l = Ci.get(t);
      l || (l = [], Ci.set(t, l), t.deferred.push(() => ng(t))), l.push(e);
    }
    i.additionalProperties = se(o.valueType, t, {
      ...r,
      path: [...r.path, "additionalProperties"]
    });
  }
  const u = a._zod.values, c = t.io === "input" && Rn(o.valueType) !== void 0;
  if (u && !o.partial && !c) {
    const l = [...u].filter((f) => typeof f == "string" || typeof f == "number");
    l.length > 0 && (i.required = l.map(String));
  }
}, ou = (e, t, n, r) => {
  const i = e._zod.def, o = se(i.innerType, t, r), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = i.innerType, n.nullable = !0) : n.anyOf = [o, { type: "null" }];
}, au = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, fo = Symbol();
function su(e, t, n, r, i) {
  let o = !1;
  const a = JSON.stringify(e, (s, u) => typeof u != "bigint" ? u : (o = !0, null));
  return o ? (_e(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), fo) : JSON.parse(a);
}
const lu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
  const a = su(i.defaultValue, e, t, n, r);
  a !== fo && (n.default = a);
}, uu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  if (o.ref = i.innerType, t.io !== "input")
    return;
  const a = su(i.defaultValue, e, t, n, r);
  a !== fo && (n._prefault = a);
}, cu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
  let a;
  try {
    a = i.catchValue(void 0);
  } catch {
    _e(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = a;
}, fu = (e, t, n, r) => {
  const i = e._zod.def, o = i.in._zod.traits.has("$ZodTransform"), a = t.io === "input" ? o ? i.out : i.in : i.out;
  se(a, t, r);
  const s = t.seen.get(e);
  s.ref = a;
}, du = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType, n.readOnly = !0;
}, rg = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, po = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, pu = (e, t, n, r) => {
  const i = e._zod.innerType;
  se(i, t, r);
  const o = t.seen.get(e);
  o.ref = i;
}, za = {
  string: Vl,
  number: ql,
  boolean: Jl,
  bigint: Bm,
  symbol: Um,
  null: Wl,
  undefined: Vm,
  void: qm,
  never: Hl,
  any: Jm,
  unknown: Kl,
  date: Wm,
  enum: Yl,
  literal: Gl,
  nan: Hm,
  template_literal: Km,
  file: Ym,
  success: Gm,
  custom: Xl,
  function: Xm,
  transform: Ql,
  map: Qm,
  set: eg,
  array: eu,
  object: tu,
  union: nu,
  intersection: ru,
  tuple: tg,
  record: iu,
  nullable: ou,
  nonoptional: au,
  default: lu,
  prefault: uu,
  catch: cu,
  pipe: fu,
  readonly: du,
  promise: rg,
  optional: po,
  lazy: pu
};
function ig(e, t) {
  if ("_idmap" in e) {
    const r = e, i = hr({ ...t, processors: za }), o = {};
    for (const u of r._idmap.entries()) {
      const [c, l] = u;
      se(l, i);
    }
    const a = {}, s = {
      registry: r,
      uri: t == null ? void 0 : t.uri,
      defs: o
    };
    i.external = s;
    for (const u of r._idmap.entries()) {
      const [c, l] = u;
      mr(i, l), ut(a, c, gr(i, l));
    }
    if (Object.keys(o).length > 0) {
      const u = i.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [u]: o
      };
    }
    return { schemas: a };
  }
  const n = hr({ ...t, processors: za });
  return se(e, n), mr(n, e), gr(n, e);
}
const Ta = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Hn(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = n(this);
      return Object.defineProperty(this, t, { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, t, { value: r, configurable: !0, writable: !0 });
    }
  });
}
const og = (e, t) => {
  yd.init(e, t), e.name = "ZodError";
  const n = Object.getPrototypeOf(e);
  Ta.has(n) || (Ta.add(n), Hn(n, "format", (r) => (i) => kd(r, i)), Hn(n, "flatten", (r) => (i) => vd(r, i)), Hn(n, "addIssue", (r) => (i) => {
    r.issues.push(i), r.message = JSON.stringify(r.issues, ki, 2);
  }), Hn(n, "addIssues", (r) => (i) => {
    r.issues.push(...i), r.message = JSON.stringify(r.issues, ki, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, He = /* @__PURE__ */ z("ZodError", og, void 0, {
  Parent: Error
}), ag = /* @__PURE__ */ ro(He), sg = /* @__PURE__ */ io(He), lg = /* @__PURE__ */ oo(He), hu = /* @__PURE__ */ ao(He), ug = /* @__PURE__ */ Ed(He), cg = /* @__PURE__ */ Cd(He), fg = /* @__PURE__ */ Ad(He), dg = /* @__PURE__ */ zd(He), pg = /* @__PURE__ */ Td(He), hg = /* @__PURE__ */ Od(He), mg = /* @__PURE__ */ Pd(He), gg = /* @__PURE__ */ Md(He);
function yg() {
  tt.localeError || lt(Fh());
}
function Ar() {
  tt.memoizer || lt({ memoizer: Dh() });
}
const pe = /* @__PURE__ */ z("ZodType", (e, t) => (yg(), de.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    const t = this.def;
    return this.clone(Le(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return Ct(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(yy(e, t));
  },
  superRefine(e, t) {
    return this.check(by(e, t));
  },
  overwrite(e) {
    return this.check(/* @__PURE__ */ rn(e));
  },
  optional() {
    return Ma(this);
  },
  exactOptional() {
    return ry(this);
  },
  nullable() {
    return Ra(this);
  },
  nullish() {
    return Ma(Ra(this));
  },
  nonoptional(e) {
    return uy(this, e);
  },
  array() {
    return on(this);
  },
  or(e) {
    return Ae([this, e]);
  },
  and(e) {
    return Qg(this, e);
  },
  transform(e) {
    return $a(this, ny(e));
  },
  default(e) {
    return ay(this, e);
  },
  prefault(e) {
    return ly(this, e);
  },
  catch(e) {
    return fy(this, e);
  },
  pipe(e) {
    return $a(this, e);
  },
  readonly() {
    return hy(this);
  },
  describe(e) {
    const t = this.clone();
    return wn.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return wn.get(this);
    const t = this.clone();
    return wn.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return no(this, "~standard", {
      ...wl(this),
      jsonSchema: {
        input: yr(this, "input"),
        output: yr(this, "output")
      }
    });
  },
  set "~standard"(e) {
    It(this, "~standard", e);
  },
  parse: function e(t, n) {
    return ag(this, t, n, { callee: e });
  },
  parseAsync: async function e(t, n) {
    return await sg(this, t, n, { callee: e });
  },
  safeParse(e, t) {
    return lg(this, e, t);
  },
  async safeParseAsync(e, t) {
    return hu(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this == null ? void 0 : this.safeParseAsync;
  },
  set spa(e) {
    It(this, "spa", e);
  },
  validate(e, t) {
    return _d(this, e, t);
  },
  validateAsync(e, t) {
    return Id(this, e, t);
  },
  encode: function e(t, n) {
    return ug(this, t, n, { callee: e });
  },
  decode: function e(t, n) {
    return cg(this, t, n, { callee: e });
  },
  encodeAsync: async function e(t, n) {
    return await fg(this, t, n, { callee: e });
  },
  decodeAsync: async function e(t, n) {
    return await dg(this, t, n, { callee: e });
  },
  safeEncode(e, t) {
    return pg(this, e, t);
  },
  safeDecode(e, t) {
    return hg(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return mg(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return gg(this, e, t);
  },
  toJSONSchema(e) {
    return Fm(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    var e;
    return (e = wn.get(this)) == null ? void 0 : e.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), mu = /* @__PURE__ */ z(
  "_ZodString",
  (e, t) => {
    uo.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Vl(e, n, r);
  },
  /* @__PURE__ */ hl({
    format: (e) => Fe(e).format ?? null,
    minLength: (e) => Fe(e).minimum ?? null,
    maxLength: (e) => Fe(e).maximum ?? null
  }, {
    regex(...e) {
      return this.check(/* @__PURE__ */ wm(...e));
    },
    includes(...e) {
      return this.check(/* @__PURE__ */ Sm(...e));
    },
    startsWith(...e) {
      return this.check(/* @__PURE__ */ Im(...e));
    },
    endsWith(...e) {
      return this.check(/* @__PURE__ */ Em(...e));
    },
    min(...e) {
      return this.check(/* @__PURE__ */ pr(...e));
    },
    max(...e) {
      return this.check(/* @__PURE__ */ $l(...e));
    },
    length(...e) {
      return this.check(/* @__PURE__ */ Dl(...e));
    },
    nonempty(...e) {
      return this.check(/* @__PURE__ */ pr(1, ...e));
    },
    lowercase(e) {
      return this.check(/* @__PURE__ */ xm(e));
    },
    uppercase(e) {
      return this.check(/* @__PURE__ */ _m(e));
    },
    trim() {
      return this.check(/* @__PURE__ */ zm());
    },
    normalize(...e) {
      return this.check(/* @__PURE__ */ Am(...e));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ Tm());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ Om());
    },
    slugify() {
      return this.check(/* @__PURE__ */ Pm());
    }
  })
), bg = /* @__PURE__ */ z("ZodString", (e, t) => {
  uo.init(e, t), mu.init(e, t);
}, {
  email(e) {
    return this.check(/* @__PURE__ */ Uh(_g, e));
  },
  url(e) {
    return this.check(/* @__PURE__ */ Kh(Ig, e));
  },
  jwt(e) {
    return this.check(/* @__PURE__ */ cm(jg, e));
  },
  emoji(e) {
    return this.check(/* @__PURE__ */ Yh(Eg, e));
  },
  guid(e) {
    return this.check(/* @__PURE__ */ Vh(Sg, e));
  },
  uuid(e) {
    return this.check(/* @__PURE__ */ qh(Kn, e));
  },
  uuidv4(e) {
    return this.check(/* @__PURE__ */ Jh(Kn, e));
  },
  uuidv6(e) {
    return this.check(/* @__PURE__ */ Wh(Kn, e));
  },
  uuidv7(e) {
    return this.check(/* @__PURE__ */ Hh(Kn, e));
  },
  nanoid(e) {
    return this.check(/* @__PURE__ */ Gh(Cg, e));
  },
  cuid(e) {
    return this.check(/* @__PURE__ */ Xh(Ag, e));
  },
  cuid2(e) {
    return this.check(/* @__PURE__ */ Qh(zg, e));
  },
  ulid(e) {
    return this.check(/* @__PURE__ */ em(Tg, e));
  },
  base64(e) {
    return this.check(/* @__PURE__ */ sm(Ng, e));
  },
  base64url(e) {
    return this.check(/* @__PURE__ */ lm(Lg, e));
  },
  xid(e) {
    return this.check(/* @__PURE__ */ tm(Og, e));
  },
  ksuid(e) {
    return this.check(/* @__PURE__ */ nm(Pg, e));
  },
  ipv4(e) {
    return this.check(/* @__PURE__ */ rm(Mg, e));
  },
  ipv6(e) {
    return this.check(/* @__PURE__ */ im(Rg, e));
  },
  cidrv4(e) {
    return this.check(/* @__PURE__ */ om($g, e));
  },
  cidrv6(e) {
    return this.check(/* @__PURE__ */ am(Dg, e));
  },
  e164(e) {
    return this.check(/* @__PURE__ */ um(Fg, e));
  },
  datetime(e) {
    return this.check(/* @__PURE__ */ fm(vg, e));
  },
  date(e) {
    return this.check(/* @__PURE__ */ dm(kg, e));
  },
  time(e) {
    return this.check(/* @__PURE__ */ pm(wg, e));
  },
  duration(e) {
    return this.check(/* @__PURE__ */ hm(xg, e));
  }
});
function $(e) {
  return /* @__PURE__ */ Bh(bg, e);
}
const me = /* @__PURE__ */ z("ZodStringFormat", (e, t) => {
  he.init(e, t), mu.init(e, t);
}), vg = /* @__PURE__ */ z("ZodISODateTime", (e, t) => {
  Bp.init(e, t), me.init(e, t);
}), kg = /* @__PURE__ */ z("ZodISODate", (e, t) => {
  Up.init(e, t), me.init(e, t);
}), wg = /* @__PURE__ */ z("ZodISOTime", (e, t) => {
  Vp.init(e, t), me.init(e, t);
}), xg = /* @__PURE__ */ z("ZodISODuration", (e, t) => {
  qp.init(e, t), me.init(e, t);
}), _g = /* @__PURE__ */ z("ZodEmail", (e, t) => {
  Ap.init(e, t), me.init(e, t);
}), Sg = /* @__PURE__ */ z("ZodGUID", (e, t) => {
  Ep.init(e, t), me.init(e, t);
}), Kn = /* @__PURE__ */ z("ZodUUID", (e, t) => {
  Cp.init(e, t), me.init(e, t);
}), Ig = /* @__PURE__ */ z("ZodURL", (e, t) => {
  Rp.init(e, t), me.init(e, t);
}), Eg = /* @__PURE__ */ z("ZodEmoji", (e, t) => {
  $p.init(e, t), me.init(e, t);
}), Cg = /* @__PURE__ */ z("ZodNanoID", (e, t) => {
  Dp.init(e, t), me.init(e, t);
}), Ag = /* @__PURE__ */ z("ZodCUID", (e, t) => {
  Np.init(e, t), me.init(e, t);
}), zg = /* @__PURE__ */ z("ZodCUID2", (e, t) => {
  Lp.init(e, t), me.init(e, t);
}), Tg = /* @__PURE__ */ z("ZodULID", (e, t) => {
  Fp.init(e, t), me.init(e, t);
}), Og = /* @__PURE__ */ z("ZodXID", (e, t) => {
  jp.init(e, t), me.init(e, t);
}), Pg = /* @__PURE__ */ z("ZodKSUID", (e, t) => {
  Zp.init(e, t), me.init(e, t);
}), Mg = /* @__PURE__ */ z("ZodIPv4", (e, t) => {
  Jp.init(e, t), me.init(e, t);
}), Rg = /* @__PURE__ */ z("ZodIPv6", (e, t) => {
  Hp.init(e, t), me.init(e, t);
}), $g = /* @__PURE__ */ z("ZodCIDRv4", (e, t) => {
  Kp.init(e, t), me.init(e, t);
}), Dg = /* @__PURE__ */ z("ZodCIDRv6", (e, t) => {
  Gp.init(e, t), me.init(e, t);
}), Ng = /* @__PURE__ */ z("ZodBase64", (e, t) => {
  Xp.init(e, t), me.init(e, t);
}), Lg = /* @__PURE__ */ z("ZodBase64URL", (e, t) => {
  eh.init(e, t), me.init(e, t);
}), Fg = /* @__PURE__ */ z("ZodE164", (e, t) => {
  th.init(e, t), me.init(e, t);
}), jg = /* @__PURE__ */ z("ZodJWT", (e, t) => {
  rh.init(e, t), me.init(e, t);
}), gu = /* @__PURE__ */ z(
  "ZodNumber",
  (e, t) => {
    Cl.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ql(e, n, r, i), e.isFinite = !0;
  },
  /* @__PURE__ */ hl({
    minValue: (e) => {
      const { minimum: t, exclusiveMinimum: n } = Fe(e);
      return Math.max(t ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (e) => {
      const { maximum: t, exclusiveMaximum: n } = Fe(e);
      return Math.min(t ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (e) => {
      const { isInt: t, multipleOf: n } = Fe(e);
      return !!t || !!(n != null && n.some(Number.isSafeInteger));
    },
    format: (e) => Fe(e).format ?? null
  }, {
    gt(e, t) {
      return this.check(/* @__PURE__ */ ka(e, t));
    },
    gte(e, t) {
      return this.check(/* @__PURE__ */ Wr(e, t));
    },
    min(e, t) {
      return this.check(/* @__PURE__ */ Wr(e, t));
    },
    lt(e, t) {
      return this.check(/* @__PURE__ */ va(e, t));
    },
    lte(e, t) {
      return this.check(/* @__PURE__ */ Jr(e, t));
    },
    max(e, t) {
      return this.check(/* @__PURE__ */ Jr(e, t));
    },
    int(e) {
      return this.check(Oa(e));
    },
    safe(e) {
      return this.check(Oa(e));
    },
    positive(e) {
      return this.check(/* @__PURE__ */ ka(0, e));
    },
    nonnegative(e) {
      return this.check(/* @__PURE__ */ Wr(0, e));
    },
    negative(e) {
      return this.check(/* @__PURE__ */ va(0, e));
    },
    nonpositive(e) {
      return this.check(/* @__PURE__ */ Jr(0, e));
    },
    multipleOf(e, t) {
      return this.check(/* @__PURE__ */ wa(e, t));
    },
    step(e, t) {
      return this.check(/* @__PURE__ */ wa(e, t));
    },
    finite() {
      return this;
    }
  })
);
function Zg(e) {
  return /* @__PURE__ */ mm(gu, e);
}
const Bg = /* @__PURE__ */ z("ZodNumberFormat", (e, t) => {
  ih.init(e, t), gu.init(e, t);
});
function Oa(e) {
  return /* @__PURE__ */ gm(Bg, e);
}
const Ug = /* @__PURE__ */ z("ZodBoolean", (e, t) => {
  oh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Jl(e, n, r);
});
function Ce(e) {
  return /* @__PURE__ */ ym(Ug, e);
}
const Vg = /* @__PURE__ */ z("ZodNull", (e, t) => {
  ah.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Wl(e, n, r);
});
function qg(e) {
  return /* @__PURE__ */ bm(Vg, e);
}
const Jg = /* @__PURE__ */ z("ZodUnknown", (e, t) => {
  sh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Kl();
});
function Re() {
  return /* @__PURE__ */ vm(Jg);
}
const Wg = /* @__PURE__ */ z("ZodNever", (e, t) => {
  lh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Hl(e, n, r);
});
function Hg(e) {
  return /* @__PURE__ */ km(Wg, e);
}
const Kg = /* @__PURE__ */ z("ZodArray", (e, t) => {
  Ar(), fh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => eu(e, n, r, i), e.element = t.element;
}, {
  min(e, t) {
    return this.check(/* @__PURE__ */ pr(e, t));
  },
  nonempty(e) {
    return this.check(/* @__PURE__ */ pr(1, e));
  },
  max(e, t) {
    return this.check(/* @__PURE__ */ $l(e, t));
  },
  length(e, t) {
    return this.check(/* @__PURE__ */ Dl(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function on(e, t) {
  return /* @__PURE__ */ Mm(Kg, e, t);
}
const yu = /* @__PURE__ */ z("ZodObject", (e, t) => {
  Ar(), hh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => tu(e, n, r, i), ud(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return zi(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone(Le(this._zod.def, { catchall: e }));
  },
  passthrough() {
    return this.clone(Le(this._zod.def, { catchall: Re() }));
  },
  loose() {
    return this.clone(Le(this._zod.def, { catchall: Re() }));
  },
  strict() {
    return this.clone(Le(this._zod.def, { catchall: Hg() }));
  },
  strip() {
    return this.clone(Le(this._zod.def, { catchall: void 0 }));
  },
  extend(e) {
    return Xf(this, e);
  },
  safeExtend(e) {
    return Qf(this, e);
  },
  merge(e) {
    return ed(this, e);
  },
  pick(e) {
    return Yf(this, e);
  },
  omit(e) {
    return Gf(this, e);
  },
  partial(...e) {
    return ea(vu, this, e[0]);
  },
  exactPartial(...e) {
    return ea(ku, this, e[0], "exactPartial");
  },
  required(...e) {
    return td(wu, this, e[0]);
  }
});
function oe(e, t) {
  const n = {
    type: "object",
    shape: e ?? {},
    ...j(t)
  };
  return new yu(n);
}
function ce(e, t) {
  return new yu({
    type: "object",
    shape: e,
    catchall: Re(),
    ...j(t)
  });
}
const bu = /* @__PURE__ */ z("ZodUnion", (e, t) => {
  Tl.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => nu(e, n, r, i), e.options = t.options;
});
function Ae(e, t) {
  return new bu({
    type: "union",
    options: e,
    ...j(t)
  });
}
const Yg = /* @__PURE__ */ z("ZodDiscriminatedUnion", (e, t) => {
  bu.init(e, t), gh.init(e, t);
});
function Gg(e, t, n) {
  return new Yg({
    type: "union",
    options: t,
    discriminator: e,
    ...j(n)
  });
}
const Xg = /* @__PURE__ */ z("ZodIntersection", (e, t) => {
  yh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ru(e, n, r, i);
});
function Qg(e, t) {
  return new Xg({
    type: "intersection",
    left: e,
    right: t
  });
}
const Pa = /* @__PURE__ */ z("ZodRecord", (e, t) => {
  Ar(), bh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => iu(e, n, r, i), e.keyType = t.keyType, e.valueType = t.valueType;
});
function Nt(e, t, n) {
  return !t || !t._zod ? new Pa({
    type: "record",
    keyType: $(),
    valueType: e,
    ...j(t)
  }) : new Pa({
    type: "record",
    keyType: e,
    valueType: t,
    ...j(n)
  });
}
const Ai = /* @__PURE__ */ z("ZodEnum", (e, t) => {
  vh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (r, i, o) => Yl(e, r, i), e.enum = t.entries, e.options = [...e._zod.values];
  const n = new Set(Object.keys(t.entries));
  e.extract = (r, i) => {
    const o = {};
    for (const a of r)
      if (n.has(a))
        o[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Ai({
      ...t,
      checks: [],
      ...j(i),
      entries: o
    });
  }, e.exclude = (r, i) => {
    const o = { ...t.entries };
    for (const a of r)
      if (n.has(a))
        delete o[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Ai({
      ...t,
      checks: [],
      ...j(i),
      entries: o
    });
  };
});
function zi(e, t) {
  const n = Array.isArray(e) ? Object.fromEntries(e.map((r) => [r, r])) : e;
  return new Ai({
    type: "enum",
    entries: n,
    ...j(t)
  });
}
const ey = /* @__PURE__ */ z("ZodLiteral", (e, t) => {
  kh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Gl(e, n, r, i), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function V(e, t) {
  return new ey({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...j(t)
  });
}
const ty = /* @__PURE__ */ z("ZodTransform", (e, t) => {
  Ar(), wh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Ql(e, n, r, i), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      throw new ml(e.constructor.name);
    n.addIssue = (o) => {
      if (typeof o == "string")
        n.issues.push(Mn(o, n.value, t));
      else {
        const a = o;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = n.value), a.inst ?? (a.inst = e), n.issues.push(Mn(a));
      }
    };
    const i = t.transform(n.value, n);
    return i instanceof Promise ? i.then((o) => (n.value = o, n)) : (n.value = i, n);
  };
});
function ny(e) {
  return new ty({
    type: "transform",
    transform: e
  });
}
const vu = /* @__PURE__ */ z("ZodOptional", (e, t) => {
  Ol.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => po(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function Ma(e) {
  return new vu({
    type: "optional",
    innerType: e
  });
}
const ku = /* @__PURE__ */ z("ZodExactOptional", (e, t) => {
  xh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => po(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function ry(e) {
  return new ku({
    type: "optional",
    innerType: e
  });
}
const iy = /* @__PURE__ */ z("ZodNullable", (e, t) => {
  _h.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ou(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function Ra(e) {
  return new iy({
    type: "nullable",
    innerType: e
  });
}
const oy = /* @__PURE__ */ z("ZodDefault", (e, t) => {
  Sh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => lu(e, n, r, i), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function ay(e, t) {
  return new oy({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : cl(t);
    }
  });
}
const sy = /* @__PURE__ */ z("ZodPrefault", (e, t) => {
  Ih.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => uu(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function ly(e, t) {
  return new sy({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : cl(t);
    }
  });
}
const wu = /* @__PURE__ */ z("ZodNonOptional", (e, t) => {
  Eh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => au(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function uy(e, t) {
  return new wu({
    type: "nonoptional",
    innerType: e,
    ...j(t)
  });
}
const cy = /* @__PURE__ */ z("ZodCatch", (e, t) => {
  Ch.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => cu(e, n, r, i), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function fy(e, t) {
  return new cy({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : fd(t)
  });
}
const dy = /* @__PURE__ */ z("ZodPipe", (e, t) => {
  Ah.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => fu(e, n, r, i), e.in = t.in, e.out = t.out;
});
function $a(e, t) {
  return new dy({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const py = /* @__PURE__ */ z("ZodReadonly", (e, t) => {
  zh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => du(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function hy(e) {
  return new py({
    type: "readonly",
    innerType: e
  });
}
const my = /* @__PURE__ */ z("ZodLazy", (e, t) => {
  Th.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => pu(e, n, r, i), e.unwrap = () => e._zod.def.getter();
});
function gy(e) {
  return new my({
    type: "lazy",
    getter: e
  });
}
const ho = /* @__PURE__ */ z("ZodCustom", (e, t) => {
  Oh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Xl(e, n, r, i);
});
function ir(e, t) {
  return /* @__PURE__ */ Rm(ho, e ?? (() => !0), t);
}
function yy(e, t = {}) {
  return /* @__PURE__ */ $m(ho, e, t);
}
function by(e, t) {
  return /* @__PURE__ */ Dm(e, t);
}
const vy = /* @__PURE__ */ z("ZodInstanceOf", (e, t) => {
  ho.init(e, t);
}, {
  properties(e, t) {
    return this.check(/* @__PURE__ */ Cm(e, t));
  }
});
function xu(e, t = {}) {
  const n = new vy({
    type: "custom",
    check: "custom",
    fn: (r) => r instanceof e,
    abort: !0,
    ...j(t)
  });
  return n._zod.bag.Class = e, n._zod.check = (r) => {
    r.value instanceof e || r.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: r.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
var K;
(function(e) {
  e.ZodString = "ZodString", e.ZodNumber = "ZodNumber", e.ZodNaN = "ZodNaN", e.ZodBigInt = "ZodBigInt", e.ZodBoolean = "ZodBoolean", e.ZodDate = "ZodDate", e.ZodSymbol = "ZodSymbol", e.ZodUndefined = "ZodUndefined", e.ZodNull = "ZodNull", e.ZodAny = "ZodAny", e.ZodUnknown = "ZodUnknown", e.ZodNever = "ZodNever", e.ZodVoid = "ZodVoid", e.ZodArray = "ZodArray", e.ZodObject = "ZodObject", e.ZodUnion = "ZodUnion", e.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", e.ZodIntersection = "ZodIntersection", e.ZodTuple = "ZodTuple", e.ZodRecord = "ZodRecord", e.ZodMap = "ZodMap", e.ZodSet = "ZodSet", e.ZodFunction = "ZodFunction", e.ZodLazy = "ZodLazy", e.ZodLiteral = "ZodLiteral", e.ZodEnum = "ZodEnum", e.ZodEffects = "ZodEffects", e.ZodNativeEnum = "ZodNativeEnum", e.ZodOptional = "ZodOptional", e.ZodNullable = "ZodNullable", e.ZodDefault = "ZodDefault", e.ZodCatch = "ZodCatch", e.ZodPromise = "ZodPromise", e.ZodBranded = "ZodBranded", e.ZodPipeline = "ZodPipeline", e.ZodReadonly = "ZodReadonly";
})(K || (K = {}));
class Kr extends Error {
  constructor(t, n) {
    super(t), this.name = "ParseError", this.type = n.type, this.field = n.field, this.value = n.value, this.line = n.line;
  }
}
const Da = 10, ky = 13, Tt = 32;
function Yr(e) {
}
function wy(e) {
  if (typeof e == "function")
    throw new TypeError(
      "`config` must be an object, got a function instead. Did you mean `createParser({onEvent: fn})`?"
    );
  const { onEvent: t = Yr, onError: n = Yr, onRetry: r = Yr, onComment: i, maxBufferSize: o } = e, a = [];
  let s = 0, u = !0, c, l = "", f = 0, p, d = !1;
  function h(_) {
    if (d)
      throw new Error(
        "Cannot feed parser: it was terminated after exceeding the configured max buffer size. Call `reset()` to resume parsing."
      );
    if (u && (u = !1, _.charCodeAt(0) === 239 && _.charCodeAt(1) === 187 && _.charCodeAt(2) === 191 && (_ = _.slice(3))), a.length === 0) {
      const R = v(_);
      R !== "" && (a.push(R), s = R.length), m();
      return;
    }
    if (_.indexOf(`
`) === -1 && _.indexOf("\r") === -1) {
      a.push(_), s += _.length, m();
      return;
    }
    a.push(_);
    const y = a.join("");
    a.length = 0, s = 0;
    const C = v(y);
    C !== "" && (a.push(C), s = C.length), m();
  }
  function m() {
    o !== void 0 && (s + l.length <= o || (d = !0, a.length = 0, s = 0, c = void 0, l = "", f = 0, p = void 0, n(
      new Kr(`Buffered data exceeded max buffer size of ${o} characters`, {
        type: "max-buffer-size-exceeded"
      })
    )));
  }
  function v(_) {
    let y = 0;
    if (_.indexOf("\r") === -1) {
      let C = _.indexOf(`
`, y);
      for (; C !== -1; ) {
        if (y === C) {
          f > 0 && t({ id: c, event: p, data: l }), c = void 0, l = "", f = 0, p = void 0, y = C + 1, C = _.indexOf(`
`, y);
          continue;
        }
        const R = _.charCodeAt(y);
        if (Na(_, y, R)) {
          const F = _.charCodeAt(y + 5) === Tt ? y + 6 : y + 5, E = _.slice(F, C);
          if (f === 0 && _.charCodeAt(C + 1) === Da) {
            t({ id: c, event: p, data: E }), c = void 0, l = "", p = void 0, y = C + 2, C = _.indexOf(`
`, y);
            continue;
          }
          l = f === 0 ? E : `${l}
${E}`, f++;
        } else La(_, y, R) ? p = _.slice(
          _.charCodeAt(y + 6) === Tt ? y + 7 : y + 6,
          C
        ) || void 0 : g(_, y, C);
        y = C + 1, C = _.indexOf(`
`, y);
      }
      return _.slice(y);
    }
    for (; y < _.length; ) {
      const C = _.indexOf("\r", y), R = _.indexOf(`
`, y);
      let F = -1;
      if (C !== -1 && R !== -1 ? F = C < R ? C : R : C !== -1 ? C === _.length - 1 ? F = -1 : F = C : R !== -1 && (F = R), F === -1)
        break;
      g(_, y, F), y = F + 1, _.charCodeAt(y - 1) === ky && _.charCodeAt(y) === Da && y++;
    }
    return _.slice(y);
  }
  function g(_, y, C) {
    if (y === C) {
      I();
      return;
    }
    const R = _.charCodeAt(y);
    if (Na(_, y, R)) {
      const Z = _.charCodeAt(y + 5) === Tt ? y + 6 : y + 5, B = _.slice(Z, C);
      l = f === 0 ? B : `${l}
${B}`, f++;
      return;
    }
    if (La(_, y, R)) {
      p = _.slice(_.charCodeAt(y + 6) === Tt ? y + 7 : y + 6, C) || void 0;
      return;
    }
    if (R === 105 && _.charCodeAt(y + 1) === 100 && _.charCodeAt(y + 2) === 58) {
      const Z = _.slice(_.charCodeAt(y + 3) === Tt ? y + 4 : y + 3, C);
      Z.includes("\0") || (c = Z);
      return;
    }
    if (R === 58) {
      if (i) {
        const Z = _.slice(y, C);
        i(Z.slice(_.charCodeAt(y + 1) === Tt ? 2 : 1));
      }
      return;
    }
    const F = _.slice(y, C), E = F.indexOf(":");
    if (E === -1) {
      w(F, "", F);
      return;
    }
    const M = F.slice(0, E), L = F.charCodeAt(E + 1) === Tt ? 2 : 1, x = F.slice(E + L);
    w(M, x, F);
  }
  function w(_, y, C) {
    switch (_) {
      case "event":
        p = y || void 0;
        break;
      case "data":
        l = f === 0 ? y : `${l}
${y}`, f++;
        break;
      case "id":
        y.includes("\0") || (c = y);
        break;
      case "retry":
        /^\d+$/.test(y) ? r(parseInt(y, 10)) : n(
          new Kr(`Invalid \`retry\` value: "${y}"`, {
            type: "invalid-retry",
            value: y,
            line: C
          })
        );
        break;
      default:
        n(
          new Kr(
            `Unknown field "${_.length > 20 ? `${_.slice(0, 20)}…` : _}"`,
            { type: "unknown-field", field: _, value: y, line: C }
          )
        );
        break;
    }
  }
  function I() {
    f > 0 && t({
      id: c,
      event: p,
      data: l
    }), c = void 0, l = "", f = 0, p = void 0;
  }
  function S(_ = {}) {
    if (_.consume && a.length > 0) {
      const y = a.join("");
      g(y, 0, y.length);
    }
    u = !0, c = void 0, l = "", f = 0, p = void 0, a.length = 0, s = 0, d = !1;
  }
  return { feed: h, reset: S };
}
function Na(e, t, n) {
  return n === 100 && e.charCodeAt(t + 1) === 97 && e.charCodeAt(t + 2) === 116 && e.charCodeAt(t + 3) === 97 && e.charCodeAt(t + 4) === 58;
}
function La(e, t, n) {
  return n === 101 && e.charCodeAt(t + 1) === 118 && e.charCodeAt(t + 2) === 101 && e.charCodeAt(t + 3) === 110 && e.charCodeAt(t + 4) === 116 && e.charCodeAt(t + 5) === 58;
}
class xy extends TransformStream {
  constructor({ onError: t, onRetry: n, onComment: r, maxBufferSize: i } = {}) {
    let o;
    super({
      start(a) {
        o = wy({
          onEvent: (s) => {
            a.enqueue(s);
          },
          onError(s) {
            typeof t == "function" && t(s), (t === "terminate" || s.type === "max-buffer-size-exceeded") && a.error(s);
          },
          onRetry: n,
          onComment: r,
          maxBufferSize: i
        });
      },
      transform(a) {
        o.feed(a);
      }
    });
  }
}
var _y = Object.getOwnPropertyDescriptor(
  Object.getPrototypeOf(Uint8Array.prototype),
  Symbol.toStringTag
).get, Sy = Object.getOwnPropertyDescriptor(
  ArrayBuffer.prototype,
  "byteLength"
).get;
function Iy(e) {
  return ArrayBuffer.isView(e) && _y.call(e) === "Uint8Array";
}
function Ey(e) {
  if (typeof e != "object" || e === null || !("byteLength" in e))
    return !1;
  try {
    return Sy.call(e), !0;
  } catch {
    return !1;
  }
}
var Ln = ({
  prefix: e,
  size: t = 16,
  alphabet: n = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
  separator: r = "-"
} = {}) => {
  const i = () => {
    const o = n.length, a = new Array(t);
    for (let s = 0; s < t; s++)
      a[s] = n[Math.random() * o | 0];
    return a.join("");
  };
  if (e == null)
    return i;
  if (n.includes(r))
    throw new Df({
      argument: "separator",
      message: `The separator "${r}" must not be part of the alphabet "${n}".`
    });
  return () => `${e}${r}${i()}`;
}, Cy = Ln();
function Ut(e) {
  if (e == null)
    return {};
  const t = {};
  if (e instanceof Headers)
    e.forEach((n, r) => {
      t[r.toLowerCase()] = n;
    });
  else {
    Array.isArray(e) || (e = Object.entries(e));
    for (const [n, r] of e)
      r != null && (t[n.toLowerCase()] = r);
  }
  return t;
}
var Ay = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/, zy = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
function Fa(e) {
  const t = JSON.parse(e);
  return t === null || typeof t != "object" || Ay.test(e) === !1 && zy.test(e) === !1 ? t : Ty(t);
}
function Ty(e) {
  let t = [e];
  for (; t.length; ) {
    const n = t;
    t = [];
    for (const r of n) {
      if (Object.prototype.hasOwnProperty.call(r, "__proto__"))
        throw new SyntaxError("Object contains forbidden prototype property");
      if (Object.prototype.hasOwnProperty.call(r, "constructor") && r.constructor !== null && typeof r.constructor == "object" && Object.prototype.hasOwnProperty.call(r.constructor, "prototype"))
        throw new SyntaxError("Object contains forbidden prototype property");
      for (const i in r) {
        const o = r[i];
        o && typeof o == "object" && t.push(o);
      }
    }
  }
  return e;
}
function Oy(e) {
  const { stackTraceLimit: t } = Error;
  try {
    Error.stackTraceLimit = 0;
  } catch {
    return Fa(e);
  }
  try {
    return Fa(e);
  } finally {
    Error.stackTraceLimit = t;
  }
}
function mo(e) {
  if (e.type === "object" || Array.isArray(e.type) && e.type.includes("object")) {
    const { additionalProperties: n } = e;
    e.additionalProperties = n != null && typeof n != "boolean" ? gt(n) : !1;
    const { properties: r } = e;
    if (r != null)
      for (const i of Object.keys(r))
        r[i] = gt(r[i]);
  }
  e.items != null && (e.items = Array.isArray(e.items) ? e.items.map(gt) : gt(e.items)), e.anyOf != null && (e.anyOf = e.anyOf.map(gt)), e.allOf != null && (e.allOf = e.allOf.map(gt)), e.oneOf != null && (e.oneOf = e.oneOf.map(gt));
  const { definitions: t } = e;
  if (t != null)
    for (const n of Object.keys(t))
      t[n] = gt(t[n]);
  return e;
}
function gt(e) {
  return typeof e == "boolean" ? e : mo(e);
}
var Py = /* @__PURE__ */ Symbol(
  "Let zodToJsonSchema decide on which parser to use"
), ja = {
  name: void 0,
  $refStrategy: "root",
  basePath: ["#"],
  effectStrategy: "input",
  pipeStrategy: "all",
  dateStrategy: "format:date-time",
  mapStrategy: "entries",
  removeAdditionalStrategy: "passthrough",
  allowedAdditionalProperties: !0,
  rejectedAdditionalProperties: !1,
  definitionPath: "definitions",
  strictUnions: !1,
  definitions: {},
  errorMessages: !1,
  patternStrategy: "escape",
  applyRegexFlags: !1,
  emailStrategy: "format:email",
  base64Strategy: "contentEncoding:base64",
  nameStrategy: "ref"
}, My = (e) => typeof e == "string" ? {
  ...ja,
  name: e
} : {
  ...ja,
  ...e
};
function je() {
  return {};
}
function Ry(e, t) {
  var n, r, i;
  const o = {
    type: "array"
  };
  return (n = e.type) != null && n._def && ((i = (r = e.type) == null ? void 0 : r._def) == null ? void 0 : i.typeName) !== K.ZodAny && (o.items = re(e.type._def, {
    ...t,
    currentPath: [...t.currentPath, "items"]
  })), e.minLength && (o.minItems = e.minLength.value), e.maxLength && (o.maxItems = e.maxLength.value), e.exactLength && (o.minItems = e.exactLength.value, o.maxItems = e.exactLength.value), o;
}
function $y(e) {
  const t = {
    type: "integer",
    format: "int64"
  };
  if (!e.checks) return t;
  for (const n of e.checks)
    switch (n.kind) {
      case "min":
        n.inclusive ? t.minimum = n.value : t.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? t.maximum = n.value : t.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        t.multipleOf = n.value;
        break;
    }
  return t;
}
function Dy() {
  return { type: "boolean" };
}
function _u(e, t) {
  return re(e.type._def, t);
}
var Ny = (e, t) => re(e.innerType._def, t);
function Su(e, t, n) {
  const r = n ?? t.dateStrategy;
  if (Array.isArray(r))
    return {
      anyOf: r.map((i, o) => Su(e, t, i))
    };
  switch (r) {
    case "string":
    case "format:date-time":
      return {
        type: "string",
        format: "date-time"
      };
    case "format:date":
      return {
        type: "string",
        format: "date"
      };
    case "integer":
      return Ly(e);
  }
}
var Ly = (e) => {
  const t = {
    type: "integer",
    format: "unix-time"
  };
  for (const n of e.checks)
    switch (n.kind) {
      case "min":
        t.minimum = n.value;
        break;
      case "max":
        t.maximum = n.value;
        break;
    }
  return t;
};
function Fy(e, t) {
  return {
    ...re(e.innerType._def, t),
    default: e.defaultValue()
  };
}
function jy(e, t) {
  return t.effectStrategy === "input" ? re(e.schema._def, t) : je();
}
function Zy(e) {
  return {
    type: "string",
    enum: Array.from(e.values)
  };
}
var By = (e) => "type" in e && e.type === "string" ? !1 : "allOf" in e;
function Uy(e, t) {
  const n = [
    re(e.left._def, {
      ...t,
      currentPath: [...t.currentPath, "allOf", "0"]
    }),
    re(e.right._def, {
      ...t,
      currentPath: [...t.currentPath, "allOf", "1"]
    })
  ].filter((i) => !!i), r = [];
  return n.forEach((i) => {
    if (By(i))
      r.push(...i.allOf);
    else {
      let o = i;
      if ("additionalProperties" in i && i.additionalProperties === !1) {
        const { additionalProperties: a, ...s } = i;
        o = s;
      }
      r.push(o);
    }
  }), r.length ? { allOf: r } : void 0;
}
function Vy(e) {
  const t = typeof e.value;
  return t !== "bigint" && t !== "number" && t !== "boolean" && t !== "string" ? {
    type: Array.isArray(e.value) ? "array" : "object"
  } : {
    type: t === "bigint" ? "integer" : t,
    const: e.value
  };
}
var Gr = void 0, Ye = {
  /**
   * `c` was changed to `[cC]` to replicate /i flag
   */
  cuid: /^[cC][^\s-]{8,}$/,
  cuid2: /^[0-9a-z]+$/,
  ulid: /^[0-9A-HJKMNP-TV-Z]{26}$/,
  /**
   * `a-z` was added to replicate /i flag
   */
  email: /^(?!\.)(?!.*\.\.)([a-zA-Z0-9_'+\-.]*)[a-zA-Z0-9_+-]@([a-zA-Z0-9][a-zA-Z0-9-]*\.)+[a-zA-Z]{2,}$/,
  /**
   * Constructed a valid Unicode RegExp
   *
   * Lazily instantiate since this type of regex isn't supported
   * in all envs (e.g. React Native).
   *
   * See:
   * https://github.com/colinhacks/zod/issues/2433
   * Fix in Zod:
   * https://github.com/colinhacks/zod/commit/9340fd51e48576a75adc919bff65dbc4a5d4c99b
   */
  emoji: () => (Gr === void 0 && (Gr = RegExp(
    "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$",
    "u"
  )), Gr),
  /**
   * Unused
   */
  uuid: /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/,
  /**
   * Unused
   */
  ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
  ipv4Cidr: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,
  /**
   * Unused
   */
  ipv6: /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,
  ipv6Cidr: /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
  base64: /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,
  base64url: /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,
  nanoid: /^[a-zA-Z0-9_-]{21}$/,
  jwt: /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/
};
function Iu(e, t) {
  const n = {
    type: "string"
  };
  if (e.checks)
    for (const r of e.checks)
      switch (r.kind) {
        case "min":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value;
          break;
        case "max":
          n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "email":
          switch (t.emailStrategy) {
            case "format:email":
              Ge(n, "email", r.message, t);
              break;
            case "format:idn-email":
              Ge(n, "idn-email", r.message, t);
              break;
            case "pattern:zod":
              Ie(n, Ye.email, r.message, t);
              break;
          }
          break;
        case "url":
          Ge(n, "uri", r.message, t);
          break;
        case "uuid":
          Ge(n, "uuid", r.message, t);
          break;
        case "regex":
          Ie(n, r.regex, r.message, t);
          break;
        case "cuid":
          Ie(n, Ye.cuid, r.message, t);
          break;
        case "cuid2":
          Ie(n, Ye.cuid2, r.message, t);
          break;
        case "startsWith":
          Ie(
            n,
            RegExp(`^${Xr(r.value, t)}`),
            r.message,
            t
          );
          break;
        case "endsWith":
          Ie(
            n,
            RegExp(`${Xr(r.value, t)}$`),
            r.message,
            t
          );
          break;
        case "datetime":
          Ge(n, "date-time", r.message, t);
          break;
        case "date":
          Ge(n, "date", r.message, t);
          break;
        case "time":
          Ge(n, "time", r.message, t);
          break;
        case "duration":
          Ge(n, "duration", r.message, t);
          break;
        case "length":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value, n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "includes": {
          Ie(
            n,
            RegExp(Xr(r.value, t)),
            r.message,
            t
          );
          break;
        }
        case "ip": {
          r.version !== "v6" && Ge(n, "ipv4", r.message, t), r.version !== "v4" && Ge(n, "ipv6", r.message, t);
          break;
        }
        case "base64url":
          Ie(n, Ye.base64url, r.message, t);
          break;
        case "jwt":
          Ie(n, Ye.jwt, r.message, t);
          break;
        case "cidr": {
          r.version !== "v6" && Ie(n, Ye.ipv4Cidr, r.message, t), r.version !== "v4" && Ie(n, Ye.ipv6Cidr, r.message, t);
          break;
        }
        case "emoji":
          Ie(n, Ye.emoji(), r.message, t);
          break;
        case "ulid": {
          Ie(n, Ye.ulid, r.message, t);
          break;
        }
        case "base64": {
          switch (t.base64Strategy) {
            case "format:binary": {
              Ge(n, "binary", r.message, t);
              break;
            }
            case "contentEncoding:base64": {
              n.contentEncoding = "base64";
              break;
            }
            case "pattern:zod": {
              Ie(n, Ye.base64, r.message, t);
              break;
            }
          }
          break;
        }
        case "nanoid":
          Ie(n, Ye.nanoid, r.message, t);
      }
  return n;
}
function Xr(e, t) {
  return t.patternStrategy === "escape" ? Jy(e) : e;
}
var qy = new Set(
  "ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789"
);
function Jy(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    qy.has(e[n]) || (t += "\\"), t += e[n];
  return t;
}
function Ge(e, t, n, r) {
  var i;
  e.format || (i = e.anyOf) != null && i.some((o) => o.format) ? (e.anyOf || (e.anyOf = []), e.format && (e.anyOf.push({
    format: e.format
  }), delete e.format), e.anyOf.push({
    format: t,
    ...n && r.errorMessages && { errorMessage: { format: n } }
  })) : e.format = t;
}
function Ie(e, t, n, r) {
  var i;
  e.pattern || (i = e.allOf) != null && i.some((o) => o.pattern) ? (e.allOf || (e.allOf = []), e.pattern && (e.allOf.push({
    pattern: e.pattern
  }), delete e.pattern), e.allOf.push({
    pattern: Za(t, r),
    ...n && r.errorMessages && { errorMessage: { pattern: n } }
  })) : e.pattern = Za(t, r);
}
function Za(e, t) {
  var n;
  if (!t.applyRegexFlags || !e.flags)
    return e.source;
  const r = {
    i: e.flags.includes("i"),
    // Case-insensitive
    m: e.flags.includes("m"),
    // `^` and `$` matches adjacent to newline characters
    s: e.flags.includes("s")
    // `.` matches newlines
  }, i = r.i ? e.source.toLowerCase() : e.source;
  let o = "", a = !1, s = !1, u = !1;
  for (let c = 0; c < i.length; c++) {
    if (a) {
      o += i[c], a = !1;
      continue;
    }
    if (r.i) {
      if (s) {
        if (i[c].match(/[a-z]/)) {
          u ? (o += i[c], o += `${i[c - 2]}-${i[c]}`.toUpperCase(), u = !1) : i[c + 1] === "-" && ((n = i[c + 2]) != null && n.match(/[a-z]/)) ? (o += i[c], u = !0) : o += `${i[c]}${i[c].toUpperCase()}`;
          continue;
        }
      } else if (i[c].match(/[a-z]/)) {
        o += `[${i[c]}${i[c].toUpperCase()}]`;
        continue;
      }
    }
    if (r.m) {
      if (i[c] === "^") {
        o += `(^|(?<=[\r
]))`;
        continue;
      } else if (i[c] === "$") {
        o += `($|(?=[\r
]))`;
        continue;
      }
    }
    if (r.s && i[c] === ".") {
      o += s ? `${i[c]}\r
` : `[${i[c]}\r
]`;
      continue;
    }
    o += i[c], i[c] === "\\" ? a = !0 : s && i[c] === "]" ? s = !1 : !s && i[c] === "[" && (s = !0);
  }
  try {
    new RegExp(o);
  } catch {
    return console.warn(
      `Could not convert regex pattern at ${t.currentPath.join(
        "/"
      )} to a flag-independent form! Falling back to the flag-ignorant source`
    ), e.source;
  }
  return o;
}
function Eu(e, t) {
  var n, r, i, o, a, s;
  const u = {
    type: "object",
    additionalProperties: (n = re(e.valueType._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalProperties"]
    })) != null ? n : t.allowedAdditionalProperties
  };
  if (((r = e.keyType) == null ? void 0 : r._def.typeName) === K.ZodString && ((i = e.keyType._def.checks) != null && i.length)) {
    const { type: c, ...l } = Iu(e.keyType._def, t);
    return {
      ...u,
      propertyNames: l
    };
  } else {
    if (((o = e.keyType) == null ? void 0 : o._def.typeName) === K.ZodEnum)
      return {
        ...u,
        propertyNames: {
          enum: e.keyType._def.values
        }
      };
    if (((a = e.keyType) == null ? void 0 : a._def.typeName) === K.ZodBranded && e.keyType._def.type._def.typeName === K.ZodString && ((s = e.keyType._def.type._def.checks) != null && s.length)) {
      const { type: c, ...l } = _u(
        e.keyType._def,
        t
      );
      return {
        ...u,
        propertyNames: l
      };
    }
  }
  return u;
}
function Wy(e, t) {
  if (t.mapStrategy === "record")
    return Eu(e, t);
  const n = re(e.keyType._def, {
    ...t,
    currentPath: [...t.currentPath, "items", "items", "0"]
  }) || je(), r = re(e.valueType._def, {
    ...t,
    currentPath: [...t.currentPath, "items", "items", "1"]
  }) || je();
  return {
    type: "array",
    maxItems: 125,
    items: {
      type: "array",
      items: [n, r],
      minItems: 2,
      maxItems: 2
    }
  };
}
function Hy(e) {
  const t = e.values, r = Object.keys(e.values).filter((o) => typeof t[t[o]] != "number").map((o) => t[o]), i = Array.from(
    new Set(r.map((o) => typeof o))
  );
  return {
    type: i.length === 1 ? i[0] === "string" ? "string" : "number" : ["string", "number"],
    enum: r
  };
}
function Ky() {
  return { not: je() };
}
function Yy() {
  return {
    type: "null"
  };
}
var Ti = {
  ZodString: "string",
  ZodNumber: "number",
  ZodBigInt: "integer",
  ZodBoolean: "boolean",
  ZodNull: "null"
};
function Gy(e, t) {
  const n = e.options instanceof Map ? Array.from(e.options.values()) : e.options;
  if (n.every(
    (r) => r._def.typeName in Ti && (!r._def.checks || !r._def.checks.length)
  )) {
    const r = n.reduce((i, o) => {
      const a = Ti[o._def.typeName];
      return a && !i.includes(a) ? [...i, a] : i;
    }, []);
    return {
      type: r.length > 1 ? r : r[0]
    };
  } else if (n.every((r) => r._def.typeName === "ZodLiteral" && !r.description)) {
    const r = n.reduce(
      (i, o) => {
        const a = typeof o._def.value;
        switch (a) {
          case "string":
          case "number":
          case "boolean":
            return [...i, a];
          case "bigint":
            return [...i, "integer"];
          case "object":
            if (o._def.value === null) return [...i, "null"];
          case "symbol":
          case "undefined":
          case "function":
          default:
            return i;
        }
      },
      []
    );
    if (r.length === n.length) {
      const i = r.filter((o, a, s) => s.indexOf(o) === a);
      return {
        type: i.length > 1 ? i : i[0],
        enum: n.reduce(
          (o, a) => o.includes(a._def.value) ? o : [...o, a._def.value],
          []
        )
      };
    }
  } else if (n.every((r) => r._def.typeName === "ZodEnum"))
    return {
      type: "string",
      enum: n.reduce(
        (r, i) => [
          ...r,
          ...i._def.values.filter((o) => !r.includes(o))
        ],
        []
      )
    };
  return Xy(e, t);
}
var Xy = (e, t) => {
  const n = (e.options instanceof Map ? Array.from(e.options.values()) : e.options).map(
    (r, i) => re(r._def, {
      ...t,
      currentPath: [...t.currentPath, "anyOf", `${i}`]
    })
  ).filter(
    (r) => !!r && (!t.strictUnions || typeof r == "object" && Object.keys(r).length > 0)
  );
  return n.length ? { anyOf: n } : void 0;
};
function Qy(e, t) {
  if (["ZodString", "ZodNumber", "ZodBigInt", "ZodBoolean", "ZodNull"].includes(
    e.innerType._def.typeName
  ) && (!e.innerType._def.checks || !e.innerType._def.checks.length))
    return {
      type: [
        Ti[e.innerType._def.typeName],
        "null"
      ]
    };
  const n = re(e.innerType._def, {
    ...t,
    currentPath: [...t.currentPath, "anyOf", "0"]
  });
  return n && { anyOf: [n, { type: "null" }] };
}
function eb(e) {
  const t = {
    type: "number"
  };
  if (!e.checks) return t;
  for (const n of e.checks)
    switch (n.kind) {
      case "int":
        t.type = "integer";
        break;
      case "min":
        n.inclusive ? t.minimum = n.value : t.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? t.maximum = n.value : t.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        t.multipleOf = n.value;
        break;
    }
  return t;
}
function tb(e, t) {
  const n = {
    type: "object",
    properties: {}
  }, r = [], i = e.shape();
  for (const a in i) {
    let s = i[a];
    if (s === void 0 || s._def === void 0)
      continue;
    const u = rb(s), c = re(s._def, {
      ...t,
      currentPath: [...t.currentPath, "properties", a],
      propertyPath: [...t.currentPath, "properties", a]
    });
    c !== void 0 && (n.properties[a] = c, u || r.push(a));
  }
  r.length && (n.required = r);
  const o = nb(e, t);
  return o !== void 0 && (n.additionalProperties = o), n;
}
function nb(e, t) {
  if (e.catchall._def.typeName !== "ZodNever")
    return re(e.catchall._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalProperties"]
    });
  switch (e.unknownKeys) {
    case "passthrough":
      return t.allowedAdditionalProperties;
    case "strict":
      return t.rejectedAdditionalProperties;
    case "strip":
      return t.removeAdditionalStrategy === "strict" ? t.allowedAdditionalProperties : t.rejectedAdditionalProperties;
  }
}
function rb(e) {
  try {
    return e.isOptional();
  } catch {
    return !0;
  }
}
var ib = (e, t) => {
  var n;
  if (t.currentPath.toString() === ((n = t.propertyPath) == null ? void 0 : n.toString()))
    return re(e.innerType._def, t);
  const r = re(e.innerType._def, {
    ...t,
    currentPath: [...t.currentPath, "anyOf", "1"]
  });
  return r ? { anyOf: [{ not: je() }, r] } : je();
}, ob = (e, t) => {
  if (t.pipeStrategy === "input")
    return re(e.in._def, t);
  if (t.pipeStrategy === "output")
    return re(e.out._def, t);
  const n = re(e.in._def, {
    ...t,
    currentPath: [...t.currentPath, "allOf", "0"]
  }), r = re(e.out._def, {
    ...t,
    currentPath: [...t.currentPath, "allOf", n ? "1" : "0"]
  });
  return {
    allOf: [n, r].filter((i) => i !== void 0)
  };
};
function ab(e, t) {
  return re(e.type._def, t);
}
function sb(e, t) {
  const r = {
    type: "array",
    uniqueItems: !0,
    items: re(e.valueType._def, {
      ...t,
      currentPath: [...t.currentPath, "items"]
    })
  };
  return e.minSize && (r.minItems = e.minSize.value), e.maxSize && (r.maxItems = e.maxSize.value), r;
}
function lb(e, t) {
  return e.rest ? {
    type: "array",
    minItems: e.items.length,
    items: e.items.map(
      (n, r) => re(n._def, {
        ...t,
        currentPath: [...t.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    ),
    additionalItems: re(e.rest._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalItems"]
    })
  } : {
    type: "array",
    minItems: e.items.length,
    maxItems: e.items.length,
    items: e.items.map(
      (n, r) => re(n._def, {
        ...t,
        currentPath: [...t.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    )
  };
}
function ub() {
  return {
    not: je()
  };
}
function cb() {
  return je();
}
var fb = (e, t) => re(e.innerType._def, t), db = (e, t, n) => {
  switch (t) {
    case K.ZodString:
      return Iu(e, n);
    case K.ZodNumber:
      return eb(e);
    case K.ZodObject:
      return tb(e, n);
    case K.ZodBigInt:
      return $y(e);
    case K.ZodBoolean:
      return Dy();
    case K.ZodDate:
      return Su(e, n);
    case K.ZodUndefined:
      return ub();
    case K.ZodNull:
      return Yy();
    case K.ZodArray:
      return Ry(e, n);
    case K.ZodUnion:
    case K.ZodDiscriminatedUnion:
      return Gy(e, n);
    case K.ZodIntersection:
      return Uy(e, n);
    case K.ZodTuple:
      return lb(e, n);
    case K.ZodRecord:
      return Eu(e, n);
    case K.ZodLiteral:
      return Vy(e);
    case K.ZodEnum:
      return Zy(e);
    case K.ZodNativeEnum:
      return Hy(e);
    case K.ZodNullable:
      return Qy(e, n);
    case K.ZodOptional:
      return ib(e, n);
    case K.ZodMap:
      return Wy(e, n);
    case K.ZodSet:
      return sb(e, n);
    case K.ZodLazy:
      return () => e.getter()._def;
    case K.ZodPromise:
      return ab(e, n);
    case K.ZodNaN:
    case K.ZodNever:
      return Ky();
    case K.ZodEffects:
      return jy(e, n);
    case K.ZodAny:
      return je();
    case K.ZodUnknown:
      return cb();
    case K.ZodDefault:
      return Fy(e, n);
    case K.ZodBranded:
      return _u(e, n);
    case K.ZodReadonly:
      return fb(e, n);
    case K.ZodCatch:
      return Ny(e, n);
    case K.ZodPipeline:
      return ob(e, n);
    case K.ZodFunction:
    case K.ZodVoid:
    case K.ZodSymbol:
      return;
    default:
      return /* @__PURE__ */ ((r) => {
      })();
  }
}, pb = (e, t) => {
  let n = 0;
  for (; n < e.length && n < t.length && e[n] === t[n]; n++)
    ;
  return [(e.length - n).toString(), ...t.slice(n)].join("/");
};
function re(e, t, n = !1) {
  var r;
  const i = t.seen.get(e);
  if (t.override) {
    const u = (r = t.override) == null ? void 0 : r.call(
      t,
      e,
      t,
      i,
      n
    );
    if (u !== Py)
      return u;
  }
  if (i && !n) {
    const u = hb(i, t);
    if (u !== void 0)
      return u;
  }
  const o = { def: e, path: t.currentPath, jsonSchema: void 0 };
  t.seen.set(e, o);
  const a = db(e, e.typeName, t), s = typeof a == "function" ? re(a(), t) : a;
  if (s && mb(e, t, s), t.postProcess) {
    const u = t.postProcess(s, e, t);
    return o.jsonSchema = s, u;
  }
  return o.jsonSchema = s, s;
}
var hb = (e, t) => {
  switch (t.$refStrategy) {
    case "root":
      return { $ref: e.path.join("/") };
    case "relative":
      return { $ref: pb(t.currentPath, e.path) };
    case "none":
    case "seen":
      return e.path.length < t.currentPath.length && e.path.every((n, r) => t.currentPath[r] === n) ? (console.warn(
        `Recursive reference detected at ${t.currentPath.join(
          "/"
        )}! Defaulting to any`
      ), je()) : t.$refStrategy === "seen" ? je() : void 0;
  }
}, mb = (e, t, n) => (e.description && (n.description = e.description), n), gb = (e) => {
  const t = My(e), n = t.name !== void 0 ? [...t.basePath, t.definitionPath, t.name] : t.basePath;
  return {
    ...t,
    currentPath: n,
    propertyPath: void 0,
    seen: new Map(
      Object.entries(t.definitions).map(([r, i]) => [
        i._def,
        {
          def: i._def,
          path: [...t.basePath, t.definitionPath, r],
          // Resolution of references will be forced even though seen, so it's ok that the schema is undefined here for now.
          jsonSchema: void 0
        }
      ])
    )
  };
}, yb = (e, t) => {
  var n;
  const r = gb(t);
  let i = typeof t == "object" && t.definitions ? Object.entries(t.definitions).reduce(
    (c, [l, f]) => {
      var p;
      return {
        ...c,
        [l]: (p = re(
          f._def,
          {
            ...r,
            currentPath: [...r.basePath, r.definitionPath, l]
          },
          !0
        )) != null ? p : je()
      };
    },
    {}
  ) : void 0;
  const o = typeof t == "string" ? t : (t == null ? void 0 : t.nameStrategy) === "title" || t == null ? void 0 : t.name, a = (n = re(
    e._def,
    o === void 0 ? r : {
      ...r,
      currentPath: [...r.basePath, r.definitionPath, o]
    },
    !1
  )) != null ? n : je(), s = typeof t == "object" && t.name !== void 0 && t.nameStrategy === "title" ? t.name : void 0;
  s !== void 0 && (a.title = s);
  const u = o === void 0 ? i ? {
    ...a,
    [r.definitionPath]: i
  } : a : {
    $ref: [
      ...r.$refStrategy === "relative" ? [] : r.basePath,
      r.definitionPath,
      o
    ].join("/"),
    [r.definitionPath]: {
      ...i,
      [o]: a
    }
  };
  return u.$schema = "http://json-schema.org/draft-07/schema#", u;
}, Oi = /* @__PURE__ */ Symbol.for("vercel.ai.schema");
function bb(e) {
  let t;
  return () => (t == null && (t = e()), t);
}
function zr(e, {
  validate: t
} = {}) {
  return {
    [Oi]: !0,
    _type: void 0,
    // should never be used directly
    get jsonSchema() {
      return typeof e == "function" && (e = e()), e;
    },
    validate: t
  };
}
function vb(e) {
  return typeof e == "object" && e !== null && Oi in e && e[Oi] === !0 && "jsonSchema" in e && "validate" in e;
}
function go(e) {
  return e == null ? zr({
    type: "object",
    properties: {},
    additionalProperties: !1
  }) : vb(e) ? e : "~standard" in e ? e["~standard"].vendor === "zod" ? Cu(e) : kb(e) : e();
}
function kb(e) {
  return zr(
    () => {
      if (!wb(e))
        throw new Error(
          `Standard schema vendor '${e["~standard"].vendor}' does not support JSON Schema conversion.`
        );
      return mo(
        e["~standard"].jsonSchema.input({
          target: "draft-07"
        })
      );
    },
    {
      validate: async (t) => {
        const n = await e["~standard"].validate(t);
        return "value" in n ? { success: !0, value: n.value } : {
          success: !1,
          error: new Xt({
            value: t,
            cause: n.issues
          })
        };
      }
    }
  );
}
function wb(e) {
  return e["~standard"].jsonSchema != null;
}
function xb(e, t) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return zr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => yb(e, {
      $refStrategy: r ? "root" : "none"
    }),
    {
      validate: async (i) => {
        const o = await e.safeParseAsync(i);
        return o.success ? { success: !0, value: o.data } : { success: !1, error: o.error };
      }
    }
  );
}
function _b(e, t) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return zr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => mo(
      ig(e, {
        target: "draft-7",
        io: "input",
        reused: r ? "ref" : "inline"
      })
    ),
    {
      validate: async (i) => {
        const o = await hu(e, i);
        return o.success ? { success: !0, value: o.data } : { success: !1, error: o.error };
      }
    }
  );
}
function Sb(e) {
  return "_zod" in e;
}
function Cu(e, t) {
  return Sb(e) ? _b(e) : xb(e);
}
async function Ba({
  value: e,
  schema: t,
  context: n
}) {
  const r = await $n({ value: e, schema: t, context: n });
  if (!r.success)
    throw Xt.wrap({ value: e, cause: r.error, context: n });
  return r.value;
}
async function $n({
  value: e,
  schema: t,
  context: n
}) {
  const r = go(t);
  try {
    if (r.validate == null)
      return { success: !0, value: e, rawValue: e };
    const i = await r.validate(e);
    return i.success ? { success: !0, value: i.value, rawValue: e } : {
      success: !1,
      error: Xt.wrap({ value: e, cause: i.error, context: n }),
      rawValue: e
    };
  } catch (i) {
    return {
      success: !1,
      error: Xt.wrap({ value: e, cause: i, context: n }),
      rawValue: e
    };
  }
}
async function Lt({
  text: e,
  schema: t
}) {
  try {
    const n = Oy(e);
    return t == null ? { success: !0, value: n, rawValue: n } : await $n({ value: n, schema: t });
  } catch (n) {
    return {
      success: !1,
      error: Ko.isInstance(n) ? n : new Ko({ text: e, cause: n }),
      rawValue: void 0
    };
  }
}
function Ib({
  stream: e,
  schema: t
}) {
  return e.pipeThrough(new TextDecoderStream()).pipeThrough(new xy()).pipeThrough(
    new TransformStream({
      async transform({ data: n }, r) {
        n !== "[DONE]" && r.enqueue(await Lt({ text: n, schema: t }));
      }
    })
  );
}
async function wt(e) {
  return typeof e == "function" && (e = e()), e;
}
new TextDecoder();
function Au(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Eb = Object.defineProperty, Cb = (e, t) => {
  for (var n in t)
    Eb(e, n, { get: t[n], enumerable: !0 });
}, zu = "AI_InvalidArgumentError", Tu = `vercel.ai.error.${zu}`, Ab = Symbol.for(Tu), Ou, zb = class extends We {
  constructor({
    parameter: e,
    value: t,
    message: n
  }) {
    super({
      name: zu,
      message: `Invalid argument for parameter ${e}: ${n}`
    }), this[Ou] = !0, this.parameter = e, this.value = t;
  }
  static isInstance(e) {
    return We.hasMarker(e, Tu);
  }
};
Ou = Ab;
var Pu = "AI_NoObjectGeneratedError", Mu = `vercel.ai.error.${Pu}`, Tb = Symbol.for(Mu), Ru, _t = class extends We {
  constructor({
    message: e = "No object generated.",
    cause: t,
    text: n,
    response: r,
    usage: i,
    finishReason: o
  }) {
    super({ name: Pu, message: e, cause: t }), this[Ru] = !0, this.text = n, this.response = r, this.usage = i, this.finishReason = o;
  }
  static isInstance(e) {
    return We.hasMarker(e, Mu);
  }
};
Ru = Tb;
var $u = "AI_UIMessageStreamError", Du = `vercel.ai.error.${$u}`, Ob = Symbol.for(Du), Nu, Vt = class extends We {
  constructor({
    chunkType: e,
    chunkId: t,
    message: n
  }) {
    super({ name: $u, message: n }), this[Nu] = !0, this.chunkType = e, this.chunkId = t;
  }
  static isInstance(e) {
    return We.hasMarker(e, Du);
  }
};
Nu = Ob;
function Lu(e, t) {
  if (e === void 0 && t === void 0)
    return;
  if (e === void 0)
    return t;
  if (t === void 0)
    return e;
  const n = { ...e };
  for (const r in t)
    if (!(r === "__proto__" || r === "constructor" || r === "prototype") && Object.prototype.hasOwnProperty.call(t, r)) {
      const i = t[r];
      if (i === void 0)
        continue;
      const o = r in e ? e[r] : void 0, a = i !== null && typeof i == "object" && !Array.isArray(i) && !(i instanceof Date) && !(i instanceof RegExp), s = o != null && typeof o == "object" && !Array.isArray(o) && !(o instanceof Date) && !(o instanceof RegExp);
      a && s ? n[r] = Lu(
        o,
        i
      ) : n[r] = i;
    }
  return n;
}
var Fu = Ae([
  $(),
  ir(Iy, { message: "Must be a Uint8Array" }),
  ir(Ey, { message: "Must be an ArrayBuffer" }),
  ir(
    // Buffer might not be available in some environments such as CloudFlare:
    (e) => {
      var t, n;
      return (n = (t = globalThis.Buffer) == null ? void 0 : t.isBuffer(e)) != null ? n : !1;
    },
    { message: "Must be a Buffer" }
  )
]), Ft = gy(
  () => Ae([
    qg(),
    $(),
    Zg(),
    Ce(),
    Nt($(), Ft.optional()),
    on(Ft)
  ])
), ee = Nt(
  $(),
  Nt($(), Ft.optional())
), ju = oe({
  type: V("text"),
  text: $(),
  providerOptions: ee.optional()
}), Pb = oe({
  type: V("image"),
  image: Ae([Fu, xu(URL)]),
  mediaType: $().optional(),
  providerOptions: ee.optional()
}), Zu = oe({
  type: V("file"),
  data: Ae([Fu, xu(URL)]),
  filename: $().optional(),
  mediaType: $(),
  providerOptions: ee.optional()
}), Mb = oe({
  type: V("reasoning"),
  text: $(),
  providerOptions: ee.optional()
}), Rb = oe({
  type: V("tool-call"),
  toolCallId: $(),
  toolName: $(),
  input: Re(),
  providerOptions: ee.optional(),
  providerExecuted: Ce().optional()
}), $b = Gg(
  "type",
  [
    oe({
      type: V("text"),
      value: $(),
      providerOptions: ee.optional()
    }),
    oe({
      type: V("json"),
      value: Ft,
      providerOptions: ee.optional()
    }),
    oe({
      type: V("execution-denied"),
      reason: $().optional(),
      providerOptions: ee.optional()
    }),
    oe({
      type: V("error-text"),
      value: $(),
      providerOptions: ee.optional()
    }),
    oe({
      type: V("error-json"),
      value: Ft,
      providerOptions: ee.optional()
    }),
    oe({
      type: V("content"),
      value: on(
        Ae([
          oe({
            type: V("text"),
            text: $(),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("media"),
            data: $(),
            mediaType: $()
          }),
          oe({
            type: V("file-data"),
            data: $(),
            mediaType: $(),
            filename: $().optional(),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("file-url"),
            url: $(),
            mediaType: $().optional(),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("file-id"),
            fileId: Ae([$(), Nt($(), $())]),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("image-data"),
            data: $(),
            mediaType: $(),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("image-url"),
            url: $(),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("image-file-id"),
            fileId: Ae([$(), Nt($(), $())]),
            providerOptions: ee.optional()
          }),
          oe({
            type: V("custom"),
            providerOptions: ee.optional()
          })
        ])
      )
    })
  ]
), Bu = oe({
  type: V("tool-result"),
  toolCallId: $(),
  toolName: $(),
  output: $b,
  providerOptions: ee.optional()
}), Db = oe({
  type: V("tool-approval-request"),
  approvalId: $(),
  toolCallId: $(),
  signature: $().optional(),
  inputSchemaInput: Re().optional()
}), Nb = oe({
  type: V("tool-approval-response"),
  approvalId: $(),
  approved: Ce(),
  reason: $().optional()
}), Lb = oe(
  {
    role: V("system"),
    content: $(),
    providerOptions: ee.optional()
  }
), Fb = oe({
  role: V("user"),
  content: Ae([
    $(),
    on(Ae([ju, Pb, Zu]))
  ]),
  providerOptions: ee.optional()
}), jb = oe({
  role: V("assistant"),
  content: Ae([
    $(),
    on(
      Ae([
        ju,
        Zu,
        Mb,
        Rb,
        Bu,
        Db
      ])
    )
  ]),
  providerOptions: ee.optional()
}), Zb = oe({
  role: V("tool"),
  content: on(Ae([Bu, Nb])),
  providerOptions: ee.optional()
});
Ae([
  Lb,
  Fb,
  jb,
  Zb
]);
new TextEncoder();
var Bb = {};
Cb(Bb, {
  array: () => Jb,
  choice: () => Wb,
  json: () => Hb,
  object: () => qb,
  text: () => Vb
});
function Ub(e) {
  const t = ["ROOT"];
  let n = -1, r = null, i = 0;
  function o(l) {
    return l >= "0" && l <= "9" || l >= "A" && l <= "F" || l >= "a" && l <= "f";
  }
  function a(l, f, p) {
    switch (l) {
      case '"': {
        n = f, t.pop(), t.push(p), t.push("INSIDE_STRING");
        break;
      }
      case "f":
      case "t":
      case "n": {
        n = f, r = f, t.pop(), t.push(p), t.push("INSIDE_LITERAL");
        break;
      }
      case "-": {
        t.pop(), t.push(p), t.push("INSIDE_NUMBER");
        break;
      }
      case "0":
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9": {
        n = f, t.pop(), t.push(p), t.push("INSIDE_NUMBER");
        break;
      }
      case "{": {
        n = f, t.pop(), t.push(p), t.push("INSIDE_OBJECT_START");
        break;
      }
      case "[": {
        n = f, t.pop(), t.push(p), t.push("INSIDE_ARRAY_START");
        break;
      }
    }
  }
  function s(l, f) {
    switch (l) {
      case ",": {
        t.pop(), t.push("INSIDE_OBJECT_AFTER_COMMA");
        break;
      }
      case "}": {
        n = f, t.pop();
        break;
      }
    }
  }
  function u(l, f) {
    switch (l) {
      case ",": {
        t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
        break;
      }
      case "]": {
        n = f, t.pop();
        break;
      }
    }
  }
  for (let l = 0; l < e.length; l++) {
    const f = e[l];
    switch (t[t.length - 1]) {
      case "ROOT":
        a(f, l, "FINISH");
        break;
      case "INSIDE_OBJECT_START": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_KEY");
            break;
          }
          case "}": {
            n = l, t.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_COMMA": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_KEY": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_AFTER_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_KEY": {
        switch (f) {
          case ":": {
            t.pop(), t.push("INSIDE_OBJECT_BEFORE_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_BEFORE_VALUE": {
        a(f, l, "INSIDE_OBJECT_AFTER_VALUE");
        break;
      }
      case "INSIDE_OBJECT_AFTER_VALUE": {
        s(f, l);
        break;
      }
      case "INSIDE_STRING": {
        switch (f) {
          case '"': {
            t.pop(), n = l;
            break;
          }
          case "\\": {
            t.push("INSIDE_STRING_ESCAPE");
            break;
          }
          default:
            n = l;
        }
        break;
      }
      case "INSIDE_ARRAY_START": {
        switch (f) {
          case "]": {
            n = l, t.pop();
            break;
          }
          default: {
            n = l, a(f, l, "INSIDE_ARRAY_AFTER_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_VALUE": {
        switch (f) {
          case ",": {
            t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
            break;
          }
          case "]": {
            n = l, t.pop();
            break;
          }
          default: {
            n = l;
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_COMMA": {
        a(f, l, "INSIDE_ARRAY_AFTER_VALUE");
        break;
      }
      case "INSIDE_STRING_ESCAPE": {
        t.pop(), f === "u" ? (i = 0, t.push("INSIDE_STRING_UNICODE_ESCAPE")) : n = l;
        break;
      }
      case "INSIDE_STRING_UNICODE_ESCAPE": {
        o(f) && (i++, i === 4 && (t.pop(), n = l));
        break;
      }
      case "INSIDE_NUMBER": {
        switch (f) {
          case "0":
          case "1":
          case "2":
          case "3":
          case "4":
          case "5":
          case "6":
          case "7":
          case "8":
          case "9": {
            n = l;
            break;
          }
          case "e":
          case "E":
          case "-":
          case ".":
            break;
          case ",": {
            t.pop(), t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && s(f, l);
            break;
          }
          case "}": {
            t.pop(), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && s(f, l);
            break;
          }
          case "]": {
            t.pop(), t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l);
            break;
          }
          default: {
            t.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_LITERAL": {
        const d = e.substring(r, l + 1);
        !"false".startsWith(d) && !"true".startsWith(d) && !"null".startsWith(d) ? (t.pop(), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" ? s(f, l) : t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l)) : n = l;
        break;
      }
    }
  }
  let c = e.slice(0, n + 1);
  for (let l = t.length - 1; l >= 0; l--)
    switch (t[l]) {
      case "INSIDE_STRING": {
        c += '"';
        break;
      }
      case "INSIDE_OBJECT_KEY":
      case "INSIDE_OBJECT_AFTER_KEY":
      case "INSIDE_OBJECT_AFTER_COMMA":
      case "INSIDE_OBJECT_START":
      case "INSIDE_OBJECT_BEFORE_VALUE":
      case "INSIDE_OBJECT_AFTER_VALUE": {
        c += "}";
        break;
      }
      case "INSIDE_ARRAY_START":
      case "INSIDE_ARRAY_AFTER_COMMA":
      case "INSIDE_ARRAY_AFTER_VALUE": {
        c += "]";
        break;
      }
      case "INSIDE_LITERAL": {
        const p = e.substring(r, e.length);
        "true".startsWith(p) ? c += "true".slice(p.length) : "false".startsWith(p) ? c += "false".slice(p.length) : "null".startsWith(p) && (c += "null".slice(p.length));
      }
    }
  return c;
}
async function Fn(e) {
  if (e === void 0)
    return { value: void 0, state: "undefined-input" };
  let t = await Lt({ text: e });
  return t.success ? { value: t.value, state: "successful-parse" } : (t = await Lt({ text: Ub(e) }), t.success ? { value: t.value, state: "repaired-parse" } : { value: void 0, state: "failed-parse" });
}
var Vb = () => ({
  name: "text",
  responseFormat: Promise.resolve({ type: "text" }),
  async parseCompleteOutput({ text: e }) {
    return e;
  },
  async parsePartialOutput({ text: e }) {
    return { partial: e };
  },
  createElementStreamTransform() {
  }
}), qb = ({
  schema: e,
  name: t,
  description: n
}) => {
  const r = go(e);
  return {
    name: "object",
    responseFormat: wt(r.jsonSchema).then((i) => ({
      type: "json",
      schema: i,
      ...t != null && { name: t },
      ...n != null && { description: n }
    })),
    async parseCompleteOutput({ text: i }, o) {
      const a = await Lt({ text: i });
      if (!a.success)
        throw new _t({
          message: "No object generated: could not parse the response.",
          cause: a.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const s = await $n({
        value: a.value,
        schema: r
      });
      if (!s.success)
        throw new _t({
          message: "No object generated: response did not match schema.",
          cause: s.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      return s.value;
    },
    async parsePartialOutput({ text: i }) {
      const o = await Fn(i);
      switch (o.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse":
          return {
            // Note: currently no validation of partial results:
            partial: o.value
          };
      }
    },
    createElementStreamTransform() {
    }
  };
}, Jb = ({
  element: e,
  name: t,
  description: n
}) => {
  const r = go(e);
  return {
    name: "array",
    // JSON schema that describes an array of elements:
    responseFormat: wt(r.jsonSchema).then((i) => {
      const { $schema: o, ...a } = i;
      return {
        type: "json",
        schema: {
          $schema: "http://json-schema.org/draft-07/schema#",
          type: "object",
          properties: {
            elements: { type: "array", items: a }
          },
          required: ["elements"],
          additionalProperties: !1
        },
        ...t != null && { name: t },
        ...n != null && { description: n }
      };
    }),
    async parseCompleteOutput({ text: i }, o) {
      const a = await Lt({ text: i });
      if (!a.success)
        throw new _t({
          message: "No object generated: could not parse the response.",
          cause: a.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const s = a.value;
      if (s == null || typeof s != "object" || !("elements" in s) || !Array.isArray(s.elements))
        throw new _t({
          message: "No object generated: response did not match schema.",
          cause: new Xt({
            value: s,
            cause: "response must be an object with an elements array"
          }),
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const u = [];
      for (const c of s.elements) {
        const l = await $n({
          value: c,
          schema: r
        });
        if (!l.success)
          throw new _t({
            message: "No object generated: response did not match schema.",
            cause: l.error,
            text: i,
            response: o.response,
            usage: o.usage,
            finishReason: o.finishReason
          });
        u.push(l.value);
      }
      return u;
    },
    async parsePartialOutput({ text: i }) {
      const o = await Fn(i);
      switch (o.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse": {
          const a = o.value;
          if (a == null || typeof a != "object" || !("elements" in a) || !Array.isArray(a.elements))
            return;
          const s = o.state === "repaired-parse" && a.elements.length > 0 ? a.elements.slice(0, -1) : a.elements, u = [];
          for (const c of s) {
            const l = await $n({
              value: c,
              schema: r
            });
            l.success && u.push(l.value);
          }
          return { partial: u };
        }
      }
    },
    createElementStreamTransform() {
      let i = 0;
      return new TransformStream({
        transform({ partialOutput: o }, a) {
          if (o != null)
            for (; i < o.length; i++)
              a.enqueue(o[i]);
        }
      });
    }
  };
}, Wb = ({
  options: e,
  name: t,
  description: n
}) => ({
  name: "choice",
  // JSON schema that describes an enumeration:
  responseFormat: Promise.resolve({
    type: "json",
    schema: {
      $schema: "http://json-schema.org/draft-07/schema#",
      type: "object",
      properties: {
        result: { type: "string", enum: e }
      },
      required: ["result"],
      additionalProperties: !1
    },
    ...t != null && { name: t },
    ...n != null && { description: n }
  }),
  async parseCompleteOutput({ text: r }, i) {
    const o = await Lt({ text: r });
    if (!o.success)
      throw new _t({
        message: "No object generated: could not parse the response.",
        cause: o.error,
        text: r,
        response: i.response,
        usage: i.usage,
        finishReason: i.finishReason
      });
    const a = o.value;
    if (a == null || typeof a != "object" || !("result" in a) || typeof a.result != "string" || !e.includes(a.result))
      throw new _t({
        message: "No object generated: response did not match schema.",
        cause: new Xt({
          value: a,
          cause: "response must be an object that contains a choice value."
        }),
        text: r,
        response: i.response,
        usage: i.usage,
        finishReason: i.finishReason
      });
    return a.result;
  },
  async parsePartialOutput({ text: r }) {
    const i = await Fn(r);
    switch (i.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse": {
        const o = i.value;
        if (o == null || typeof o != "object" || !("result" in o) || typeof o.result != "string")
          return;
        const a = e.filter(
          (s) => s.startsWith(o.result)
        );
        return i.state === "successful-parse" ? a.includes(o.result) ? { partial: o.result } : void 0 : a.length === 1 ? { partial: a[0] } : void 0;
      }
    }
  },
  createElementStreamTransform() {
  }
}), Hb = ({
  name: e,
  description: t
} = {}) => ({
  name: "json",
  responseFormat: Promise.resolve({
    type: "json",
    ...e != null && { name: e },
    ...t != null && { description: t }
  }),
  async parseCompleteOutput({ text: n }, r) {
    const i = await Lt({ text: n });
    if (!i.success)
      throw new _t({
        message: "No object generated: could not parse the response.",
        cause: i.error,
        text: n,
        response: r.response,
        usage: r.usage,
        finishReason: r.finishReason
      });
    return i.value;
  },
  async parsePartialOutput({ text: n }) {
    const r = await Fn(n);
    switch (r.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse":
        return r.value === void 0 ? void 0 : { partial: r.value };
    }
  },
  createElementStreamTransform() {
  }
});
Ln({
  prefix: "aitxt",
  size: 24
});
(class extends TransformStream {
  constructor() {
    super({
      transform(e, t) {
        t.enqueue(`data: ${JSON.stringify(e)}

`);
      },
      flush(e) {
        e.enqueue(`data: [DONE]

`);
      }
    });
  }
});
var hn = Nt(
  $(),
  Ft.optional()
), Kb = bb(
  () => Cu(
    Ae([
      ce({
        type: V("text-start"),
        id: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("text-delta"),
        id: $(),
        delta: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("text-end"),
        id: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("error"),
        errorText: $()
      }),
      ce({
        type: V("tool-input-start"),
        toolCallId: $(),
        toolName: $(),
        inputEncoding: zi(["json", "text"]).optional(),
        providerExecuted: Ce().optional(),
        providerMetadata: ee.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        title: $().optional()
      }),
      ce({
        type: V("tool-input-delta"),
        toolCallId: $(),
        inputTextDelta: $()
      }),
      ce({
        type: V("tool-input-available"),
        toolCallId: $(),
        toolName: $(),
        input: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: ee.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        title: $().optional()
      }),
      ce({
        type: V("tool-input-error"),
        toolCallId: $(),
        toolName: $(),
        input: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: ee.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        errorText: $(),
        title: $().optional()
      }),
      ce({
        type: V("tool-approval-request"),
        approvalId: $(),
        toolCallId: $(),
        approvalDescriptor: Re().optional(),
        inputSchemaInput: Re().optional(),
        signature: $().optional()
      }),
      ce({
        type: V("tool-output-available"),
        toolCallId: $(),
        output: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: ee.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        preliminary: Ce().optional()
      }),
      ce({
        type: V("tool-output-error"),
        toolCallId: $(),
        errorText: $(),
        providerExecuted: Ce().optional(),
        providerMetadata: ee.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional()
      }),
      ce({
        type: V("tool-output-denied"),
        toolCallId: $()
      }),
      ce({
        type: V("reasoning-start"),
        id: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("reasoning-delta"),
        id: $(),
        delta: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("reasoning-end"),
        id: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("source-url"),
        sourceId: $(),
        url: $(),
        title: $().optional(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("source-document"),
        sourceId: $(),
        mediaType: $(),
        title: $(),
        filename: $().optional(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: V("file"),
        url: $(),
        mediaType: $(),
        providerMetadata: ee.optional()
      }),
      ce({
        type: ir(
          (e) => typeof e == "string" && e.startsWith("data-"),
          { message: 'Type must start with "data-"' }
        ),
        id: $().optional(),
        data: Re(),
        transient: Ce().optional()
      }),
      ce({
        type: V("start-step")
      }),
      ce({
        type: V("finish-step")
      }),
      ce({
        type: V("start"),
        messageId: $().optional(),
        messageMetadata: Re().optional()
      }),
      ce({
        type: V("finish"),
        finishReason: zi([
          "stop",
          "length",
          "content-filter",
          "tool-calls",
          "error",
          "other"
        ]).optional(),
        messageMetadata: Re().optional()
      }),
      ce({
        type: V("abort"),
        reason: $().optional()
      }),
      ce({
        type: V("message-metadata"),
        messageMetadata: Re()
      })
    ])
  )
);
function Yb(e) {
  return e.type.startsWith("data-");
}
function Cn() {
  return /* @__PURE__ */ Object.create(null);
}
function br(e) {
  return e.type.startsWith("tool-");
}
function Gb(e) {
  return e.type === "dynamic-tool";
}
function st(e) {
  return br(e) || Gb(e);
}
function Pi(e) {
  return e.type.split("-").slice(1).join("-");
}
function Uu({
  lastMessage: e,
  messageId: t
}) {
  var n;
  const r = (e == null ? void 0 : e.role) === "assistant" ? e : {
    id: t,
    metadata: void 0,
    role: "assistant",
    parts: []
  }, i = Cn(), o = r.parts.findLastIndex(
    (s) => s.type === "step-start"
  );
  let a = 0;
  for (const s of r.parts.slice(o + 1)) {
    if (!st(s))
      continue;
    const u = a;
    br(s) && a++, s.state === "input-streaming" && (i[s.toolCallId] = {
      text: (n = s.rawInput) != null ? n : "",
      inputEncoding: s.inputEncoding,
      index: u,
      toolName: s.type === "dynamic-tool" ? s.toolName : Pi(s),
      dynamic: s.type === "dynamic-tool",
      title: s.title,
      toolMetadata: s.toolMetadata
    });
  }
  return {
    message: r,
    activeTextParts: Cn(),
    activeReasoningParts: Cn(),
    partialToolCalls: i
  };
}
function Xb({
  stream: e,
  messageMetadataSchema: t,
  dataPartSchemas: n,
  runUpdateMessageJob: r,
  onError: i,
  onToolCall: o,
  onData: a,
  resetStateOnMessageIdChange: s = !1,
  resetStateOnFirstMessageStart: u = !1
}) {
  let c = !0;
  return e.pipeThrough(
    new TransformStream({
      async transform(l, f) {
        await r(async ({ state: p, write: d }) => {
          var h, m, v, g, w, I, S, _, y;
          function C() {
            const x = p.message.parts;
            let Z = x.length - 1;
            for (; Z >= 0 && x[Z].type !== "step-start"; )
              Z--;
            return x.slice(Z + 1);
          }
          function R() {
            return C().filter(st);
          }
          function F(x) {
            let B = R().find(
              (Y) => Y.toolCallId === x
            );
            if (B == null) {
              const Y = p.message.parts;
              for (let N = Y.length - 1; N >= 0; N--) {
                const H = Y[N];
                if (st(H) && H.toolCallId === x) {
                  B = H;
                  break;
                }
              }
            }
            if (B == null)
              throw new Vt({
                chunkType: "tool-invocation",
                chunkId: x,
                message: `No tool invocation found for tool call ID "${x}".`
              });
            return B;
          }
          function E(x, Z) {
            var B;
            const Y = Z ?? C().find(
              (le) => br(le) && le.toolCallId === x.toolCallId
            ), N = x, H = Y;
            if (Y != null) {
              Y.state = x.state, H.type = `tool-${x.toolName}`, H.input = N.input, H.output = N.output, H.errorText = N.errorText, H.rawInput = N.rawInput, N.inputEncoding != null ? H.inputEncoding = N.inputEncoding : delete H.inputEncoding, H.preliminary = N.preliminary, x.title !== void 0 && (H.title = x.title), x.toolMetadata !== void 0 && (H.toolMetadata = x.toolMetadata), H.providerExecuted = (B = N.providerExecuted) != null ? B : Y.providerExecuted;
              const le = N.providerMetadata;
              if (le != null)
                if (x.state === "output-available" || x.state === "output-error") {
                  const b = Y;
                  b.resultProviderMetadata = le;
                } else
                  Y.callProviderMetadata = le;
            } else
              p.message.parts.push({
                type: `tool-${x.toolName}`,
                toolCallId: x.toolCallId,
                state: x.state,
                title: x.title,
                ...x.toolMetadata !== void 0 ? { toolMetadata: x.toolMetadata } : {},
                input: N.input,
                ...N.inputEncoding != null ? { inputEncoding: N.inputEncoding } : {},
                output: N.output,
                rawInput: N.rawInput,
                errorText: N.errorText,
                providerExecuted: N.providerExecuted,
                preliminary: N.preliminary,
                ...N.providerMetadata != null && (x.state === "output-available" || x.state === "output-error") ? { resultProviderMetadata: N.providerMetadata } : {},
                ...N.providerMetadata != null && !(x.state === "output-available" || x.state === "output-error") ? { callProviderMetadata: N.providerMetadata } : {}
              });
          }
          function M(x, Z) {
            var B;
            const Y = Z ?? C().find(
              (le) => le.type === "dynamic-tool" && le.toolCallId === x.toolCallId
            ), N = x, H = Y;
            if (Y != null) {
              Y.state = x.state, H.toolName = x.toolName, H.input = N.input, H.output = N.output, H.errorText = N.errorText, H.rawInput = N.rawInput, N.inputEncoding != null ? H.inputEncoding = N.inputEncoding : delete H.inputEncoding, H.preliminary = N.preliminary, x.title !== void 0 && (H.title = x.title), x.toolMetadata !== void 0 && (H.toolMetadata = x.toolMetadata), H.providerExecuted = (B = N.providerExecuted) != null ? B : Y.providerExecuted;
              const le = N.providerMetadata;
              if (le != null)
                if (x.state === "output-available" || x.state === "output-error") {
                  const b = Y;
                  b.resultProviderMetadata = le;
                } else
                  Y.callProviderMetadata = le;
            } else
              p.message.parts.push({
                type: "dynamic-tool",
                toolName: x.toolName,
                toolCallId: x.toolCallId,
                state: x.state,
                input: N.input,
                ...N.inputEncoding != null ? { inputEncoding: N.inputEncoding } : {},
                output: N.output,
                errorText: N.errorText,
                preliminary: N.preliminary,
                providerExecuted: N.providerExecuted,
                title: x.title,
                ...x.toolMetadata !== void 0 ? { toolMetadata: x.toolMetadata } : {},
                ...N.providerMetadata != null && (x.state === "output-available" || x.state === "output-error") ? { resultProviderMetadata: N.providerMetadata } : {},
                ...N.providerMetadata != null && !(x.state === "output-available" || x.state === "output-error") ? { callProviderMetadata: N.providerMetadata } : {}
              });
          }
          async function L(x) {
            if (x != null) {
              const Z = p.message.metadata != null ? Lu(p.message.metadata, x) : x;
              t != null && await Ba({
                value: Z,
                schema: t,
                context: {
                  field: "message.metadata",
                  entityId: p.message.id
                }
              }), p.message.metadata = Z;
            }
          }
          switch (l.type) {
            case "text-start": {
              const x = {
                type: "text",
                text: "",
                providerMetadata: l.providerMetadata,
                state: "streaming"
              };
              p.activeTextParts[l.id] = x, p.message.parts.push(x), d();
              break;
            }
            case "text-delta": {
              const x = p.activeTextParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "text-delta",
                  chunkId: l.id,
                  message: `Received text-delta for missing text part with ID "${l.id}". Ensure a "text-start" chunk is sent before any "text-delta" chunks.`
                });
              x.text += l.delta, x.providerMetadata = (h = l.providerMetadata) != null ? h : x.providerMetadata, d();
              break;
            }
            case "text-end": {
              const x = p.activeTextParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "text-end",
                  chunkId: l.id,
                  message: `Received text-end for missing text part with ID "${l.id}". Ensure a "text-start" chunk is sent before any "text-end" chunks.`
                });
              x.state = "done", x.providerMetadata = (m = l.providerMetadata) != null ? m : x.providerMetadata, delete p.activeTextParts[l.id], d();
              break;
            }
            case "reasoning-start": {
              const x = {
                type: "reasoning",
                id: l.id,
                text: "",
                providerMetadata: l.providerMetadata,
                state: "streaming"
              };
              p.activeReasoningParts[l.id] = x, p.message.parts.push(x), d();
              break;
            }
            case "reasoning-delta": {
              const x = p.activeReasoningParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "reasoning-delta",
                  chunkId: l.id,
                  message: `Received reasoning-delta for missing reasoning part with ID "${l.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-delta" chunks.`
                });
              x.text += l.delta, x.providerMetadata = (v = l.providerMetadata) != null ? v : x.providerMetadata, d();
              break;
            }
            case "reasoning-end": {
              const x = p.activeReasoningParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "reasoning-end",
                  chunkId: l.id,
                  message: `Received reasoning-end for missing reasoning part with ID "${l.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-end" chunks.`
                });
              x.providerMetadata = (g = l.providerMetadata) != null ? g : x.providerMetadata, x.state = "done", delete p.activeReasoningParts[l.id], d();
              break;
            }
            case "file": {
              p.message.parts.push({
                type: "file",
                mediaType: l.mediaType,
                url: l.url,
                ...l.providerMetadata != null ? { providerMetadata: l.providerMetadata } : {}
              }), d();
              break;
            }
            case "source-url": {
              p.message.parts.push({
                type: "source-url",
                sourceId: l.sourceId,
                url: l.url,
                title: l.title,
                providerMetadata: l.providerMetadata
              }), d();
              break;
            }
            case "source-document": {
              p.message.parts.push({
                type: "source-document",
                sourceId: l.sourceId,
                mediaType: l.mediaType,
                title: l.title,
                filename: l.filename,
                providerMetadata: l.providerMetadata
              }), d();
              break;
            }
            case "tool-input-start": {
              const x = C().filter(br);
              p.partialToolCalls[l.toolCallId] = {
                text: "",
                inputEncoding: l.inputEncoding,
                toolName: l.toolName,
                index: x.length,
                dynamic: l.dynamic,
                title: l.title,
                toolMetadata: l.toolMetadata
              }, l.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-streaming",
                inputEncoding: l.inputEncoding,
                input: void 0,
                providerExecuted: l.providerExecuted,
                title: l.title,
                toolMetadata: l.toolMetadata,
                providerMetadata: l.providerMetadata
              }) : E({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-streaming",
                inputEncoding: l.inputEncoding,
                input: void 0,
                providerExecuted: l.providerExecuted,
                title: l.title,
                toolMetadata: l.toolMetadata,
                providerMetadata: l.providerMetadata
              }), d();
              break;
            }
            case "tool-input-delta": {
              const x = p.partialToolCalls[l.toolCallId];
              if (x == null)
                throw new Vt({
                  chunkType: "tool-input-delta",
                  chunkId: l.toolCallId,
                  message: `Received tool-input-delta for missing tool call with ID "${l.toolCallId}". Ensure a "tool-input-start" chunk is sent before any "tool-input-delta" chunks.`
                });
              x.text += l.inputTextDelta;
              const Z = x.inputEncoding === "text" ? x.text : (await Fn(x.text)).value;
              x.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: x.toolName,
                state: "input-streaming",
                inputEncoding: x.inputEncoding,
                input: Z,
                rawInput: x.text,
                title: x.title,
                toolMetadata: x.toolMetadata
              }) : E({
                toolCallId: l.toolCallId,
                toolName: x.toolName,
                state: "input-streaming",
                inputEncoding: x.inputEncoding,
                input: Z,
                rawInput: x.text,
                title: x.title,
                toolMetadata: x.toolMetadata
              }), d();
              break;
            }
            case "tool-input-available": {
              l.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-available",
                input: l.input,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                title: l.title,
                toolMetadata: l.toolMetadata
              }) : E({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-available",
                input: l.input,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                title: l.title,
                toolMetadata: l.toolMetadata
              }), d(), o && !l.providerExecuted && await o({
                toolCall: l
              });
              break;
            }
            case "tool-input-error": {
              const x = C().filter(st).find((B) => B.toolCallId === l.toolCallId);
              (x != null ? x.type === "dynamic-tool" : !!l.dynamic) ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "output-error",
                input: l.input,
                errorText: l.errorText,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                toolMetadata: l.toolMetadata
              }) : E({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "output-error",
                input: void 0,
                rawInput: l.input,
                errorText: l.errorText,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                toolMetadata: l.toolMetadata
              }), d();
              break;
            }
            case "tool-approval-request": {
              const x = F(l.toolCallId);
              x.state = "approval-requested", x.approval = {
                id: l.approvalId,
                ...l.approvalDescriptor != null ? { descriptor: l.approvalDescriptor } : {},
                ...Object.prototype.hasOwnProperty.call(
                  l,
                  "inputSchemaInput"
                ) ? { inputSchemaInput: l.inputSchemaInput } : {},
                ...l.signature != null ? { signature: l.signature } : {}
              }, d();
              break;
            }
            case "tool-output-denied": {
              const x = F(l.toolCallId);
              x.state = "output-denied", d();
              break;
            }
            case "tool-output-available": {
              const x = F(l.toolCallId);
              x.type === "dynamic-tool" ? M(
                {
                  toolCallId: l.toolCallId,
                  toolName: x.toolName,
                  state: "output-available",
                  input: x.input,
                  output: l.output,
                  preliminary: l.preliminary,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (w = l.toolMetadata) != null ? w : x.toolMetadata
                },
                x
              ) : E(
                {
                  toolCallId: l.toolCallId,
                  toolName: Pi(x),
                  state: "output-available",
                  input: x.input,
                  output: l.output,
                  providerExecuted: l.providerExecuted,
                  preliminary: l.preliminary,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (I = l.toolMetadata) != null ? I : x.toolMetadata
                },
                x
              ), d();
              break;
            }
            case "tool-output-error": {
              const x = F(l.toolCallId);
              x.type === "dynamic-tool" ? M(
                {
                  toolCallId: l.toolCallId,
                  toolName: x.toolName,
                  state: "output-error",
                  input: x.input,
                  errorText: l.errorText,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (S = l.toolMetadata) != null ? S : x.toolMetadata
                },
                x
              ) : E(
                {
                  toolCallId: l.toolCallId,
                  toolName: Pi(x),
                  state: "output-error",
                  input: x.input,
                  rawInput: x.rawInput,
                  errorText: l.errorText,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (_ = l.toolMetadata) != null ? _ : x.toolMetadata
                },
                x
              ), d();
              break;
            }
            case "start-step": {
              p.message.parts.push({ type: "step-start" });
              break;
            }
            case "finish-step": {
              p.activeTextParts = Cn(), p.activeReasoningParts = Cn();
              break;
            }
            case "start": {
              const x = u && c || s && l.messageId != null && l.messageId !== p.message.id;
              c = !1, x && Object.assign(
                p,
                Uu({
                  lastMessage: void 0,
                  messageId: (y = l.messageId) != null ? y : p.message.id
                }),
                { finishReason: void 0 }
              ), l.messageId != null && (p.message.id = l.messageId), await L(l.messageMetadata), (x || l.messageId != null || l.messageMetadata != null) && d({ updateStatus: !1 });
              break;
            }
            case "finish": {
              l.finishReason != null && (p.finishReason = l.finishReason), await L(l.messageMetadata), l.messageMetadata != null && d();
              break;
            }
            case "message-metadata": {
              await L(l.messageMetadata), l.messageMetadata != null && d();
              break;
            }
            case "error": {
              i == null || i(new Error(l.errorText));
              break;
            }
            default:
              if (Yb(l)) {
                if ((n == null ? void 0 : n[l.type]) != null) {
                  const B = p.message.parts.findIndex(
                    (N) => "id" in N && "data" in N && N.id === l.id && N.type === l.type
                  ), Y = B >= 0 ? B : p.message.parts.length;
                  await Ba({
                    value: l.data,
                    schema: n[l.type],
                    context: {
                      field: `message.parts[${Y}].data`,
                      entityName: l.type,
                      entityId: l.id
                    }
                  });
                }
                const x = l;
                if (x.transient) {
                  a == null || a(x);
                  break;
                }
                const Z = x.id != null ? p.message.parts.find(
                  (B) => x.type === B.type && x.id === B.id
                ) : void 0;
                Z != null ? Z.data = x.data : p.message.parts.push(x), a == null || a(x), d();
              }
          }
          f.enqueue(l);
        });
      }
    })
  );
}
async function Qb({
  stream: e,
  onError: t,
  abortSignal: n
}) {
  const r = e.getReader(), i = () => {
    r.cancel().catch(() => {
    });
  };
  n != null && n.aborted ? i() : n == null || n.addEventListener("abort", i, { once: !0 });
  try {
    for (; ; ) {
      const { done: o } = await r.read();
      if (o)
        break;
    }
  } catch (o) {
    t == null || t(o);
  } finally {
    n == null || n.removeEventListener("abort", i), r.releaseLock();
  }
}
function ev() {
  let e, t;
  return {
    promise: new Promise((r, i) => {
      e = r, t = i;
    }),
    resolve: e,
    reject: t
  };
}
Ln({
  prefix: "aitxt",
  size: 24
});
Nt(
  $(),
  Ft.optional()
);
new TextEncoder();
Ln({ prefix: "aiobj", size: 24 });
var tv = class {
  constructor() {
    this.queue = [], this.isProcessing = !1, this.idleWaiters = [];
  }
  async processQueue() {
    if (!this.isProcessing) {
      this.isProcessing = !0;
      try {
        for (; this.queue.length > 0; )
          await this.queue[0](), this.queue.shift();
      } finally {
        this.isProcessing = !1;
        for (const e of this.idleWaiters.splice(0))
          e();
      }
    }
  }
  async run(e) {
    return new Promise((t, n) => {
      this.queue.push(async () => {
        try {
          await e(), t();
        } catch (r) {
          n(r);
        }
      }), this.processQueue();
    });
  }
  async waitForIdle() {
    !this.isProcessing && this.queue.length === 0 || await new Promise((e) => {
      this.idleWaiters.push(e);
    });
  }
};
Ln({ prefix: "aiobj", size: 24 });
async function nv(e) {
  if (e == null)
    return [];
  if (!globalThis.FileList || !(e instanceof globalThis.FileList))
    throw new Error("FileList is not supported in the current environment");
  return Promise.all(
    Array.from(e).map(async (t) => {
      const { name: n, type: r } = t, i = await new Promise((o, a) => {
        const s = new FileReader();
        s.onload = (u) => {
          var c;
          o((c = u.target) == null ? void 0 : c.result);
        }, s.onerror = (u) => a(u), s.readAsDataURL(t);
      });
      return {
        type: "file",
        mediaType: r,
        filename: n,
        url: i
      };
    })
  );
}
function rv(e, t) {
  const n = e.search(/[?#]/), r = n === -1 ? e : e.slice(0, n), i = n === -1 ? "" : e.slice(n);
  return `${r.endsWith("/") && t.startsWith("/") ? r.slice(0, -1) : r}${t}${i}`;
}
var iv = class {
  constructor({
    api: e = "/api/chat",
    credentials: t,
    headers: n,
    body: r,
    fetch: i,
    prepareSendMessagesRequest: o,
    prepareReconnectToStreamRequest: a
  }) {
    this.api = e, this.credentials = t, this.headers = n, this.body = r, this.fetch = i, this.prepareSendMessagesRequest = o, this.prepareReconnectToStreamRequest = a;
  }
  async sendMessages({
    abortSignal: e,
    ...t
  }) {
    var n, r, i, o, a;
    const s = await wt(this.body), u = await wt(this.headers), c = await wt(this.credentials), l = {
      ...Ut(u),
      ...Ut(t.headers)
    }, f = await ((n = this.prepareSendMessagesRequest) == null ? void 0 : n.call(this, {
      api: this.api,
      id: t.chatId,
      messages: t.messages,
      body: { ...s, ...t.body },
      headers: l,
      credentials: c,
      requestMetadata: t.metadata,
      trigger: t.trigger,
      messageId: t.messageId
    })), p = (r = f == null ? void 0 : f.api) != null ? r : this.api, d = (f == null ? void 0 : f.headers) !== void 0 ? Ut(f.headers) : l, h = (f == null ? void 0 : f.body) !== void 0 ? f.body : {
      ...s,
      ...t.body,
      id: t.chatId,
      messages: t.messages,
      trigger: t.trigger,
      messageId: t.messageId
    }, m = (i = f == null ? void 0 : f.credentials) != null ? i : c, g = await ((o = this.fetch) != null ? o : globalThis.fetch)(p, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...d
      },
      body: JSON.stringify(h),
      credentials: m,
      signal: e
    });
    if (!g.ok)
      throw new Error(
        (a = await g.text()) != null ? a : "Failed to fetch the chat response."
      );
    if (!g.body)
      throw new Error("The response body is empty.");
    return this.processResponseStream(g.body);
  }
  async reconnectToStream(e) {
    var t, n, r, i;
    const o = await wt(this.body), a = await wt(this.headers), s = await wt(this.credentials), u = {
      ...Ut(a),
      ...Ut(e.headers)
    }, c = await ((t = this.prepareReconnectToStreamRequest) == null ? void 0 : t.call(this, {
      api: this.api,
      id: e.chatId,
      body: { ...o, ...e.body },
      headers: u,
      credentials: s,
      requestMetadata: e.metadata
    }));
    let l = c == null ? void 0 : c.api;
    if (l == null) {
      if (e.chatId === "." || e.chatId === "..")
        throw new zb({
          parameter: "chatId",
          value: e.chatId,
          message: 'Chat IDs must not be "." or ".." when using the default reconnect URL.'
        });
      l = rv(
        this.api,
        `/${encodeURIComponent(e.chatId)}/stream`
      );
    }
    const f = (c == null ? void 0 : c.headers) !== void 0 ? Ut(c.headers) : u, p = (n = c == null ? void 0 : c.credentials) != null ? n : s, h = await ((r = this.fetch) != null ? r : globalThis.fetch)(l, {
      method: "GET",
      headers: f,
      credentials: p,
      signal: e.abortSignal
    });
    if (h.status === 204)
      return null;
    if (!h.ok)
      throw new Error(
        (i = await h.text()) != null ? i : "Failed to fetch the chat response."
      );
    if (!h.body)
      throw new Error("The response body is empty.");
    return this.processResponseStream(h.body);
  }
}, Vu = class extends iv {
  constructor({
    resumeStreamIsReplay: e = !0,
    ...t
  } = {}) {
    super(t), this.resumeStreamIsReplay = e;
  }
  processResponseStream(e) {
    return Ib({
      stream: e,
      schema: Kb
    }).pipeThrough(
      new TransformStream({
        async transform(t, n) {
          if (!t.success)
            throw t.error;
          n.enqueue(t.value);
        }
      })
    );
  }
}, ov = class {
  constructor({
    generateId: e = Cy,
    id: t = e(),
    transport: n = new Vu(),
    messageMetadataSchema: r,
    dataPartSchemas: i,
    state: o,
    onError: a,
    onToolCall: s,
    onFinish: u,
    onData: c,
    sendAutomaticallyWhen: l
  }) {
    this.activeResponse = void 0, this.activeResumeRequest = void 0, this.resumableStreamState = void 0, this.jobExecutor = new tv(), this.activeStopCount = 0, this.stopGeneration = 0, this.sendMessage = async (f, p) => {
      var d, h, m, v;
      if (f == null) {
        let w = this.pendingApprovalMessageId;
        if (w == null) {
          w = (d = this.lastMessage) == null ? void 0 : d.id;
          for (let _ = this.state.messages.length - 1; _ >= 0; _--) {
            const y = this.state.messages[_];
            if (y.role === "assistant" && y.parts.some(
              (C) => st(C) && C.state === "approval-responded"
            )) {
              w = y.id;
              break;
            }
          }
        }
        const S = w != null && w === this.pendingApprovalMessageId ? this.state.messages.findIndex((_) => _.id === w) : -1;
        await this.makeRequestForToolApproval({
          messageId: w,
          messageIndex: S,
          ...p
        });
        return;
      }
      let g;
      if ("text" in f || "files" in f ? g = {
        parts: [
          ...Array.isArray(f.files) ? f.files : await nv(f.files),
          ..."text" in f && f.text != null ? [{ type: "text", text: f.text }] : []
        ]
      } : g = f, f.messageId != null) {
        const w = this.state.messages.findIndex(
          (I) => I.id === f.messageId
        );
        if (w === -1)
          throw new Error(`message with id ${f.messageId} not found`);
        if (this.state.messages[w].role !== "user")
          throw new Error(
            `message with id ${f.messageId} is not a user message`
          );
        this.state.messages = this.state.messages.slice(0, w + 1), this.state.replaceMessage(w, {
          ...g,
          id: f.messageId,
          role: (h = g.role) != null ? h : "user",
          metadata: f.metadata
        });
      } else
        this.state.pushMessage({
          ...g,
          id: (m = g.id) != null ? m : this.generateId(),
          role: (v = g.role) != null ? v : "user",
          metadata: f.metadata
        });
      await this.makeRequest({
        trigger: "submit-message",
        messageId: f.messageId,
        ...p
      });
    }, this.regenerate = async ({
      messageId: f,
      ...p
    } = {}) => {
      const d = f == null ? this.state.messages.length - 1 : this.state.messages.findIndex((h) => h.id === f);
      if (d === -1)
        throw new Error(`message ${f} not found`);
      this.state.messages = this.state.messages.slice(
        0,
        // if the message is a user message, we need to include it in the request:
        this.messages[d].role === "assistant" ? d : d + 1
      ), await this.makeRequest({
        trigger: "regenerate-message",
        messageId: f,
        ...p
      });
    }, this.resumeStream = async (f = {}) => {
      await this.makeRequest({ trigger: "resume-stream", ...f });
    }, this["~resumeStreamIfDisconnected"] = async ({
      shouldResume: f = () => !0
    } = {}) => {
      const p = this.activeResponse;
      this.resumableStreamState == null && p != null && (await p.completionPromise, this.resumableStreamState !== p.state) || this.resumableStreamState != null && f() && await this.resumeStream();
    }, this.clearError = () => {
      this.status === "error" && (this.state.error = void 0, this.setStatus({ status: "ready" }));
    }, this.addToolApprovalResponse = async ({
      id: f,
      approved: p,
      reason: d,
      options: h
    }) => this.jobExecutor.run(async () => {
      const m = this.state.messages, v = (w) => st(w) && w.state === "approval-requested" && w.approval.id === f ? {
        ...w,
        state: "approval-responded",
        approval: { ...w.approval, id: f, approved: p, reason: d }
      } : w, g = m.findIndex(
        (w) => w.parts.some(
          (I) => st(I) && I.state === "approval-requested" && I.approval.id === f
        )
      );
      if (g !== -1) {
        const w = m[g];
        this.state.replaceMessage(g, {
          ...w,
          parts: w.parts.map(v)
        }), this.pendingApprovalMessageId = w.id;
      }
      if (this.activeResponse && (this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(v)), this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) {
        const w = await this.shouldSendAutomatically();
        w && this.runAutomaticRequest(() => {
          var I;
          const S = g === -1 ? (I = this.lastMessage) == null ? void 0 : I.id : m[g].id;
          return this.makeRequestForToolApproval({
            messageId: S,
            messageIndex: g,
            ...h
          });
        }, w);
      }
    }), this.addToolOutput = async ({
      state: f = "output-available",
      toolCallId: p,
      output: d,
      errorText: h,
      options: m
    }) => this.jobExecutor.run(async () => {
      const v = this.state.messages, g = (I) => st(I) && I.toolCallId === p ? { ...I, state: f, output: d, errorText: h } : I, w = v.findIndex(
        (I) => I.parts.some(
          (S) => st(S) && S.toolCallId === p
        )
      );
      if (w !== -1) {
        const I = v[w];
        this.state.replaceMessage(w, {
          ...I,
          parts: I.parts.map(g)
        });
      }
      if (this.activeResponse && (this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(g)), w !== -1 && this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) {
        const I = await this.shouldSendAutomatically();
        I && this.runAutomaticRequest(
          () => this.makeRequest({
            trigger: "submit-message",
            messageId: v[w].id,
            ...m
          }),
          I
        );
      }
    }), this.addToolResult = this.addToolOutput, this.stop = async () => {
      this.activeStopCount++, this.stopGeneration++;
      try {
        const f = this.activeResumeRequest, p = this.activeResponse;
        f == null || f.abortController.abort(), p == null || p.abortController.abort(), await Promise.all([
          f == null ? void 0 : f.completionPromise,
          p == null ? void 0 : p.completionPromise
        ]), await this.jobExecutor.waitForIdle();
      } finally {
        this.activeStopCount--;
      }
    }, this.id = t, this.transport = n, this.generateId = e, this.messageMetadataSchema = r, this.dataPartSchemas = i, this.state = o, this.onError = a, this.onToolCall = s, this.onFinish = u, this.onData = c, this.sendAutomaticallyWhen = l;
  }
  /**
   * Hook status:
   *
   * - `submitted`: The message has been sent to the API and we're awaiting the start of the response stream.
   * - `streaming`: The response is actively streaming in from the API, receiving chunks of data.
   * - `ready`: The full response has been received and processed; a new user message can be submitted.
   * - `error`: An error occurred during the API request, preventing successful completion.
   */
  get status() {
    return this.state.status;
  }
  setStatus({
    status: e,
    error: t
  }) {
    if (this.status === e) {
      this.error !== t && (this.state.error = t);
      return;
    }
    this.state.status = e, this.state.error = t;
  }
  get error() {
    return this.state.error;
  }
  get messages() {
    return this.state.messages;
  }
  get lastMessage() {
    return this.state.messages[this.state.messages.length - 1];
  }
  set messages(e) {
    this.state.messages = e;
  }
  async shouldSendAutomatically() {
    if (!this.sendAutomaticallyWhen)
      return !1;
    const e = this.sendAutomaticallyWhen({
      messages: this.state.messages
    });
    return e && typeof e == "object" && "then" in e ? await e : e;
  }
  async runAutomaticRequest(e, t) {
    const n = this.stopGeneration, r = this.activeStopCount > 0;
    (t ?? await this.shouldSendAutomatically()) && (r || n !== this.stopGeneration || this.activeStopCount > 0 || await e());
  }
  async makeRequestForToolApproval({
    messageId: e,
    messageIndex: t,
    ...n
  }) {
    var r, i;
    const o = e != null && e === this.pendingApprovalMessageId;
    o && (this.pendingApprovalMessageId = void 0), await this.makeRequest({
      trigger: "submit-message",
      messageId: e,
      ...n
    }), o && this.status === "error" && this.pendingApprovalMessageId == null && (this.pendingApprovalMessageId = (i = (r = this.state.messages[t]) == null ? void 0 : r.id) != null ? i : e);
  }
  async makeRequest(e) {
    const t = ev();
    try {
      await this.makeRequestImpl({
        ...e,
        completionPromise: t.promise
      });
    } finally {
      t.resolve();
    }
  }
  async makeRequestImpl({
    trigger: e,
    metadata: t,
    headers: n,
    body: r,
    messageId: i,
    completionPromise: o
  }) {
    var a, s;
    e !== "resume-stream" && (this.resumableStreamState = void 0);
    const u = new AbortController(), c = e === "resume-stream" ? { abortController: u, completionPromise: o } : void 0;
    c && ((a = this.activeResumeRequest) == null || a.abortController.abort(), this.activeResumeRequest = c);
    const l = () => c == null || this.activeResumeRequest === c, f = () => {
      this.activeResumeRequest === c && (this.activeResumeRequest = void 0);
    };
    let p;
    if (e === "resume-stream")
      try {
        const C = await this.transport.reconnectToStream({
          chatId: this.id,
          abortSignal: u.signal,
          metadata: t,
          headers: n,
          body: r
        });
        if (u.signal.aborted || !l()) {
          await (C == null ? void 0 : C.cancel().catch(() => {
          })), l() && (this.setStatus({ status: "ready" }), this.resumableStreamState = void 0), f();
          return;
        }
        if (C == null) {
          this.setStatus({ status: "ready" }), this.resumableStreamState = void 0, f();
          return;
        }
        p = C;
      } catch (C) {
        if (u.signal.aborted || C.name === "AbortError") {
          l() && (this.setStatus({ status: "ready" }), this.resumableStreamState = void 0), f();
          return;
        }
        if (!l())
          return;
        this.onError && C instanceof Error && this.onError(C), this.setStatus({ status: "error", error: C }), f();
        return;
      }
    this.setStatus({ status: "submitted", error: void 0 });
    const d = this.lastMessage, h = e === "submit-message" && i != null ? this.state.messages.findIndex((C) => C.id === i) : this.state.messages.length - 1, m = h === -1 ? d : this.state.messages[h], v = m == null ? void 0 : m.id, g = e === "resume-stream" && (m == null ? void 0 : m.role) === "assistant" && m.parts.some(
      (C) => st(C) && C.state === "input-streaming"
    ) ? this.state.snapshot(m) : void 0, w = h !== -1 && h < this.state.messages.length - 1 && (m == null ? void 0 : m.role) === "assistant";
    let I = !1, S = !1, _ = !1, y;
    try {
      const C = {
        state: e === "resume-stream" && this.resumableStreamState != null ? this.resumableStreamState : Uu({
          lastMessage: e === "resume-stream" ? g : e === "regenerate-message" ? void 0 : this.state.snapshot(m),
          messageId: this.generateId()
        }),
        abortController: u,
        completionPromise: o
      };
      y = C, C.abortController.signal.addEventListener("abort", () => {
        I = !0;
      }), this.activeResponse = C;
      let R;
      e === "resume-stream" ? R = p : R = await this.transport.sendMessages({
        chatId: this.id,
        messages: this.state.messages,
        abortSignal: C.abortController.signal,
        metadata: t,
        headers: n,
        body: r,
        trigger: e,
        messageId: i
      });
      const F = (E) => (
        // serialize the job execution to avoid race conditions:
        this.jobExecutor.run(() => C.abortController.signal.aborted ? Promise.resolve() : E({
          state: C.state,
          write: ({ updateStatus: M = !0 } = {}) => {
            if (C.abortController.signal.aborted)
              return;
            M && this.setStatus({ status: "streaming" });
            const L = this.state.messages.findLastIndex(
              (x) => x.id === C.state.message.id
            );
            if (L !== -1)
              this.state.replaceMessage(
                L,
                C.state.message
              );
            else if (w) {
              const x = this.state.messages.findLastIndex(
                (Z) => Z.id === v
              );
              x !== -1 ? this.state.replaceMessage(
                x,
                C.state.message
              ) : this.state.pushMessage(C.state.message);
            } else
              this.state.pushMessage(C.state.message);
          }
        }))
      );
      if (await Qb({
        stream: Xb({
          stream: R,
          resetStateOnMessageIdChange: e === "resume-stream",
          resetStateOnFirstMessageStart: e === "resume-stream" && this.transport.resumeStreamIsReplay,
          onToolCall: this.onToolCall,
          onData: this.onData,
          messageMetadataSchema: this.messageMetadataSchema,
          dataPartSchemas: this.dataPartSchemas,
          runUpdateMessageJob: F,
          onError: (E) => {
            throw E;
          }
        }),
        abortSignal: C.abortController.signal,
        onError: (E) => {
          throw E;
        }
      }), I)
        return l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === C.state && (this.resumableStreamState = void 0)), null;
      l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === C.state && (this.resumableStreamState = void 0));
    } catch (C) {
      if (I || C.name === "AbortError")
        return I = !0, l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === (y == null ? void 0 : y.state) && (this.resumableStreamState = void 0)), null;
      if (!l())
        return null;
      _ = !0, C instanceof TypeError && (C.message.toLowerCase().includes("fetch") || C.message.toLowerCase().includes("network")) && (S = !0), S ? this.resumableStreamState = y == null ? void 0 : y.state : this.resumableStreamState === (y == null ? void 0 : y.state) && (this.resumableStreamState = void 0), this.onError && C instanceof Error && this.onError(C), this.setStatus({ status: "error", error: C });
    } finally {
      try {
        y && ((s = this.onFinish) == null || s.call(this, {
          message: y.state.message,
          messages: this.state.messages,
          isAbort: I,
          isDisconnect: S,
          isError: _,
          finishReason: y.state.finishReason
        }));
      } finally {
        this.activeResponse === y && (this.activeResponse = void 0), f();
      }
    }
    !I && !_ && await this.runAutomaticRequest(
      () => {
        var C;
        return this.makeRequest({
          trigger: "submit-message",
          messageId: (C = this.lastMessage) == null ? void 0 : C.id,
          metadata: t,
          headers: n,
          body: r
        });
      }
    );
  }
};
function av(e, t) {
  if (typeof e != "function")
    throw new TypeError(`Expected the first argument to be a \`function\`, got \`${typeof e}\`.`);
  let n, r = 0;
  return function(...o) {
    clearTimeout(n);
    const a = Date.now(), s = a - r, u = t - s;
    u <= 0 ? (r = a, e.apply(this, o)) : n = setTimeout(() => {
      r = Date.now(), e.apply(this, o);
    }, u);
  };
}
var sv = av;
const lv = /* @__PURE__ */ Au(sv);
var qu = (e, t, n) => {
  if (!t.has(e))
    throw TypeError("Cannot " + n);
}, fe = (e, t, n) => (qu(e, t, "read from private field"), n ? n.call(e) : t.get(e)), ot = (e, t, n) => {
  if (t.has(e))
    throw TypeError("Cannot add the same private member more than once");
  t instanceof WeakSet ? t.add(e) : t.set(e, n);
}, vt = (e, t, n, r) => (qu(e, t, "write to private field"), t.set(e, n), n);
function uv(e, t) {
  return t != null ? lv(e, t) : e;
}
function cv(e) {
  return Array.isArray(e) ? [...e] : e != null && typeof e == "object" && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null) ? { ...e } : e;
}
var Ue, or, ar, xn, _n, Sn, Jt, Mi, Ri, fv = class {
  constructor(e = []) {
    ot(this, Ue, void 0), ot(this, or, "ready"), ot(this, ar, void 0), ot(this, xn, /* @__PURE__ */ new Set()), ot(this, _n, /* @__PURE__ */ new Set()), ot(this, Sn, /* @__PURE__ */ new Set()), this.pushMessage = (t) => {
      vt(this, Ue, fe(this, Ue).concat(t)), fe(this, Jt).call(this);
    }, this.popMessage = () => {
      vt(this, Ue, fe(this, Ue).slice(0, -1)), fe(this, Jt).call(this);
    }, this.replaceMessage = (t, n) => {
      vt(this, Ue, [
        ...fe(this, Ue).slice(0, t),
        this.snapshot(n),
        ...fe(this, Ue).slice(t + 1)
      ]), fe(this, Jt).call(this);
    }, this.snapshot = (t) => {
      if (t == null || typeof t != "object" || !("parts" in t) || !Array.isArray(t.parts))
        return t;
      const n = t, r = {
        ...n,
        parts: n.parts.map((i) => ({ ...i }))
      };
      return "metadata" in n && (r.metadata = cv(n.metadata)), r;
    }, this["~registerMessagesCallback"] = (t, n) => {
      const r = n ? uv(t, n) : t;
      return fe(this, xn).add(r), () => {
        fe(this, xn).delete(r);
      };
    }, this["~registerStatusCallback"] = (t) => (fe(this, _n).add(t), () => {
      fe(this, _n).delete(t);
    }), this["~registerErrorCallback"] = (t) => (fe(this, Sn).add(t), () => {
      fe(this, Sn).delete(t);
    }), ot(this, Jt, () => {
      fe(this, xn).forEach((t) => t());
    }), ot(this, Mi, () => {
      fe(this, _n).forEach((t) => t());
    }), ot(this, Ri, () => {
      fe(this, Sn).forEach((t) => t());
    }), vt(this, Ue, e);
  }
  get status() {
    return fe(this, or);
  }
  set status(e) {
    vt(this, or, e), fe(this, Mi).call(this);
  }
  get error() {
    return fe(this, ar);
  }
  set error(e) {
    vt(this, ar, e), fe(this, Ri).call(this);
  }
  get messages() {
    return fe(this, Ue);
  }
  set messages(e) {
    vt(this, Ue, [...e]), fe(this, Jt).call(this);
  }
};
Ue = /* @__PURE__ */ new WeakMap();
or = /* @__PURE__ */ new WeakMap();
ar = /* @__PURE__ */ new WeakMap();
xn = /* @__PURE__ */ new WeakMap();
_n = /* @__PURE__ */ new WeakMap();
Sn = /* @__PURE__ */ new WeakMap();
Jt = /* @__PURE__ */ new WeakMap();
Mi = /* @__PURE__ */ new WeakMap();
Ri = /* @__PURE__ */ new WeakMap();
var Wt, Ua = class extends ov {
  constructor({ messages: e, ...t }) {
    const n = new fv(e);
    super({ ...t, state: n }), ot(this, Wt, void 0), this["~registerMessagesCallback"] = (r, i) => fe(this, Wt)["~registerMessagesCallback"](r, i), this["~registerStatusCallback"] = (r) => fe(this, Wt)["~registerStatusCallback"](r), this["~registerErrorCallback"] = (r) => fe(this, Wt)["~registerErrorCallback"](r), vt(this, Wt, n);
  }
};
Wt = /* @__PURE__ */ new WeakMap();
var sr = /* @__PURE__ */ new WeakMap();
function dv({
  chat: e,
  state: t
}) {
  if (document.visibilityState !== "visible" || t.pendingVisibilityResume != null)
    return;
  const n = () => sr.get(e) === t && t.registrations.size > 0, r = () => {
    t.pendingVisibilityResume = void 0;
  }, i = e;
  t.pendingVisibilityResume = i["~resumeStreamIfDisconnected"]({
    shouldResume: () => n() && document.visibilityState === "visible"
  }).then(r, r);
}
function pv({
  chat: e,
  registration: t
}) {
  let n = sr.get(e);
  if (n == null) {
    const o = { registrations: /* @__PURE__ */ new Set() };
    if (sr.set(e, o), n = o, typeof document < "u") {
      const a = () => dv({ chat: e, state: o });
      document.addEventListener("visibilitychange", a), o.cleanupVisibilityListener = () => {
        document.removeEventListener("visibilitychange", a);
      };
    }
  }
  const { registrations: r } = n, i = r.size === 0;
  return r.add(t), i && e.status !== "submitted" && e.status !== "streaming" && e.resumeStream(), () => {
    var o;
    r.delete(t), r.size === 0 && ((o = n.cleanupVisibilityListener) == null || o.call(n), sr.delete(e));
  };
}
function hv({
  experimental_throttle: e,
  resume: t = !1,
  ...n
} = {}) {
  const r = Ve({}), i = Ve({});
  "chat" in n || (i.current = {
    onToolCall: n.onToolCall,
    onData: n.onData,
    onFinish: n.onFinish,
    onError: n.onError,
    sendAutomaticallyWhen: n.sendAutomaticallyWhen,
    transport: n.transport
  });
  let o;
  const a = () => {
    var S;
    return (S = i.current.transport) != null ? S : o ?? (o = new Vu());
  }, s = {
    ...n,
    transport: {
      sendMessages: (S) => a().sendMessages(S),
      reconnectToStream: (S) => a().reconnectToStream(S)
    },
    onToolCall: (S) => {
      var _, y;
      return (y = (_ = i.current).onToolCall) == null ? void 0 : y.call(_, S);
    },
    onData: (S) => {
      var _, y;
      return (y = (_ = i.current).onData) == null ? void 0 : y.call(_, S);
    },
    onFinish: (S) => {
      var _, y;
      return (y = (_ = i.current).onFinish) == null ? void 0 : y.call(_, S);
    },
    onError: (S) => {
      var _, y;
      return (y = (_ = i.current).onError) == null ? void 0 : y.call(_, S);
    },
    sendAutomaticallyWhen: (S) => {
      var _, y, C;
      return (C = (y = (_ = i.current).sendAutomaticallyWhen) == null ? void 0 : y.call(_, S)) != null ? C : !1;
    }
  }, u = Ve(
    "chat" in n ? n.chat : new Ua(s)
  );
  ("chat" in n && n.chat !== u.current || "id" in n && n.id != null && u.current.id !== n.id) && (u.current = "chat" in n ? n.chat : new Ua(s));
  const l = u.current, f = Ve({
    chat: l,
    messages: l.messages
  });
  f.current.chat !== l && (f.current = { chat: l, messages: l.messages });
  const p = be(
    (S) => {
      let _ = !0;
      const y = () => {
        !_ || f.current.chat !== l || (f.current = { chat: l, messages: l.messages }, S());
      }, C = l["~registerMessagesCallback"](
        y,
        e
      );
      return f.current = { chat: l, messages: l.messages }, () => {
        _ = !1, C();
      };
    },
    [l, e]
  ), d = be(
    () => f.current.messages,
    []
  ), h = Zr(
    p,
    d,
    d
  ), m = be(
    (S) => l["~registerStatusCallback"](() => {
      f.current.chat === l && ((l.status === "ready" || l.status === "error") && (f.current = { chat: l, messages: l.messages }), S());
    }),
    [l]
  ), v = be(() => l.status, [l]), g = Zr(
    m,
    v,
    v
  ), w = Zr(
    u.current["~registerErrorCallback"],
    () => u.current.error,
    () => u.current.error
  ), I = be(
    (S) => {
      typeof S == "function" && (S = S(u.current.messages)), u.current.messages = S;
    },
    [u]
  );
  return qe(() => {
    if (t)
      return pv({
        chat: l,
        registration: r.current
      });
  }, [t, l]), {
    id: u.current.id,
    messages: h,
    setMessages: I,
    sendMessage: u.current.sendMessage,
    regenerate: u.current.regenerate,
    clearError: u.current.clearError,
    stop: u.current.stop,
    error: w,
    resumeStream: u.current.resumeStream,
    status: g,
    /**
     * @deprecated Use `addToolOutput` instead.
     */
    addToolResult: u.current.addToolOutput,
    addToolOutput: u.current.addToolOutput,
    addToolApprovalResponse: u.current.addToolApprovalResponse
  };
}
function Ju(e) {
  return e.parts.filter((t) => t.type === "text").map((t) => t.text).join(`
`);
}
function mv(e) {
  return e.map((t) => ({ role: t.role, content: Ju(t) }));
}
const Qr = "reply";
class gv {
  constructor(t) {
    this.deps = t;
  }
  async sendMessages(t) {
    const { messages: n, abortSignal: r, body: i } = t, o = this.deps.getModelId();
    if (!o)
      throw new Error("请先在设置中添加模型");
    const a = await this.deps.getApiKey(o) ?? "";
    let s, u = !1;
    const c = () => {
      s !== void 0 && this.deps.invokeBackend("stopStream", { requestId: s }).catch(() => {
      });
    };
    r == null || r.addEventListener(
      "abort",
      () => {
        u = !0, c();
      },
      { once: !0 }
    );
    const l = {
      // 首块超时 90s（方案 D14：适配推理模型首 token 常超 30s）
      firstChunkTimeoutSecs: 90,
      onStart: (f) => {
        s = f.requestId, u && c();
      }
    };
    return new ReadableStream({
      start: async (f) => {
        const p = (m) => f.enqueue(m);
        p({ type: "start" });
        let d = !1;
        const h = () => {
          d && (p({ type: "text-end", id: Qr }), d = !1);
        };
        try {
          const m = await this.deps.invokeBackendStream(
            "streamChat",
            {
              modelId: o,
              apiKey: a,
              messages: mv(n),
              // 角色动作：roleKey 进 streamChat 参数（后端解析透传，P2.6 拼装双层提示词）
              ...i != null && i.roleKey ? { roleKey: i.roleKey } : {}
            },
            (v) => {
              const g = (v == null ? void 0 : v.text) ?? "";
              g !== "" && (d || (p({ type: "text-start", id: Qr }), d = !0), p({ type: "text-delta", id: Qr, delta: g }));
            },
            l
          );
          h(), p({
            type: "message-metadata",
            messageMetadata: { stopped: m == null ? void 0 : m.stopped, omitted: m == null ? void 0 : m.omitted }
          }), p({ type: "finish" }), f.close();
        } catch (m) {
          h(), p({
            type: "error",
            errorText: m instanceof Error ? m.message : String(m)
          }), f.close();
        }
      },
      // 中途取消读取（useChat.stop 已先触发 abortSignal → stopStream）
      cancel() {
      }
    });
  }
  /** 无重连语义：刷新/切换会话历史直接从数据库加载 */
  async reconnectToStream() {
    return null;
  }
}
const Va = "activeSessionId", qa = "activeModelId", $i = "applyInline";
function yv(e) {
  return e.displayText && e.displayText !== "" ? e.displayText : e.content;
}
function bv(e) {
  return e.map((t) => ({
    id: t.id,
    role: t.role === "assistant" ? "assistant" : t.role === "system" ? "system" : "user",
    metadata: {
      displayText: t.displayText ?? void 0,
      roleKey: t.roleKey ?? void 0
    },
    parts: [{ type: "text", text: yv(t) }]
  }));
}
function vv(e) {
  const [t, n] = ye([]), [r, i] = ye(null), o = Ve(null), a = be((d) => {
    o.current = d, i(d);
  }, []), s = be(async () => {
    var v, g;
    const { models: d } = await e.invokeBackend("listModels");
    n(d);
    const { value: h } = await e.invokeBackend("getSetting", {
      key: qa
    }), m = h && d.some((w) => w.id === h) ? h : ((v = d.find((w) => w.isDefault)) == null ? void 0 : v.id) ?? ((g = d[0]) == null ? void 0 : g.id) ?? null;
    a(m);
  }, [e, a]), u = be(
    (d) => {
      a(d), e.invokeBackend("setSetting", { key: qa, value: d }).catch(() => {
      });
    },
    [e, a]
  ), c = be(
    async (d) => {
      const { id: h } = await e.invokeBackend("saveModel", {
        id: d.id,
        name: d.name,
        provider: d.provider,
        modelId: d.modelId,
        baseUrl: d.baseUrl,
        contextWindow: d.contextWindow
      });
      return d.apiKey && d.apiKey !== "" && await e.secureStorage.set(`model:${h}`, d.apiKey), await s(), h;
    },
    [e, s]
  ), l = be(
    async (d) => {
      await e.invokeBackend("deleteModel", { id: d }), await e.secureStorage.delete(`model:${d}`).catch(() => {
      }), await s();
    },
    [e, s]
  ), f = be(
    async (d) => {
      await e.invokeBackend("setDefaultModel", { id: d }), await s();
    },
    [e, s]
  ), p = be(
    async (d) => {
      const { models: h } = await e.invokeBackend(
        "fetchUpstreamModels",
        {
          provider: d.provider,
          baseUrl: d.baseUrl ?? "",
          apiKey: d.apiKey ?? ""
        }
      );
      return h;
    },
    [e]
  );
  return qe(() => {
    s().catch(() => {
    });
  }, [s]), Gt(
    () => ({
      models: t,
      activeModelId: r,
      activeModelIdRef: o,
      setActiveModel: u,
      saveModel: c,
      deleteModel: l,
      setDefaultModel: f,
      fetchUpstreamModels: p,
      refresh: s
    }),
    [t, r, o, u, c, l, f, p, s]
  );
}
function kv(e) {
  const [t, n] = ye([]), [r, i] = ye(null), [o, a] = ye(!1), s = be(async () => {
    const { sessions: p } = await e.invokeBackend("listSessions");
    n(p);
  }, [e]), u = be(
    (p) => {
      i(p), p !== null && e.invokeBackend("setSetting", { key: Va, value: p }).catch(() => {
      });
    },
    [e]
  );
  qe(() => {
    let p = !1;
    return (async () => {
      var d;
      try {
        const { sessions: h } = await e.invokeBackend("listSessions");
        if (p) return;
        n(h);
        const { value: m } = await e.invokeBackend("getSetting", {
          key: Va
        });
        if (p) return;
        const v = m && h.some((g) => g.id === m) ? m : ((d = h[0]) == null ? void 0 : d.id) ?? null;
        v !== null && i(v);
      } catch {
      } finally {
        p || a(!0);
      }
    })(), () => {
      p = !0;
    };
  }, [e]);
  const c = be(
    async (p) => {
      const { id: d } = await e.invokeBackend("createSession", {
        title: p ?? ""
      });
      return await s(), u(d), d;
    },
    [e, s, u]
  ), l = be(
    async (p, d) => {
      await e.invokeBackend("renameSession", { id: p, title: d }), await s();
    },
    [e, s]
  ), f = be(
    async (p) => {
      var h;
      await e.invokeBackend("deleteSession", { id: p });
      const d = t.filter((m) => m.id !== p);
      n(d), r === p && u(((h = d[0]) == null ? void 0 : h.id) ?? null);
    },
    [e, t, r, u]
  );
  return Gt(
    () => ({ sessions: t, activeId: r, loaded: o, activate: u, create: c, rename: l, remove: f, refresh: s }),
    [t, r, o, u, c, l, f, s]
  );
}
function wv(e) {
  const t = be(
    async (i, o, a) => {
      await e.invokeBackend("appendMessage", {
        sessionId: i,
        role: "user",
        content: o,
        ...a != null && a.roleKey ? { roleKey: a.roleKey } : {},
        ...a != null && a.displayText ? { displayText: a.displayText } : {},
        ...a != null && a.metaJson ? { metaJson: a.metaJson } : {}
      });
    },
    [e]
  ), n = be(
    async (i, o, a) => {
      const s = {};
      a.stopped && (s.stopped = !0), typeof a.omitted == "number" && a.omitted > 0 && (s.omitted = a.omitted), a.applied && (s.applied = !0, a.selectionOriginal && (s.selectionOriginal = a.selectionOriginal));
      const u = Object.keys(s).length > 0 ? JSON.stringify(s) : void 0;
      await e.invokeBackend("appendMessage", {
        sessionId: i,
        role: "assistant",
        content: o,
        metaJson: u
      });
    },
    [e]
  ), r = be(
    async (i) => {
      const { messages: o } = await e.invokeBackend("listMessages", {
        sessionId: i
      });
      return bv(o);
    },
    [e]
  );
  return Gt(
    () => ({ appendUser: t, appendAssistant: n, loadMessages: r }),
    [t, n, r]
  );
}
function xv(e, t) {
  const n = {};
  return (e[e.length - 1] === "" ? [...e, ""] : e).join(
    (n.padRight ? " " : "") + "," + (n.padLeft === !1 ? "" : " ")
  ).trim();
}
const _v = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Sv = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, Iv = {};
function Ja(e, t) {
  return (Iv.jsx ? Sv : _v).test(e);
}
const Ev = /[ \t\n\f\r]/g;
function Cv(e) {
  return typeof e == "object" ? e.type === "text" ? Wa(e.value) : !1 : Wa(e);
}
function Wa(e) {
  return e.replace(Ev, "") === "";
}
class jn {
  /**
   * @param {SchemaType['property']} property
   *   Property.
   * @param {SchemaType['normal']} normal
   *   Normal.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Schema.
   */
  constructor(t, n, r) {
    this.normal = n, this.property = t, r && (this.space = r);
  }
}
jn.prototype.normal = {};
jn.prototype.property = {};
jn.prototype.space = void 0;
function Wu(e, t) {
  const n = {}, r = {};
  for (const i of e)
    Object.assign(n, i.property), Object.assign(r, i.normal);
  return new jn(n, r, t);
}
function Di(e) {
  return e.toLowerCase();
}
class $e {
  /**
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @returns
   *   Info.
   */
  constructor(t, n) {
    this.attribute = n, this.property = t;
  }
}
$e.prototype.attribute = "";
$e.prototype.booleanish = !1;
$e.prototype.boolean = !1;
$e.prototype.commaOrSpaceSeparated = !1;
$e.prototype.commaSeparated = !1;
$e.prototype.defined = !1;
$e.prototype.mustUseProperty = !1;
$e.prototype.number = !1;
$e.prototype.overloadedBoolean = !1;
$e.prototype.property = "";
$e.prototype.spaceSeparated = !1;
$e.prototype.space = void 0;
let Av = 0;
const J = Zt(), ve = Zt(), Ni = Zt(), P = Zt(), ie = Zt(), $t = Zt(), Ne = Zt();
function Zt() {
  return 2 ** ++Av;
}
const Li = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  boolean: J,
  booleanish: ve,
  commaOrSpaceSeparated: Ne,
  commaSeparated: $t,
  number: P,
  overloadedBoolean: Ni,
  spaceSeparated: ie
}, Symbol.toStringTag, { value: "Module" })), ei = (
  /** @type {ReadonlyArray<keyof typeof types>} */
  Object.keys(Li)
);
class yo extends $e {
  /**
   * @constructor
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @param {number | null | undefined} [mask]
   *   Mask.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Info.
   */
  constructor(t, n, r, i) {
    let o = -1;
    if (super(t, n), Ha(this, "space", i), typeof r == "number")
      for (; ++o < ei.length; ) {
        const a = ei[o];
        Ha(this, ei[o], (r & Li[a]) === Li[a]);
      }
  }
}
yo.prototype.defined = !0;
function Ha(e, t, n) {
  n && (e[t] = n);
}
function an(e) {
  const t = {}, n = {};
  for (const [r, i] of Object.entries(e.properties)) {
    const o = new yo(
      r,
      e.transform(e.attributes || {}, r),
      i,
      e.space
    );
    e.mustUseProperty && e.mustUseProperty.includes(r) && (o.mustUseProperty = !0), t[r] = o, n[Di(r)] = r, n[Di(o.attribute)] = r;
  }
  return new jn(t, n, e.space);
}
const Hu = an({
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: ve,
    ariaAutoComplete: null,
    ariaBusy: ve,
    ariaChecked: ve,
    ariaColCount: P,
    ariaColIndex: P,
    ariaColSpan: P,
    ariaControls: ie,
    ariaCurrent: null,
    ariaDescribedBy: ie,
    ariaDetails: null,
    ariaDisabled: ve,
    ariaDropEffect: ie,
    ariaErrorMessage: null,
    ariaExpanded: ve,
    ariaFlowTo: ie,
    ariaGrabbed: ve,
    ariaHasPopup: null,
    ariaHidden: ve,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: ie,
    ariaLevel: P,
    ariaLive: null,
    ariaModal: ve,
    ariaMultiLine: ve,
    ariaMultiSelectable: ve,
    ariaOrientation: null,
    ariaOwns: ie,
    ariaPlaceholder: null,
    ariaPosInSet: P,
    ariaPressed: ve,
    ariaReadOnly: ve,
    ariaRelevant: null,
    ariaRequired: ve,
    ariaRoleDescription: ie,
    ariaRowCount: P,
    ariaRowIndex: P,
    ariaRowSpan: P,
    ariaSelected: ve,
    ariaSetSize: P,
    ariaSort: null,
    ariaValueMax: P,
    ariaValueMin: P,
    ariaValueNow: P,
    ariaValueText: null,
    role: null
  },
  transform(e, t) {
    return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
  }
});
function Ku(e, t) {
  return t in e ? e[t] : t;
}
function Yu(e, t) {
  return Ku(e, t.toLowerCase());
}
const zv = an({
  attributes: {
    acceptcharset: "accept-charset",
    classname: "class",
    htmlfor: "for",
    httpequiv: "http-equiv"
  },
  mustUseProperty: ["checked", "multiple", "muted", "selected"],
  properties: {
    // Standard Properties.
    abbr: null,
    accept: $t,
    acceptCharset: ie,
    accessKey: ie,
    action: null,
    allow: null,
    allowFullScreen: J,
    allowPaymentRequest: J,
    allowUserMedia: J,
    alpha: J,
    alt: null,
    as: null,
    async: J,
    autoCapitalize: null,
    autoComplete: ie,
    autoFocus: J,
    autoPlay: J,
    blocking: ie,
    capture: null,
    charSet: null,
    checked: J,
    cite: null,
    className: ie,
    closedBy: null,
    colorSpace: null,
    cols: P,
    colSpan: P,
    command: null,
    commandFor: null,
    content: null,
    contentEditable: ve,
    controls: J,
    controlsList: ie,
    coords: P | $t,
    crossOrigin: null,
    data: null,
    dateTime: null,
    decoding: null,
    default: J,
    defer: J,
    dir: null,
    dirName: null,
    disabled: J,
    download: Ni,
    draggable: ve,
    encType: null,
    enterKeyHint: null,
    fetchPriority: null,
    form: null,
    formAction: null,
    formEncType: null,
    formMethod: null,
    formNoValidate: J,
    formTarget: null,
    headers: ie,
    height: P,
    hidden: Ni,
    high: P,
    href: null,
    hrefLang: null,
    htmlFor: ie,
    httpEquiv: ie,
    id: null,
    imageSizes: null,
    imageSrcSet: null,
    inert: J,
    inputMode: null,
    integrity: null,
    is: null,
    isMap: J,
    itemId: null,
    itemProp: ie,
    itemRef: ie,
    itemScope: J,
    itemType: ie,
    kind: null,
    label: null,
    lang: null,
    language: null,
    list: null,
    loading: null,
    loop: J,
    low: P,
    manifest: null,
    max: null,
    maxLength: P,
    media: null,
    method: null,
    min: null,
    minLength: P,
    multiple: J,
    muted: J,
    name: null,
    nonce: null,
    noModule: J,
    noValidate: J,
    onAbort: null,
    onAfterPrint: null,
    onAuxClick: null,
    onBeforeMatch: null,
    onBeforePrint: null,
    onBeforeToggle: null,
    onBeforeUnload: null,
    onBlur: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onContextLost: null,
    onContextMenu: null,
    onContextRestored: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFormData: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLanguageChange: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadEnd: null,
    onLoadStart: null,
    onMessage: null,
    onMessageError: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRejectionHandled: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onScrollEnd: null,
    onSecurityPolicyViolation: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onSlotChange: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnhandledRejection: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onWheel: null,
    open: J,
    optimum: P,
    pattern: null,
    ping: ie,
    placeholder: null,
    playsInline: J,
    popover: null,
    popoverTarget: null,
    popoverTargetAction: null,
    poster: null,
    preload: null,
    readOnly: J,
    referrerPolicy: null,
    rel: ie,
    required: J,
    reversed: J,
    rows: P,
    rowSpan: P,
    sandbox: ie,
    scope: null,
    scoped: J,
    seamless: J,
    selected: J,
    shadowRootClonable: J,
    shadowRootCustomElementRegistry: J,
    shadowRootDelegatesFocus: J,
    shadowRootMode: null,
    shadowRootSerializable: J,
    shape: null,
    size: P,
    sizes: null,
    slot: null,
    span: P,
    spellCheck: ve,
    src: null,
    srcDoc: null,
    srcLang: null,
    srcSet: null,
    start: P,
    step: null,
    style: null,
    tabIndex: P,
    target: null,
    title: null,
    translate: null,
    type: null,
    typeMustMatch: J,
    useMap: null,
    value: ve,
    width: P,
    wrap: null,
    writingSuggestions: null,
    // Legacy.
    // See: https://html.spec.whatwg.org/#other-elements,-attributes-and-apis
    align: null,
    // Several. Use CSS `text-align` instead,
    aLink: null,
    // `<body>`. Use CSS `a:active {color}` instead
    archive: ie,
    // `<object>`. List of URIs to archives
    axis: null,
    // `<td>` and `<th>`. Use `scope` on `<th>`
    background: null,
    // `<body>`. Use CSS `background-image` instead
    bgColor: null,
    // `<body>` and table elements. Use CSS `background-color` instead
    border: P,
    // `<table>`. Use CSS `border-width` instead,
    borderColor: null,
    // `<table>`. Use CSS `border-color` instead,
    bottomMargin: P,
    // `<body>`
    cellPadding: null,
    // `<table>`
    cellSpacing: null,
    // `<table>`
    char: null,
    // Several table elements. When `align=char`, sets the character to align on
    charOff: null,
    // Several table elements. When `char`, offsets the alignment
    classId: null,
    // `<object>`
    clear: null,
    // `<br>`. Use CSS `clear` instead
    code: null,
    // `<object>`
    codeBase: null,
    // `<object>`
    codeType: null,
    // `<object>`
    color: null,
    // `<font>` and `<hr>`. Use CSS instead
    compact: J,
    // Lists. Use CSS to reduce space between items instead
    declare: J,
    // `<object>`
    event: null,
    // `<script>`
    face: null,
    // `<font>`. Use CSS instead
    frame: null,
    // `<table>`
    frameBorder: null,
    // `<iframe>`. Use CSS `border` instead
    hSpace: P,
    // `<img>` and `<object>`
    leftMargin: P,
    // `<body>`
    link: null,
    // `<body>`. Use CSS `a:link {color: *}` instead
    longDesc: null,
    // `<frame>`, `<iframe>`, and `<img>`. Use an `<a>`
    lowSrc: null,
    // `<img>`. Use a `<picture>`
    marginHeight: P,
    // `<body>`
    marginWidth: P,
    // `<body>`
    noResize: J,
    // `<frame>`
    noHref: J,
    // `<area>`. Use no href instead of an explicit `nohref`
    noShade: J,
    // `<hr>`. Use background-color and height instead of borders
    noWrap: J,
    // `<td>` and `<th>`
    object: null,
    // `<applet>`
    profile: null,
    // `<head>`
    prompt: null,
    // `<isindex>`
    rev: null,
    // `<link>`
    rightMargin: P,
    // `<body>`
    rules: null,
    // `<table>`
    scheme: null,
    // `<meta>`
    scrolling: ve,
    // `<frame>`. Use overflow in the child context
    standby: null,
    // `<object>`
    summary: null,
    // `<table>`
    text: null,
    // `<body>`. Use CSS `color` instead
    topMargin: P,
    // `<body>`
    valueType: null,
    // `<param>`
    version: null,
    // `<html>`. Use a doctype.
    vAlign: null,
    // Several. Use CSS `vertical-align` instead
    vLink: null,
    // `<body>`. Use CSS `a:visited {color}` instead
    vSpace: P,
    // `<img>` and `<object>`
    // Non-standard Properties.
    allowTransparency: null,
    autoCorrect: null,
    autoSave: null,
    credentialless: J,
    disablePictureInPicture: J,
    disableRemotePlayback: J,
    exportParts: $t,
    part: ie,
    prefix: null,
    property: null,
    results: P,
    security: null,
    unselectable: null
  },
  space: "html",
  transform: Yu
}), Tv = an({
  attributes: {
    accentHeight: "accent-height",
    alignmentBaseline: "alignment-baseline",
    arabicForm: "arabic-form",
    baselineShift: "baseline-shift",
    capHeight: "cap-height",
    className: "class",
    clipPath: "clip-path",
    clipRule: "clip-rule",
    colorInterpolation: "color-interpolation",
    colorInterpolationFilters: "color-interpolation-filters",
    colorProfile: "color-profile",
    colorRendering: "color-rendering",
    crossOrigin: "crossorigin",
    dataType: "datatype",
    dominantBaseline: "dominant-baseline",
    enableBackground: "enable-background",
    fillOpacity: "fill-opacity",
    fillRule: "fill-rule",
    floodColor: "flood-color",
    floodOpacity: "flood-opacity",
    fontFamily: "font-family",
    fontSize: "font-size",
    fontSizeAdjust: "font-size-adjust",
    fontStretch: "font-stretch",
    fontStyle: "font-style",
    fontVariant: "font-variant",
    fontWeight: "font-weight",
    glyphName: "glyph-name",
    glyphOrientationHorizontal: "glyph-orientation-horizontal",
    glyphOrientationVertical: "glyph-orientation-vertical",
    hrefLang: "hreflang",
    horizAdvX: "horiz-adv-x",
    horizOriginX: "horiz-origin-x",
    horizOriginY: "horiz-origin-y",
    imageRendering: "image-rendering",
    letterSpacing: "letter-spacing",
    lightingColor: "lighting-color",
    markerEnd: "marker-end",
    markerMid: "marker-mid",
    markerStart: "marker-start",
    maskType: "mask-type",
    navDown: "nav-down",
    navDownLeft: "nav-down-left",
    navDownRight: "nav-down-right",
    navLeft: "nav-left",
    navNext: "nav-next",
    navPrev: "nav-prev",
    navRight: "nav-right",
    navUp: "nav-up",
    navUpLeft: "nav-up-left",
    navUpRight: "nav-up-right",
    onAbort: "onabort",
    onActivate: "onactivate",
    onAfterPrint: "onafterprint",
    onBeforePrint: "onbeforeprint",
    onBegin: "onbegin",
    onCancel: "oncancel",
    onCanPlay: "oncanplay",
    onCanPlayThrough: "oncanplaythrough",
    onChange: "onchange",
    onClick: "onclick",
    onClose: "onclose",
    onCopy: "oncopy",
    onCueChange: "oncuechange",
    onCut: "oncut",
    onDblClick: "ondblclick",
    onDrag: "ondrag",
    onDragEnd: "ondragend",
    onDragEnter: "ondragenter",
    onDragExit: "ondragexit",
    onDragLeave: "ondragleave",
    onDragOver: "ondragover",
    onDragStart: "ondragstart",
    onDrop: "ondrop",
    onDurationChange: "ondurationchange",
    onEmptied: "onemptied",
    onEnd: "onend",
    onEnded: "onended",
    onError: "onerror",
    onFocus: "onfocus",
    onFocusIn: "onfocusin",
    onFocusOut: "onfocusout",
    onHashChange: "onhashchange",
    onInput: "oninput",
    onInvalid: "oninvalid",
    onKeyDown: "onkeydown",
    onKeyPress: "onkeypress",
    onKeyUp: "onkeyup",
    onLoad: "onload",
    onLoadedData: "onloadeddata",
    onLoadedMetadata: "onloadedmetadata",
    onLoadStart: "onloadstart",
    onMessage: "onmessage",
    onMouseDown: "onmousedown",
    onMouseEnter: "onmouseenter",
    onMouseLeave: "onmouseleave",
    onMouseMove: "onmousemove",
    onMouseOut: "onmouseout",
    onMouseOver: "onmouseover",
    onMouseUp: "onmouseup",
    onMouseWheel: "onmousewheel",
    onOffline: "onoffline",
    onOnline: "ononline",
    onPageHide: "onpagehide",
    onPageShow: "onpageshow",
    onPaste: "onpaste",
    onPause: "onpause",
    onPlay: "onplay",
    onPlaying: "onplaying",
    onPopState: "onpopstate",
    onProgress: "onprogress",
    onRateChange: "onratechange",
    onRepeat: "onrepeat",
    onReset: "onreset",
    onResize: "onresize",
    onScroll: "onscroll",
    onSeeked: "onseeked",
    onSeeking: "onseeking",
    onSelect: "onselect",
    onShow: "onshow",
    onStalled: "onstalled",
    onStorage: "onstorage",
    onSubmit: "onsubmit",
    onSuspend: "onsuspend",
    onTimeUpdate: "ontimeupdate",
    onToggle: "ontoggle",
    onUnload: "onunload",
    onVolumeChange: "onvolumechange",
    onWaiting: "onwaiting",
    onZoom: "onzoom",
    overlinePosition: "overline-position",
    overlineThickness: "overline-thickness",
    paintOrder: "paint-order",
    panose1: "panose-1",
    pointerEvents: "pointer-events",
    referrerPolicy: "referrerpolicy",
    renderingIntent: "rendering-intent",
    shapeRendering: "shape-rendering",
    stopColor: "stop-color",
    stopOpacity: "stop-opacity",
    strikethroughPosition: "strikethrough-position",
    strikethroughThickness: "strikethrough-thickness",
    strokeDashArray: "stroke-dasharray",
    strokeDashOffset: "stroke-dashoffset",
    strokeLineCap: "stroke-linecap",
    strokeLineJoin: "stroke-linejoin",
    strokeMiterLimit: "stroke-miterlimit",
    strokeOpacity: "stroke-opacity",
    strokeWidth: "stroke-width",
    tabIndex: "tabindex",
    textAnchor: "text-anchor",
    textDecoration: "text-decoration",
    textRendering: "text-rendering",
    transformOrigin: "transform-origin",
    typeOf: "typeof",
    underlinePosition: "underline-position",
    underlineThickness: "underline-thickness",
    unicodeBidi: "unicode-bidi",
    unicodeRange: "unicode-range",
    unitsPerEm: "units-per-em",
    vAlphabetic: "v-alphabetic",
    vHanging: "v-hanging",
    vIdeographic: "v-ideographic",
    vMathematical: "v-mathematical",
    vectorEffect: "vector-effect",
    vertAdvY: "vert-adv-y",
    vertOriginX: "vert-origin-x",
    vertOriginY: "vert-origin-y",
    wordSpacing: "word-spacing",
    writingMode: "writing-mode",
    xHeight: "x-height",
    // These were camelcased in Tiny. Now lowercased in SVG 2
    playbackOrder: "playbackorder",
    timelineBegin: "timelinebegin"
  },
  properties: {
    about: Ne,
    accentHeight: P,
    accumulate: null,
    additive: null,
    alignmentBaseline: null,
    alphabetic: P,
    amplitude: P,
    arabicForm: null,
    ascent: P,
    attributeName: null,
    attributeType: null,
    azimuth: P,
    bandwidth: null,
    baselineShift: null,
    baseFrequency: null,
    baseProfile: null,
    bbox: null,
    begin: null,
    bias: P,
    by: null,
    calcMode: null,
    capHeight: P,
    className: ie,
    clip: null,
    clipPath: null,
    clipPathUnits: null,
    clipRule: null,
    color: null,
    colorInterpolation: null,
    colorInterpolationFilters: null,
    colorProfile: null,
    colorRendering: null,
    content: null,
    contentScriptType: null,
    contentStyleType: null,
    crossOrigin: null,
    cursor: null,
    cx: null,
    cy: null,
    d: null,
    dataType: null,
    defaultAction: null,
    descent: P,
    diffuseConstant: P,
    direction: null,
    display: null,
    dur: null,
    divisor: P,
    dominantBaseline: null,
    download: J,
    dx: null,
    dy: null,
    edgeMode: null,
    editable: null,
    elevation: P,
    enableBackground: null,
    end: null,
    event: null,
    exponent: P,
    externalResourcesRequired: null,
    fill: null,
    fillOpacity: P,
    fillRule: null,
    filter: null,
    filterRes: null,
    filterUnits: null,
    floodColor: null,
    floodOpacity: null,
    focusable: null,
    focusHighlight: null,
    fontFamily: null,
    fontSize: null,
    fontSizeAdjust: null,
    fontStretch: null,
    fontStyle: null,
    fontVariant: null,
    fontWeight: null,
    format: null,
    fr: null,
    from: null,
    fx: null,
    fy: null,
    g1: $t,
    g2: $t,
    glyphName: $t,
    glyphOrientationHorizontal: null,
    glyphOrientationVertical: null,
    glyphRef: null,
    gradientTransform: null,
    gradientUnits: null,
    handler: null,
    hanging: P,
    hatchContentUnits: null,
    hatchUnits: null,
    height: null,
    href: null,
    hrefLang: null,
    horizAdvX: P,
    horizOriginX: P,
    horizOriginY: P,
    id: null,
    ideographic: P,
    imageRendering: null,
    initialVisibility: null,
    in: null,
    in2: null,
    intercept: P,
    k: P,
    k1: P,
    k2: P,
    k3: P,
    k4: P,
    kernelMatrix: Ne,
    kernelUnitLength: null,
    keyPoints: null,
    // SEMI_COLON_SEPARATED
    keySplines: null,
    // SEMI_COLON_SEPARATED
    keyTimes: null,
    // SEMI_COLON_SEPARATED
    kerning: null,
    lang: null,
    lengthAdjust: null,
    letterSpacing: null,
    lightingColor: null,
    limitingConeAngle: P,
    local: null,
    markerEnd: null,
    markerMid: null,
    markerStart: null,
    markerHeight: null,
    markerUnits: null,
    markerWidth: null,
    mask: null,
    maskContentUnits: null,
    maskType: null,
    maskUnits: null,
    mathematical: null,
    max: null,
    media: null,
    mediaCharacterEncoding: null,
    mediaContentEncodings: null,
    mediaSize: P,
    mediaTime: null,
    method: null,
    min: null,
    mode: null,
    name: null,
    navDown: null,
    navDownLeft: null,
    navDownRight: null,
    navLeft: null,
    navNext: null,
    navPrev: null,
    navRight: null,
    navUp: null,
    navUpLeft: null,
    navUpRight: null,
    numOctaves: null,
    observer: null,
    offset: null,
    onAbort: null,
    onActivate: null,
    onAfterPrint: null,
    onBeforePrint: null,
    onBegin: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnd: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFocusIn: null,
    onFocusOut: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadStart: null,
    onMessage: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onMouseWheel: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRepeat: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onShow: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onZoom: null,
    opacity: null,
    operator: null,
    order: null,
    orient: null,
    orientation: null,
    origin: null,
    overflow: null,
    overlay: null,
    overlinePosition: P,
    overlineThickness: P,
    paintOrder: null,
    panose1: null,
    path: null,
    pathLength: P,
    patternContentUnits: null,
    patternTransform: null,
    patternUnits: null,
    phase: null,
    ping: ie,
    pitch: null,
    playbackOrder: null,
    pointerEvents: null,
    points: null,
    pointsAtX: P,
    pointsAtY: P,
    pointsAtZ: P,
    preserveAlpha: null,
    preserveAspectRatio: null,
    primitiveUnits: null,
    propagate: null,
    property: Ne,
    r: null,
    radius: null,
    referrerPolicy: null,
    refX: null,
    refY: null,
    rel: Ne,
    rev: Ne,
    renderingIntent: null,
    repeatCount: null,
    repeatDur: null,
    requiredExtensions: Ne,
    requiredFeatures: Ne,
    requiredFonts: Ne,
    requiredFormats: Ne,
    resource: null,
    restart: null,
    result: null,
    rotate: null,
    rx: null,
    ry: null,
    scale: null,
    seed: null,
    shapeRendering: null,
    side: null,
    slope: null,
    snapshotTime: null,
    specularConstant: P,
    specularExponent: P,
    spreadMethod: null,
    spacing: null,
    startOffset: null,
    stdDeviation: null,
    stemh: null,
    stemv: null,
    stitchTiles: null,
    stopColor: null,
    stopOpacity: null,
    strikethroughPosition: P,
    strikethroughThickness: P,
    string: null,
    stroke: null,
    strokeDashArray: Ne,
    strokeDashOffset: null,
    strokeLineCap: null,
    strokeLineJoin: null,
    strokeMiterLimit: P,
    strokeOpacity: P,
    strokeWidth: null,
    style: null,
    surfaceScale: P,
    syncBehavior: null,
    syncBehaviorDefault: null,
    syncMaster: null,
    syncTolerance: null,
    syncToleranceDefault: null,
    systemLanguage: Ne,
    tabIndex: P,
    tableValues: null,
    target: null,
    targetX: P,
    targetY: P,
    textAnchor: null,
    textDecoration: null,
    textRendering: null,
    textLength: null,
    timelineBegin: null,
    title: null,
    transformBehavior: null,
    type: null,
    typeOf: Ne,
    to: null,
    transform: null,
    transformOrigin: null,
    u1: null,
    u2: null,
    underlinePosition: P,
    underlineThickness: P,
    unicode: null,
    unicodeBidi: null,
    unicodeRange: null,
    unitsPerEm: P,
    values: null,
    vAlphabetic: P,
    vMathematical: P,
    vectorEffect: null,
    vHanging: P,
    vIdeographic: P,
    version: null,
    vertAdvY: P,
    vertOriginX: P,
    vertOriginY: P,
    viewBox: null,
    viewTarget: null,
    visibility: null,
    width: null,
    widths: null,
    wordSpacing: null,
    writingMode: null,
    x: null,
    x1: null,
    x2: null,
    xChannelSelector: null,
    xHeight: P,
    y: null,
    y1: null,
    y2: null,
    yChannelSelector: null,
    z: null,
    zoomAndPan: null
  },
  space: "svg",
  transform: Ku
}), Gu = an({
  properties: {
    xLinkActuate: null,
    xLinkArcRole: null,
    xLinkHref: null,
    xLinkRole: null,
    xLinkShow: null,
    xLinkTitle: null,
    xLinkType: null
  },
  space: "xlink",
  transform(e, t) {
    return "xlink:" + t.slice(5).toLowerCase();
  }
}), Xu = an({
  attributes: { xmlnsxlink: "xmlns:xlink" },
  properties: { xmlnsXLink: null, xmlns: null },
  space: "xmlns",
  transform: Yu
}), Qu = an({
  properties: { xmlBase: null, xmlLang: null, xmlSpace: null },
  space: "xml",
  transform(e, t) {
    return "xml:" + t.slice(3).toLowerCase();
  }
}), Ov = {
  classId: "classID",
  dataType: "datatype",
  itemId: "itemID",
  strokeDashArray: "strokeDasharray",
  strokeDashOffset: "strokeDashoffset",
  strokeLineCap: "strokeLinecap",
  strokeLineJoin: "strokeLinejoin",
  strokeMiterLimit: "strokeMiterlimit",
  typeOf: "typeof",
  xLinkActuate: "xlinkActuate",
  xLinkArcRole: "xlinkArcrole",
  xLinkHref: "xlinkHref",
  xLinkRole: "xlinkRole",
  xLinkShow: "xlinkShow",
  xLinkTitle: "xlinkTitle",
  xLinkType: "xlinkType",
  xmlnsXLink: "xmlnsXlink"
}, Pv = /[A-Z]/g, Ka = /-[a-z]/g, Mv = /^data[-\w.:]+$/i;
function Rv(e, t) {
  const n = Di(t);
  let r = t, i = $e;
  if (n in e.normal)
    return e.property[e.normal[n]];
  if (n.length > 4 && n.slice(0, 4) === "data" && Mv.test(t)) {
    if (t.charAt(4) === "-") {
      const o = t.slice(5).replace(Ka, Dv);
      r = "data" + o.charAt(0).toUpperCase() + o.slice(1);
    } else {
      const o = t.slice(4);
      if (!Ka.test(o)) {
        let a = o.replace(Pv, $v);
        a.charAt(0) !== "-" && (a = "-" + a), t = "data" + a;
      }
    }
    i = yo;
  }
  return new i(r, t);
}
function $v(e) {
  return "-" + e.toLowerCase();
}
function Dv(e) {
  return e.charAt(1).toUpperCase();
}
const Nv = Wu([Hu, zv, Gu, Xu, Qu], "html"), bo = Wu([Hu, Tv, Gu, Xu, Qu], "svg");
function Lv(e) {
  return e.join(" ").trim();
}
var Ya = /\/\*(?:[^*]|\*(?!\/))*\*\//g, Fv = /\n/g, jv = /^\s*/, Zv = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, Bv = /^:\s*/, Uv = /^((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|url\((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|[^)]*)\)|[^};])+)/, Vv = /^[;\s]*/, qv = `
`, Ga = "/", Xa = "*", mn = "", Jv = "comment", Wv = "declaration";
function Hv(e, t) {
  if (typeof e != "string")
    throw new TypeError("First argument must be a string");
  if (!e) return [];
  t = t || {};
  var n = 1, r = 1;
  function i(h) {
    var m = h.match(Fv);
    m && (n += m.length);
    var v = h.lastIndexOf(qv);
    r = ~v ? h.length - v : r + h.length;
  }
  function o() {
    var h = { line: n, column: r };
    return function(m) {
      return m.position = new a(h), c(), m;
    };
  }
  function a(h) {
    this.start = h, this.end = { line: n, column: r }, this.source = t.source;
  }
  a.prototype.content = e;
  function s(h) {
    var m = new Error(
      t.source + ":" + n + ":" + r + ": " + h
    );
    if (m.reason = h, m.filename = t.source, m.line = n, m.column = r, m.source = e, !t.silent) throw m;
  }
  function u(h) {
    var m = h.exec(e);
    if (m) {
      var v = m[0];
      return i(v), e = e.slice(v.length), m;
    }
  }
  function c() {
    u(jv);
  }
  function l(h) {
    for (var m; m = f(); )
      h.push(m);
    return h;
  }
  function f() {
    var h = o();
    if (!(Ga != e.charAt(0) || Xa != e.charAt(1))) {
      for (var m = 2; mn != e.charAt(m) && (Xa != e.charAt(m) || Ga != e.charAt(m + 1)); )
        ++m;
      if (m += 2, mn === e.charAt(m - 1))
        return s("End of comment missing");
      var v = e.slice(2, m - 2);
      return r += 2, i(v), e = e.slice(m), r += 2, h({
        type: Jv,
        comment: v
      });
    }
  }
  function p() {
    var h = o(), m = u(Zv);
    if (m) {
      if (f(), !u(Bv)) return s("property missing ':'");
      var v = u(Uv), g = h({
        type: Wv,
        property: m[0].replace(Ya, mn).trim(),
        value: v ? v[0].replace(Ya, mn).trim() : mn
      });
      return u(Vv), g;
    }
  }
  function d() {
    var h = [];
    l(h);
    for (var m; m = p(); )
      h.push(m), l(h);
    return h;
  }
  return c(), d();
}
function Kv(e, t) {
  let n = null;
  if (!e || typeof e != "string") return n;
  const r = Hv(e), i = typeof t == "function";
  return r.forEach((o) => {
    if (o.type !== "declaration") return;
    const { property: a, value: s } = o;
    i ? t(a, s, o) : s && (n = n ?? {}, n[a] = s);
  }), n;
}
const ec = tc("end"), vo = tc("start");
function tc(e) {
  return t;
  function t(n) {
    const r = n && n.position && n.position[e] || {};
    if (typeof r.line == "number" && r.line > 0 && typeof r.column == "number" && r.column > 0)
      return {
        line: r.line,
        column: r.column,
        offset: typeof r.offset == "number" && r.offset > -1 ? r.offset : void 0
      };
  }
}
function Yv(e) {
  const t = vo(e), n = ec(e);
  if (t && n)
    return { start: t, end: n };
}
function An(e) {
  return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? Qa(e.position) : "start" in e || "end" in e ? Qa(e) : "line" in e || "column" in e ? Fi(e) : "";
}
function Fi(e) {
  return es(e && e.line) + ":" + es(e && e.column);
}
function Qa(e) {
  return Fi(e && e.start) + "-" + Fi(e && e.end);
}
function es(e) {
  return e && typeof e == "number" ? e : 1;
}
class Tr extends Error {
  /**
   * Create a message for `reason`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Options | null | undefined} [options]
   *   Configuration (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | null | undefined} parent
   *   Node or node-like, used for `ancestors` and `place`.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Point | Position | null | undefined} place
   *   Place of message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {Node | NodeLike | null | undefined} parent
   *   Node or node-like, used for `ancestors` and `place`.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {Point | Position | null | undefined} place
   *   Place of message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | Options | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns
   *   Instance of `VFileMessage`.
   */
  // eslint-disable-next-line complexity
  constructor(t, n, r) {
    super(), typeof n == "string" && (r = n, n = void 0);
    let i = "", o = {}, a = !1;
    if (n && ("line" in n && "column" in n ? o = { place: n } : "start" in n && "end" in n ? o = { place: n } : "type" in n ? o = {
      ancestors: [n],
      place: n.position
    } : o = { ...n }), typeof t == "string" ? i = t : !o.cause && t && (a = !0, i = t.message, o.cause = t), !o.ruleId && !o.source && typeof r == "string") {
      const u = r.indexOf(":");
      u === -1 ? o.ruleId = r : (o.source = r.slice(0, u), o.ruleId = r.slice(u + 1));
    }
    if (!o.place && o.ancestors) {
      const u = o.ancestors[o.ancestors.length - 1];
      u && (o.place = u.position);
    }
    const s = o.place && "start" in o.place ? o.place.start : o.place;
    this.ancestors = o.ancestors || void 0, this.cause = o.cause || void 0, this.column = s ? s.column : void 0, this.fatal = void 0, this.file = "", this.message = i, this.line = s ? s.line : void 0, this.name = An(o.place) || "1:1", this.place = o.place || void 0, this.reason = this.message, this.ruleId = o.ruleId || void 0, this.source = o.source || void 0, this.stack = a && o.cause && typeof o.cause.stack == "string" ? o.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
  }
}
Object.defineProperties(Tr.prototype, {
  file: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  name: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  reason: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  message: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  stack: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  column: { configurable: !0, enumerable: !0, writable: !0 },
  line: { configurable: !0, enumerable: !0, writable: !0 },
  ancestors: { configurable: !0, enumerable: !0, writable: !0 },
  cause: { configurable: !0, enumerable: !0, writable: !0 },
  fatal: { configurable: !0, enumerable: !0, writable: !0 },
  place: { configurable: !0, enumerable: !0, writable: !0 },
  ruleId: { configurable: !0, enumerable: !0, writable: !0 },
  source: { configurable: !0, enumerable: !0, writable: !0 }
});
const ko = {}.hasOwnProperty, Gv = /* @__PURE__ */ new Map(), Xv = /[A-Z]/g, Qv = /-([a-z])/g, ek = /* @__PURE__ */ new Set(["table", "tbody", "thead", "tfoot", "tr"]), tk = /* @__PURE__ */ new Set(["td", "th"]), nc = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function nk(e, t) {
  if (!t || t.Fragment === void 0)
    throw new TypeError("Expected `Fragment` in options");
  const n = t.filePath || void 0;
  let r;
  if (t.development) {
    if (typeof t.jsxDEV != "function")
      throw new TypeError(
        "Expected `jsxDEV` in options when `development: true`"
      );
    r = ck(n, t.jsxDEV);
  } else {
    if (typeof t.jsx != "function")
      throw new TypeError("Expected `jsx` in production options");
    if (typeof t.jsxs != "function")
      throw new TypeError("Expected `jsxs` in production options");
    r = uk(n, t.jsx, t.jsxs);
  }
  const i = {
    Fragment: t.Fragment,
    ancestors: [],
    components: t.components || {},
    create: r,
    elementAttributeNameCase: t.elementAttributeNameCase || "react",
    evaluater: t.createEvaluater ? t.createEvaluater() : void 0,
    filePath: n,
    ignoreInvalidStyle: t.ignoreInvalidStyle || !1,
    passKeys: t.passKeys !== !1,
    passNode: t.passNode || !1,
    schema: t.space === "svg" ? bo : Nv,
    stylePropertyNameCase: t.stylePropertyNameCase || "dom",
    tableCellAlignToStyle: t.tableCellAlignToStyle !== !1
  }, o = rc(i, e, void 0);
  return o && typeof o != "string" ? o : i.create(
    e,
    i.Fragment,
    { children: o || void 0 },
    void 0
  );
}
function rc(e, t, n) {
  if (t.type === "element")
    return rk(e, t, n);
  if (t.type === "mdxFlowExpression" || t.type === "mdxTextExpression")
    return ik(e, t);
  if (t.type === "mdxJsxFlowElement" || t.type === "mdxJsxTextElement")
    return ak(e, t, n);
  if (t.type === "mdxjsEsm")
    return ok(e, t);
  if (t.type === "root")
    return sk(e, t, n);
  if (t.type === "text")
    return lk(e, t);
}
function rk(e, t, n) {
  const r = e.schema;
  let i = r;
  t.tagName.toLowerCase() === "svg" && r.space === "html" && (i = bo, e.schema = i), e.ancestors.push(t);
  const o = oc(e, t.tagName, !1), a = fk(e, t);
  let s = xo(e, t);
  return ek.has(t.tagName) && (s = s.filter(function(u) {
    return typeof u == "string" ? !Cv(u) : !0;
  })), ic(e, a, o, t), wo(a, s), e.ancestors.pop(), e.schema = r, e.create(t, o, a, n);
}
function ik(e, t) {
  if (t.data && t.data.estree && e.evaluater) {
    const r = t.data.estree.body[0];
    return r.type, /** @type {Child | undefined} */
    e.evaluater.evaluateExpression(r.expression);
  }
  Dn(e, t.position);
}
function ok(e, t) {
  if (t.data && t.data.estree && e.evaluater)
    return (
      /** @type {Child | undefined} */
      e.evaluater.evaluateProgram(t.data.estree)
    );
  Dn(e, t.position);
}
function ak(e, t, n) {
  const r = e.schema;
  let i = r;
  t.name === "svg" && r.space === "html" && (i = bo, e.schema = i), e.ancestors.push(t);
  const o = t.name === null ? e.Fragment : oc(e, t.name, !0), a = dk(e, t), s = xo(e, t);
  return ic(e, a, o, t), wo(a, s), e.ancestors.pop(), e.schema = r, e.create(t, o, a, n);
}
function sk(e, t, n) {
  const r = {};
  return wo(r, xo(e, t)), e.create(t, e.Fragment, r, n);
}
function lk(e, t) {
  return t.value;
}
function ic(e, t, n, r) {
  typeof n != "string" && n !== e.Fragment && e.passNode && (t.node = r);
}
function wo(e, t) {
  if (t.length > 0) {
    const n = t.length > 1 ? t : t[0];
    n && (e.children = n);
  }
}
function uk(e, t, n) {
  return r;
  function r(i, o, a, s) {
    const c = Array.isArray(a.children) ? n : t;
    return s ? c(o, a, s) : c(o, a);
  }
}
function ck(e, t) {
  return n;
  function n(r, i, o, a) {
    const s = Array.isArray(o.children), u = vo(r);
    return t(
      i,
      o,
      a,
      s,
      {
        columnNumber: u ? u.column - 1 : void 0,
        fileName: e,
        lineNumber: u ? u.line : void 0
      },
      void 0
    );
  }
}
function fk(e, t) {
  const n = {};
  let r, i;
  for (i in t.properties)
    if (i !== "children" && ko.call(t.properties, i)) {
      const o = pk(e, i, t.properties[i]);
      if (o) {
        const [a, s] = o;
        e.tableCellAlignToStyle && a === "align" && typeof s == "string" && tk.has(t.tagName) ? r = s : n[a] = s;
      }
    }
  if (r) {
    const o = (
      /** @type {Style} */
      n.style || (n.style = {})
    );
    o[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = r;
  }
  return n;
}
function dk(e, t) {
  const n = {};
  for (const r of t.attributes)
    if (r.type === "mdxJsxExpressionAttribute")
      if (r.data && r.data.estree && e.evaluater) {
        const o = r.data.estree.body[0];
        o.type;
        const a = o.expression;
        a.type;
        const s = a.properties[0];
        s.type, Object.assign(
          n,
          e.evaluater.evaluateExpression(s.argument)
        );
      } else
        Dn(e, t.position);
    else {
      const { name: i } = r;
      let o;
      if (r.value && typeof r.value == "object")
        if (r.value.data && r.value.data.estree && e.evaluater) {
          const s = r.value.data.estree.body[0];
          s.type, o = e.evaluater.evaluateExpression(s.expression);
        } else
          Dn(e, t.position);
      else
        o = r.value === null ? !0 : r.value;
      n[i] = /** @type {Props[keyof Props]} */
      o;
    }
  return n;
}
function xo(e, t) {
  const n = [];
  let r = -1;
  const i = e.passKeys ? /* @__PURE__ */ new Map() : Gv;
  for (; ++r < t.children.length; ) {
    const o = t.children[r];
    let a;
    if (e.passKeys) {
      const u = o.type === "element" ? o.tagName : o.type === "mdxJsxFlowElement" || o.type === "mdxJsxTextElement" ? o.name : void 0;
      if (u) {
        const c = i.get(u) || 0;
        a = u + "-" + c, i.set(u, c + 1);
      }
    }
    const s = rc(e, o, a);
    s !== void 0 && n.push(s);
  }
  return n;
}
function pk(e, t, n) {
  if (n == null || typeof n == "number" && Number.isNaN(n))
    return;
  const r = Rv(e.schema, t);
  return Array.isArray(n) && (n = r.commaSeparated ? xv(n) : Lv(n)), r.property === "style" ? ["style", typeof n == "object" ? e.stylePropertyNameCase === "dom" ? n : mk(n) : hk(e, String(n))] : [
    e.elementAttributeNameCase === "react" && r.space ? Ov[r.property] || r.property : r.attribute,
    n
  ];
}
function hk(e, t) {
  const n = {};
  try {
    Kv(t, function(r, i) {
      if (r && i) {
        let o = r;
        o.slice(0, 2) !== "--" && (o = o.toLowerCase(), e.stylePropertyNameCase === "dom" && (o.slice(0, 4) === "-ms-" && (o = o.slice(1)), o = o.replace(Qv, bk))), n[o] = i;
      }
    });
  } catch (r) {
    if (e.ignoreInvalidStyle)
      return {};
    const i = (
      /** @type {Error} */
      r
    ), o = new Tr("Cannot parse `style` attribute", {
      ancestors: e.ancestors,
      cause: i,
      ruleId: "style",
      source: "hast-util-to-jsx-runtime"
    });
    throw o.file = e.filePath || void 0, o.url = nc + "#cannot-parse-style-attribute", o;
  }
  return n;
}
function oc(e, t, n) {
  let r;
  if (!n)
    r = { type: "Literal", value: t };
  else if (t.includes(".")) {
    const i = t.split(".");
    let o = -1, a;
    for (; ++o < i.length; ) {
      const s = Ja(i[o]) ? { type: "Identifier", name: i[o] } : { type: "Literal", value: i[o] };
      a = a ? {
        type: "MemberExpression",
        object: a,
        property: s,
        computed: !!(o && s.type === "Literal"),
        optional: !1
      } : s;
    }
    r = a;
  } else
    r = Ja(t) && !/^[a-z]/.test(t) ? { type: "Identifier", name: t } : { type: "Literal", value: t };
  if (r.type === "Literal") {
    const i = (
      /** @type {string | number} */
      r.value
    );
    return ko.call(e.components, i) ? e.components[i] : i;
  }
  if (e.evaluater)
    return e.evaluater.evaluateExpression(r);
  Dn(e);
}
function Dn(e, t) {
  const n = new Tr(
    "Cannot handle MDX estrees without `createEvaluater`",
    {
      ancestors: e.ancestors,
      place: t,
      ruleId: "mdx-estree",
      source: "hast-util-to-jsx-runtime"
    }
  );
  throw n.file = e.filePath || void 0, n.url = nc + "#cannot-handle-mdx-estrees-without-createevaluater", n;
}
function mk(e) {
  const t = {};
  let n;
  for (n in e)
    ko.call(e, n) && (t[gk(n)] = e[n]);
  return t;
}
function gk(e) {
  if (e.slice(0, 2) === "--") return e;
  let t = e.replace(Xv, yk);
  return t.slice(0, 3) === "ms-" && (t = "-" + t), t;
}
function yk(e) {
  return "-" + e.toLowerCase();
}
function bk(e, t) {
  return t.toUpperCase();
}
const ti = {
  action: ["form"],
  cite: ["blockquote", "del", "ins", "q"],
  data: ["object"],
  formAction: ["button", "input"],
  href: ["a", "area", "base", "link"],
  icon: ["menuitem"],
  itemId: null,
  manifest: ["html"],
  ping: ["a", "area"],
  poster: ["video"],
  src: [
    "audio",
    "embed",
    "iframe",
    "img",
    "input",
    "script",
    "source",
    "track",
    "video"
  ]
}, vk = {};
function Or(e, t) {
  const n = vk, r = typeof n.includeImageAlt == "boolean" ? n.includeImageAlt : !0, i = typeof n.includeHtml == "boolean" ? n.includeHtml : !0;
  return ac(e, r, i);
}
function ac(e, t, n) {
  if (kk(e)) {
    if ("value" in e)
      return e.type === "html" && !n ? "" : e.value;
    if (t && "alt" in e && e.alt)
      return e.alt;
    if ("children" in e)
      return ts(e.children, t, n);
  }
  return Array.isArray(e) ? ts(e, t, n) : "";
}
function ts(e, t, n) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; )
    r[i] = ac(e[i], t, n);
  return r.join("");
}
function kk(e) {
  return !!(e && typeof e == "object");
}
const ns = document.createElement("i");
function _o(e) {
  const t = "&" + e + ";";
  ns.innerHTML = t;
  const n = ns.textContent;
  return n.charCodeAt(n.length - 1) === 59 && e !== "semi" || n === t ? !1 : n;
}
function Qe(e, t, n, r) {
  const i = e.length;
  let o = 0, a;
  if (t < 0 ? t = -t > i ? 0 : i + t : t = t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4)
    a = Array.from(r), a.unshift(t, n), e.splice(...a);
  else
    for (n && e.splice(t, n); o < r.length; )
      a = r.slice(o, o + 1e4), a.unshift(t, 0), e.splice(...a), o += 1e4, t += 1e4;
}
function Je(e, t) {
  return e.length > 0 ? (Qe(e, e.length, 0, t), e) : t;
}
const rs = {}.hasOwnProperty;
function sc(e) {
  const t = {};
  let n = -1;
  for (; ++n < e.length; )
    wk(t, e[n]);
  return t;
}
function wk(e, t) {
  let n;
  for (n in t) {
    const i = (rs.call(e, n) ? e[n] : void 0) || (e[n] = {}), o = t[n];
    let a;
    if (o)
      for (a in o) {
        rs.call(i, a) || (i[a] = []);
        const s = o[a];
        xk(
          // @ts-expect-error Looks like a list.
          i[a],
          Array.isArray(s) ? s : s ? [s] : []
        );
      }
  }
}
function xk(e, t) {
  let n = -1;
  const r = [];
  for (; ++n < t.length; )
    (t[n].add === "after" ? e : r).push(t[n]);
  Qe(e, 0, 0, r);
}
function lc(e, t) {
  const n = Number.parseInt(e, t);
  return (
    // C0 except for HT, LF, FF, CR, space.
    n < 9 || n === 11 || n > 13 && n < 32 || // Control character (DEL) of C0, and C1 controls.
    n > 126 && n < 160 || // Lone high surrogates and low surrogates.
    n > 55295 && n < 57344 || // Noncharacters.
    n > 64975 && n < 65008 || /* eslint-disable no-bitwise */
    (n & 65535) === 65535 || (n & 65535) === 65534 || /* eslint-enable no-bitwise */
    // Out of range
    n > 1114111 ? "�" : String.fromCodePoint(n)
  );
}
function et(e) {
  return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
const we = At(/[A-Za-z]/), xe = At(/[\dA-Za-z]/), _k = At(/[#-'*+\--9=?A-Z^-~]/);
function vr(e) {
  return (
    // Special whitespace codes (which have negative values), C0 and Control
    // character DEL
    e !== null && (e < 32 || e === 127)
  );
}
const ji = At(/\d/), Sk = At(/[\dA-Fa-f]/), uc = At(/[!-/:-@[-`{-~]/);
function q(e) {
  return e !== null && e < -2;
}
function ae(e) {
  return e !== null && (e < 0 || e === 32);
}
function X(e) {
  return e === -2 || e === -1 || e === 32;
}
const Zn = At(new RegExp("\\p{P}|\\p{S}", "u")), jt = At(/\s/);
function At(e) {
  return t;
  function t(n) {
    return n !== null && n > -1 && e.test(String.fromCharCode(n));
  }
}
function sn(e) {
  const t = [];
  let n = -1, r = 0, i = 0;
  for (; ++n < e.length; ) {
    const o = e.charCodeAt(n);
    let a = "";
    if (o === 37 && xe(e.charCodeAt(n + 1)) && xe(e.charCodeAt(n + 2)))
      i = 2;
    else if (o < 128)
      /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) || (a = String.fromCharCode(o));
    else if (o > 55295 && o < 57344) {
      const s = e.charCodeAt(n + 1);
      o < 56320 && s > 56319 && s < 57344 ? (a = String.fromCharCode(o, s), i = 1) : a = "�";
    } else
      a = String.fromCharCode(o);
    a && (t.push(e.slice(r, n), encodeURIComponent(a)), r = n + i + 1, a = ""), i && (n += i, i = 0);
  }
  return t.join("") + e.slice(r);
}
function ne(e, t, n, r) {
  const i = r ? r - 1 : 1 / 0;
  let o = 0;
  return a;
  function a(u) {
    return X(u) ? (e.enter(n), s(u)) : t(u);
  }
  function s(u) {
    return X(u) && o++ < i ? (e.consume(u), s) : (e.exit(n), t(u));
  }
}
function cc(e, t, n, r, i, o) {
  let a = 0;
  return s;
  function s(l) {
    return X(l) ? (e.enter(r), u(l)) : c(l);
  }
  function u(l) {
    return X(l) && a < o ? (e.consume(l), a++, u) : (e.exit(r), c(l));
  }
  function c(l) {
    return a >= i ? t(l) : n(l);
  }
}
const Ik = {
  tokenize: Ek
};
function Ek(e) {
  const t = e.attempt(this.parser.constructs.contentInitial, r, i);
  let n;
  return t;
  function r(s) {
    if (s === null) {
      e.consume(s);
      return;
    }
    return e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), ne(e, t, "linePrefix");
  }
  function i(s) {
    return e.enter("paragraph"), o(s);
  }
  function o(s) {
    const u = e.enter("chunkText", {
      contentType: "text",
      previous: n
    });
    return n && (n.next = u), n = u, a(s);
  }
  function a(s) {
    if (s === null) {
      e.exit("chunkText"), e.exit("paragraph"), e.consume(s);
      return;
    }
    return q(s) ? (e.consume(s), e.exit("chunkText"), o) : (e.consume(s), a);
  }
}
let kr = class {
  /**
   * Create a new edit map.
   *
   * @returns
   *   New instance.
   */
  constructor() {
    this.index = /* @__PURE__ */ new Map(), this.map = [];
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  add(t, n, r) {
    is(this, t, n, r, !1);
  }
  /**
   * Create an edit: but insert `add` before existing additions, instead of
   * after them.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  addBefore(t, n, r) {
    is(this, t, n, r, !0);
  }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   *   List of events to apply the edits to.
   * @returns {undefined}
   *   Nothing.
   */
  consume(t) {
    if (this.map.sort(function(o, a) {
      return o[0] - a[0];
    }), this.map.length === 0)
      return;
    let n = this.map.length;
    const r = [];
    for (; n > 0; )
      n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
    r.push(t.slice()), t.length = 0;
    let i = r.pop();
    for (; i; ) {
      for (const o of i)
        t.push(o);
      i = r.pop();
    }
    this.map.length = 0, this.index.clear();
  }
};
function is(e, t, n, r, i) {
  if (n === 0 && r.length === 0)
    return;
  const o = e.index.get(t);
  if (o) {
    o[1] += n, i ? (r.push(...o[2]), o[2] = r) : o[2].push(...r);
    return;
  }
  const a = [t, n, r];
  e.map.push(a), e.index.set(t, a);
}
const Ck = {
  tokenize: Ak
}, os = {
  tokenize: zk
};
function Ak(e) {
  const t = this, n = [];
  let r = 0, i, o, a;
  return s;
  function s(I) {
    if (r < n.length) {
      const S = n[r];
      return t.containerState = S[1], e.attempt(S[0].continuation, u, c)(I);
    }
    return c(I);
  }
  function u(I) {
    if (r++, t.containerState._closeFlow) {
      t.containerState._closeFlow = void 0, i && w();
      const S = t.events.length;
      let _ = S, y;
      for (; _--; )
        if (t.events[_][0] === "exit" && t.events[_][1].type === "chunkFlow") {
          y = t.events[_][1].end;
          break;
        }
      g(r);
      let C = S;
      for (; C < t.events.length; )
        t.events[C][1].end = {
          ...y
        }, C++;
      const R = new kr();
      return R.add(_ + 1, 0, t.events.slice(S)), R.add(S, C - S, []), R.consume(t.events), c(I);
    }
    return s(I);
  }
  function c(I) {
    if (r === n.length) {
      if (!i)
        return p(I);
      if (i.currentConstruct && i.currentConstruct.concrete)
        return h(I);
      t.interrupt = !!(i.currentConstruct && !i._gfmTableDynamicInterruptHack);
    }
    return t.containerState = {}, e.check(os, l, f)(I);
  }
  function l(I) {
    return i && w(), g(r), p(I);
  }
  function f(I) {
    return t.parser.lazy[t.now().line] = r !== n.length, a = t.now().offset, h(I);
  }
  function p(I) {
    return t.containerState = {}, e.attempt(os, d, h)(I);
  }
  function d(I) {
    return r++, n.push([t.currentConstruct, t.containerState]), p(I);
  }
  function h(I) {
    if (I === null) {
      i && w(), g(0), e.consume(I);
      return;
    }
    return i = i || t.parser.flow(t.now()), e.enter("chunkFlow", {
      _tokenizer: i,
      contentType: "flow",
      previous: o
    }), m(I);
  }
  function m(I) {
    if (I === null) {
      v(e.exit("chunkFlow"), !0), g(0), e.consume(I);
      return;
    }
    return q(I) ? (e.consume(I), v(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(I), m);
  }
  function v(I, S) {
    const _ = t.sliceStream(I);
    if (S && _.push(null), I.previous = o, o && (o.next = I), o = I, i.defineSkip(I.start), i.write(_), t.parser.lazy[I.start.line]) {
      let y = i.events.length;
      for (; y--; )
        if (
          // The token starts before the line ending…
          i.events[y][1].start.offset < a && // …and either is not ended yet…
          (!i.events[y][1].end || // …or ends after it.
          i.events[y][1].end.offset > a)
        )
          return;
      const C = t.events.length;
      let R = C, F, E;
      for (; R--; )
        if (t.events[R][0] === "exit" && t.events[R][1].type === "chunkFlow") {
          if (F) {
            E = t.events[R][1].end;
            break;
          }
          F = !0;
        }
      for (g(r), y = C; y < t.events.length; )
        t.events[y][1].end = {
          ...E
        }, y++;
      const M = new kr();
      M.add(R + 1, 0, t.events.slice(C)), M.add(C, y - C, []), M.consume(t.events);
    }
  }
  function g(I) {
    let S = n.length;
    for (; S-- > I; ) {
      const _ = n[S];
      t.containerState = _[1], _[0].exit.call(t, e);
    }
    n.length = I;
  }
  function w() {
    i.write([null]), o = void 0, i = void 0, t.containerState._closeFlow = void 0;
  }
}
function zk(e, t, n) {
  return ne(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
function Et(e) {
  if (e === null || ae(e) || jt(e))
    return 1;
  if (Zn(e))
    return 2;
}
function Pr(e, t, n) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; ) {
    const o = e[i].resolveAll;
    o && !r.includes(o) && (t = o(t, n), r.push(o));
  }
  return t;
}
const Zi = {
  name: "attention",
  resolveAll: Tk,
  tokenize: Ok
};
function Tk(e, t) {
  let n = -1, r;
  for (; ++n < e.length; )
    if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
      let i = n;
      for (; i--; )
        if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && // If the markers are the same:
        t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
          if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3))
            continue;
          const o = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, a = {
            ...e[i][1].end
          }, s = {
            ...e[n][1].start
          };
          as(a, -o), as(s, o);
          const u = {
            type: o > 1 ? "strongSequence" : "emphasisSequence",
            start: a,
            end: {
              ...e[i][1].end
            }
          }, c = {
            type: o > 1 ? "strongSequence" : "emphasisSequence",
            start: {
              ...e[n][1].start
            },
            end: s
          }, l = {
            type: o > 1 ? "strongText" : "emphasisText",
            start: {
              ...e[i][1].end
            },
            end: {
              ...e[n][1].start
            }
          }, f = {
            type: o > 1 ? "strong" : "emphasis",
            start: {
              ...u.start
            },
            end: {
              ...c.end
            }
          };
          e[i][1].end = {
            ...u.start
          }, e[n][1].start = {
            ...c.end
          }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = Je(r, [["enter", e[i][1], t], ["exit", e[i][1], t]])), r = Je(r, [["enter", f, t], ["enter", u, t], ["exit", u, t], ["enter", l, t]]), r = Je(r, Pr(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = Je(r, [["exit", l, t], ["enter", c, t], ["exit", c, t], ["exit", f, t]]);
          let p = 0;
          e[n][1].end.offset - e[n][1].start.offset && (p = 2, r = Je(r, [["enter", e[n][1], t], ["exit", e[n][1], t]])), Qe(e, i - 1, n - i + 3, r), n = i + r.length - p - 2;
          break;
        }
    }
  for (n = -1; ++n < e.length; )
    e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
  return e;
}
function Ok(e, t) {
  const n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = Et(r);
  let o;
  return a;
  function a(u) {
    return o = u, e.enter("attentionSequence"), s(u);
  }
  function s(u) {
    if (u === o)
      return e.consume(u), s;
    const c = e.exit("attentionSequence"), l = Et(u), f = !l || l === 2 && i || n.includes(u) && u !== 42 && u !== 95, p = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
    return c._open = !!(o === 42 ? f : f && (i || !p)), c._close = !!(o === 42 ? p : p && (l || !f)), t(u);
  }
}
function as(e, t) {
  e.column += t, e.offset += t, e._bufferIndex += t;
}
const Pk = {
  name: "autolink",
  tokenize: Mk
};
function Mk(e, t, n) {
  let r = 0;
  return i;
  function i(d) {
    return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), o;
  }
  function o(d) {
    return we(d) ? (e.consume(d), a) : d === 64 ? n(d) : c(d);
  }
  function a(d) {
    return d === 43 || d === 45 || d === 46 || xe(d) ? (r = 1, s(d)) : c(d);
  }
  function s(d) {
    return d === 58 ? (e.consume(d), r = 0, u) : (d === 43 || d === 45 || d === 46 || xe(d)) && r++ < 32 ? (e.consume(d), s) : (r = 0, c(d));
  }
  function u(d) {
    return d === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.exit("autolink"), t) : d === null || d === 32 || d === 60 || vr(d) ? n(d) : (e.consume(d), u);
  }
  function c(d) {
    return d === 64 ? (e.consume(d), l) : _k(d) ? (e.consume(d), c) : n(d);
  }
  function l(d) {
    return xe(d) ? f(d) : n(d);
  }
  function f(d) {
    return d === 46 ? (e.consume(d), r = 0, l) : d === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(d), e.exit("autolinkMarker"), e.exit("autolink"), t) : p(d);
  }
  function p(d) {
    if ((d === 45 || xe(d)) && r++ < 63) {
      const h = d === 45 ? p : f;
      return e.consume(d), h;
    }
    return n(d);
  }
}
const Bn = {
  partial: !0,
  tokenize: Rk
};
function Rk(e, t, n) {
  return r;
  function r(o) {
    return X(o) ? ne(e, i, "linePrefix")(o) : i(o);
  }
  function i(o) {
    return o === null || q(o) ? t(o) : n(o);
  }
}
const fc = {
  continuation: {
    tokenize: Dk
  },
  exit: Nk,
  name: "blockQuote",
  tokenize: $k
};
function $k(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    if (a === 62) {
      const s = r.containerState;
      return s.open || (e.enter("blockQuote", {
        _container: !0
      }), s.open = !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(a), e.exit("blockQuoteMarker"), o;
    }
    return n(a);
  }
  function o(a) {
    return X(a) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(a), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(a));
  }
}
function Dk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return X(a) ? ne(e, o, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(a) : o(a);
  }
  function o(a) {
    return e.attempt(fc, t, n)(a);
  }
}
function Nk(e) {
  e.exit("blockQuote");
}
const dc = {
  name: "characterEscape",
  tokenize: Lk
};
function Lk(e, t, n) {
  return r;
  function r(o) {
    return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(o), e.exit("escapeMarker"), i;
  }
  function i(o) {
    return uc(o) ? (e.enter("characterEscapeValue"), e.consume(o), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(o);
  }
}
const pc = {
  name: "characterReference",
  tokenize: Fk
};
function Fk(e, t, n) {
  const r = this;
  let i = 0, o, a;
  return s;
  function s(f) {
    return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(f), e.exit("characterReferenceMarker"), u;
  }
  function u(f) {
    return f === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(f), e.exit("characterReferenceMarkerNumeric"), c) : (e.enter("characterReferenceValue"), o = 31, a = xe, l(f));
  }
  function c(f) {
    return f === 88 || f === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(f), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), o = 6, a = Sk, l) : (e.enter("characterReferenceValue"), o = 7, a = ji, l(f));
  }
  function l(f) {
    if (f === 59 && i) {
      const p = e.exit("characterReferenceValue");
      return a === xe && !_o(r.sliceSerialize(p)) ? n(f) : (e.enter("characterReferenceMarker"), e.consume(f), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
    }
    return a(f) && i++ < o ? (e.consume(f), l) : n(f);
  }
}
const Bi = {
  partial: !0,
  tokenize: jk
};
function jk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return a === null ? n(a) : (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), o);
  }
  function o(a) {
    return r.parser.lazy[r.now().line] ? n(a) : t(a);
  }
}
const ss = {
  concrete: !0,
  name: "codeFenced",
  tokenize: Zk
};
function Zk(e, t, n) {
  const r = this, i = {
    partial: !0,
    tokenize: _
  };
  let o = 0, a = 0, s;
  return u;
  function u(y) {
    return c(y);
  }
  function c(y) {
    const C = r.events[r.events.length - 1];
    return o = C && C[1].type === "linePrefix" ? C[2].sliceSerialize(C[1], !0).length : 0, s = y, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), l(y);
  }
  function l(y) {
    return y === s ? (a++, e.consume(y), l) : a < 3 ? n(y) : (e.exit("codeFencedFenceSequence"), X(y) ? ne(e, f, "whitespace")(y) : f(y));
  }
  function f(y) {
    return y === null || q(y) ? (e.exit("codeFencedFence"), r.interrupt ? t(y) : e.check(Bi, m, S)(y)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
      contentType: "string"
    }), p(y));
  }
  function p(y) {
    return y === null || q(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), f(y)) : X(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), ne(e, d, "whitespace")(y)) : y === 96 && y === s ? n(y) : (e.consume(y), p);
  }
  function d(y) {
    return y === null || q(y) ? f(y) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
      contentType: "string"
    }), h(y));
  }
  function h(y) {
    return y === null || q(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), f(y)) : y === 96 && y === s ? n(y) : (e.consume(y), h);
  }
  function m(y) {
    return e.attempt(i, S, v)(y);
  }
  function v(y) {
    return e.enter("lineEnding"), e.consume(y), e.exit("lineEnding"), g;
  }
  function g(y) {
    return o > 0 && X(y) ? ne(e, w, "linePrefix", o + 1)(y) : w(y);
  }
  function w(y) {
    return y === null || q(y) ? e.check(Bi, m, S)(y) : (e.enter("codeFlowValue"), I(y));
  }
  function I(y) {
    return y === null || q(y) ? (e.exit("codeFlowValue"), w(y)) : (e.consume(y), I);
  }
  function S(y) {
    return e.exit("codeFenced"), t(y);
  }
  function _(y, C, R) {
    let F = 0;
    return E;
    function E(B) {
      return y.enter("lineEnding"), y.consume(B), y.exit("lineEnding"), M;
    }
    function M(B) {
      return y.enter("codeFencedFence"), X(B) ? ne(y, L, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(B) : L(B);
    }
    function L(B) {
      return B === s ? (y.enter("codeFencedFenceSequence"), x(B)) : R(B);
    }
    function x(B) {
      return B === s ? (F++, y.consume(B), x) : F >= a ? (y.exit("codeFencedFenceSequence"), X(B) ? ne(y, Z, "whitespace")(B) : Z(B)) : R(B);
    }
    function Z(B) {
      return B === null || q(B) ? (y.exit("codeFencedFence"), C(B)) : R(B);
    }
  }
}
const ni = {
  name: "codeIndented",
  tokenize: Uk
}, Bk = {
  partial: !0,
  tokenize: Vk
};
function Uk(e, t, n) {
  return r;
  function r(s) {
    return e.enter("codeIndented"), cc(e, i, n, "linePrefix", 4, 4)(s);
  }
  function i(s) {
    return s === null ? a(s) : q(s) ? e.attempt(Bk, i, a)(s) : (e.enter("codeFlowValue"), o(s));
  }
  function o(s) {
    return s === null || q(s) ? (e.exit("codeFlowValue"), i(s)) : (e.consume(s), o);
  }
  function a(s) {
    return e.exit("codeIndented"), t(s);
  }
}
function Vk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return r.parser.lazy[r.now().line] ? n(a) : q(a) ? (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), i) : cc(e, t, o, "linePrefix", 4, 4)(a);
  }
  function o(a) {
    return q(a) ? i(a) : n(a);
  }
}
const qk = {
  name: "codeText",
  previous: Wk,
  resolve: Jk,
  tokenize: Hk
};
function Jk(e) {
  let t = e.length - 4, n = 3, r, i;
  if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
    for (r = n; ++r < t; )
      if (e[r][1].type === "codeTextData") {
        e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
        break;
      }
  }
  for (r = n - 1, t++; ++r <= t; )
    i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
  return e;
}
function Wk(e) {
  return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function Hk(e, t, n) {
  let r = 0, i, o;
  return a;
  function a(f) {
    return e.enter("codeText"), e.enter("codeTextSequence"), s(f);
  }
  function s(f) {
    return f === 96 ? (e.consume(f), r++, s) : (e.exit("codeTextSequence"), u(f));
  }
  function u(f) {
    return f === null ? n(f) : f === 32 ? (e.enter("space"), e.consume(f), e.exit("space"), u) : f === 96 ? (o = e.enter("codeTextSequence"), i = 0, l(f)) : q(f) ? (e.enter("lineEnding"), e.consume(f), e.exit("lineEnding"), u) : (e.enter("codeTextData"), c(f));
  }
  function c(f) {
    return f === null || f === 32 || f === 96 || q(f) ? (e.exit("codeTextData"), u(f)) : (e.consume(f), c);
  }
  function l(f) {
    return f === 96 ? (e.consume(f), i++, l) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(f)) : (o.type = "codeTextData", c(f));
  }
}
class Kk {
  /**
   * @param {ReadonlyArray<T> | null | undefined} [initial]
   *   Initial items (optional).
   * @returns
   *   Splice buffer.
   */
  constructor(t) {
    this.left = t ? [...t] : [], this.right = [];
  }
  /**
   * Array access;
   * does not move the cursor.
   *
   * @param {number} index
   *   Index.
   * @return {T}
   *   Item.
   */
  get(t) {
    if (t < 0 || t >= this.left.length + this.right.length)
      throw new RangeError("Cannot access index `" + t + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    return t < this.left.length ? this.left[t] : this.right[this.right.length - t + this.left.length - 1];
  }
  /**
   * The length of the splice buffer, one greater than the largest index in the
   * array.
   */
  get length() {
    return this.left.length + this.right.length;
  }
  /**
   * Remove and return `list[0]`;
   * moves the cursor to `0`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  shift() {
    return this.setCursor(0), this.right.pop();
  }
  /**
   * Slice the buffer to get an array;
   * does not move the cursor.
   *
   * @param {number} start
   *   Start.
   * @param {number | null | undefined} [end]
   *   End (optional).
   * @returns {Array<T>}
   *   Array of items.
   */
  slice(t, n) {
    const r = n ?? Number.POSITIVE_INFINITY;
    return r < this.left.length ? this.left.slice(t, r) : t > this.left.length ? this.right.slice(this.right.length - r + this.left.length, this.right.length - t + this.left.length).reverse() : this.left.slice(t).concat(this.right.slice(this.right.length - r + this.left.length).reverse());
  }
  /**
   * Mimics the behavior of Array.prototype.splice() except for the change of
   * interface necessary to avoid segfaults when patching in very large arrays.
   *
   * This operation moves cursor is moved to `start` and results in the cursor
   * placed after any inserted items.
   *
   * @param {number} start
   *   Start;
   *   zero-based index at which to start changing the array;
   *   negative numbers count backwards from the end of the array and values
   *   that are out-of bounds are clamped to the appropriate end of the array.
   * @param {number | null | undefined} [deleteCount=0]
   *   Delete count (default: `0`);
   *   maximum number of elements to delete, starting from start.
   * @param {Array<T> | null | undefined} [items=[]]
   *   Items to include in place of the deleted items (default: `[]`).
   * @return {Array<T>}
   *   Any removed items.
   */
  splice(t, n, r) {
    const i = n || 0;
    this.setCursor(Math.trunc(t));
    const o = this.right.splice(this.right.length - i, Number.POSITIVE_INFINITY);
    return r && gn(this.left, r), o.reverse();
  }
  /**
   * Remove and return the highest-numbered item in the array, so
   * `list[list.length - 1]`;
   * Moves the cursor to `length`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  pop() {
    return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
  }
  /**
   * Inserts a single item to the high-numbered side of the array;
   * moves the cursor to `length`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  push(t) {
    this.setCursor(Number.POSITIVE_INFINITY), this.left.push(t);
  }
  /**
   * Inserts many items to the high-numbered side of the array.
   * Moves the cursor to `length`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  pushMany(t) {
    this.setCursor(Number.POSITIVE_INFINITY), gn(this.left, t);
  }
  /**
   * Inserts a single item to the low-numbered side of the array;
   * Moves the cursor to `0`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  unshift(t) {
    this.setCursor(0), this.right.push(t);
  }
  /**
   * Inserts many items to the low-numbered side of the array;
   * moves the cursor to `0`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  unshiftMany(t) {
    this.setCursor(0), gn(this.right, t.reverse());
  }
  /**
   * Move the cursor to a specific position in the array. Requires
   * time proportional to the distance moved.
   *
   * If `n < 0`, the cursor will end up at the beginning.
   * If `n > length`, the cursor will end up at the end.
   *
   * @param {number} n
   *   Position.
   * @return {undefined}
   *   Nothing.
   */
  setCursor(t) {
    if (!(t === this.left.length || t > this.left.length && this.right.length === 0 || t < 0 && this.left.length === 0))
      if (t < this.left.length) {
        const n = this.left.splice(t, Number.POSITIVE_INFINITY);
        gn(this.right, n.reverse());
      } else {
        const n = this.right.splice(this.left.length + this.right.length - t, Number.POSITIVE_INFINITY);
        gn(this.left, n.reverse());
      }
  }
}
function gn(e, t) {
  let n = 0;
  if (t.length < 1e4)
    e.push(...t);
  else
    for (; n < t.length; )
      e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
function hc(e) {
  const t = {};
  let n = -1, r, i, o, a, s, u, c;
  const l = new Kk(e);
  for (; ++n < l.length; ) {
    for (; n in t; )
      n = t[n];
    if (r = l.get(n), n && r[1].type === "chunkFlow" && l.get(n - 1)[1].type === "listItemPrefix" && (u = r[1]._tokenizer.events, o = 0, o < u.length && u[o][1].type === "lineEndingBlank" && (o += 2), o < u.length && u[o][1].type === "content"))
      for (; ++o < u.length && u[o][1].type !== "content"; )
        u[o][1].type === "chunkText" && (u[o][1]._isInFirstContentOfListItem = !0, o++);
    if (r[0] === "enter")
      r[1].contentType && (Object.assign(t, Yk(l, n)), n = t[n], c = !0);
    else if (r[1]._container) {
      for (o = n, i = void 0; o--; )
        if (a = l.get(o), a[1].type === "lineEnding" || a[1].type === "lineEndingBlank")
          a[0] === "enter" && (i && (l.get(i)[1].type = "lineEndingBlank"), a[1].type = "lineEnding", i = o);
        else if (!(a[1].type === "linePrefix" || a[1].type === "listItemIndent")) break;
      i && (r[1].end = {
        ...l.get(i)[1].start
      }, s = l.slice(i, n), s.unshift(r), l.splice(i, n - i + 1, s));
    }
  }
  return Qe(e, 0, Number.POSITIVE_INFINITY, l.slice(0)), !c;
}
function Yk(e, t) {
  const n = e.get(t)[1], r = e.get(t)[2];
  let i = t - 1;
  const o = [];
  let a = n._tokenizer;
  a || (a = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (a._contentTypeTextTrailing = !0));
  const s = a.events, u = [], c = {};
  let l, f, p = -1, d = n, h = 0, m = 0;
  const v = [m];
  for (; d; ) {
    for (; e.get(++i)[1] !== d; )
      ;
    o.push(i), d._tokenizer || (l = r.sliceStream(d), d.next || l.push(null), f && a.defineSkip(d.start), d._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = !0), a.write(l), d._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = void 0)), f = d, d = d.next;
  }
  for (d = n; ++p < s.length; )
    // Find a void token that includes a break.
    s[p][0] === "exit" && s[p - 1][0] === "enter" && s[p][1].type === s[p - 1][1].type && s[p][1].start.line !== s[p][1].end.line && (m = p + 1, v.push(m), d._tokenizer = void 0, d.previous = void 0, d = d.next);
  for (a.events = [], d ? (d._tokenizer = void 0, d.previous = void 0) : v.pop(), p = v.length; p--; ) {
    const g = s.slice(v[p], v[p + 1]), w = o.pop();
    u.push([w, w + g.length - 1]), e.splice(w, 2, g);
  }
  for (u.reverse(), p = -1; ++p < u.length; )
    c[h + u[p][0]] = h + u[p][1], h += u[p][1] - u[p][0] - 1;
  return c;
}
const Gk = {
  resolve: Qk,
  tokenize: ew
}, Xk = {
  partial: !0,
  tokenize: tw
};
function Qk(e) {
  return hc(e), e;
}
function ew(e, t) {
  let n;
  return r;
  function r(s) {
    return e.enter("content"), n = e.enter("chunkContent", {
      contentType: "content"
    }), i(s);
  }
  function i(s) {
    return s === null ? o(s) : q(s) ? e.check(Xk, a, o)(s) : (e.consume(s), i);
  }
  function o(s) {
    return e.exit("chunkContent"), e.exit("content"), t(s);
  }
  function a(s) {
    return e.consume(s), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
      contentType: "content",
      previous: n
    }), n = n.next, i;
  }
}
function tw(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), ne(e, o, "linePrefix");
  }
  function o(a) {
    if (a === null || q(a))
      return n(a);
    const s = r.events[r.events.length - 1];
    return !r.parser.constructs.disable.null.includes("codeIndented") && s && s[1].type === "linePrefix" && s[2].sliceSerialize(s[1], !0).length >= 4 ? t(a) : e.interrupt(r.parser.constructs.flow, n, t)(a);
  }
}
function mc(e, t, n, r, i, o, a, s, u) {
  const c = u || Number.POSITIVE_INFINITY;
  let l = 0;
  return f;
  function f(g) {
    return g === 60 ? (e.enter(r), e.enter(i), e.enter(o), e.consume(g), e.exit(o), p) : g === null || g === 32 || g === 41 || vr(g) ? n(g) : (e.enter(r), e.enter(a), e.enter(s), e.enter("chunkString", {
      contentType: "string"
    }), m(g));
  }
  function p(g) {
    return g === 62 ? (e.enter(o), e.consume(g), e.exit(o), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", {
      contentType: "string"
    }), d(g));
  }
  function d(g) {
    return g === 62 ? (e.exit("chunkString"), e.exit(s), p(g)) : g === null || g === 60 || q(g) ? n(g) : (e.consume(g), g === 92 ? h : d);
  }
  function h(g) {
    return g === 60 || g === 62 || g === 92 ? (e.consume(g), d) : d(g);
  }
  function m(g) {
    return !l && (g === null || g === 41 || ae(g)) ? (e.exit("chunkString"), e.exit(s), e.exit(a), e.exit(r), t(g)) : l < c && g === 40 ? (e.consume(g), l++, m) : g === 41 ? (e.consume(g), l--, m) : g === null || g === 32 || g === 40 || vr(g) ? n(g) : (e.consume(g), g === 92 ? v : m);
  }
  function v(g) {
    return g === 40 || g === 41 || g === 92 ? (e.consume(g), m) : m(g);
  }
}
function gc(e, t, n, r, i, o) {
  const a = this;
  let s = 0, u;
  return c;
  function c(d) {
    return e.enter(r), e.enter(i), e.consume(d), e.exit(i), e.enter(o), l;
  }
  function l(d) {
    return s > 999 || d === null || d === 91 || d === 93 && !u || // To do: remove in the future once we’ve switched from
    // `micromark-extension-footnote` to `micromark-extension-gfm-footnote`,
    // which doesn’t need this.
    // Hidden footnotes hook.
    /* c8 ignore next 3 */
    d === 94 && !s && "_hiddenFootnoteSupport" in a.parser.constructs ? n(d) : d === 93 ? (e.exit(o), e.enter(i), e.consume(d), e.exit(i), e.exit(r), t) : q(d) ? (e.enter("lineEnding"), e.consume(d), e.exit("lineEnding"), l) : (e.enter("chunkString", {
      contentType: "string"
    }), f(d));
  }
  function f(d) {
    return d === null || d === 91 || d === 93 || q(d) || s++ > 999 ? (e.exit("chunkString"), l(d)) : (e.consume(d), u || (u = !X(d)), d === 92 ? p : f);
  }
  function p(d) {
    return d === 91 || d === 92 || d === 93 ? (e.consume(d), s++, f) : f(d);
  }
}
function yc(e, t, n, r, i, o) {
  let a;
  return s;
  function s(p) {
    return p === 34 || p === 39 || p === 40 ? (e.enter(r), e.enter(i), e.consume(p), e.exit(i), a = p === 40 ? 41 : p, u) : n(p);
  }
  function u(p) {
    return p === a ? (e.enter(i), e.consume(p), e.exit(i), e.exit(r), t) : (e.enter(o), c(p));
  }
  function c(p) {
    return p === a ? (e.exit(o), u(a)) : p === null ? n(p) : q(p) ? (e.enter("lineEnding"), e.consume(p), e.exit("lineEnding"), ne(e, c, "linePrefix")) : (e.enter("chunkString", {
      contentType: "string"
    }), l(p));
  }
  function l(p) {
    return p === a || p === null || q(p) ? (e.exit("chunkString"), c(p)) : (e.consume(p), p === 92 ? f : l);
  }
  function f(p) {
    return p === a || p === 92 ? (e.consume(p), l) : l(p);
  }
}
function zn(e, t) {
  let n;
  return r;
  function r(i) {
    return q(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : X(i) ? ne(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
  }
}
const nw = {
  name: "definition",
  tokenize: iw
}, rw = {
  partial: !0,
  tokenize: ow
};
function iw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(d) {
    return e.enter("definition"), a(d);
  }
  function a(d) {
    return gc.call(
      r,
      e,
      s,
      // Note: we don’t need to reset the way `markdown-rs` does.
      n,
      "definitionLabel",
      "definitionLabelMarker",
      "definitionLabelString"
    )(d);
  }
  function s(d) {
    return i = et(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), d === 58 ? (e.enter("definitionMarker"), e.consume(d), e.exit("definitionMarker"), u) : n(d);
  }
  function u(d) {
    return ae(d) ? zn(e, c)(d) : c(d);
  }
  function c(d) {
    return mc(
      e,
      l,
      // Note: we don’t need to reset the way `markdown-rs` does.
      n,
      "definitionDestination",
      "definitionDestinationLiteral",
      "definitionDestinationLiteralMarker",
      "definitionDestinationRaw",
      "definitionDestinationString"
    )(d);
  }
  function l(d) {
    return e.attempt(rw, f, f)(d);
  }
  function f(d) {
    return X(d) ? ne(e, p, "whitespace")(d) : p(d);
  }
  function p(d) {
    return d === null || q(d) ? (e.exit("definition"), r.parser.defined.push(i), t(d)) : n(d);
  }
}
function ow(e, t, n) {
  return r;
  function r(s) {
    return ae(s) ? zn(e, i)(s) : n(s);
  }
  function i(s) {
    return yc(e, o, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(s);
  }
  function o(s) {
    return X(s) ? ne(e, a, "whitespace")(s) : a(s);
  }
  function a(s) {
    return s === null || q(s) ? t(s) : n(s);
  }
}
const aw = {
  name: "hardBreakEscape",
  tokenize: sw
};
function sw(e, t, n) {
  return r;
  function r(o) {
    return e.enter("hardBreakEscape"), e.consume(o), i;
  }
  function i(o) {
    return q(o) ? (e.exit("hardBreakEscape"), t(o)) : n(o);
  }
}
const lw = {
  name: "headingAtx",
  resolve: uw,
  tokenize: cw
};
function uw(e, t) {
  let n = e.length - 2, r = 3;
  if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
    const i = {
      type: "atxHeadingText",
      start: e[r][1].start,
      end: e[n][1].end
    }, o = {
      type: "chunkText",
      start: e[r][1].start,
      end: e[n][1].end,
      contentType: "text"
    };
    Qe(e, r, n - r + 1, [["enter", i, t], ["enter", o, t], ["exit", o, t], ["exit", i, t]]);
  }
  return e;
}
function cw(e, t, n) {
  let r = 0;
  return i;
  function i(l) {
    return e.enter("atxHeading"), o(l);
  }
  function o(l) {
    return e.enter("atxHeadingSequence"), a(l);
  }
  function a(l) {
    return l === 35 && r++ < 6 ? (e.consume(l), a) : l === null || ae(l) ? (e.exit("atxHeadingSequence"), s(l)) : n(l);
  }
  function s(l) {
    return l === 35 ? (e.enter("atxHeadingSequence"), u(l)) : l === null || q(l) ? (e.exit("atxHeading"), t(l)) : X(l) ? ne(e, s, "whitespace")(l) : (e.enter("atxHeadingText"), c(l));
  }
  function u(l) {
    return l === 35 ? (e.consume(l), u) : (e.exit("atxHeadingSequence"), s(l));
  }
  function c(l) {
    return l === null || l === 35 || ae(l) ? (e.exit("atxHeadingText"), s(l)) : (e.consume(l), c);
  }
}
const bc = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
], Ui = ["pre", "script", "style", "textarea"], fw = {
  concrete: !0,
  name: "htmlFlow",
  resolveTo: pw,
  tokenize: hw
}, dw = {
  partial: !0,
  tokenize: mw
};
function pw(e) {
  let t = e.length;
  for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"); )
    ;
  return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function hw(e, t, n) {
  const r = this;
  let i, o, a, s, u;
  return c;
  function c(k) {
    return l(k);
  }
  function l(k) {
    return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(k), f;
  }
  function f(k) {
    return k === 33 ? (e.consume(k), p) : k === 47 ? (e.consume(k), o = !0, m) : k === 63 ? (e.consume(k), i = 3, r.interrupt ? t : b) : we(k) ? (e.consume(k), a = String.fromCharCode(k), v) : n(k);
  }
  function p(k) {
    return k === 45 ? (e.consume(k), i = 2, d) : k === 91 ? (e.consume(k), i = 5, s = 0, h) : we(k) ? (e.consume(k), i = 4, r.interrupt ? t : b) : n(k);
  }
  function d(k) {
    return k === 45 ? (e.consume(k), r.interrupt ? t : b) : n(k);
  }
  function h(k) {
    const Te = "CDATA[";
    return k === Te.charCodeAt(s++) ? (e.consume(k), s === Te.length ? r.interrupt ? t : L : h) : n(k);
  }
  function m(k) {
    return we(k) ? (e.consume(k), a = String.fromCharCode(k), v) : n(k);
  }
  function v(k) {
    if (k === null || k === 47 || k === 62 || ae(k)) {
      const Te = k === 47, nt = a.toLowerCase();
      return !Te && !o && Ui.includes(nt) ? (i = 1, r.interrupt ? t(k) : L(k)) : bc.includes(a.toLowerCase()) ? (i = 6, Te ? (e.consume(k), g) : r.interrupt ? t(k) : L(k)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(k) : o ? w(k) : I(k));
    }
    return k === 45 || xe(k) ? (e.consume(k), a += String.fromCharCode(k), v) : n(k);
  }
  function g(k) {
    return k === 62 ? (e.consume(k), r.interrupt ? t : L) : n(k);
  }
  function w(k) {
    return X(k) ? (e.consume(k), w) : E(k);
  }
  function I(k) {
    return k === 47 ? (e.consume(k), E) : k === 58 || k === 95 || we(k) ? (e.consume(k), S) : X(k) ? (e.consume(k), I) : E(k);
  }
  function S(k) {
    return k === 45 || k === 46 || k === 58 || k === 95 || xe(k) ? (e.consume(k), S) : _(k);
  }
  function _(k) {
    return k === 61 ? (e.consume(k), y) : X(k) ? (e.consume(k), _) : I(k);
  }
  function y(k) {
    return k === null || k === 60 || k === 61 || k === 62 || k === 96 ? n(k) : k === 34 || k === 39 ? (e.consume(k), u = k, C) : X(k) ? (e.consume(k), y) : R(k);
  }
  function C(k) {
    return k === u ? (e.consume(k), u = null, F) : k === null || q(k) ? n(k) : (e.consume(k), C);
  }
  function R(k) {
    return k === null || k === 34 || k === 39 || k === 47 || k === 60 || k === 61 || k === 62 || k === 96 || ae(k) ? _(k) : (e.consume(k), R);
  }
  function F(k) {
    return k === 47 || k === 62 || X(k) ? I(k) : n(k);
  }
  function E(k) {
    return k === 62 ? (e.consume(k), M) : n(k);
  }
  function M(k) {
    return k === null || q(k) ? L(k) : X(k) ? (e.consume(k), M) : n(k);
  }
  function L(k) {
    return k === 45 && i === 2 ? (e.consume(k), Y) : k === 60 && i === 1 ? (e.consume(k), N) : k === 62 && i === 4 ? (e.consume(k), ke) : k === 63 && i === 3 ? (e.consume(k), b) : k === 93 && i === 5 ? (e.consume(k), le) : q(k) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(dw, Ze, x)(k)) : k === null || q(k) ? (e.exit("htmlFlowData"), x(k)) : (e.consume(k), L);
  }
  function x(k) {
    return e.check(Bi, Z, Ze)(k);
  }
  function Z(k) {
    return e.enter("lineEnding"), e.consume(k), e.exit("lineEnding"), B;
  }
  function B(k) {
    return k === null || q(k) ? x(k) : (e.enter("htmlFlowData"), L(k));
  }
  function Y(k) {
    return k === 45 ? (e.consume(k), b) : L(k);
  }
  function N(k) {
    return k === 47 ? (e.consume(k), a = "", H) : L(k);
  }
  function H(k) {
    if (k === 62) {
      const Te = a.toLowerCase();
      return Ui.includes(Te) ? (e.consume(k), ke) : L(k);
    }
    return we(k) && a.length < 8 ? (e.consume(k), a += String.fromCharCode(k), H) : L(k);
  }
  function le(k) {
    return k === 93 ? (e.consume(k), b) : L(k);
  }
  function b(k) {
    return k === 62 ? (e.consume(k), ke) : k === 45 && i === 2 ? (e.consume(k), b) : L(k);
  }
  function ke(k) {
    return k === null || q(k) ? (e.exit("htmlFlowData"), Ze(k)) : (e.consume(k), ke);
  }
  function Ze(k) {
    return e.exit("htmlFlow"), t(k);
  }
}
function mw(e, t, n) {
  return r;
  function r(i) {
    return e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), e.attempt(Bn, t, n);
  }
}
const gw = {
  name: "htmlText",
  tokenize: yw
};
function yw(e, t, n) {
  const r = this;
  let i, o, a;
  return s;
  function s(b) {
    return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(b), u;
  }
  function u(b) {
    return b === 33 ? (e.consume(b), c) : b === 47 ? (e.consume(b), _) : b === 63 ? (e.consume(b), I) : we(b) ? (e.consume(b), R) : n(b);
  }
  function c(b) {
    return b === 45 ? (e.consume(b), l) : b === 91 ? (e.consume(b), o = 0, h) : we(b) ? (e.consume(b), w) : n(b);
  }
  function l(b) {
    return b === 45 ? (e.consume(b), d) : n(b);
  }
  function f(b) {
    return b === null ? n(b) : b === 45 ? (e.consume(b), p) : q(b) ? (a = f, N(b)) : (e.consume(b), f);
  }
  function p(b) {
    return b === 45 ? (e.consume(b), d) : f(b);
  }
  function d(b) {
    return b === 62 ? Y(b) : b === 45 ? p(b) : f(b);
  }
  function h(b) {
    const ke = "CDATA[";
    return b === ke.charCodeAt(o++) ? (e.consume(b), o === ke.length ? m : h) : n(b);
  }
  function m(b) {
    return b === null ? n(b) : b === 93 ? (e.consume(b), v) : q(b) ? (a = m, N(b)) : (e.consume(b), m);
  }
  function v(b) {
    return b === 93 ? (e.consume(b), g) : m(b);
  }
  function g(b) {
    return b === 62 ? Y(b) : b === 93 ? (e.consume(b), g) : m(b);
  }
  function w(b) {
    return b === null || b === 62 ? Y(b) : q(b) ? (a = w, N(b)) : (e.consume(b), w);
  }
  function I(b) {
    return b === null ? n(b) : b === 63 ? (e.consume(b), S) : q(b) ? (a = I, N(b)) : (e.consume(b), I);
  }
  function S(b) {
    return b === 62 ? Y(b) : I(b);
  }
  function _(b) {
    return we(b) ? (e.consume(b), y) : n(b);
  }
  function y(b) {
    return b === 45 || xe(b) ? (e.consume(b), y) : C(b);
  }
  function C(b) {
    return q(b) ? (a = C, N(b)) : X(b) ? (e.consume(b), C) : Y(b);
  }
  function R(b) {
    return b === 45 || xe(b) ? (e.consume(b), R) : b === 47 || b === 62 || ae(b) ? F(b) : n(b);
  }
  function F(b) {
    return b === 47 ? (e.consume(b), Y) : b === 58 || b === 95 || we(b) ? (e.consume(b), E) : q(b) ? (a = F, N(b)) : X(b) ? (e.consume(b), F) : Y(b);
  }
  function E(b) {
    return b === 45 || b === 46 || b === 58 || b === 95 || xe(b) ? (e.consume(b), E) : M(b);
  }
  function M(b) {
    return b === 61 ? (e.consume(b), L) : q(b) ? (a = M, N(b)) : X(b) ? (e.consume(b), M) : F(b);
  }
  function L(b) {
    return b === null || b === 60 || b === 61 || b === 62 || b === 96 ? n(b) : b === 34 || b === 39 ? (e.consume(b), i = b, x) : q(b) ? (a = L, N(b)) : X(b) ? (e.consume(b), L) : (e.consume(b), Z);
  }
  function x(b) {
    return b === i ? (e.consume(b), i = void 0, B) : b === null ? n(b) : q(b) ? (a = x, N(b)) : (e.consume(b), x);
  }
  function Z(b) {
    return b === null || b === 34 || b === 39 || b === 60 || b === 61 || b === 96 ? n(b) : b === 47 || b === 62 || ae(b) ? F(b) : (e.consume(b), Z);
  }
  function B(b) {
    return b === 47 || b === 62 || ae(b) ? F(b) : n(b);
  }
  function Y(b) {
    return b === 62 ? (e.consume(b), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(b);
  }
  function N(b) {
    return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(b), e.exit("lineEnding"), H;
  }
  function H(b) {
    return X(b) ? ne(e, le, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(b) : le(b);
  }
  function le(b) {
    return e.enter("htmlTextData"), a(b);
  }
}
const So = {
  name: "labelEnd",
  resolveAll: ww,
  resolveTo: xw,
  tokenize: _w
}, bw = {
  tokenize: Sw
}, vw = {
  tokenize: Iw
}, kw = {
  tokenize: Ew
};
function ww(e) {
  let t = -1;
  const n = [];
  for (; ++t < e.length; ) {
    const r = e[t][1];
    if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
      const i = r.type === "labelImage" ? 4 : 2;
      r.type = "data", t += i;
    }
  }
  return e.length !== n.length && Qe(e, 0, e.length, n), e;
}
function xw(e, t) {
  let n = e.length, r = 0, i, o, a;
  for (; n--; ) {
    const l = e[n][1];
    if (i) {
      if (l.type === "link" || l.type === "labelLink" && l._inactive)
        break;
      e[n][0] === "enter" && l.type === "labelLink" && (l._inactive = !0);
    } else if (o) {
      if (e[n][0] === "enter" && (l.type === "labelImage" || l.type === "labelLink") && !l._balanced && (i = n, l.type !== "labelLink")) {
        r = 2;
        break;
      }
    } else l.type === "labelEnd" && (o = n);
  }
  const s = {
    type: e[i][1].type === "labelLink" ? "link" : "image",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  }, u = {
    type: "label",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[o][1].end
    }
  }, c = {
    type: "labelText",
    start: {
      ...e[i + r + 2][1].end
    },
    end: {
      ...e[o - 2][1].start
    }
  };
  return a = [["enter", s, t], ["enter", u, t]], a = Je(a, e.slice(i + 1, i + r + 3)), a = Je(a, [["enter", c, t]]), a = Je(a, Pr(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, o - 3), t)), a = Je(a, [["exit", c, t], e[o - 2], e[o - 1], ["exit", u, t]]), a = Je(a, e.slice(o + 1)), a = Je(a, [["exit", s, t]]), Qe(e, i, e.length, a), e;
}
function _w(e, t, n) {
  const r = this, i = r._labelStarts;
  let o, a;
  if (i) {
    for (; i.length > 0 && i[i.length - 1]._balanced; )
      i.pop();
    o = i[i.length - 1];
  }
  return s;
  function s(p) {
    return o ? o._inactive ? f(p) : (a = r.parser.defined.includes(et(r.sliceSerialize({
      start: o.end,
      end: r.now()
    }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(p), e.exit("labelMarker"), e.exit("labelEnd"), u) : n(p);
  }
  function u(p) {
    return p === 40 ? e.attempt(bw, l, a ? l : f)(p) : p === 91 ? e.attempt(vw, l, a ? c : f)(p) : a ? l(p) : f(p);
  }
  function c(p) {
    return e.attempt(kw, l, f)(p);
  }
  function l(p) {
    return i.pop(), t(p);
  }
  function f(p) {
    return o._balanced = !0, n(p);
  }
}
function Sw(e, t, n) {
  return r;
  function r(f) {
    return e.enter("resource"), e.enter("resourceMarker"), e.consume(f), e.exit("resourceMarker"), i;
  }
  function i(f) {
    return ae(f) ? zn(e, o)(f) : o(f);
  }
  function o(f) {
    return f === 41 ? l(f) : mc(e, a, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(f);
  }
  function a(f) {
    return ae(f) ? zn(e, u)(f) : l(f);
  }
  function s(f) {
    return n(f);
  }
  function u(f) {
    return f === 34 || f === 39 || f === 40 ? yc(e, c, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(f) : l(f);
  }
  function c(f) {
    return ae(f) ? zn(e, l)(f) : l(f);
  }
  function l(f) {
    return f === 41 ? (e.enter("resourceMarker"), e.consume(f), e.exit("resourceMarker"), e.exit("resource"), t) : n(f);
  }
}
function Iw(e, t, n) {
  const r = this;
  return i;
  function i(s) {
    return gc.call(r, e, o, a, "reference", "referenceMarker", "referenceString")(s);
  }
  function o(s) {
    return r.parser.defined.includes(et(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(s) : n(s);
  }
  function a(s) {
    return n(s);
  }
}
function Ew(e, t, n) {
  return r;
  function r(o) {
    return e.enter("reference"), e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), i;
  }
  function i(o) {
    return o === 93 ? (e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), e.exit("reference"), t) : n(o);
  }
}
const Cw = {
  name: "labelStartImage",
  resolveAll: So.resolveAll,
  tokenize: Aw
};
function Aw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(u) {
    return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(u), e.exit("labelImageMarker"), a;
  }
  function a(u) {
    return u === 91 ? (e.enter("labelMarker"), e.consume(u), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(u);
  }
  function s(u) {
    return u === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(u) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(u));
  }
}
const zw = {
  name: "labelStartLink",
  resolveAll: So.resolveAll,
  tokenize: Tw
};
function Tw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(s) {
    return e.enter("labelLink"), e.enter("labelMarker"), e.consume(s), e.exit("labelMarker"), i = e.exit("labelLink"), a;
  }
  function a(s) {
    return s === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(s) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(s));
  }
}
const ri = {
  name: "lineEnding",
  tokenize: Ow
};
function Ow(e, t) {
  return n;
  function n(r) {
    return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), ne(e, t, "linePrefix");
  }
}
const lr = {
  name: "thematicBreak",
  tokenize: Pw
};
function Pw(e, t, n) {
  let r = 0, i;
  return o;
  function o(c) {
    return e.enter("thematicBreak"), a(c);
  }
  function a(c) {
    return i = c, s(c);
  }
  function s(c) {
    return c === i ? (e.enter("thematicBreakSequence"), u(c)) : r >= 3 && (c === null || q(c)) ? (e.exit("thematicBreak"), t(c)) : n(c);
  }
  function u(c) {
    return c === i ? (e.consume(c), r++, u) : (e.exit("thematicBreakSequence"), X(c) ? ne(e, s, "whitespace")(c) : s(c));
  }
}
const Me = {
  continuation: {
    tokenize: Dw
  },
  exit: Lw,
  name: "list",
  tokenize: $w
}, Mw = {
  partial: !0,
  tokenize: Fw
}, Rw = {
  partial: !0,
  tokenize: Nw
};
function $w(e, t, n) {
  const r = this, i = r.events[r.events.length - 1];
  let o = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, a = 0;
  return s;
  function s(d) {
    const h = r.containerState.type || (d === 42 || d === 43 || d === 45 ? "listUnordered" : "listOrdered");
    if (h === "listUnordered" ? !r.containerState.marker || d === r.containerState.marker : ji(d)) {
      if (r.containerState.type || (r.containerState.type = h, e.enter(h, {
        _container: !0
      })), h === "listUnordered")
        return e.enter("listItemPrefix"), d === 42 || d === 45 ? e.check(lr, n, c)(d) : c(d);
      if (!r.interrupt || d === 49)
        return e.enter("listItemPrefix"), e.enter("listItemValue"), u(d);
    }
    return n(d);
  }
  function u(d) {
    return ji(d) && ++a < 10 ? (e.consume(d), u) : (!r.interrupt || a < 2) && (r.containerState.marker ? d === r.containerState.marker : d === 41 || d === 46) ? (e.exit("listItemValue"), c(d)) : n(d);
  }
  function c(d) {
    return e.enter("listItemMarker"), e.consume(d), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || d, e.check(
      Bn,
      // Can’t be empty when interrupting.
      r.interrupt ? n : l,
      e.attempt(Mw, p, f)
    );
  }
  function l(d) {
    return r.containerState.initialBlankLine = !0, o++, p(d);
  }
  function f(d) {
    return X(d) ? (e.enter("listItemPrefixWhitespace"), e.consume(d), e.exit("listItemPrefixWhitespace"), p) : n(d);
  }
  function p(d) {
    return r.containerState.size = o + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(d);
  }
}
function Dw(e, t, n) {
  const r = this;
  return r.containerState._closeFlow = void 0, e.check(Bn, i, o);
  function i(s) {
    return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, ne(e, t, "listItemIndent", r.containerState.size + 1)(s);
  }
  function o(s) {
    return r.containerState.furtherBlankLines || !X(s) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, a(s)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(Rw, t, a)(s));
  }
  function a(s) {
    return r.containerState._closeFlow = !0, r.interrupt = void 0, ne(e, e.attempt(Me, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s);
  }
}
function Nw(e, t, n) {
  const r = this;
  return ne(e, i, "listItemIndent", r.containerState.size + 1);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "listItemIndent" && a[2].sliceSerialize(a[1], !0).length === r.containerState.size ? t(o) : n(o);
  }
}
function Lw(e) {
  e.exit(this.containerState.type);
}
function Fw(e, t, n) {
  const r = this;
  return ne(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return !X(o) && a && a[1].type === "listItemPrefixWhitespace" ? t(o) : n(o);
  }
}
const ls = {
  name: "setextUnderline",
  resolveTo: jw,
  tokenize: Zw
};
function jw(e, t) {
  const n = new kr();
  let r = e.length, i, o, a;
  for (; r--; )
    if (e[r][0] === "enter") {
      if (e[r][1].type === "content") {
        i = r;
        break;
      }
      e[r][1].type === "paragraph" && (o = r);
    } else
      e[r][1].type === "content" && n.add(r, 1, []), !a && e[r][1].type === "definition" && (a = r);
  const s = {
    type: "setextHeading",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  };
  return e[o][1].type = "setextHeadingText", a ? (n.add(o, 0, [["enter", s, t]]), n.add(a + 1, 0, [["exit", e[i][1], t]]), e[i][1].end = {
    ...e[a][1].end
  }) : e[i][1] = s, n.add(e.length, 0, [["exit", s, t]]), n.consume(e), e;
}
function Zw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(c) {
    let l = r.events.length, f;
    for (; l--; )
      if (r.events[l][1].type !== "lineEnding" && r.events[l][1].type !== "linePrefix" && r.events[l][1].type !== "content") {
        f = r.events[l][1].type === "paragraph";
        break;
      }
    return !r.parser.lazy[r.now().line] && (r.interrupt || f) ? (e.enter("setextHeadingLine"), i = c, a(c)) : n(c);
  }
  function a(c) {
    return e.enter("setextHeadingLineSequence"), s(c);
  }
  function s(c) {
    return c === i ? (e.consume(c), s) : (e.exit("setextHeadingLineSequence"), X(c) ? ne(e, u, "lineSuffix")(c) : u(c));
  }
  function u(c) {
    return c === null || q(c) ? (e.exit("setextHeadingLine"), t(c)) : n(c);
  }
}
const Bw = {
  tokenize: Uw
};
function Uw(e) {
  const t = this, n = e.attempt(
    // Try to parse a blank line.
    Bn,
    r,
    // Try to parse initial flow (essentially, only code).
    e.attempt(this.parser.constructs.flowInitial, i, ne(e, e.attempt(this.parser.constructs.flow, i, e.attempt(Gk, i)), "linePrefix"))
  );
  return n;
  function r(o) {
    if (o === null) {
      e.consume(o);
      return;
    }
    return e.enter("lineEndingBlank"), e.consume(o), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
  }
  function i(o) {
    if (o === null) {
      e.consume(o);
      return;
    }
    return e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), t.currentConstruct = void 0, n;
  }
}
const Vw = {
  resolveAll: kc()
}, qw = vc("string"), Jw = vc("text");
function vc(e) {
  return {
    resolveAll: kc(e === "text" ? Ww : void 0),
    tokenize: t
  };
  function t(n) {
    const r = this, i = this.parser.constructs[e], o = n.attempt(i, a, s);
    return a;
    function a(l) {
      return c(l) ? o(l) : s(l);
    }
    function s(l) {
      if (l === null) {
        n.consume(l);
        return;
      }
      return n.enter("data"), n.consume(l), u;
    }
    function u(l) {
      return c(l) ? (n.exit("data"), o(l)) : (n.consume(l), u);
    }
    function c(l) {
      if (l === null)
        return !0;
      const f = i[l];
      let p = -1;
      if (f)
        for (; ++p < f.length; ) {
          const d = f[p];
          if (!d.previous || d.previous.call(r, r.previous))
            return !0;
        }
      return !1;
    }
  }
}
function kc(e) {
  return t;
  function t(n, r) {
    let i = -1, o;
    for (; ++i <= n.length; )
      o === void 0 ? n[i] && n[i][1].type === "data" && (o = i, i++) : (!n[i] || n[i][1].type !== "data") && (i !== o + 2 && (n[o][1].end = n[i - 1][1].end, n.splice(o + 2, i - o - 2), i = o + 2), o = void 0);
    return e ? e(n, r) : n;
  }
}
function Ww(e, t) {
  const n = new kr();
  let r = 0;
  for (; ++r <= e.length; )
    if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
      const i = e[r - 1][1], o = t.sliceStream(i);
      let a = o.length, s = -1, u = 0, c;
      for (; a--; ) {
        const l = o[a];
        if (typeof l == "string") {
          for (s = l.length; l.charCodeAt(s - 1) === 32; )
            u++, s--;
          if (s)
            break;
          s = -1;
        } else if (l === -2)
          c = !0, u++;
        else if (l !== -1) {
          a++;
          break;
        }
      }
      if (t._contentTypeTextTrailing && r === e.length && (u = 0), u) {
        const l = {
          type: r === e.length || c || u < 2 ? "lineSuffix" : "hardBreakTrailing",
          start: {
            _bufferIndex: a ? s : i.start._bufferIndex + s,
            _index: i.start._index + a,
            line: i.end.line,
            column: i.end.column - u,
            offset: i.end.offset - u
          },
          end: {
            ...i.end
          }
        };
        i.end = {
          ...l.start
        }, i.start.offset === i.end.offset ? Object.assign(i, l) : n.add(r, 0, [["enter", l, t], ["exit", l, t]]);
      }
      r++;
    }
  return n.consume(e), e;
}
const Hw = {
  42: Me,
  43: Me,
  45: Me,
  48: Me,
  49: Me,
  50: Me,
  51: Me,
  52: Me,
  53: Me,
  54: Me,
  55: Me,
  56: Me,
  57: Me,
  62: fc
}, Kw = {
  91: nw
}, Yw = {
  [-2]: ni,
  [-1]: ni,
  32: ni
}, Gw = {
  35: lw,
  42: lr,
  45: [ls, lr],
  60: fw,
  61: ls,
  95: lr,
  96: ss,
  126: ss
}, Xw = {
  38: pc,
  92: dc
}, Qw = {
  [-5]: ri,
  [-4]: ri,
  [-3]: ri,
  33: Cw,
  38: pc,
  42: Zi,
  60: [Pk, gw],
  91: zw,
  92: [aw, dc],
  93: So,
  95: Zi,
  96: qk
}, e0 = {
  null: [Zi, Vw]
}, t0 = {
  null: [42, 95]
}, n0 = {
  null: []
}, r0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  attentionMarkers: t0,
  contentInitial: Kw,
  disable: n0,
  document: Hw,
  flow: Gw,
  flowInitial: Yw,
  insideSpan: e0,
  string: Xw,
  text: Qw
}, Symbol.toStringTag, { value: "Module" }));
function i0(e, t, n) {
  let r = {
    _bufferIndex: -1,
    _index: 0,
    line: n && n.line || 1,
    column: n && n.column || 1,
    offset: n && n.offset || 0
  };
  const i = {}, o = [];
  let a = [], s = [];
  const u = {
    attempt: C(_),
    check: C(y),
    consume: w,
    enter: I,
    exit: S,
    interrupt: C(y, {
      interrupt: !0
    })
  }, c = {
    code: null,
    containerState: {},
    defineSkip: m,
    events: [],
    now: h,
    parser: e,
    previous: null,
    sliceSerialize: p,
    sliceStream: d,
    write: f
  };
  let l = t.tokenize.call(c, u);
  return t.resolveAll && o.push(t), c;
  function f(M) {
    return a = Je(a, M), v(), a[a.length - 1] !== null ? [] : (R(t, 0), c.events = Pr(o, c.events, c), c.events);
  }
  function p(M, L) {
    return a0(d(M), L);
  }
  function d(M) {
    return o0(a, M);
  }
  function h() {
    const {
      _bufferIndex: M,
      _index: L,
      line: x,
      column: Z,
      offset: B
    } = r;
    return {
      _bufferIndex: M,
      _index: L,
      line: x,
      column: Z,
      offset: B
    };
  }
  function m(M) {
    i[M.line] = M.column, E();
  }
  function v() {
    for (; r._index < a.length; ) {
      const M = a[r._index];
      if (typeof M == "string") {
        const L = r._index;
        for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === L && r._bufferIndex < M.length; )
          g(M.charCodeAt(r._bufferIndex));
      } else
        g(M);
    }
  }
  function g(M) {
    l = l(M);
  }
  function w(M) {
    q(M) ? (r.line++, r.column = 1, r.offset += M === -3 ? 2 : 1, E()) : M !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === // Points w/ non-negative `_bufferIndex` reference
    // strings.
    /** @type {string} */
    a[r._index].length && (r._bufferIndex = -1, r._index++)), c.previous = M;
  }
  function I(M, L) {
    const x = L || {};
    return x.type = M, x.start = h(), c.events.push(["enter", x, c]), s.push(x), x;
  }
  function S(M) {
    const L = s.pop();
    return L.end = h(), c.events.push(["exit", L, c]), L;
  }
  function _(M, L) {
    R(M, L.from);
  }
  function y(M, L) {
    L.restore();
  }
  function C(M, L) {
    return x;
    function x(Z, B, Y) {
      let N, H, le, b;
      return Array.isArray(Z) ? (
        /* c8 ignore next 1 */
        Ze(Z)
      ) : "tokenize" in Z ? (
        // Looks like a construct.
        Ze([
          /** @type {Construct} */
          Z
        ])
      ) : ke(Z);
      function ke(ge) {
        return rt;
        function rt(Ke) {
          const mt = Ke !== null && ge[Ke], O = Ke !== null && ge.null, U = [
            // To do: add more extension tests.
            /* c8 ignore next 2 */
            ...Array.isArray(mt) ? mt : mt ? [mt] : [],
            ...Array.isArray(O) ? O : O ? [O] : []
          ];
          return Ze(U)(Ke);
        }
      }
      function Ze(ge) {
        return N = ge, H = 0, ge.length === 0 ? Y : k(ge[H]);
      }
      function k(ge) {
        return rt;
        function rt(Ke) {
          return b = F(), le = ge, ge.partial || (c.currentConstruct = ge), ge.name && c.parser.constructs.disable.null.includes(ge.name) ? nt() : ge.tokenize.call(
            // If we do have fields, create an object w/ `context` as its
            // prototype.
            // This allows a “live binding”, which is needed for `interrupt`.
            L ? Object.assign(Object.create(c), L) : c,
            u,
            Te,
            nt
          )(Ke);
        }
      }
      function Te(ge) {
        return M(le, b), B;
      }
      function nt(ge) {
        return b.restore(), ++H < N.length ? k(N[H]) : Y;
      }
    }
  }
  function R(M, L) {
    M.resolveAll && !o.includes(M) && o.push(M), M.resolve && Qe(c.events, L, c.events.length - L, M.resolve(c.events.slice(L), c)), M.resolveTo && (c.events = M.resolveTo(c.events, c));
  }
  function F() {
    const M = h(), L = c.previous, x = c.currentConstruct, Z = c.events.length, B = Array.from(s);
    return {
      from: Z,
      restore: Y
    };
    function Y() {
      r = M, c.previous = L, c.currentConstruct = x, c.events.length = Z, s = B, E();
    }
  }
  function E() {
    r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
  }
}
function o0(e, t) {
  const n = t.start._index, r = t.start._bufferIndex, i = t.end._index, o = t.end._bufferIndex;
  let a;
  if (n === i)
    a = [e[n].slice(r, o)];
  else {
    if (a = e.slice(n, i), r > -1) {
      const s = a[0];
      typeof s == "string" ? a[0] = s.slice(r) : a.shift();
    }
    o > 0 && a.push(e[i].slice(0, o));
  }
  return a;
}
function a0(e, t) {
  let n = -1;
  const r = [];
  let i;
  for (; ++n < e.length; ) {
    const o = e[n];
    let a;
    if (typeof o == "string")
      a = o;
    else
      switch (o) {
        case -5: {
          a = "\r";
          break;
        }
        case -4: {
          a = `
`;
          break;
        }
        case -3: {
          a = `\r
`;
          break;
        }
        case -2: {
          a = t ? " " : "	";
          break;
        }
        case -1: {
          if (!t && i)
            continue;
          a = " ";
          break;
        }
        default:
          a = String.fromCharCode(o);
      }
    i = o === -2, r.push(a);
  }
  return r.join("");
}
function s0(e) {
  const r = {
    constructs: (
      /** @type {FullNormalizedExtension} */
      sc([r0, ...(e || {}).extensions || []])
    ),
    content: i(Ik),
    defined: [],
    document: i(Ck),
    flow: i(Bw),
    lazy: {},
    string: i(qw),
    text: i(Jw)
  };
  return r;
  function i(o) {
    return a;
    function a(s) {
      return i0(r, o, s);
    }
  }
}
function l0(e) {
  for (; !hc(e); )
    ;
  return e;
}
const us = /[\0\t\n\r]/g;
function u0() {
  let e = 1, t = "", n = !0, r;
  return i;
  function i(o, a, s) {
    o = t + (typeof o == "string" ? o.toString() : new TextDecoder(a || void 0).decode(o));
    const u = [];
    let c = 0;
    for (t = "", n && (o.charCodeAt(0) === 65279 && c++, n = void 0); c < o.length; ) {
      us.lastIndex = c;
      const l = us.exec(o), f = l && l.index !== void 0 ? l.index : o.length, p = o.charCodeAt(f);
      if (!l) {
        t = o.slice(c);
        break;
      }
      if (p === 10 && c === f && r)
        u.push(-3), r = void 0;
      else
        switch (r && (u.push(-5), r = void 0), c < f && (u.push(o.slice(c, f)), e += f - c), p) {
          case 0: {
            u.push(65533), e++;
            break;
          }
          case 9: {
            const d = Math.ceil(e / 4) * 4;
            for (u.push(-2); e++ < d; )
              u.push(-1);
            break;
          }
          case 10: {
            u.push(-4), e = 1;
            break;
          }
          default:
            r = !0, e = 1;
        }
      c = f + 1;
    }
    return s && (r && u.push(-5), t && u.push(t), u.push(null)), u;
  }
}
const c0 = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function f0(e) {
  return e.replace(c0, d0);
}
function d0(e, t, n) {
  if (t)
    return t;
  if (n.charCodeAt(0) === 35) {
    const i = n.charCodeAt(1), o = i === 120 || i === 88;
    return lc(n.slice(o ? 2 : 1), o ? 16 : 10);
  }
  return _o(n) || e;
}
const wc = {}.hasOwnProperty;
function p0(e, t, n) {
  return t && typeof t == "object" && (n = t, t = void 0), h0(n)(l0(s0(n).document().write(u0()(e, t, !0))));
}
function h0(e) {
  const t = {
    afterExit: [],
    beforeEnter: [],
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: a(Fo),
      autolinkProtocol: E,
      autolinkEmail: E,
      atxHeading: a(un),
      blockQuote: a(U),
      characterEscape: E,
      characterReference: E,
      codeFenced: a(Be),
      codeFencedFenceInfo: s,
      codeFencedFenceMeta: s,
      codeIndented: a(Be, s),
      codeText: a(zt, s),
      codeTextData: E,
      data: E,
      codeFlowValue: E,
      definition: a(Vn),
      definitionDestinationString: s,
      definitionLabelString: s,
      definitionTitleString: s,
      emphasis: a(ln),
      hardBreakEscape: a(Fr),
      hardBreakTrailing: a(Fr),
      htmlFlow: a(Lo, s),
      htmlFlowData: E,
      htmlText: a(Lo, s),
      htmlTextData: E,
      image: a(sf),
      label: s,
      link: a(Fo),
      listItem: a(lf),
      listItemValue: d,
      listOrdered: a(jo, p),
      listUnordered: a(jo),
      paragraph: a(uf),
      reference: Te,
      referenceString: s,
      resourceDestinationString: s,
      resourceTitleString: s,
      setextHeading: a(un),
      strong: a(cf),
      thematicBreak: a(df)
    },
    exit: {
      atxHeading: c(),
      atxHeadingSequence: y,
      autolink: c(),
      autolinkEmail: O,
      autolinkProtocol: mt,
      blockQuote: c(),
      characterEscapeValue: M,
      characterReferenceMarkerHexadecimal: ge,
      characterReferenceMarkerNumeric: ge,
      characterReferenceValue: rt,
      characterReference: Ke,
      codeFenced: c(g),
      codeFencedFence: v,
      codeFencedFenceInfo: h,
      codeFencedFenceMeta: m,
      codeFlowValue: M,
      codeIndented: c(w),
      codeText: c(Y),
      codeTextData: M,
      data: M,
      definition: c(),
      definitionDestinationString: _,
      definitionLabelString: I,
      definitionTitleString: S,
      emphasis: c(),
      hardBreakEscape: c(x),
      hardBreakTrailing: c(x),
      htmlFlow: c(Z),
      htmlFlowData: M,
      htmlText: c(B),
      htmlTextData: M,
      image: c(H),
      label: b,
      labelText: le,
      lineEnding: L,
      link: c(N),
      listItem: c(),
      listOrdered: c(),
      listUnordered: c(),
      paragraph: c(),
      referenceString: nt,
      resourceDestinationString: ke,
      resourceTitleString: Ze,
      resource: k,
      setextHeading: c(F),
      setextHeadingLineSequence: R,
      setextHeadingText: C,
      strong: c(),
      thematicBreak: c()
    }
  };
  xc(t, (e || {}).mdastExtensions || []);
  const n = {};
  return r;
  function r(A) {
    let D = {
      type: "root",
      children: [],
      position: void 0
    };
    const W = {
      stack: [D],
      tokenStack: [],
      config: t,
      enter: u,
      exit: l,
      buffer: s,
      resume: f,
      data: n
    }, G = [], Oe = [];
    let ue = -1;
    for (; ++ue < A.length; )
      if (Oe.push(A[ue]), A[ue][1].type === "listOrdered" || A[ue][1].type === "listUnordered")
        if (A[ue][0] === "enter")
          G.push(Oe.length - 1);
        else {
          const Pe = G.pop();
          o(Oe, Pe);
        }
    for (A = Oe, ue = -1; ++ue < A.length; ) {
      const Pe = t[A[ue][0]];
      A[ue][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]), wc.call(Pe, A[ue][1].type) && Pe[A[ue][1].type].call({
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]), A[ue][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]);
    }
    if (W.tokenStack.length > 0) {
      const Pe = W.tokenStack[W.tokenStack.length - 1];
      (Pe[1] || cs).call(W, void 0, Pe[0]);
    }
    for (D.position = {
      start: yt(A.length > 0 ? A[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: yt(A.length > 0 ? A[A.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    }, ue = -1; ++ue < t.transforms.length; )
      D = t.transforms[ue](D) || D;
    return D;
  }
  function i(A, D, W) {
    let G = -1;
    for (; ++G < A.length; )
      A[G].call(D, W);
  }
  function o(A, D) {
    const W = A.length - 1;
    let G = D - 1, Oe = -1, ue = !1, Pe, it, cn, fn;
    const dn = [];
    for (; ++G <= W; ) {
      const De = A[G];
      switch (De[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote": {
          De[0] === "enter" ? Oe++ : Oe--, fn = void 0;
          break;
        }
        case "lineEndingBlank": {
          De[0] === "enter" && (Pe && !fn && !Oe && !cn && (cn = G), fn = void 0);
          break;
        }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace":
          break;
        default:
          fn = void 0;
      }
      if (!Oe && De[0] === "enter" && De[1].type === "listItemPrefix" || Oe === -1 && De[0] === "exit" && (De[1].type === "listUnordered" || De[1].type === "listOrdered")) {
        if (Pe) {
          let Bt = G;
          for (it = void 0; Bt--; ) {
            const ft = A[Bt];
            if (ft[1].type === "lineEnding" || ft[1].type === "lineEndingBlank") {
              if (ft[0] === "exit") continue;
              it && (A[it][1].type = "lineEndingBlank", ue = !0), ft[1].type = "lineEnding", it = Bt;
            } else if (!(ft[1].type === "linePrefix" || ft[1].type === "blockQuotePrefix" || ft[1].type === "blockQuotePrefixWhitespace" || ft[1].type === "blockQuoteMarker" || ft[1].type === "listItemIndent")) break;
          }
          cn && (!it || cn < it) && (Pe._spread = !0), Pe.end = Object.assign({}, it ? A[it][1].start : De[1].end), dn.push({
            at: it || G,
            event: ["exit", Pe, De[2]]
          });
        }
        if (De[1].type === "listItemPrefix") {
          const Bt = {
            type: "listItem",
            _spread: !1,
            start: Object.assign({}, De[1].start),
            // @ts-expect-error: we’ll add `end` in a second.
            end: void 0
          };
          Pe = Bt, dn.push({
            at: G,
            event: ["enter", Bt, De[2]]
          }), cn = void 0, fn = !0;
        }
      }
    }
    const Zo = A.splice(D);
    let jr = 0;
    for (G = -1; ++G < Zo.length; ) {
      for (; jr < dn.length && dn[jr].at === D + G; )
        A.push(dn[jr++].event);
      A.push(Zo[G]);
    }
    A[D][1]._spread = ue;
  }
  function a(A, D) {
    return W;
    function W(G) {
      u.call(this, A(G), G), D && D.call(this, G);
    }
  }
  function s() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function u(A, D, W) {
    this.stack[this.stack.length - 1].children.push(A), this.stack.push(A), this.tokenStack.push([D, W || void 0]), A.position = {
      start: yt(D.start),
      // @ts-expect-error: `end` will be patched later.
      end: void 0
    };
  }
  function c(A) {
    return D;
    function D(W) {
      A && A.call(this, W), l.call(this, W);
    }
  }
  function l(A, D) {
    const W = this.stack.pop(), G = this.tokenStack.pop();
    if (!G)
      throw new Error("Cannot close `" + A.type + "` (" + An({
        start: A.start,
        end: A.end
      }) + "): it’s not open");
    G[0].type !== A.type && (D ? D.call(this, A, G[0]) : (G[1] || cs).call(this, A, G[0])), W.position.end = yt(A.end);
  }
  function f() {
    return Or(this.stack.pop());
  }
  function p() {
    this.data.expectingFirstListItemValue = !0;
  }
  function d(A) {
    if (this.data.expectingFirstListItemValue) {
      const D = this.stack[this.stack.length - 2];
      D.start = Number.parseInt(this.sliceSerialize(A), 10), this.data.expectingFirstListItemValue = void 0;
    }
  }
  function h() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.lang = A;
  }
  function m() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.meta = A;
  }
  function v() {
    this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
  }
  function g() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.value = A.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
  }
  function w() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.value = A.replace(/(\r?\n|\r)$/g, "");
  }
  function I(A) {
    const D = this.resume(), W = this.stack[this.stack.length - 1];
    W.label = D, W.identifier = et(this.sliceSerialize(A)).toLowerCase();
  }
  function S() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.title = A;
  }
  function _() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.url = A;
  }
  function y(A) {
    const D = this.stack[this.stack.length - 1];
    if (!D.depth) {
      const W = this.sliceSerialize(A).length;
      D.depth = W;
    }
  }
  function C() {
    this.data.setextHeadingSlurpLineEnding = !0;
  }
  function R(A) {
    const D = this.stack[this.stack.length - 1];
    D.depth = this.sliceSerialize(A).codePointAt(0) === 61 ? 1 : 2;
  }
  function F() {
    this.data.setextHeadingSlurpLineEnding = void 0;
  }
  function E(A) {
    const W = this.stack[this.stack.length - 1].children;
    let G = W[W.length - 1];
    (!G || G.type !== "text") && (G = ff(), G.position = {
      start: yt(A.start),
      // @ts-expect-error: we’ll add `end` later.
      end: void 0
    }, W.push(G)), this.stack.push(G);
  }
  function M(A) {
    const D = this.stack.pop();
    D.value += this.sliceSerialize(A), D.position.end = yt(A.end);
  }
  function L(A) {
    const D = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const W = D.children[D.children.length - 1];
      W.position.end = yt(A.end), this.data.atHardBreak = void 0;
      return;
    }
    !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(D.type) && (E.call(this, A), M.call(this, A));
  }
  function x() {
    this.data.atHardBreak = !0;
  }
  function Z() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.value = A;
  }
  function B() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.value = A;
  }
  function Y() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.value = A;
  }
  function N() {
    const A = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const D = this.data.referenceType || "shortcut";
      A.type += "Reference", A.referenceType = D, delete A.url, delete A.title;
    } else
      delete A.identifier, delete A.label;
    this.data.referenceType = void 0;
  }
  function H() {
    const A = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const D = this.data.referenceType || "shortcut";
      A.type += "Reference", A.referenceType = D, delete A.url, delete A.title;
    } else
      delete A.identifier, delete A.label;
    this.data.referenceType = void 0;
  }
  function le(A) {
    const D = this.sliceSerialize(A), W = this.stack[this.stack.length - 2];
    W.label = f0(D), W.identifier = et(D).toLowerCase();
  }
  function b() {
    const A = this.stack[this.stack.length - 1], D = this.resume(), W = this.stack[this.stack.length - 1];
    if (this.data.inReference = !0, W.type === "link") {
      const G = A.children;
      W.children = G;
    } else
      W.alt = D;
  }
  function ke() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.url = A;
  }
  function Ze() {
    const A = this.resume(), D = this.stack[this.stack.length - 1];
    D.title = A;
  }
  function k() {
    this.data.inReference = void 0;
  }
  function Te() {
    this.data.referenceType = "collapsed";
  }
  function nt(A) {
    const D = this.resume(), W = this.stack[this.stack.length - 1];
    W.label = D, W.identifier = et(this.sliceSerialize(A)).toLowerCase(), this.data.referenceType = "full";
  }
  function ge(A) {
    this.data.characterReferenceType = A.type;
  }
  function rt(A) {
    const D = this.sliceSerialize(A), W = this.data.characterReferenceType;
    let G;
    W ? (G = lc(D, W === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : G = _o(D);
    const Oe = this.stack[this.stack.length - 1];
    Oe.value += G;
  }
  function Ke(A) {
    const D = this.stack.pop();
    D.position.end = yt(A.end);
  }
  function mt(A) {
    M.call(this, A);
    const D = this.stack[this.stack.length - 1];
    D.url = this.sliceSerialize(A);
  }
  function O(A) {
    M.call(this, A);
    const D = this.stack[this.stack.length - 1];
    D.url = "mailto:" + this.sliceSerialize(A);
  }
  function U() {
    return {
      type: "blockquote",
      children: [],
      position: void 0
    };
  }
  function Be() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: "",
      position: void 0
    };
  }
  function zt() {
    return {
      type: "inlineCode",
      value: "",
      position: void 0
    };
  }
  function Vn() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: "",
      position: void 0
    };
  }
  function ln() {
    return {
      type: "emphasis",
      children: [],
      position: void 0
    };
  }
  function un() {
    return {
      type: "heading",
      // @ts-expect-error `depth` will be set later.
      depth: 0,
      children: [],
      position: void 0
    };
  }
  function Fr() {
    return {
      type: "break",
      position: void 0
    };
  }
  function Lo() {
    return {
      type: "html",
      value: "",
      position: void 0
    };
  }
  function sf() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null,
      position: void 0
    };
  }
  function Fo() {
    return {
      type: "link",
      title: null,
      url: "",
      children: [],
      position: void 0
    };
  }
  function jo(A) {
    return {
      type: "list",
      ordered: A.type === "listOrdered",
      start: null,
      spread: A._spread,
      children: [],
      position: void 0
    };
  }
  function lf(A) {
    return {
      type: "listItem",
      spread: A._spread,
      checked: null,
      children: [],
      position: void 0
    };
  }
  function uf() {
    return {
      type: "paragraph",
      children: [],
      position: void 0
    };
  }
  function cf() {
    return {
      type: "strong",
      children: [],
      position: void 0
    };
  }
  function ff() {
    return {
      type: "text",
      value: "",
      position: void 0
    };
  }
  function df() {
    return {
      type: "thematicBreak",
      position: void 0
    };
  }
}
function yt(e) {
  return {
    line: e.line,
    column: e.column,
    offset: e.offset
  };
}
function xc(e, t) {
  let n = -1;
  for (; ++n < t.length; ) {
    const r = t[n];
    Array.isArray(r) ? xc(e, r) : m0(e, r);
  }
}
function m0(e, t) {
  let n;
  for (n in t)
    if (wc.call(t, n))
      switch (n) {
        case "canContainEols": {
          const r = t[n];
          r && e[n].push(...r);
          break;
        }
        case "transforms": {
          const r = t[n];
          r && e[n].push(...r);
          break;
        }
        case "afterExit":
        case "beforeEnter": {
          const r = t[n];
          r && e[n].push(r);
          break;
        }
        case "enter":
        case "exit": {
          const r = t[n];
          r && Object.assign(e[n], r);
          break;
        }
      }
}
function cs(e, t) {
  throw e ? new Error("Cannot close `" + e.type + "` (" + An({
    start: e.start,
    end: e.end
  }) + "): a different token (`" + t.type + "`, " + An({
    start: t.start,
    end: t.end
  }) + ") is open") : new Error("Cannot close document, a token (`" + t.type + "`, " + An({
    start: t.start,
    end: t.end
  }) + ") is still open");
}
function g0(e) {
  const t = this;
  t.parser = n;
  function n(r) {
    return p0(r, {
      ...t.data("settings"),
      ...e,
      // Note: these options are not in the readme.
      // The goal is for them to be set by plugins on `data` instead of being
      // passed by users.
      extensions: t.data("micromarkExtensions") || [],
      mdastExtensions: t.data("fromMarkdownExtensions") || []
    });
  }
}
function y0(e, t) {
  const n = {
    type: "element",
    tagName: "blockquote",
    properties: {},
    children: e.wrap(e.all(t), !0)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function b0(e, t) {
  const n = { type: "element", tagName: "br", properties: {}, children: [] };
  return e.patch(t, n), [e.applyData(t, n), { type: "text", value: `
` }];
}
function v0(e, t) {
  const n = t.value ? t.value + `
` : "", r = {}, i = t.lang ? t.lang.split(/\s+/) : [];
  i.length > 0 && (r.className = ["language-" + i[0]]);
  let o = {
    type: "element",
    tagName: "code",
    properties: r,
    children: [{ type: "text", value: n }]
  };
  return t.meta && (o.data = { meta: t.meta }), e.patch(t, o), o = e.applyData(t, o), o = { type: "element", tagName: "pre", properties: {}, children: [o] }, e.patch(t, o), o;
}
function k0(e, t) {
  const n = {
    type: "element",
    tagName: "del",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function w0(e, t) {
  const n = {
    type: "element",
    tagName: "em",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function x0(e, t) {
  const n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", r = String(t.identifier).toUpperCase(), i = sn(r.toLowerCase()), o = e.footnoteOrder.indexOf(r);
  let a, s = e.footnoteCounts.get(r);
  s === void 0 ? (s = 0, e.footnoteOrder.push(r), a = e.footnoteOrder.length) : a = o + 1, s += 1, e.footnoteCounts.set(r, s);
  const u = {
    type: "element",
    tagName: "a",
    properties: {
      href: "#" + n + "fn-" + i,
      id: n + "fnref-" + i + (s > 1 ? "-" + s : ""),
      dataFootnoteRef: !0,
      ariaDescribedBy: ["footnote-label"]
    },
    children: [{ type: "text", value: String(a) }]
  };
  e.patch(t, u);
  const c = {
    type: "element",
    tagName: "sup",
    properties: {},
    children: [u]
  };
  return e.patch(t, c), e.applyData(t, c);
}
function _0(e, t) {
  const n = {
    type: "element",
    tagName: "h" + t.depth,
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function S0(e, t) {
  if (e.options.allowDangerousHtml) {
    const n = { type: "raw", value: t.value };
    return e.patch(t, n), e.applyData(t, n);
  }
}
function _c(e, t) {
  const n = t.referenceType;
  let r = "]";
  if (n === "collapsed" ? r += "[]" : n === "full" && (r += "[" + (t.label || t.identifier) + "]"), t.type === "imageReference")
    return [{ type: "text", value: "![" + t.alt + r }];
  const i = e.all(t), o = i[0];
  o && o.type === "text" ? o.value = "[" + o.value : i.unshift({ type: "text", value: "[" });
  const a = i[i.length - 1];
  return a && a.type === "text" ? a.value += r : i.push({ type: "text", value: r }), i;
}
function I0(e, t) {
  const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
  if (!r)
    return _c(e, t);
  const i = { src: sn(r.url || ""), alt: t.alt };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const o = { type: "element", tagName: "img", properties: i, children: [] };
  return e.patch(t, o), e.applyData(t, o);
}
function E0(e, t) {
  const n = { src: sn(t.url) };
  t.alt !== null && t.alt !== void 0 && (n.alt = t.alt), t.title !== null && t.title !== void 0 && (n.title = t.title);
  const r = { type: "element", tagName: "img", properties: n, children: [] };
  return e.patch(t, r), e.applyData(t, r);
}
function C0(e, t) {
  const n = { type: "text", value: t.value.replace(/\r?\n|\r/g, " ") };
  e.patch(t, n);
  const r = {
    type: "element",
    tagName: "code",
    properties: {},
    children: [n]
  };
  return e.patch(t, r), e.applyData(t, r);
}
function A0(e, t) {
  const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
  if (!r)
    return _c(e, t);
  const i = { href: sn(r.url || "") };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const o = {
    type: "element",
    tagName: "a",
    properties: i,
    children: e.all(t)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function z0(e, t) {
  const n = { href: sn(t.url) };
  t.title !== null && t.title !== void 0 && (n.title = t.title);
  const r = {
    type: "element",
    tagName: "a",
    properties: n,
    children: e.all(t)
  };
  return e.patch(t, r), e.applyData(t, r);
}
function T0(e, t, n) {
  const r = e.all(t), i = n ? O0(n) : Sc(t), o = {}, a = [];
  if (typeof t.checked == "boolean") {
    const l = r[0];
    let f;
    l && l.type === "element" && l.tagName === "p" ? f = l : (f = { type: "element", tagName: "p", properties: {}, children: [] }, r.unshift(f)), f.children.length > 0 && f.children.unshift({ type: "text", value: " " }), f.children.unshift({
      type: "element",
      tagName: "input",
      properties: { type: "checkbox", checked: t.checked, disabled: !0 },
      children: []
    }), o.className = ["task-list-item"];
  }
  let s = -1;
  for (; ++s < r.length; ) {
    const l = r[s];
    (i || s !== 0 || l.type !== "element" || l.tagName !== "p") && a.push({ type: "text", value: `
` }), l.type === "element" && l.tagName === "p" && !i ? a.push(...l.children) : a.push(l);
  }
  const u = r[r.length - 1];
  u && (i || u.type !== "element" || u.tagName !== "p") && a.push({ type: "text", value: `
` });
  const c = { type: "element", tagName: "li", properties: o, children: a };
  return e.patch(t, c), e.applyData(t, c);
}
function O0(e) {
  let t = !1;
  if (e.type === "list") {
    t = e.spread || !1;
    const n = e.children;
    let r = -1;
    for (; !t && ++r < n.length; )
      t = Sc(n[r]);
  }
  return t;
}
function Sc(e) {
  const t = e.spread;
  return t ?? e.children.length > 1;
}
function P0(e, t) {
  const n = {}, r = e.all(t);
  let i = -1;
  for (typeof t.start == "number" && t.start !== 1 && (n.start = t.start); ++i < r.length; ) {
    const a = r[i];
    if (a.type === "element" && a.tagName === "li" && a.properties && Array.isArray(a.properties.className) && a.properties.className.includes("task-list-item")) {
      n.className = ["contains-task-list"];
      break;
    }
  }
  const o = {
    type: "element",
    tagName: t.ordered ? "ol" : "ul",
    properties: n,
    children: e.wrap(r, !0)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function M0(e, t) {
  const n = {
    type: "element",
    tagName: "p",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function R0(e, t) {
  const n = { type: "root", children: e.wrap(e.all(t)) };
  return e.patch(t, n), e.applyData(t, n);
}
function $0(e, t) {
  const n = {
    type: "element",
    tagName: "strong",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function D0(e, t) {
  const n = e.all(t), r = n.shift(), i = [];
  if (r) {
    const a = {
      type: "element",
      tagName: "thead",
      properties: {},
      children: e.wrap([r], !0)
    };
    e.patch(t.children[0], a), i.push(a);
  }
  if (n.length > 0) {
    const a = {
      type: "element",
      tagName: "tbody",
      properties: {},
      children: e.wrap(n, !0)
    }, s = vo(t.children[1]), u = ec(t.children[t.children.length - 1]);
    s && u && (a.position = { start: s, end: u }), i.push(a);
  }
  const o = {
    type: "element",
    tagName: "table",
    properties: {},
    children: e.wrap(i, !0)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function N0(e, t, n) {
  const r = n ? n.children : void 0, o = (r ? r.indexOf(t) : 1) === 0 ? "th" : "td", a = n && n.type === "table" ? n.align : void 0, s = a ? a.length : t.children.length;
  let u = -1;
  const c = [];
  for (; ++u < s; ) {
    const f = t.children[u], p = {}, d = a ? a[u] : void 0;
    d && (p.align = d);
    let h = { type: "element", tagName: o, properties: p, children: [] };
    f && (h.children = e.all(f), e.patch(f, h), h = e.applyData(f, h)), c.push(h);
  }
  const l = {
    type: "element",
    tagName: "tr",
    properties: {},
    children: e.wrap(c, !0)
  };
  return e.patch(t, l), e.applyData(t, l);
}
function L0(e, t) {
  const n = {
    type: "element",
    tagName: "td",
    // Assume body cell.
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
const fs = 9, ds = 32;
function F0(e) {
  const t = String(e), n = /\r?\n|\r/g;
  let r = n.exec(t), i = 0;
  const o = [];
  for (; r; )
    o.push(
      ps(t.slice(i, r.index), i > 0, !0),
      r[0]
    ), i = r.index + r[0].length, r = n.exec(t);
  return o.push(ps(t.slice(i), i > 0, !1)), o.join("");
}
function ps(e, t, n) {
  let r = 0, i = e.length;
  if (t) {
    let o = e.codePointAt(r);
    for (; o === fs || o === ds; )
      r++, o = e.codePointAt(r);
  }
  if (n) {
    let o = e.codePointAt(i - 1);
    for (; o === fs || o === ds; )
      i--, o = e.codePointAt(i - 1);
  }
  return i > r ? e.slice(r, i) : "";
}
function j0(e, t) {
  const n = { type: "text", value: F0(String(t.value)) };
  return e.patch(t, n), e.applyData(t, n);
}
function Z0(e, t) {
  const n = {
    type: "element",
    tagName: "hr",
    properties: {},
    children: []
  };
  return e.patch(t, n), e.applyData(t, n);
}
const B0 = {
  blockquote: y0,
  break: b0,
  code: v0,
  delete: k0,
  emphasis: w0,
  footnoteReference: x0,
  heading: _0,
  html: S0,
  imageReference: I0,
  image: E0,
  inlineCode: C0,
  linkReference: A0,
  link: z0,
  listItem: T0,
  list: P0,
  paragraph: M0,
  // @ts-expect-error: root is different, but hard to type.
  root: R0,
  strong: $0,
  table: D0,
  tableCell: L0,
  tableRow: N0,
  text: j0,
  thematicBreak: Z0,
  toml: Yn,
  yaml: Yn,
  definition: Yn,
  footnoteDefinition: Yn
};
function Yn() {
}
const Ic = -1, Mr = 0, Tn = 1, wr = 2, Io = 3, Eo = 4, Co = 5, Ao = 6, Ec = 7, Cc = 8, { defineProperty: U0 } = Object, Ac = typeof self == "object" ? self : globalThis, hs = (e, t) => {
  switch (e) {
    case "Function":
    case "SharedWorker":
    case "Worker":
    case "eval":
    case "setInterval":
    case "setTimeout":
      throw new TypeError("unable to deserialize " + e);
  }
  return new Ac[e](t);
}, V0 = (e, t) => {
  const n = (i, o) => (e.set(o, i), i), r = (i) => {
    if (e.has(i))
      return e.get(i);
    const [o, a] = t[i];
    switch (o) {
      case Mr:
      case Ic:
        return n(a, i);
      case Tn: {
        const s = n([], i);
        for (const u of a)
          s.push(r(u));
        return s;
      }
      case wr: {
        const s = n({}, i);
        for (const [u, c] of a) {
          const l = r(u), f = r(c);
          l === "__proto__" ? U0(s, l, {
            value: f,
            configurable: !0,
            enumerable: !0,
            writable: !0
          }) : s[l] = f;
        }
        return s;
      }
      case Io:
        return n(new Date(a), i);
      case Eo: {
        const { source: s, flags: u } = a;
        return n(new RegExp(s, u), i);
      }
      case Co: {
        const s = n(/* @__PURE__ */ new Map(), i);
        for (const [u, c] of a)
          s.set(r(u), r(c));
        return s;
      }
      case Ao: {
        const s = n(/* @__PURE__ */ new Set(), i);
        for (const u of a)
          s.add(r(u));
        return s;
      }
      case Ec: {
        const { name: s, message: u } = a;
        return n(
          typeof Ac[s] == "function" ? hs(s, u) : new Error(u),
          i
        );
      }
      case Cc:
        return n(BigInt(a), i);
      case "BigInt":
        return n(Object(BigInt(a)), i);
      case "ArrayBuffer":
        return n(new Uint8Array(a).buffer, a);
      case "DataView": {
        const { buffer: s } = new Uint8Array(a);
        return n(new DataView(s), a);
      }
      case "-0":
        return -0;
    }
    return n(hs(o, a), i);
  };
  return r;
}, ms = (e) => V0(/* @__PURE__ */ new Map(), e)(0), Pt = "", { toString: q0 } = {}, { keys: J0, is: W0 } = Object, yn = (e) => {
  const t = typeof e;
  if (t !== "object" || !e)
    return [Mr, t];
  const n = q0.call(e).slice(8, -1);
  switch (n) {
    case "Array":
      return [Tn, Pt];
    case "Object":
      return [wr, Pt];
    case "Date":
      return [Io, Pt];
    case "RegExp":
      return [Eo, Pt];
    case "Map":
      return [Co, Pt];
    case "Set":
      return [Ao, Pt];
    case "DataView":
      return [Tn, n];
  }
  return n.includes("Array") ? [Tn, n] : e instanceof Error ? [Ec, e.name || "Error"] : [wr, n];
}, Gn = ([e, t]) => e === Mr && (t === "function" || t === "symbol"), H0 = (e, t, n, r) => {
  const i = (a, s) => {
    const u = r.push(a) - 1;
    return n.set(s, u), u;
  }, o = (a) => {
    if (n.has(a))
      return n.get(a);
    let [s, u] = yn(a);
    switch (s) {
      case Mr: {
        let l = a;
        switch (u) {
          case "bigint":
            s = Cc, l = a.toString();
            break;
          case "number":
            if (!a && W0(a, -0))
              return r.push(["-0"]) - 1;
            break;
          case "function":
          case "symbol":
            if (e)
              throw new TypeError("unable to serialize " + u);
            l = null;
            break;
          case "undefined":
            return i([Ic], a);
        }
        return i([s, l], a);
      }
      case Tn: {
        if (u) {
          let p = a;
          return u === "DataView" ? p = new Uint8Array(a.buffer) : u === "ArrayBuffer" && (p = new Uint8Array(a)), i([u, [...p]], a);
        }
        const l = [], f = i([s, l], a);
        for (const p of a)
          l.push(o(p));
        return f;
      }
      case wr: {
        if (u)
          switch (u) {
            case "BigInt":
              return i([u, a.toString()], a);
            case "Boolean":
            case "Number":
            case "String":
              return i([u, a.valueOf()], a);
          }
        if (t && "toJSON" in a)
          return o(a.toJSON());
        const l = [], f = i([s, l], a);
        for (const p of J0(a))
          (e || !Gn(yn(a[p]))) && l.push([o(p), o(a[p])]);
        return f;
      }
      case Io:
        return i([s, isNaN(a.getTime()) ? Pt : a.toISOString()], a);
      case Eo: {
        const { source: l, flags: f } = a;
        return i([s, { source: l, flags: f }], a);
      }
      case Co: {
        const l = [], f = i([s, l], a);
        for (const [p, d] of a)
          (e || !(Gn(yn(p)) || Gn(yn(d)))) && l.push([o(p), o(d)]);
        return f;
      }
      case Ao: {
        const l = [], f = i([s, l], a);
        for (const p of a)
          (e || !Gn(yn(p))) && l.push(o(p));
        return f;
      }
    }
    const { message: c } = a;
    return i([s, { name: u, message: c }], a);
  };
  return o;
}, gs = (e, { json: t, lossy: n } = {}) => {
  const r = [];
  return H0(!(t || n), !!t, /* @__PURE__ */ new Map(), r)(e), r;
}, xr = typeof structuredClone == "function" ? (
  /* c8 ignore start */
  (e, t) => t && ("json" in t || "lossy" in t) ? ms(gs(e, t)) : structuredClone(e)
) : (e, t) => ms(gs(e, t));
function K0(e, t) {
  const n = [{ type: "text", value: "↩" }];
  return t > 1 && n.push({
    type: "element",
    tagName: "sup",
    properties: {},
    children: [{ type: "text", value: String(t) }]
  }), n;
}
function Y0(e, t) {
  return "Back to reference " + (e + 1) + (t > 1 ? "-" + t : "");
}
function G0(e) {
  const t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", n = e.options.footnoteBackContent || K0, r = e.options.footnoteBackLabel || Y0, i = e.options.footnoteLabel || "Footnotes", o = e.options.footnoteLabelTagName || "h2", a = e.options.footnoteLabelProperties || {
    className: ["sr-only"]
  }, s = [];
  let u = -1;
  for (; ++u < e.footnoteOrder.length; ) {
    const c = e.footnoteById.get(
      e.footnoteOrder[u]
    );
    if (!c)
      continue;
    const l = e.all(c), f = String(c.identifier).toUpperCase(), p = sn(f.toLowerCase());
    let d = 0;
    const h = [], m = e.footnoteCounts.get(f);
    for (; m !== void 0 && ++d <= m; ) {
      h.length > 0 && h.push({ type: "text", value: " " });
      let w = typeof n == "string" ? n : n(u, d);
      typeof w == "string" && (w = { type: "text", value: w }), h.push({
        type: "element",
        tagName: "a",
        properties: {
          href: "#" + t + "fnref-" + p + (d > 1 ? "-" + d : ""),
          dataFootnoteBackref: "",
          ariaLabel: typeof r == "string" ? r : r(u, d),
          className: ["data-footnote-backref"]
        },
        children: Array.isArray(w) ? w : [w]
      });
    }
    const v = l[l.length - 1];
    if (v && v.type === "element" && v.tagName === "p") {
      const w = v.children[v.children.length - 1];
      w && w.type === "text" ? w.value += " " : v.children.push({ type: "text", value: " " }), v.children.push(...h);
    } else
      l.push(...h);
    const g = {
      type: "element",
      tagName: "li",
      properties: { id: t + "fn-" + p },
      children: e.wrap(l, !0)
    };
    e.patch(c, g), s.push(g);
  }
  if (s.length !== 0)
    return {
      type: "element",
      tagName: "section",
      properties: { dataFootnotes: !0, className: ["footnotes"] },
      children: [
        {
          type: "element",
          tagName: o,
          properties: {
            ...xr(a),
            id: "footnote-label"
          },
          children: [{ type: "text", value: i }]
        },
        { type: "text", value: `
` },
        {
          type: "element",
          tagName: "ol",
          properties: {},
          children: e.wrap(s, !0)
        },
        { type: "text", value: `
` }
      ]
    };
}
const Rr = (
  // Note: overloads in JSDoc can’t yet use different `@template`s.
  /**
   * @type {(
   *   (<Condition extends string>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & {type: Condition}) &
   *   (<Condition extends Props>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Condition) &
   *   (<Condition extends TestFunction>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Predicate<Condition, Node>) &
   *   ((test?: null | undefined) => (node?: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node) &
   *   ((test?: Test) => Check)
   * )}
   */
  /**
   * @param {Test} [test]
   * @returns {Check}
   */
  function(e) {
    if (e == null)
      return t1;
    if (typeof e == "function")
      return $r(e);
    if (typeof e == "object")
      return Array.isArray(e) ? X0(e) : (
        // Cast because `ReadonlyArray` goes into the above but `isArray`
        // narrows to `Array`.
        Q0(
          /** @type {Props} */
          e
        )
      );
    if (typeof e == "string")
      return e1(e);
    throw new Error("Expected function, string, or object as test");
  }
);
function X0(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.length; )
    t[n] = Rr(e[n]);
  return $r(r);
  function r(...i) {
    let o = -1;
    for (; ++o < t.length; )
      if (t[o].apply(this, i)) return !0;
    return !1;
  }
}
function Q0(e) {
  const t = (
    /** @type {Record<string, unknown>} */
    e
  );
  return $r(n);
  function n(r) {
    const i = (
      /** @type {Record<string, unknown>} */
      /** @type {unknown} */
      r
    );
    let o;
    for (o in e)
      if (i[o] !== t[o]) return !1;
    return !0;
  }
}
function e1(e) {
  return $r(t);
  function t(n) {
    return n && n.type === e;
  }
}
function $r(e) {
  return t;
  function t(n, r, i) {
    return !!(n1(n) && e.call(
      this,
      n,
      typeof r == "number" ? r : void 0,
      i || void 0
    ));
  }
}
function t1() {
  return !0;
}
function n1(e) {
  return e !== null && typeof e == "object" && "type" in e;
}
const zc = [], r1 = !0, On = !1, Vi = "skip";
function qi(e, t, n, r) {
  if (!e || typeof e != "object")
    throw new Error("Unexpected value `" + e + "` for `tree`, expected node");
  let i = !0, o, a, s, u;
  if (typeof n == "function" || n && typeof n == "object" ? (o = /** @type {Test} */
  t, a = n, r && (i = !1)) : (a = /** @type {Visitors | Visitor} */
  t, n && (i = !1)), typeof a == "function")
    s = a;
  else if (a && typeof a == "object") {
    if (!(a.enter === null || a.enter === void 0)) if (typeof a.enter == "function")
      s = a.enter;
    else
      throw new Error(
        "Unexpected value `" + a.enter + "` for `visitors.enter`, expected optional visitor"
      );
    if (typeof a.exit == "function")
      u = a.exit;
    else
      throw new Error(
        "Unexpected value `" + a.exit + "` for `visitors.exit`, expected visitor (pass a visitor directly if you only want an enter visitor)"
      );
  } else
    throw new Error(
      "Unexpected value `" + a + "` for `enter` or `visitors`, expected visitor or object with visitors"
    );
  const c = Rr(o), l = i ? 1 : -1;
  f(e, void 0, [])();
  function f(p, d, h) {
    const m = (
      /** @type {Record<string, unknown>} */
      p && typeof p == "object" ? p : {}
    );
    if (typeof m.type == "string") {
      const g = (
        // `hast`
        typeof m.tagName == "string" ? m.tagName : (
          // `xast`
          typeof m.name == "string" ? m.name : void 0
        )
      );
      Object.defineProperty(v, "name", {
        value: "node (" + (p.type + (g ? "<" + g + ">" : "")) + ")"
      });
    }
    return v;
    function v() {
      const g = !o || c(p, d, h[h.length - 1] || void 0);
      let w = zc;
      if (s && g && (w = ys(s(p, h, d)), w[0] === On))
        return w;
      if ("children" in p && p.children) {
        const I = (
          /** @type {UnistParent} */
          p
        );
        if (I.children && w[0] !== Vi) {
          let S = (i ? -1 : I.children.length) + l;
          const _ = [...h, I];
          for (; S > -1 && S < I.children.length; ) {
            const y = I.children[S], C = f(y, S, _)();
            if (C[0] === On)
              return C;
            S = typeof C[1] == "number" ? C[1] : S + l;
          }
        }
      }
      if (u && g) {
        const I = ys(u(p, h, d));
        if (I[0] === Vi)
          throw new Error(
            "Unexpected value `" + I[0] + "` from `exit`, expected `CONTINUE`, `EXIT`, index, or nothing"
          );
        if (I[0] === On || typeof I[1] == "number")
          return I;
      }
      return w;
    }
  }
}
function ys(e) {
  return Array.isArray(e) ? e : typeof e == "number" ? [r1, e] : e == null ? zc : [e];
}
function Dr(e, t, n, r) {
  let i, o, a;
  o = /** @type {Visitor | Visitors} */
  t, a = n, typeof o == "function" ? qi(e, i, Ji(o), a) : qi(e, i, i1(o), a);
}
function i1(e) {
  return !e || typeof e != "object" ? e : {
    enter: typeof e.enter == "function" ? Ji(e.enter) : e.enter,
    exit: typeof e.exit == "function" ? Ji(e.exit) : e.exit
  };
}
function Ji(e) {
  return t;
  function t(n, r, i) {
    return e(n, i, r[r.length - 1]);
  }
}
const Wi = {}.hasOwnProperty, o1 = {};
function a1(e, t) {
  const n = t || o1, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), a = { ...B0, ...n.handlers }, s = {
    all: c,
    applyData: l1,
    definitionById: r,
    footnoteById: i,
    footnoteCounts: o,
    footnoteOrder: [],
    handlers: a,
    one: u,
    options: n,
    patch: s1,
    wrap: c1
  };
  return Dr(e, function(l) {
    if (l.type === "definition" || l.type === "footnoteDefinition") {
      const f = l.type === "definition" ? r : i, p = String(l.identifier).toUpperCase();
      f.has(p) || f.set(p, l);
    }
  }), s;
  function u(l, f) {
    const p = l.type, d = s.handlers[p];
    if (Wi.call(s.handlers, p) && d)
      return d(s, l, f);
    if (s.options.passThrough && s.options.passThrough.includes(p)) {
      if ("children" in l) {
        const { children: m, ...v } = l, g = xr(v);
        return g.children = s.all(l), g;
      }
      return xr(l);
    }
    return (s.options.unknownHandler || u1)(s, l, f);
  }
  function c(l) {
    const f = [];
    if ("children" in l) {
      const p = l.children;
      let d = -1;
      for (; ++d < p.length; ) {
        const h = s.one(p[d], l);
        if (h) {
          if (d && p[d - 1].type === "break" && (!Array.isArray(h) && h.type === "text" && (h.value = bs(h.value)), !Array.isArray(h) && h.type === "element")) {
            const m = h.children[0];
            m && m.type === "text" && (m.value = bs(m.value));
          }
          Array.isArray(h) ? f.push(...h) : f.push(h);
        }
      }
    }
    return f;
  }
}
function s1(e, t) {
  e.position && (t.position = Yv(e));
}
function l1(e, t) {
  let n = t;
  if (e && e.data) {
    const r = e.data.hName, i = e.data.hChildren, o = e.data.hProperties;
    if (typeof r == "string")
      if (n.type === "element")
        n.tagName = r;
      else {
        const a = "children" in n ? n.children : [n];
        n = { type: "element", tagName: r, properties: {}, children: a };
      }
    n.type === "element" && o && Object.assign(n.properties, xr(o)), "children" in n && n.children && i !== null && i !== void 0 && (n.children = i);
  }
  return n;
}
function u1(e, t) {
  const n = t.data || {}, r = "value" in t && !(Wi.call(n, "hProperties") || Wi.call(n, "hChildren")) ? { type: "text", value: t.value } : {
    type: "element",
    tagName: "div",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, r), e.applyData(t, r);
}
function c1(e, t) {
  const n = [];
  let r = -1;
  for (t && n.push({ type: "text", value: `
` }); ++r < e.length; )
    r && n.push({ type: "text", value: `
` }), n.push(e[r]);
  return t && e.length > 0 && n.push({ type: "text", value: `
` }), n;
}
function bs(e) {
  let t = 0, n = e.charCodeAt(t);
  for (; n === 9 || n === 32; )
    t++, n = e.charCodeAt(t);
  return e.slice(t);
}
function vs(e, t) {
  const n = a1(e, t), r = n.one(e, void 0), i = G0(n), o = Array.isArray(r) ? { type: "root", children: r } : r || { type: "root", children: [] };
  return i && o.children.push({ type: "text", value: `
` }, i), o;
}
function f1(e, t) {
  return e && "run" in e ? async function(n, r) {
    const i = (
      /** @type {HastRoot} */
      vs(n, { file: r, ...t })
    );
    await e.run(i, r);
  } : function(n, r) {
    return (
      /** @type {HastRoot} */
      vs(n, { file: r, ...e || t })
    );
  };
}
function ks(e) {
  if (e)
    throw e;
}
var ur = Object.prototype.hasOwnProperty, Tc = Object.prototype.toString, ws = Object.defineProperty, xs = Object.getOwnPropertyDescriptor, _s = function(t) {
  return typeof Array.isArray == "function" ? Array.isArray(t) : Tc.call(t) === "[object Array]";
}, Ss = function(t) {
  if (!t || Tc.call(t) !== "[object Object]")
    return !1;
  var n = ur.call(t, "constructor"), r = t.constructor && t.constructor.prototype && ur.call(t.constructor.prototype, "isPrototypeOf");
  if (t.constructor && !n && !r)
    return !1;
  var i;
  for (i in t)
    ;
  return typeof i > "u" || ur.call(t, i);
}, Is = function(t, n) {
  ws && n.name === "__proto__" ? ws(t, n.name, {
    enumerable: !0,
    configurable: !0,
    value: n.newValue,
    writable: !0
  }) : t[n.name] = n.newValue;
}, Es = function(t, n) {
  if (n === "__proto__")
    if (ur.call(t, n)) {
      if (xs)
        return xs(t, n).value;
    } else return;
  return t[n];
}, d1 = function e() {
  var t, n, r, i, o, a, s = arguments[0], u = 1, c = arguments.length, l = !1;
  for (typeof s == "boolean" && (l = s, s = arguments[1] || {}, u = 2), (s == null || typeof s != "object" && typeof s != "function") && (s = {}); u < c; ++u)
    if (t = arguments[u], t != null)
      for (n in t)
        r = Es(s, n), i = Es(t, n), s !== i && (l && i && (Ss(i) || (o = _s(i))) ? (o ? (o = !1, a = r && _s(r) ? r : []) : a = r && Ss(r) ? r : {}, Is(s, { name: n, newValue: e(l, a, i) })) : typeof i < "u" && Is(s, { name: n, newValue: i }));
  return s;
};
const ii = /* @__PURE__ */ Au(d1);
function Hi(e) {
  if (typeof e != "object" || e === null)
    return !1;
  const t = Object.getPrototypeOf(e);
  return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
function p1() {
  const e = [], t = { run: n, use: r };
  return t;
  function n(...i) {
    let o = -1;
    const a = i.pop();
    if (typeof a != "function")
      throw new TypeError("Expected function as last argument, not " + a);
    s(null, ...i);
    function s(u, ...c) {
      const l = e[++o];
      let f = -1;
      if (u) {
        a(u);
        return;
      }
      for (; ++f < i.length; )
        (c[f] === null || c[f] === void 0) && (c[f] = i[f]);
      i = c, l ? h1(l, s)(...c) : a(null, ...c);
    }
  }
  function r(i) {
    if (typeof i != "function")
      throw new TypeError(
        "Expected `middelware` to be a function, not " + i
      );
    return e.push(i), t;
  }
}
function h1(e, t) {
  let n;
  return r;
  function r(...a) {
    const s = e.length > a.length;
    let u;
    s && a.push(i);
    try {
      u = e.apply(this, a);
    } catch (c) {
      const l = (
        /** @type {Error} */
        c
      );
      if (s && n)
        throw l;
      return i(l);
    }
    s || (u && u.then && typeof u.then == "function" ? u.then(o, i) : u instanceof Error ? i(u) : o(u));
  }
  function i(a, ...s) {
    n || (n = !0, t(a, ...s));
  }
  function o(a) {
    i(null, a);
  }
}
const at = { basename: m1, dirname: g1, extname: y1, join: b1, sep: "/" };
function m1(e, t) {
  if (t !== void 0 && typeof t != "string")
    throw new TypeError('"ext" argument must be a string');
  Un(e);
  let n = 0, r = -1, i = e.length, o;
  if (t === void 0 || t.length === 0 || t.length > e.length) {
    for (; i--; )
      if (e.codePointAt(i) === 47) {
        if (o) {
          n = i + 1;
          break;
        }
      } else r < 0 && (o = !0, r = i + 1);
    return r < 0 ? "" : e.slice(n, r);
  }
  if (t === e)
    return "";
  let a = -1, s = t.length - 1;
  for (; i--; )
    if (e.codePointAt(i) === 47) {
      if (o) {
        n = i + 1;
        break;
      }
    } else
      a < 0 && (o = !0, a = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = a));
  return n === r ? r = a : r < 0 && (r = e.length), e.slice(n, r);
}
function g1(e) {
  if (Un(e), e.length === 0)
    return ".";
  let t = -1, n = e.length, r;
  for (; --n; )
    if (e.codePointAt(n) === 47) {
      if (r) {
        t = n;
        break;
      }
    } else r || (r = !0);
  return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function y1(e) {
  Un(e);
  let t = e.length, n = -1, r = 0, i = -1, o = 0, a;
  for (; t--; ) {
    const s = e.codePointAt(t);
    if (s === 47) {
      if (a) {
        r = t + 1;
        break;
      }
      continue;
    }
    n < 0 && (a = !0, n = t + 1), s === 46 ? i < 0 ? i = t : o !== 1 && (o = 1) : i > -1 && (o = -1);
  }
  return i < 0 || n < 0 || // We saw a non-dot character immediately before the dot.
  o === 0 || // The (right-most) trimmed path component is exactly `..`.
  o === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function b1(...e) {
  let t = -1, n;
  for (; ++t < e.length; )
    Un(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
  return n === void 0 ? "." : v1(n);
}
function v1(e) {
  Un(e);
  const t = e.codePointAt(0) === 47;
  let n = k1(e, !t);
  return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function k1(e, t) {
  let n = "", r = 0, i = -1, o = 0, a = -1, s, u;
  for (; ++a <= e.length; ) {
    if (a < e.length)
      s = e.codePointAt(a);
    else {
      if (s === 47)
        break;
      s = 47;
    }
    if (s === 47) {
      if (!(i === a - 1 || o === 1)) if (i !== a - 1 && o === 2) {
        if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
          if (n.length > 2) {
            if (u = n.lastIndexOf("/"), u !== n.length - 1) {
              u < 0 ? (n = "", r = 0) : (n = n.slice(0, u), r = n.length - 1 - n.lastIndexOf("/")), i = a, o = 0;
              continue;
            }
          } else if (n.length > 0) {
            n = "", r = 0, i = a, o = 0;
            continue;
          }
        }
        t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
      } else
        n.length > 0 ? n += "/" + e.slice(i + 1, a) : n = e.slice(i + 1, a), r = a - i - 1;
      i = a, o = 0;
    } else s === 46 && o > -1 ? o++ : o = -1;
  }
  return n;
}
function Un(e) {
  if (typeof e != "string")
    throw new TypeError(
      "Path must be a string. Received " + JSON.stringify(e)
    );
}
const w1 = { cwd: x1 };
function x1() {
  return "/";
}
function Ki(e) {
  return !!(e !== null && typeof e == "object" && "href" in e && e.href && "protocol" in e && e.protocol && // @ts-expect-error: indexing is fine.
  e.auth === void 0);
}
function _1(e) {
  if (typeof e == "string")
    e = new URL(e);
  else if (!Ki(e)) {
    const t = new TypeError(
      'The "path" argument must be of type string or an instance of URL. Received `' + e + "`"
    );
    throw t.code = "ERR_INVALID_ARG_TYPE", t;
  }
  if (e.protocol !== "file:") {
    const t = new TypeError("The URL must be of scheme file");
    throw t.code = "ERR_INVALID_URL_SCHEME", t;
  }
  return S1(e);
}
function S1(e) {
  if (e.hostname !== "") {
    const r = new TypeError(
      'File URL host must be "localhost" or empty on darwin'
    );
    throw r.code = "ERR_INVALID_FILE_URL_HOST", r;
  }
  const t = e.pathname;
  let n = -1;
  for (; ++n < t.length; )
    if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
      const r = t.codePointAt(n + 2);
      if (r === 70 || r === 102) {
        const i = new TypeError(
          "File URL path must not include encoded / characters"
        );
        throw i.code = "ERR_INVALID_FILE_URL_PATH", i;
      }
    }
  return decodeURIComponent(t);
}
const oi = (
  /** @type {const} */
  [
    "history",
    "path",
    "basename",
    "stem",
    "extname",
    "dirname"
  ]
);
class Oc {
  /**
   * Create a new virtual file.
   *
   * `options` is treated as:
   *
   * *   `string` or `Uint8Array` — `{value: options}`
   * *   `URL` — `{path: options}`
   * *   `VFile` — shallow copies its data over to the new file
   * *   `object` — all fields are shallow copied over to the new file
   *
   * Path related fields are set in the following order (least specific to
   * most specific): `history`, `path`, `basename`, `stem`, `extname`,
   * `dirname`.
   *
   * You cannot set `dirname` or `extname` without setting either `history`,
   * `path`, `basename`, or `stem` too.
   *
   * @param {Compatible | null | undefined} [value]
   *   File value.
   * @returns
   *   New instance.
   */
  constructor(t) {
    let n;
    t ? Ki(t) ? n = { path: t } : typeof t == "string" || I1(t) ? n = { value: t } : n = t : n = {}, this.cwd = "cwd" in n ? "" : w1.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
    let r = -1;
    for (; ++r < oi.length; ) {
      const o = oi[r];
      o in n && n[o] !== void 0 && n[o] !== null && (this[o] = o === "history" ? [...n[o]] : n[o]);
    }
    let i;
    for (i in n)
      oi.includes(i) || (this[i] = n[i]);
  }
  /**
   * Get the basename (including extname) (example: `'index.min.js'`).
   *
   * @returns {string | undefined}
   *   Basename.
   */
  get basename() {
    return typeof this.path == "string" ? at.basename(this.path) : void 0;
  }
  /**
   * Set basename (including extname) (`'index.min.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} basename
   *   Basename.
   * @returns {undefined}
   *   Nothing.
   */
  set basename(t) {
    si(t, "basename"), ai(t, "basename"), this.path = at.join(this.dirname || "", t);
  }
  /**
   * Get the parent path (example: `'~'`).
   *
   * @returns {string | undefined}
   *   Dirname.
   */
  get dirname() {
    return typeof this.path == "string" ? at.dirname(this.path) : void 0;
  }
  /**
   * Set the parent path (example: `'~'`).
   *
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} dirname
   *   Dirname.
   * @returns {undefined}
   *   Nothing.
   */
  set dirname(t) {
    Cs(this.basename, "dirname"), this.path = at.join(t || "", this.basename);
  }
  /**
   * Get the extname (including dot) (example: `'.js'`).
   *
   * @returns {string | undefined}
   *   Extname.
   */
  get extname() {
    return typeof this.path == "string" ? at.extname(this.path) : void 0;
  }
  /**
   * Set the extname (including dot) (example: `'.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} extname
   *   Extname.
   * @returns {undefined}
   *   Nothing.
   */
  set extname(t) {
    if (ai(t, "extname"), Cs(this.dirname, "extname"), t) {
      if (t.codePointAt(0) !== 46)
        throw new Error("`extname` must start with `.`");
      if (t.includes(".", 1))
        throw new Error("`extname` cannot contain multiple dots");
    }
    this.path = at.join(this.dirname, this.stem + (t || ""));
  }
  /**
   * Get the full path (example: `'~/index.min.js'`).
   *
   * @returns {string}
   *   Path.
   */
  get path() {
    return this.history[this.history.length - 1];
  }
  /**
   * Set the full path (example: `'~/index.min.js'`).
   *
   * Cannot be nullified.
   * You can set a file URL (a `URL` object with a `file:` protocol) which will
   * be turned into a path with `url.fileURLToPath`.
   *
   * @param {URL | string} path
   *   Path.
   * @returns {undefined}
   *   Nothing.
   */
  set path(t) {
    Ki(t) && (t = _1(t)), si(t, "path"), this.path !== t && this.history.push(t);
  }
  /**
   * Get the stem (basename w/o extname) (example: `'index.min'`).
   *
   * @returns {string | undefined}
   *   Stem.
   */
  get stem() {
    return typeof this.path == "string" ? at.basename(this.path, this.extname) : void 0;
  }
  /**
   * Set the stem (basename w/o extname) (example: `'index.min'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} stem
   *   Stem.
   * @returns {undefined}
   *   Nothing.
   */
  set stem(t) {
    si(t, "stem"), ai(t, "stem"), this.path = at.join(this.dirname || "", t + (this.extname || ""));
  }
  // Normal prototypal methods.
  /**
   * Create a fatal message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `true` (error; file not usable)
   * and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {never}
   *   Never.
   * @throws {VFileMessage}
   *   Message.
   */
  fail(t, n, r) {
    const i = this.message(t, n, r);
    throw i.fatal = !0, i;
  }
  /**
   * Create an info message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `undefined` (info; change
   * likely not needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  info(t, n, r) {
    const i = this.message(t, n, r);
    return i.fatal = void 0, i;
  }
  /**
   * Create a message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `false` (warning; change may be
   * needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  message(t, n, r) {
    const i = new Tr(
      // @ts-expect-error: the overloads are fine.
      t,
      n,
      r
    );
    return this.path && (i.name = this.path + ":" + i.name, i.file = this.path), i.fatal = !1, this.messages.push(i), i;
  }
  /**
   * Serialize the file.
   *
   * > **Note**: which encodings are supported depends on the engine.
   * > For info on Node.js, see:
   * > <https://nodejs.org/api/util.html#whatwg-supported-encodings>.
   *
   * @param {string | null | undefined} [encoding='utf8']
   *   Character encoding to understand `value` as when it’s a `Uint8Array`
   *   (default: `'utf-8'`).
   * @returns {string}
   *   Serialized file.
   */
  toString(t) {
    return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(t || void 0).decode(this.value);
  }
}
function ai(e, t) {
  if (e && e.includes(at.sep))
    throw new Error(
      "`" + t + "` cannot be a path: did not expect `" + at.sep + "`"
    );
}
function si(e, t) {
  if (!e)
    throw new Error("`" + t + "` cannot be empty");
}
function Cs(e, t) {
  if (!e)
    throw new Error("Setting `" + t + "` requires `path` to be set too");
}
function I1(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const E1 = (
  /**
   * @type {new <Parameters extends Array<unknown>, Result>(property: string | symbol) => (...parameters: Parameters) => Result}
   */
  /** @type {unknown} */
  /**
   * @this {Function}
   * @param {string | symbol} property
   * @returns {(...parameters: Array<unknown>) => unknown}
   */
  function(e) {
    const r = (
      /** @type {Record<string | symbol, Function>} */
      // Prototypes do exist.
      // type-coverage:ignore-next-line
      this.constructor.prototype
    ), i = r[e], o = function() {
      return i.apply(o, arguments);
    };
    return Object.setPrototypeOf(o, r), o;
  }
), C1 = {}.hasOwnProperty;
class zo extends E1 {
  /**
   * Create a processor.
   */
  constructor() {
    super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = p1();
  }
  /**
   * Copy a processor.
   *
   * @deprecated
   *   This is a private internal method and should not be used.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   New *unfrozen* processor ({@linkcode Processor}) that is
   *   configured to work the same as its ancestor.
   *   When the descendant processor is configured in the future it does not
   *   affect the ancestral processor.
   */
  copy() {
    const t = (
      /** @type {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>} */
      new zo()
    );
    let n = -1;
    for (; ++n < this.attachers.length; ) {
      const r = this.attachers[n];
      t.use(...r);
    }
    return t.data(ii(!0, {}, this.namespace)), t;
  }
  /**
   * Configure the processor with info available to all plugins.
   * Information is stored in an object.
   *
   * Typically, options can be given to a specific plugin, but sometimes it
   * makes sense to have information shared with several plugins.
   * For example, a list of HTML elements that are self-closing, which is
   * needed during all phases.
   *
   * > **Note**: setting information cannot occur on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * > **Note**: to register custom data in TypeScript, augment the
   * > {@linkcode Data} interface.
   *
   * @example
   *   This example show how to get and set info:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   const processor = unified().data('alpha', 'bravo')
   *
   *   processor.data('alpha') // => 'bravo'
   *
   *   processor.data() // => {alpha: 'bravo'}
   *
   *   processor.data({charlie: 'delta'})
   *
   *   processor.data() // => {charlie: 'delta'}
   *   ```
   *
   * @template {keyof Data} Key
   *
   * @overload
   * @returns {Data}
   *
   * @overload
   * @param {Data} dataset
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Key} key
   * @returns {Data[Key]}
   *
   * @overload
   * @param {Key} key
   * @param {Data[Key]} value
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @param {Data | Key} [key]
   *   Key to get or set, or entire dataset to set, or nothing to get the
   *   entire dataset (optional).
   * @param {Data[Key]} [value]
   *   Value to set (optional).
   * @returns {unknown}
   *   The current processor when setting, the value at `key` when getting, or
   *   the entire dataset when getting without key.
   */
  data(t, n) {
    return typeof t == "string" ? arguments.length === 2 ? (ci("data", this.frozen), this.namespace[t] = n, this) : C1.call(this.namespace, t) && this.namespace[t] || void 0 : t ? (ci("data", this.frozen), this.namespace = t, this) : this.namespace;
  }
  /**
   * Freeze a processor.
   *
   * Frozen processors are meant to be extended and not to be configured
   * directly.
   *
   * When a processor is frozen it cannot be unfrozen.
   * New processors working the same way can be created by calling the
   * processor.
   *
   * It’s possible to freeze processors explicitly by calling `.freeze()`.
   * Processors freeze automatically when `.parse()`, `.run()`, `.runSync()`,
   * `.stringify()`, `.process()`, or `.processSync()` are called.
   *
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   The current processor.
   */
  freeze() {
    if (this.frozen)
      return this;
    const t = (
      /** @type {Processor} */
      /** @type {unknown} */
      this
    );
    for (; ++this.freezeIndex < this.attachers.length; ) {
      const [n, ...r] = this.attachers[this.freezeIndex];
      if (r[0] === !1)
        continue;
      r[0] === !0 && (r[0] = void 0);
      const i = n.call(t, ...r);
      typeof i == "function" && this.transformers.use(i);
    }
    return this.frozen = !0, this.freezeIndex = Number.POSITIVE_INFINITY, this;
  }
  /**
   * Parse text to a syntax tree.
   *
   * > **Note**: `parse` freezes the processor if not already *frozen*.
   *
   * > **Note**: `parse` performs the parse phase, not the run phase or other
   * > phases.
   *
   * @param {Compatible | undefined} [file]
   *   file to parse (optional); typically `string` or `VFile`; any value
   *   accepted as `x` in `new VFile(x)`.
   * @returns {ParseTree extends undefined ? Node : ParseTree}
   *   Syntax tree representing `file`.
   */
  parse(t) {
    this.freeze();
    const n = Xn(t), r = this.parser || this.Parser;
    return li("parse", r), r(String(n), n);
  }
  /**
   * Process the given file as configured on the processor.
   *
   * > **Note**: `process` freezes the processor if not already *frozen*.
   *
   * > **Note**: `process` performs the parse, run, and stringify phases.
   *
   * @overload
   * @param {Compatible | undefined} file
   * @param {ProcessCallback<VFileWithOutput<CompileResult>>} done
   * @returns {undefined}
   *
   * @overload
   * @param {Compatible | undefined} [file]
   * @returns {Promise<VFileWithOutput<CompileResult>>}
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`]; any value accepted as
   *   `x` in `new VFile(x)`.
   * @param {ProcessCallback<VFileWithOutput<CompileResult>> | undefined} [done]
   *   Callback (optional).
   * @returns {Promise<VFile> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise a promise, rejected with a fatal error or resolved with the
   *   processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  process(t, n) {
    const r = this;
    return this.freeze(), li("process", this.parser || this.Parser), ui("process", this.compiler || this.Compiler), n ? i(void 0, n) : new Promise(i);
    function i(o, a) {
      const s = Xn(t), u = (
        /** @type {HeadTree extends undefined ? Node : HeadTree} */
        /** @type {unknown} */
        r.parse(s)
      );
      r.run(u, s, function(l, f, p) {
        if (l || !f || !p)
          return c(l);
        const d = (
          /** @type {CompileTree extends undefined ? Node : CompileTree} */
          /** @type {unknown} */
          f
        ), h = r.stringify(d, p);
        T1(h) ? p.value = h : p.result = h, c(
          l,
          /** @type {VFileWithOutput<CompileResult>} */
          p
        );
      });
      function c(l, f) {
        l || !f ? a(l) : o ? o(f) : n(void 0, f);
      }
    }
  }
  /**
   * Process the given file as configured on the processor.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `processSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `processSync` performs the parse, run, and stringify phases.
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`; any value accepted as
   *   `x` in `new VFile(x)`.
   * @returns {VFileWithOutput<CompileResult>}
   *   The processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  processSync(t) {
    let n = !1, r;
    return this.freeze(), li("processSync", this.parser || this.Parser), ui("processSync", this.compiler || this.Compiler), this.process(t, i), zs("processSync", "process", n), r;
    function i(o, a) {
      n = !0, ks(o), r = a;
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * > **Note**: `run` freezes the processor if not already *frozen*.
   *
   * > **Note**: `run` performs the run phase, not other phases.
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} file
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} [file]
   * @returns {Promise<TailTree extends undefined ? Node : TailTree>}
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {(
   *   RunCallback<TailTree extends undefined ? Node : TailTree> |
   *   Compatible
   * )} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} [done]
   *   Callback (optional).
   * @returns {Promise<TailTree extends undefined ? Node : TailTree> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise, a promise rejected with a fatal error or resolved with the
   *   transformed tree.
   */
  run(t, n, r) {
    As(t), this.freeze();
    const i = this.transformers;
    return !r && typeof n == "function" && (r = n, n = void 0), r ? o(void 0, r) : new Promise(o);
    function o(a, s) {
      const u = Xn(n);
      i.run(t, u, c);
      function c(l, f, p) {
        const d = (
          /** @type {TailTree extends undefined ? Node : TailTree} */
          f || t
        );
        l ? s(l) : a ? a(d) : r(void 0, d, p);
      }
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `runSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `runSync` performs the run phase, not other phases.
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {TailTree extends undefined ? Node : TailTree}
   *   Transformed tree.
   */
  runSync(t, n) {
    let r = !1, i;
    return this.run(t, n, o), zs("runSync", "run", r), i;
    function o(a, s) {
      ks(a), i = s, r = !0;
    }
  }
  /**
   * Compile a syntax tree.
   *
   * > **Note**: `stringify` freezes the processor if not already *frozen*.
   *
   * > **Note**: `stringify` performs the stringify phase, not the run phase
   * > or other phases.
   *
   * @param {CompileTree extends undefined ? Node : CompileTree} tree
   *   Tree to compile.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {CompileResult extends undefined ? Value : CompileResult}
   *   Textual representation of the tree (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most compilers
   *   > return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  stringify(t, n) {
    this.freeze();
    const r = Xn(n), i = this.compiler || this.Compiler;
    return ui("stringify", i), As(t), i(t, r);
  }
  /**
   * Configure the processor to use a plugin, a list of usable values, or a
   * preset.
   *
   * If the processor is already using a plugin, the previous plugin
   * configuration is changed based on the options that are passed in.
   * In other words, the plugin is not added a second time.
   *
   * > **Note**: `use` cannot be called on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * @example
   *   There are many ways to pass plugins to `.use()`.
   *   This example gives an overview:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   unified()
   *     // Plugin with options:
   *     .use(pluginA, {x: true, y: true})
   *     // Passing the same plugin again merges configuration (to `{x: true, y: false, z: true}`):
   *     .use(pluginA, {y: false, z: true})
   *     // Plugins:
   *     .use([pluginB, pluginC])
   *     // Two plugins, the second with options:
   *     .use([pluginD, [pluginE, {}]])
   *     // Preset with plugins and settings:
   *     .use({plugins: [pluginF, [pluginG, {}]], settings: {position: false}})
   *     // Settings only:
   *     .use({settings: {position: false}})
   *   ```
   *
   * @template {Array<unknown>} [Parameters=[]]
   * @template {Node | string | undefined} [Input=undefined]
   * @template [Output=Input]
   *
   * @overload
   * @param {Preset | null | undefined} [preset]
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {PluggableList} list
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Plugin<Parameters, Input, Output>} plugin
   * @param {...(Parameters | [boolean])} parameters
   * @returns {UsePlugin<ParseTree, HeadTree, TailTree, CompileTree, CompileResult, Input, Output>}
   *
   * @param {PluggableList | Plugin | Preset | null | undefined} value
   *   Usable value.
   * @param {...unknown} parameters
   *   Parameters, when a plugin is given as a usable value.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   Current processor.
   */
  use(t, ...n) {
    const r = this.attachers, i = this.namespace;
    if (ci("use", this.frozen), t != null) if (typeof t == "function")
      u(t, n);
    else if (typeof t == "object")
      Array.isArray(t) ? s(t) : a(t);
    else
      throw new TypeError("Expected usable value, not `" + t + "`");
    return this;
    function o(c) {
      if (typeof c == "function")
        u(c, []);
      else if (typeof c == "object")
        if (Array.isArray(c)) {
          const [l, ...f] = (
            /** @type {PluginTuple<Array<unknown>>} */
            c
          );
          u(l, f);
        } else
          a(c);
      else
        throw new TypeError("Expected usable value, not `" + c + "`");
    }
    function a(c) {
      if (!("plugins" in c) && !("settings" in c))
        throw new Error(
          "Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither"
        );
      s(c.plugins), c.settings && (i.settings = ii(!0, i.settings, c.settings));
    }
    function s(c) {
      let l = -1;
      if (c != null) if (Array.isArray(c))
        for (; ++l < c.length; ) {
          const f = c[l];
          o(f);
        }
      else
        throw new TypeError("Expected a list of plugins, not `" + c + "`");
    }
    function u(c, l) {
      let f = -1, p = -1;
      for (; ++f < r.length; )
        if (r[f][0] === c) {
          p = f;
          break;
        }
      if (p === -1)
        r.push([c, ...l]);
      else if (l.length > 0) {
        let [d, ...h] = l;
        const m = r[p][1];
        Hi(m) && Hi(d) && (d = ii(!0, m, d)), r[p] = [c, d, ...h];
      }
    }
  }
}
const A1 = new zo().freeze();
function li(e, t) {
  if (typeof t != "function")
    throw new TypeError("Cannot `" + e + "` without `parser`");
}
function ui(e, t) {
  if (typeof t != "function")
    throw new TypeError("Cannot `" + e + "` without `compiler`");
}
function ci(e, t) {
  if (t)
    throw new Error(
      "Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`."
    );
}
function As(e) {
  if (!Hi(e) || typeof e.type != "string")
    throw new TypeError("Expected node, got `" + e + "`");
}
function zs(e, t, n) {
  if (!n)
    throw new Error(
      "`" + e + "` finished async. Use `" + t + "` instead"
    );
}
function Xn(e) {
  return z1(e) ? e : new Oc(e);
}
function z1(e) {
  return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function T1(e) {
  return typeof e == "string" || O1(e);
}
function O1(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const P1 = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md", Ts = [], Os = { allowDangerousHtml: !0 }, M1 = /^(https?|ircs?|mailto|xmpp)$/i, R1 = [
  { from: "astPlugins", id: "remove-buggy-html-in-markdown-parser" },
  { from: "allowDangerousHtml", id: "remove-buggy-html-in-markdown-parser" },
  {
    from: "allowNode",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowElement"
  },
  {
    from: "allowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowedElements"
  },
  { from: "className", id: "remove-classname" },
  {
    from: "disallowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "disallowedElements"
  },
  { from: "escapeHtml", id: "remove-buggy-html-in-markdown-parser" },
  { from: "includeElementIndex", id: "#remove-includeelementindex" },
  {
    from: "includeNodeIndex",
    id: "change-includenodeindex-to-includeelementindex"
  },
  { from: "linkTarget", id: "remove-linktarget" },
  { from: "plugins", id: "change-plugins-to-remarkplugins", to: "remarkPlugins" },
  { from: "rawSourcePos", id: "#remove-rawsourcepos" },
  { from: "renderers", id: "change-renderers-to-components", to: "components" },
  { from: "source", id: "change-source-to-children", to: "children" },
  { from: "sourcePos", id: "#remove-sourcepos" },
  { from: "transformImageUri", id: "#add-urltransform", to: "urlTransform" },
  { from: "transformLinkUri", id: "#add-urltransform", to: "urlTransform" }
];
function $1(e) {
  const t = D1(e), n = N1(e);
  return L1(t.runSync(t.parse(n), n), e);
}
function D1(e) {
  const t = e.rehypePlugins || Ts, n = e.remarkPlugins || Ts, r = e.remarkRehypeOptions ? { ...e.remarkRehypeOptions, ...Os } : Os;
  return A1().use(g0).use(n).use(f1, r).use(t);
}
function N1(e) {
  const t = e.children || "", n = new Oc();
  return typeof t == "string" && (n.value = t), n;
}
function L1(e, t) {
  const n = t.allowedElements, r = t.allowElement, i = t.components, o = t.disallowedElements, a = t.skipHtml, s = t.unwrapDisallowed, u = t.urlTransform || F1;
  for (const l of R1)
    Object.hasOwn(t, l.from) && ("" + l.from + (l.to ? "use `" + l.to + "` instead" : "remove it") + P1 + l.id, void 0);
  return Dr(e, c), nk(e, {
    Fragment: Nn,
    components: i,
    ignoreInvalidStyle: !0,
    jsx: T,
    jsxs: Q,
    passKeys: !0,
    passNode: !0
  });
  function c(l, f, p) {
    if (l.type === "raw" && p && typeof f == "number")
      return a ? p.children.splice(f, 1) : p.children[f] = { type: "text", value: l.value }, f;
    if (l.type === "element") {
      let d;
      for (d in ti)
        if (Object.hasOwn(ti, d) && Object.hasOwn(l.properties, d)) {
          const h = l.properties[d], m = ti[d];
          (m === null || m.includes(l.tagName)) && (l.properties[d] = u(String(h || ""), d, l));
        }
    }
    if (l.type === "element") {
      let d = n ? !n.includes(l.tagName) : o ? o.includes(l.tagName) : !1;
      if (!d && r && typeof f == "number" && (d = !r(l, f, p)), d && p && typeof f == "number")
        return s && l.children ? p.children.splice(f, 1, ...l.children) : p.children.splice(f, 1), f;
    }
  }
}
function F1(e) {
  const t = e.indexOf(":"), n = e.indexOf("?"), r = e.indexOf("#"), i = e.indexOf("/");
  return (
    // If there is no protocol, it’s relative.
    t === -1 || // If the first colon is after a `?`, `#`, or `/`, it’s not a protocol.
    i !== -1 && t > i || n !== -1 && t > n || r !== -1 && t > r || // It is a protocol, it should be allowed.
    M1.test(e.slice(0, t)) ? e : ""
  );
}
function Ps(e, t) {
  const n = String(e);
  if (typeof t != "string")
    throw new TypeError("Expected character");
  let r = 0, i = n.indexOf(t);
  for (; i !== -1; )
    r++, i = n.indexOf(t, i + t.length);
  return r;
}
function j1(e) {
  if (typeof e != "string")
    throw new TypeError("Expected a string");
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
function Z1(e, t, n) {
  const i = Rr((n || {}).ignore || []), o = B1(t);
  let a = -1;
  for (; ++a < o.length; )
    qi(e, s);
  function s(c, l, f) {
    if (c.type === "text" && typeof f == "number")
      return u(c, l, f);
    if (i(c, f, l[l.length - 1])) return Vi;
  }
  function u(c, l, f) {
    const p = l[l.length - 1], d = o[a][0], h = o[a][1];
    let m = 0, v = !1, g = [];
    d.lastIndex = 0;
    let w = d.exec(c.value);
    for (; w; ) {
      const S = w.index, _ = {
        index: w.index,
        input: w.input,
        stack: [...l, c]
      };
      let y = h(...w, _);
      if (typeof y == "string" && (y = y.length > 0 ? { type: "text", value: y } : void 0), y === !1)
        d.lastIndex = S + 1;
      else {
        if (m !== S && I({ type: "text", value: c.value.slice(m, S) }), Array.isArray(y))
          for (const C of y) I(C);
        else y && I(y);
        m = S + w[0].length, v = !0;
      }
      if (!d.global)
        break;
      w = d.exec(c.value);
    }
    return v ? (m < c.value.length && I({ type: "text", value: c.value.slice(m) }), p.children.splice(f, 1, ...g)) : g = [c], f + g.length;
    function I(S) {
      const _ = g[g.length - 1];
      _ && _.type === "text" && S.type === "text" ? _.value += S.value : g.push(S);
    }
  }
}
function B1(e) {
  if (!Array.isArray(e))
    throw new TypeError("Expected find and replace tuple or list of tuples");
  const t = [], n = !e[0] || Array.isArray(e[0]) ? (
    /** @type {FindAndReplaceList} */
    e
  ) : [
    /** @type {FindAndReplaceTuple} */
    e
  ];
  let r = -1;
  for (; ++r < n.length; ) {
    const i = n[r];
    t.push([U1(i[0]), V1(i[1])]);
  }
  return t;
}
function U1(e) {
  return typeof e == "string" ? new RegExp(j1(e), "g") : e;
}
function V1(e) {
  return typeof e == "function" ? e : function() {
    return e;
  };
}
const fi = "phrasing", di = ["autolink", "link", "image", "label"];
function q1() {
  return {
    transforms: [X1],
    enter: {
      literalAutolink: W1,
      literalAutolinkEmail: pi,
      literalAutolinkHttp: pi,
      literalAutolinkWww: pi
    },
    exit: {
      literalAutolink: G1,
      literalAutolinkEmail: Y1,
      literalAutolinkHttp: H1,
      literalAutolinkWww: K1
    }
  };
}
function J1() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct: fi,
        notInConstruct: di
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct: fi,
        notInConstruct: di
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct: fi,
        notInConstruct: di
      }
    ]
  };
}
function W1(e) {
  this.enter(
    { type: "link", title: null, url: "", children: [], position: void 0 },
    e
  );
}
function pi(e) {
  this.config.enter.autolinkProtocol.call(this, e);
}
function H1(e) {
  this.config.exit.autolinkProtocol.call(this, e);
}
function K1(e) {
  this.config.exit.data.call(this, e);
  const t = this.stack[this.stack.length - 1];
  t.type, t.url = "http://" + this.sliceSerialize(e);
}
function Y1(e) {
  this.config.exit.autolinkEmail.call(this, e);
}
function G1(e) {
  this.exit(e);
}
function X1(e) {
  Z1(
    e,
    [
      [
        new RegExp("(?<![\\da-z])(https?:\\/\\/|www(?=\\.))([\\w-]*\\.[\\w\\-.]*)([^\\t\\n\\r ]*)", "gi"),
        Q1
      ],
      [
        new RegExp("(?<![\\w+\\-.@])xmpp:([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)(\\/(?:[\\w\\-/]|\\.(?=[\\dA-Za-z]))*)?", "g"),
        nx
      ],
      [new RegExp("(?<![\\w+\\-.@])mailto:([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)", "g"), tx],
      [
        new RegExp("(?<![\\w+\\-.]|(?:^|[^\\d@A-Za-z])(?:mailto|xmpp):)([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)", "g"),
        ex
      ]
    ],
    { ignore: ["link", "linkReference"] }
  );
}
function Q1(e, t, n, r, i) {
  if (!ox(i))
    return !1;
  let o = "";
  if (/^w/i.test(t) && (n = t + n, t = "", o = "http://"), Zn(n.charCodeAt(0)) || !rx(n))
    return !1;
  const a = ix(n + r), s = {
    type: "link",
    title: null,
    url: o + t + a[0],
    children: [{ type: "text", value: t + a[0], position: void 0 }],
    position: void 0
  };
  return a[1] ? [s, { type: "text", value: a[1], position: void 0 }] : s;
}
function ex(e, t, n) {
  return /[\d\-_]$/.test(n) ? !1 : {
    type: "link",
    title: null,
    url: "mailto:" + t + "@" + n,
    children: [{ type: "text", value: t + "@" + n, position: void 0 }],
    position: void 0
  };
}
function tx(e, t, n) {
  if (/[\d\-_]$/.test(n))
    return !1;
  const r = "mailto:" + t + "@" + n;
  return {
    type: "link",
    title: null,
    url: r,
    children: [{ type: "text", value: r, position: void 0 }],
    position: void 0
  };
}
function nx(e, t, n, r, i) {
  if (/[\d\-_]$/.test(n) || r && (!/[A-Za-z]$/.test(r) || i.input.charAt(i.index + e.length) === "@"))
    return !1;
  const o = "xmpp:" + t + "@" + n + (r || "");
  return {
    type: "link",
    title: null,
    url: o,
    children: [{ type: "text", value: o, position: void 0 }],
    position: void 0
  };
}
function rx(e) {
  const t = e.split(".");
  return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[\dA-Za-z]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[\dA-Za-z]/.test(t[t.length - 2])));
}
function ix(e) {
  let t = e.length;
  for (; t > 0; ) {
    const a = e.charCodeAt(t - 1);
    if (a === 33 || a === 34 || a === 38 || a === 39 || a === 41 || a === 44 || a === 46 || a === 58 || a === 59 || a === 60 || a === 62 || a === 63 || a === 93 || a === 125)
      t--;
    else
      break;
  }
  if (t === e.length)
    return [e, void 0];
  let n = e.slice(t);
  e = e.slice(0, t);
  let r = n.indexOf(")");
  const i = Ps(e, "(");
  let o = Ps(e, ")");
  for (; r !== -1 && i > o; )
    e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), o++;
  return [e, n];
}
function ox(e) {
  const t = e.input.charCodeAt(e.index - 1);
  return e.index === 0 || jt(t) || Zn(t);
}
Pc.peek = hx;
function ax() {
  this.buffer();
}
function sx(e) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, e);
}
function lx() {
  this.buffer();
}
function ux(e) {
  this.enter(
    { type: "footnoteDefinition", identifier: "", label: "", children: [] },
    e
  );
}
function cx(e) {
  const t = this.resume(), n = this.stack[this.stack.length - 1];
  n.type, n.identifier = et(
    this.sliceSerialize(e)
  ).toLowerCase(), n.label = t;
}
function fx(e) {
  this.exit(e);
}
function dx(e) {
  const t = this.resume(), n = this.stack[this.stack.length - 1];
  n.type, n.identifier = et(
    this.sliceSerialize(e)
  ).toLowerCase(), n.label = t;
}
function px(e) {
  this.exit(e);
}
function hx() {
  return "[";
}
function Pc(e, t, n, r) {
  const i = n.createTracker(r);
  let o = i.move("[^");
  const a = n.enter("footnoteReference"), s = n.enter("reference");
  return o += i.move(
    n.safe(n.associationId(e), { after: "]", before: o })
  ), s(), a(), o += i.move("]"), o;
}
function mx() {
  return {
    enter: {
      gfmFootnoteCallString: ax,
      gfmFootnoteCall: sx,
      gfmFootnoteDefinitionLabelString: lx,
      gfmFootnoteDefinition: ux
    },
    exit: {
      gfmFootnoteCallString: cx,
      gfmFootnoteCall: fx,
      gfmFootnoteDefinitionLabelString: dx,
      gfmFootnoteDefinition: px
    }
  };
}
function gx(e) {
  let t = !1;
  return e && e.firstLineBlank && (t = !0), {
    handlers: { footnoteDefinition: n, footnoteReference: Pc },
    // This is on by default already.
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function n(r, i, o, a) {
    const s = o.createTracker(a);
    let u = s.move("[^");
    const c = o.enter("footnoteDefinition"), l = o.enter("label");
    return u += s.move(
      o.safe(o.associationId(r), { before: u, after: "]" })
    ), l(), u += s.move("]:"), r.children && r.children.length > 0 && (s.shift(4), u += s.move(
      (t ? `
` : " ") + o.indentLines(
        o.containerFlow(r, s.current()),
        t ? Mc : yx
      )
    )), c(), u;
  }
}
function yx(e, t, n) {
  return t === 0 ? e : Mc(e, t, n);
}
function Mc(e, t, n) {
  return (n ? "" : "    ") + e;
}
const bx = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
To.attention = _x;
To.peek = Sx;
function vx() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: wx },
    exit: { strikethrough: xx }
  };
}
function kx() {
  return {
    handlers: { delete: To },
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: bx
      }
    ]
  };
}
function wx(e) {
  this.enter({ type: "delete", children: [], position: void 0 }, e);
}
function xx(e) {
  this.exit(e);
}
function To(e, t, n, r) {
  const i = n.createTracker(r), o = n.stack.includes("strikethrough") ? "~" : "~~", a = n.enter("strikethrough");
  let s = i.move(o);
  return s += n.containerPhrasing(e, {
    ...i.current(),
    before: s,
    after: "~"
  }), s += i.move(o), a(), s;
}
function _x() {
  return { construct: "strikethrough", markers: ["~"], sizes: [2, 1] };
}
function Sx() {
  return "~";
}
function Ix(e) {
  return e.length;
}
function Ex(e, t) {
  const n = t || {}, r = (n.align || []).concat(), i = n.stringLength || Ix, o = [], a = [], s = [], u = [];
  let c = 0, l = -1;
  for (; ++l < e.length; ) {
    const m = [], v = [];
    let g = -1;
    for (e[l].length > c && (c = e[l].length); ++g < e[l].length; ) {
      const w = Cx(e[l][g]);
      if (n.alignDelimiters !== !1) {
        const I = i(w);
        v[g] = I, (u[g] === void 0 || I > u[g]) && (u[g] = I);
      }
      m.push(w);
    }
    a[l] = m, s[l] = v;
  }
  let f = -1;
  if (typeof r == "object" && "length" in r)
    for (; ++f < c; )
      o[f] = Ms(r[f]);
  else {
    const m = Ms(r);
    for (; ++f < c; )
      o[f] = m;
  }
  f = -1;
  const p = [], d = [];
  for (; ++f < c; ) {
    const m = o[f];
    let v = "", g = "";
    m === 99 ? (v = ":", g = ":") : m === 108 ? v = ":" : m === 114 && (g = ":");
    let w = n.alignDelimiters === !1 ? 1 : Math.max(
      1,
      u[f] - v.length - g.length
    );
    const I = v + "-".repeat(w) + g;
    n.alignDelimiters !== !1 && (w = v.length + w + g.length, w > u[f] && (u[f] = w), d[f] = w), p[f] = I;
  }
  a.splice(1, 0, p), s.splice(1, 0, d), l = -1;
  const h = [];
  for (; ++l < a.length; ) {
    const m = a[l], v = s[l], g = n.fillRows === !1 ? Math.max(1, a[l === 1 ? 0 : l].length) : c;
    f = -1;
    const w = [];
    for (; ++f < g; ) {
      const I = m[f] || "";
      let S = "", _ = "";
      if (n.alignDelimiters !== !1) {
        const y = u[f] - (v[f] || 0), C = o[f];
        if (C === 114)
          S = " ".repeat(y);
        else if (C === 99) {
          const R = y / 2;
          y % 2 ? (S = " ".repeat(R + 0.5), _ = " ".repeat(R - 0.5)) : (S = " ".repeat(R), _ = S);
        } else
          _ = " ".repeat(y);
      }
      n.delimiterStart !== !1 && !f && w.push("|"), n.padding !== !1 && // Don’t add the opening space if we’re not aligning and the cell is
      // empty: there will be a closing space.
      !(n.alignDelimiters === !1 && I === "") && (n.delimiterStart !== !1 || f) && w.push(" "), n.alignDelimiters !== !1 && w.push(S), w.push(I), n.alignDelimiters !== !1 && w.push(_), n.padding !== !1 && w.push(" "), (n.delimiterEnd !== !1 || f !== g - 1) && w.push("|");
    }
    h.push(
      n.delimiterEnd === !1 ? w.join("").replace(/ +$/, "") : w.join("")
    );
  }
  return h.join(`
`);
}
function Cx(e) {
  return e == null ? "" : String(e);
}
function Ms(e) {
  const t = typeof e == "string" ? e.codePointAt(0) : 0;
  return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
}
const Ax = (
  /** @type {(node?: unknown) => node is Exclude<PhrasingContent, Html>} */
  Rr([
    "break",
    "delete",
    "emphasis",
    // To do: next major: removed since footnotes were added to GFM.
    "footnote",
    "footnoteReference",
    "image",
    "imageReference",
    "inlineCode",
    // Enabled by `mdast-util-math`:
    "inlineMath",
    "link",
    "linkReference",
    // Enabled by `mdast-util-mdx`:
    "mdxJsxTextElement",
    // Enabled by `mdast-util-mdx`:
    "mdxTextExpression",
    "strong",
    "text",
    // Enabled by `mdast-util-directive`:
    "textDirective"
  ])
);
function zx(e, t, n, r) {
  const i = n.enter("blockquote"), o = n.createTracker(r);
  o.move("> "), o.shift(2);
  const a = n.indentLines(
    n.containerFlow(e, o.current()),
    Tx
  );
  return i(), a;
}
function Tx(e, t, n) {
  return ">" + (n ? "" : " ") + e;
}
function Ox(e, t) {
  return Rs(e, t.inConstruct, !0) && !Rs(e, t.notInConstruct, !1);
}
function Rs(e, t, n) {
  if (typeof t == "string" && (t = [t]), !t || t.length === 0)
    return n;
  let r = -1;
  for (; ++r < t.length; )
    if (e.includes(t[r]))
      return !0;
  return !1;
}
function $s(e, t, n, r) {
  let i = -1;
  for (; ++i < n.unsafe.length; ) {
    const o = n.unsafe[i];
    if (o.character === `
` && !o.before && !o.after && Ox(n.stack, o))
      return /[\t ]/.test(r.before) ? "" : " ";
  }
  return `\\
`;
}
function Px(e, t) {
  const n = String(e);
  let r = n.indexOf(t), i = r, o = 0, a = 0;
  if (typeof t != "string")
    throw new TypeError("Expected substring");
  for (; r !== -1; )
    r === i ? ++o > a && (a = o) : o = 1, i = r + t.length, r = n.indexOf(t, i);
  return a;
}
function Mx(e, t) {
  return !!(t.options.fences === !1 && e.value && // If there’s no info…
  !e.lang && // And there’s a non-whitespace character…
  /[^\n\r ]/.test(e.value) && // And the value doesn’t start or end in a blank…
  !/^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(e.value));
}
function Rx(e) {
  const t = e.options.fence || "`";
  if (t !== "`" && t !== "~")
    throw new Error(
      "Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`"
    );
  return t;
}
function $x(e, t, n, r) {
  const i = Rx(n), o = e.value || "";
  if (Mx(e, n)) {
    const f = n.enter("codeIndented"), p = n.indentLines(o, Dx);
    return f(), p;
  }
  const a = n.createTracker(r), s = i.repeat(Math.max(Px(o, i) + 1, 3)), u = n.enter("codeFenced"), c = i === "`" ? "GraveAccent" : "Tilde";
  let l = a.move(s);
  if (e.lang) {
    const f = n.enter(`codeFencedLang${c}`);
    l += a.move(
      n.safe(e.lang, {
        before: l,
        after: " ",
        encode: ["`"],
        ...a.current()
      })
    ), f();
  }
  if (e.lang && e.meta) {
    const f = n.enter(`codeFencedMeta${c}`);
    l += a.move(" "), l += a.move(
      n.safe(e.meta, {
        before: l,
        after: `
`,
        encode: ["`"],
        ...a.current()
      })
    ), f();
  }
  return l += a.move(`
`), o && (l += a.move(o + `
`)), l += a.move(s), u(), l;
}
function Dx(e, t, n) {
  return (n ? "" : "    ") + e;
}
function Oo(e) {
  const t = e.options.quote || '"';
  if (t !== '"' && t !== "'")
    throw new Error(
      "Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`"
    );
  return t;
}
function Nx(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.enter("definition");
  let s = n.enter("label");
  const u = n.createTracker(r);
  let c = u.move("[");
  return c += u.move(
    n.safe(n.associationId(e), {
      before: c,
      after: "]",
      ...u.current()
    })
  ), c += u.move("]: "), s(), // If there’s no url, or…
  !e.url || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), c += u.move("<"), c += u.move(
    n.safe(e.url, { before: c, after: ">", ...u.current() })
  ), c += u.move(">")) : (s = n.enter("destinationRaw"), c += u.move(
    n.safe(e.url, {
      before: c,
      after: e.title ? " " : `
`,
      ...u.current()
    })
  )), s(), e.title && (s = n.enter(`title${o}`), c += u.move(" " + i), c += u.move(
    n.safe(e.title, {
      before: c,
      after: i,
      ...u.current()
    })
  ), c += u.move(i), s()), a(), c;
}
function Lx(e) {
  const t = e.options.emphasis || "*";
  if (t !== "*" && t !== "_")
    throw new Error(
      "Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`"
    );
  return t;
}
function _r(e) {
  const t = e.codePointAt(0);
  return t === void 0 ? "" : String.fromCodePoint(t);
}
function Yt(e) {
  const t = e.codePointAt(e.length - 2);
  return t !== void 0 && t > 65535 ? e.slice(-2) : e.slice(-1);
}
function Rc(e) {
  return "&#x" + e.toString(16).toUpperCase() + ";";
}
function Ds(e, t, n) {
  const r = Et(e), i = Et(t);
  return r === void 0 ? i === void 0 ? (
    // Letter inside:
    // we have to encode *both* letters for `_` as it is looser.
    // it already forms for `*` (and GFMs `~`).
    n === "_" ? { inside: !0, outside: !0 } : { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (letter, whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: encode outer (letter)
    { inside: !1, outside: !0 }
  ) : r === 1 ? i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode inner (whitespace).
    { inside: !0, outside: !1 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  );
}
function Fx(e) {
  if (e.charCodeAt(0) !== 60) return;
  const t = e.charCodeAt(1);
  if (t === 33) {
    const s = e.charCodeAt(2);
    return s === 45 ? 2 : s === 91 ? 5 : we(s) ? 4 : void 0;
  }
  if (t === 63) return 3;
  const n = t === 47, r = n ? 2 : 1;
  let i = r, o = e.charCodeAt(i);
  if (!we(o)) return;
  for (; o === 45 || xe(o); )
    o = e.charCodeAt(++i);
  const a = e.slice(r, i).toLowerCase();
  return !n && o !== 47 && Ui.includes(a) ? 1 : bc.includes(a) ? 6 : 7;
}
const $c = /* @__PURE__ */ new Map([
  ["*", !1],
  ["_", !0]
]);
function jx(e, t, n) {
  const r = /* @__PURE__ */ new Set();
  for (const o of e) {
    const a = n.get(o);
    if (a && o.attention && t.some((s) => s.attention === o.attention))
      for (const s of a.tokens)
        r.add(s.attention);
  }
  const i = [];
  for (const o of e)
    o.attention && r.delete(o.attention) && i.push(o.attention);
  return i.reverse(), i;
}
function Dc(e, t, n) {
  const r = [], i = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map();
  let a = 0;
  for (; a < e.length; ) {
    if (!e[a].attention) {
      a++;
      continue;
    }
    const s = e[a].value.charAt(0), u = $c.get(s);
    let c = a + 1;
    for (; c < e.length && e[c].attention && e[c].value.charAt(0) === s; )
      c++;
    const l = a ? e[a - 1].value : t, f = Et(l.charCodeAt(l.length - 1)), p = Et(
      (c < e.length ? e[c].value : n).charCodeAt(0)
    ), d = !p || p === 2 && !!f, h = !f || f === 2 && !!p, m = {
      tokens: e.slice(a, c),
      markers: [],
      start: 0,
      end: 0,
      // Underscores are strict, they cannot open or close inside words.
      open: u ? d && (!!f || !h) : d,
      close: u ? h && (!!p || !d) : h,
      // All builtins can split runs.
      split: u !== void 0
    };
    for (const v of m.tokens) {
      i.set(v, [...m.tokens]), o.set(v, m);
      let g = v.value.length;
      for (; g--; ) m.markers.push(v);
    }
    m.end = m.markers.length, r.push(m), a = c;
  }
  for (Bx(r, i), a = -1; ++a < e.length; ) {
    const s = i.get(e[a]);
    if (s) return { attention: jx(e, s, o), index: a };
  }
}
function Qn(e, t) {
  const n = e[t ? 0 : e.length - 1];
  if (!n || n.attention) return;
  const r = t ? _r(n.value) : Yt(n.value), i = Rc(
    /** @type {number} */
    r.codePointAt(0)
  );
  if (t)
    n.value = i + n.value.slice(r.length);
  else {
    let o = n.value.slice(0, n.value.length - r.length), a = 0;
    for (; o.charCodeAt(o.length - 1 - a) === 92; )
      a++;
    a % 2 && (o += "\\"), n.value = o + i;
  }
}
function Zx(e, t, n, r, i) {
  for (const o of n.attention) {
    const a = t.get(o) || o.sequences[0];
    for (const s of o.sequences) {
      if (s === a) continue;
      const u = new Map(t);
      u.set(o, s);
      const c = Nr(e, u, r, i), l = Dc(c, r, i);
      if (!l || l.index > n.index)
        return { chosen: u, mistake: l, tokens: c };
    }
  }
}
function Bx(e, t) {
  const n = /* @__PURE__ */ new Map();
  for (const r of e) {
    const i = r.tokens[0].value.charAt(0);
    let o = n.get(i);
    o || (o = [], n.set(i, o));
    let a = r.close ? o.length : 0;
    for (; a-- && r.start < r.end; ) {
      const s = o[a], u = s.end - s.start, c = r.end - r.start;
      if (r.split ? (
        // The rule of 3, on the sizes that are left.
        (s.close || r.open) && c % 3 && !((u + c) % 3)
      ) : (
        // Others pair whole runs of the same size.
        u !== s.markers.length || u !== c
      ))
        continue;
      const l = r.split ? u > 1 && c > 1 ? 2 : 1 : c, f = s.markers.slice(s.end - l, s.end), p = r.markers.slice(r.start, r.start + l), d = f[0], h = p[0];
      if (
        // Whole sequences:
        // the markers of a sequence are next to each other,
        // so if the first and last marker are of one sequence of that size,
        // all markers are exactly that sequence.
        d === f[l - 1] && d.value.length === l && h === p[l - 1] && h.value.length === l && // Of the same attention, so its opening and closing sequence.
        d.attention === h.attention
      )
        t.delete(d), t.delete(h);
      else {
        const m = [.../* @__PURE__ */ new Set([...f, ...p])];
        for (const v of m) {
          const g = t.get(v);
          g && g.push(...m);
        }
      }
      s.end -= l, r.start += l, s.start === s.end && o.splice(a, 1), a = o.length;
    }
    r.open && r.start < r.end && o.push(r);
  }
}
function Ux(e, t, n) {
  if (t.length === 0)
    throw new Error(
      "Cannot serialize `" + e + "` as attention without markers, expected one or more markers"
    );
  if (n.length === 0)
    throw new Error(
      "Cannot serialize `" + e + "` as attention without sizes, expected one or more sizes"
    );
  for (const i of n)
    if (!Number.isSafeInteger(i) || i < 1)
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as size, expected positive integer"
      );
  const r = [];
  for (const i of t) {
    if (i.length !== 1)
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected a single ascii character"
      );
    if (!uc(i.charCodeAt(0)))
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected ascii punctuation"
      );
    for (const o of n)
      r.push(i.repeat(o));
  }
  return r;
}
function Vx(e, t, n) {
  const r = t.indexStack, i = e.children || [], o = [];
  let a = -1, s = n.before;
  r.push(-1);
  let u = t.createTracker(n);
  for (; ++a < i.length; ) {
    const c = i[a];
    let l;
    if (r[r.length - 1] = a, a + 1 < i.length) {
      let d = t.handle.handlers[i[a + 1].type];
      d && d.peek && (d = d.peek), l = d ? _r(
        d(i[a + 1], e, t, {
          before: "",
          after: "",
          ...u.current()
        })
      ) : "";
    } else
      l = n.after;
    const f = o[o.length - 1];
    typeof f == "string" && (s === "\r" || s === `
`) && c.type === "html" && Fx(c.value) !== 7 && (o[o.length - 1] = f.replace(/(\r?\n|\r)$/, " "), s = " ", u = t.createTracker(n), u.move(Lr(o, n.before, n.after)));
    const p = t.handle.handlers[c.type];
    if (p && p.attention) {
      const d = Po(
        /** @type {PhrasingParents} */
        c,
        p.attention,
        t,
        u
      );
      if (!d) continue;
      o.push(d), s = Yt(d.sequences[0]);
    } else {
      const d = t.handle(c, e, t, {
        ...u.current(),
        after: l,
        before: s
      });
      if (!d) continue;
      u.move(d), o.push(d), s = Yt(d);
    }
  }
  return r.pop(), o;
}
function Po(e, t, n, r) {
  const { construct: i, markers: o, sizes: a } = t(e, n), s = Ux(e.type, o, a), u = s[0], c = n.enter(i), l = n.createTracker(r.current());
  l.move(u);
  const f = Vx(e, n, {
    ...l.current(),
    before: u,
    after: u
  });
  if (c(), f.length !== 0)
    return r.move(u), r.move(Lr(f, u, u)), r.move(u), { children: f, sequences: s };
}
function Ns(e, t, n, r) {
  let i = Nr(e, t, n, r), o = Dc(i, n, r);
  for (; o; ) {
    const a = Zx(e, t, o, n, r);
    if (!a) return;
    t = a.chosen, i = a.tokens, o = a.mistake;
  }
  return i;
}
function Nc(e, t, n, r) {
  let i = n, o = -1;
  for (; ++o < e.length; ) {
    const a = e[o];
    if (typeof a == "string") {
      i = "";
      continue;
    }
    const s = o === e.length - 1 ? r : "", u = a.sequences.find(function(c) {
      const l = c.charAt(0);
      return l !== i.charAt(0) && l !== s.charAt(0) || e.length === 1 && $c.has(l) && c.length > n.length;
    }) || a.sequences[0];
    u !== a.sequences[0] && t.set(a, u), Nc(a.children, t, u, u), i = u;
  }
}
function Nr(e, t, n, r) {
  const i = [];
  let o, a = Yt(n), s = -1;
  for (; ++s < e.length; ) {
    const u = e[s];
    if (typeof u == "string") {
      const I = { value: u, attention: void 0 };
      o && o === _r(u) && Qn([I], !0), o = void 0, i.push(I), I.value && (a = Yt(I.value));
      continue;
    }
    const c = t.get(u) || u.sequences[0], l = c.charAt(0), f = e[s + 1], p = a, d = _r(
      f === void 0 ? r : typeof f == "string" ? f : t.get(f) || f.sequences[0]
    ), h = Nr(u.children, t, c, c), m = h[0].value, v = Ds(
      p.charCodeAt(p.length - 1),
      m.charCodeAt(0),
      l
    );
    v.inside && Qn(h, !0);
    const g = Yt(h[h.length - 1].value), w = Ds(
      d.charCodeAt(0),
      g.charCodeAt(g.length - 1),
      l
    );
    w.inside && Qn(h, !1), v.outside && p !== `
` && p !== "\r" && Qn(i, !1), w.outside && (o = d), i.push({ value: c, attention: u }, ...h, {
      value: c,
      attention: u
    }), a = c.charAt(c.length - 1);
  }
  return i;
}
function Lr(e, t, n) {
  const r = /* @__PURE__ */ new Map();
  Nc(e, r, t, n);
  const i = (
    // Start from guesses (based on the preferred sequences).
    (r.size > 0 ? Ns(e, r, t, n) : void 0) || // If stuck, start from the preferred sequences instead.
    Ns(e, /* @__PURE__ */ new Map(), t, n) || // If stuck again, use the preferred sequences as they are.
    Nr(e, /* @__PURE__ */ new Map(), t, n)
  );
  let o = "";
  for (const a of i) o += a.value;
  return o;
}
Mo.attention = Lc;
Mo.peek = qx;
function Mo(e, t, n, r) {
  const i = n.enter("phrasing"), o = Po(e, Lc, n, n.createTracker(r)), a = o ? Lr([o], r.before, r.after) : "";
  return i(), a;
}
function Lc(e, t) {
  return {
    construct: "emphasis",
    markers: Lx(t) === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [1]
  };
}
function qx(e, t, n) {
  return n.options.emphasis || "*";
}
function Jx(e, t) {
  let n = !1;
  return Dr(e, function(r) {
    if ("value" in r && /\r?\n|\r/.test(r.value) || r.type === "break")
      return n = !0, On;
  }), !!((!e.depth || e.depth < 3) && Or(e) && (t.options.setext || n));
}
function Wx(e, t, n, r) {
  const i = Math.max(Math.min(6, e.depth || 1), 1), o = n.createTracker(r);
  if (Jx(e, n)) {
    const f = n.enter("headingSetext"), p = n.enter("phrasing"), d = n.containerPhrasing(e, {
      ...o.current(),
      before: `
`,
      after: `
`
    });
    return p(), f(), d + `
` + (i === 1 ? "=" : "-").repeat(
      // The whole size…
      d.length - // Minus the position of the character after the last EOL (or
      // 0 if there is none)…
      (Math.max(d.lastIndexOf("\r"), d.lastIndexOf(`
`)) + 1)
    );
  }
  const a = "#".repeat(i), s = n.enter("headingAtx"), u = n.enter("phrasing");
  o.move(a + " ");
  let c = n.containerPhrasing(e, {
    before: "# ",
    after: `
`,
    ...o.current()
  });
  const l = c.charCodeAt(0);
  return (l === 9 || l === 32) && (c = Rc(l) + c.slice(1)), c = c ? a + " " + c : a, n.options.closeAtx && (c += " " + a), u(), s(), c;
}
Fc.peek = Hx;
function Fc(e) {
  return e.value || "";
}
function Hx() {
  return "<";
}
jc.peek = Kx;
function jc(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.enter("image");
  let s = n.enter("label");
  const u = n.createTracker(r);
  let c = u.move("![");
  return c += u.move(
    n.safe(e.alt, { before: c, after: "]", ...u.current() })
  ), c += u.move("]("), s(), // If there’s no url but there is a title…
  !e.url && e.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), c += u.move("<"), c += u.move(
    n.safe(e.url, { before: c, after: ">", ...u.current() })
  ), c += u.move(">")) : (s = n.enter("destinationRaw"), c += u.move(
    n.safe(e.url, {
      before: c,
      after: e.title ? " " : ")",
      ...u.current()
    })
  )), s(), e.title && (s = n.enter(`title${o}`), c += u.move(" " + i), c += u.move(
    n.safe(e.title, {
      before: c,
      after: i,
      ...u.current()
    })
  ), c += u.move(i), s()), c += u.move(")"), a(), c;
}
function Kx() {
  return "!";
}
Zc.peek = Yx;
function Zc(e, t, n, r) {
  const i = e.referenceType, o = n.enter("imageReference");
  let a = n.enter("label");
  const s = n.createTracker(r);
  let u = s.move("![");
  const c = n.safe(e.alt, {
    before: u,
    after: "]",
    ...s.current()
  });
  u += s.move(c + "]["), a();
  const l = n.stack;
  n.stack = l.filter(function(p) {
    return p !== "phrasing";
  }), a = n.enter("reference");
  const f = n.safe(n.associationId(e), {
    before: u,
    after: "]",
    ...s.current()
  });
  return a(), n.stack = l, o(), i === "full" || !c || c !== f ? u += s.move(f + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += s.move("]"), u;
}
function Yx() {
  return "!";
}
Bc.peek = Gx;
function Bc(e, t, n) {
  let r = e.value || "", i = "`", o = -1;
  for (; new RegExp("(^|[^`])" + i + "([^`]|$)").test(r); )
    i += "`";
  for (/[^\n\r ]/.test(r) && (/^[\n\r ]/.test(r) && /[\n\r ]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++o < n.unsafe.length; ) {
    const a = n.unsafe[o], s = n.compilePattern(a);
    if (!a.atBreak) continue;
    let u;
    for (; u = s.exec(r); ) {
      let c = u.index;
      r.charCodeAt(c) === 10 && r.charCodeAt(c - 1) === 13 && c--, r = r.slice(0, c) + " " + r.slice(u.index + 1);
    }
  }
  return i + r + i;
}
function Gx() {
  return "`";
}
function Uc(e, t) {
  const n = Or(e);
  return !!(!t.options.resourceLink && // If there’s a url…
  e.url && // And there’s no title…
  !e.title && // And the content of `node` is a single text node…
  e.children && e.children.length === 1 && e.children[0].type === "text" && // And if the url is the same as the content…
  (n === e.url || "mailto:" + n === e.url) && // And that starts w/ a protocol…
  /^[a-z][+\-.a-z]+:/i.test(e.url) && // And that doesn’t contain ASCII control codes (character escapes and
  // references don’t work), space, or angle brackets…
  !/[\0- <>\u007F]/.test(e.url));
}
Vc.peek = Xx;
function Vc(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.createTracker(r);
  if (Uc(e, n)) {
    const h = n.stack;
    n.stack = h.filter(function(g) {
      return g !== "phrasing";
    });
    const m = n.enter("autolink");
    let v = a.move("<");
    return v += a.move(
      n.containerPhrasing(e, {
        before: v,
        after: ">",
        ...a.current()
      })
    ), v += a.move(">"), m(), n.stack = h, v;
  }
  const s = n.enter("link");
  let u = n.enter("label"), c = a.move("[");
  const l = n.containerPhrasing(e, {
    before: c,
    after: "](",
    ...a.current()
  });
  c += a.move(l), u(), c += a.move("](");
  const f = /[\0- \u007F]/.test(e.url), p = r.before.charAt(r.before.length - 1);
  let d = e.title || void 0;
  if (!d && !f && (p === `
` || p === "\r")) {
    let h = 0;
    for (; h < l.length && l.charCodeAt(h) !== 93; )
      h += l.charCodeAt(h) === 92 ? 2 : 1;
    l.charCodeAt(h + 1) === 58 && (d = "");
  }
  return /* If there’s no url but there is a title… */ !e.url && typeof d == "string" || // If there are control characters or whitespace.
  f ? (u = n.enter("destinationLiteral"), c += a.move("<"), c += a.move(
    n.safe(e.url, { before: c, after: ">", ...a.current() })
  ), c += a.move(">")) : (u = n.enter("destinationRaw"), c += a.move(
    n.safe(e.url, {
      before: c,
      after: typeof d == "string" ? " " : ")",
      ...a.current()
    })
  )), u(), typeof d == "string" && (u = n.enter(`title${o}`), c += a.move(" " + i), c += a.move(
    n.safe(d, {
      before: c,
      after: i,
      ...a.current()
    })
  ), c += a.move(i), u()), c += a.move(")"), s(), c;
}
function Xx(e, t, n) {
  return Uc(e, n) ? "<" : "[";
}
qc.peek = Qx;
function qc(e, t, n, r) {
  const i = e.referenceType, o = n.enter("linkReference");
  let a = n.enter("label");
  const s = n.createTracker(r);
  let u = s.move("[");
  const c = n.containerPhrasing(e, {
    before: u,
    after: "]",
    ...s.current()
  });
  u += s.move(c + "]["), a();
  const l = n.stack;
  n.stack = l.filter(function(p) {
    return p !== "phrasing";
  }), a = n.enter("reference");
  const f = n.safe(n.associationId(e), {
    before: u,
    after: "]",
    ...s.current()
  });
  return a(), n.stack = l, o(), i === "full" || !c || c !== f ? u += s.move(f + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += s.move("]"), u;
}
function Qx() {
  return "[";
}
function Ro(e) {
  const t = e.options.bullet || "*";
  if (t !== "*" && t !== "+" && t !== "-")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`"
    );
  return t;
}
function e_(e) {
  const t = Ro(e), n = e.options.bulletOther;
  if (!n)
    return t === "*" ? "-" : "*";
  if (n !== "*" && n !== "+" && n !== "-")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`"
    );
  if (n === t)
    throw new Error(
      "Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different"
    );
  return n;
}
function t_(e) {
  const t = e.options.bulletOrdered || ".";
  if (t !== "." && t !== ")")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`"
    );
  return t;
}
function Jc(e) {
  const t = e.options.rule || "*";
  if (t !== "*" && t !== "-" && t !== "_")
    throw new Error(
      "Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`"
    );
  return t;
}
function n_(e, t, n, r) {
  const i = n.enter("list"), o = n.bulletCurrent;
  let a = e.ordered ? t_(n) : Ro(n);
  const s = e.ordered ? a === "." ? ")" : "." : e_(n);
  let u = t && n.bulletLastUsed ? a === n.bulletLastUsed : !1;
  if (!e.ordered) {
    const l = e.children ? e.children[0] : void 0;
    if (
      // Bullet could be used as a thematic break marker:
      (a === "*" || a === "-") && // Empty first list item:
      l && (!l.children || !l.children[0]) && // Directly in two other list items:
      n.stack[n.stack.length - 1] === "list" && n.stack[n.stack.length - 2] === "listItem" && n.stack[n.stack.length - 3] === "list" && n.stack[n.stack.length - 4] === "listItem" && // That are each the first child.
      n.indexStack[n.indexStack.length - 1] === 0 && n.indexStack[n.indexStack.length - 2] === 0 && n.indexStack[n.indexStack.length - 3] === 0 && (u = !0), Jc(n) === a && l
    ) {
      let f = -1;
      for (; ++f < e.children.length; ) {
        const p = e.children[f];
        if (p && p.type === "listItem" && p.children && p.children[0] && p.children[0].type === "thematicBreak") {
          u = !0;
          break;
        }
      }
    }
  }
  u && (a = s), n.bulletCurrent = a;
  const c = n.containerFlow(e, r);
  return n.bulletLastUsed = a, n.bulletCurrent = o, i(), c;
}
function r_(e) {
  const t = e.options.listItemIndent || "one";
  if (t !== "tab" && t !== "one" && t !== "mixed")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`"
    );
  return t;
}
function i_(e, t, n, r) {
  const i = r_(n);
  let o = n.bulletCurrent || Ro(n);
  t && t.type === "list" && t.ordered && (o = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === !1 ? 0 : t.children.indexOf(e)) + o);
  let a = o.length + 1;
  (i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (a = Math.ceil(a / 4) * 4);
  const s = n.createTracker(r);
  s.move(o + " ".repeat(a - o.length)), s.shift(a);
  const u = n.enter("listItem"), c = n.indentLines(
    n.containerFlow(e, s.current()),
    l
  );
  return u(), c;
  function l(f, p, d) {
    return p ? (d ? "" : " ".repeat(a)) + f : (d ? o : o + " ".repeat(a - o.length)) + f;
  }
}
function o_(e, t, n, r) {
  const i = n.enter("paragraph"), o = n.enter("phrasing"), a = n.containerPhrasing(e, r);
  return o(), i(), a;
}
function a_(e, t, n, r) {
  if (!e.children.some(function(s) {
    return Ax(s);
  })) return n.containerFlow(e, r);
  const o = n.enter("phrasing"), a = n.containerPhrasing(e, r);
  return o(), a;
}
function s_(e) {
  const t = e.options.strong || "*";
  if (t !== "*" && t !== "_")
    throw new Error(
      "Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`"
    );
  return t;
}
$o.attention = Wc;
$o.peek = l_;
function $o(e, t, n, r) {
  const i = n.enter("phrasing"), o = Po(e, Wc, n, n.createTracker(r)), a = o ? Lr([o], r.before, r.after) : "";
  return i(), a;
}
function Wc(e, t) {
  return {
    construct: "strong",
    markers: s_(t) === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [2]
  };
}
function l_(e, t, n) {
  return n.options.strong || "*";
}
function u_(e, t, n, r) {
  const i = t ? t.children : [], o = n.indexStack[n.indexStack.length - 1];
  return n.safe(e.value, {
    ...r,
    afterNode: i[o + 1],
    beforeNode: i[o - 1]
  });
}
function c_(e) {
  const t = e.options.ruleRepetition || 3;
  if (t < 3)
    throw new Error(
      "Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more"
    );
  return t;
}
function f_(e, t, n) {
  const r = (Jc(n) + (n.options.ruleSpaces ? " " : "")).repeat(c_(n));
  return n.options.ruleSpaces ? r.slice(0, -1) : r;
}
const Yi = {
  blockquote: zx,
  break: $s,
  code: $x,
  definition: Nx,
  emphasis: Mo,
  hardBreak: $s,
  heading: Wx,
  html: Fc,
  image: jc,
  imageReference: Zc,
  inlineCode: Bc,
  link: Vc,
  linkReference: qc,
  list: n_,
  listItem: i_,
  paragraph: o_,
  root: a_,
  strong: $o,
  text: u_,
  thematicBreak: f_
};
function d_() {
  return {
    enter: {
      table: p_,
      tableData: Ls,
      tableHeader: Ls,
      tableRow: m_
    },
    exit: {
      codeText: g_,
      table: h_,
      tableData: hi,
      tableHeader: hi,
      tableRow: hi
    }
  };
}
function p_(e) {
  const t = e._align;
  this.enter(
    {
      type: "table",
      align: t.map(function(n) {
        return n === "none" ? null : n;
      }),
      children: [],
      position: void 0
    },
    e
  ), this.data.inTable = !0;
}
function h_(e) {
  this.exit(e), this.data.inTable = void 0;
}
function m_(e) {
  this.enter({ type: "tableRow", children: [], position: void 0 }, e);
}
function hi(e) {
  this.exit(e);
}
function Ls(e) {
  this.enter({ type: "tableCell", children: [], position: void 0 }, e);
}
function g_(e) {
  let t = this.resume();
  this.data.inTable && (t = t.replace(/\\([\\|])/g, y_));
  const n = this.stack[this.stack.length - 1];
  n.type, n.value = t, this.exit(e);
}
function y_(e, t) {
  return t === "|" ? t : e;
}
function b_(e) {
  const t = e || {}, {
    tableCellPadding: n,
    tablePipeAlign: r,
    stringLength: i
  } = t, o = n ? " " : "|";
  return {
    handlers: {
      inlineCode: p,
      table: a,
      tableCell: u,
      tableRow: s
    },
    join: [v_],
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      // A pipe, when followed by a tab or space (padding), or a dash or colon
      // (unpadded delimiter row), could result in a table.
      { atBreak: !0, character: "|", after: "[	 :-]" },
      // A pipe in a cell must be encoded.
      { character: "|", inConstruct: "tableCell" },
      // A colon must be followed by a dash, in which case it could start a
      // delimiter row.
      { atBreak: !0, character: ":", after: "-" },
      // A delimiter row can also start with a dash, when followed by more
      // dashes, a colon, or a pipe.
      // This is a stricter version than the built in check for lists, thematic
      // breaks, and setex heading underlines though:
      // <https://github.com/syntax-tree/mdast-util-to-markdown/blob/51a2038/lib/unsafe.js#L57>
      { atBreak: !0, character: "-", after: "[:|-]" }
    ]
  };
  function a(d, h, m, v) {
    const g = l(d, m, v), w = g[0];
    if (w) {
      let I = d.align ? d.align.length : 0, S = -1;
      if (!I)
        for (; ++S < g.length; )
          g[S].length > I && (I = g[S].length);
      for (; w.length < I; ) w.push("");
    }
    return c(g, d.align);
  }
  function s(d, h, m, v) {
    const g = f(d, m, v), w = c([g]);
    return w.slice(0, w.indexOf(`
`));
  }
  function u(d, h, m, v) {
    const g = m.enter("tableCell"), w = m.enter("phrasing"), I = m.containerPhrasing(d, {
      ...v,
      before: o,
      after: o
    });
    return w(), g(), I;
  }
  function c(d, h) {
    return Ex(d, {
      align: h,
      alignDelimiters: r,
      fillRows: !1,
      padding: n,
      stringLength: i
    });
  }
  function l(d, h, m) {
    const { children: v } = d;
    let g = -1;
    const w = [], I = h.enter("table");
    for (; ++g < v.length; )
      w[g] = f(v[g], h, m);
    return I(), w;
  }
  function f(d, h, m) {
    const { children: v } = d;
    let g = -1;
    const w = [], I = h.enter("tableRow");
    for (; ++g < v.length; )
      w[g] = u(v[g], d, h, m);
    return I(), w;
  }
  function p(d, h, m) {
    const v = Yi.inlineCode(d, h, m);
    if (!m.stack.includes("tableCell")) return v;
    const g = [];
    let w = 0, I = v.indexOf("|");
    for (; I !== -1; ) {
      let S = I;
      for (; S > w && v.charCodeAt(S - 1) === 92; )
        S--;
      g.push(v.slice(w, I)), (I - S) % 2 === 0 && g.push("\\"), w = I, I = v.indexOf("|", I + 1);
    }
    return g.push(v.slice(w)), g.join("");
  }
}
function v_(e, t, n, r) {
  if (e.type === "table" && n.type === "listItem" && n.spread === !1 && (t.type === "definition" || t.type === "heading" && k_(t, r) || t.type === "paragraph" || t.type === "table"))
    return 1;
}
function k_(e, t) {
  let n = !1;
  return Dr(e, function(r) {
    if (r.type === "break" || "value" in r && /\r?\n|\r/.test(r.value))
      return n = !0, On;
  }), !!((!e.depth || e.depth < 3) && Or(e) && (t.options.setext || n));
}
function w_() {
  return {
    exit: {
      taskListCheckValueChecked: Fs,
      taskListCheckValueUnchecked: Fs,
      paragraph: __
    }
  };
}
function x_() {
  return {
    handlers: { paragraph: S_ },
    join: [I_]
  };
}
function Fs(e) {
  const t = this.stack[this.stack.length - 2];
  t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function __(e) {
  const t = this.stack[this.stack.length - 2];
  if (t && t.type === "listItem" && typeof t.checked == "boolean") {
    const n = this.stack[this.stack.length - 1];
    n.type;
    const r = n.children[0];
    if (r && r.type === "text") {
      const i = t.children;
      let o = -1, a;
      for (; ++o < i.length; ) {
        const s = i[o];
        if (s.type === "paragraph") {
          a = s;
          break;
        }
      }
      a === n && (r.value = r.value.slice(1), r.value.length === 0 ? n.children.shift() : n.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, n.position.start = { ...r.position.start }));
    }
  }
  this.exit(e);
}
function S_(e, t, n, r) {
  if (!t || t.type !== "listItem" || Hc(t) !== e)
    return Yi.paragraph(e, t, n, r);
  const i = "[" + (t.checked ? "x" : " ") + "] ", o = n.createTracker(r);
  o.move(i);
  const a = Yi.paragraph(
    e.children.length > 0 ? e : { type: "paragraph", children: [{ type: "text", value: " " }] },
    t,
    n,
    { ...r, ...o.current() }
  );
  return i + a;
}
function I_(e, t, n) {
  if (!(e.type === "definition" && n.type === "listItem"))
    return;
  const r = Hc(n);
  if (r && n.children.indexOf(e) < n.children.indexOf(r))
    return 0;
}
function Hc(e) {
  if (typeof e.checked == "boolean")
    for (const t of e.children) {
      if (t.type === "paragraph")
        return t;
      if (t.type !== "definition")
        return;
    }
}
function E_() {
  return [
    q1(),
    mx(),
    vx(),
    d_(),
    w_()
  ];
}
function C_(e) {
  return {
    extensions: [
      J1(),
      gx(e),
      kx(),
      b_(e),
      x_()
    ]
  };
}
const A_ = {
  tokenize: R_,
  partial: !0
}, Kc = {
  tokenize: $_,
  partial: !0
}, Yc = {
  tokenize: D_,
  partial: !0
}, Gc = {
  tokenize: N_,
  partial: !0
}, z_ = {
  tokenize: L_,
  partial: !0
}, Xc = {
  name: "wwwAutolink",
  tokenize: P_,
  previous: ef
}, Qc = {
  name: "protocolAutolink",
  tokenize: M_,
  previous: tf
}, ht = {
  name: "emailAutolink",
  tokenize: O_,
  previous: nf
}, ct = {};
function T_() {
  return {
    text: ct
  };
}
let Ot = 48;
for (; Ot < 123; )
  ct[Ot] = ht, Ot++, Ot === 58 ? Ot = 65 : Ot === 91 && (Ot = 97);
ct[43] = ht;
ct[45] = ht;
ct[46] = ht;
ct[95] = ht;
ct[72] = [ht, Qc];
ct[104] = [ht, Qc];
ct[87] = [ht, Xc];
ct[119] = [ht, Xc];
function O_(e, t, n) {
  const r = this;
  let i, o;
  return a;
  function a(f) {
    return !Gi(f) || !nf.call(r, r.previous) || Do(r.events) ? n(f) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), s(f));
  }
  function s(f) {
    return Gi(f) ? (e.consume(f), s) : f === 64 ? (e.consume(f), u) : n(f);
  }
  function u(f) {
    return f === 46 ? e.check(z_, l, c)(f) : f === 45 || f === 95 || xe(f) ? (o = !0, e.consume(f), u) : l(f);
  }
  function c(f) {
    return e.consume(f), i = !0, u;
  }
  function l(f) {
    return o && i && we(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(f)) : n(f);
  }
}
function P_(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return a !== 87 && a !== 119 || !ef.call(r, r.previous) || Do(r.events) ? n(a) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(A_, e.attempt(Kc, e.attempt(Yc, o), n), n)(a));
  }
  function o(a) {
    return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(a);
  }
}
function M_(e, t, n) {
  const r = this;
  let i = "", o = !1;
  return a;
  function a(f) {
    return (f === 72 || f === 104) && tf.call(r, r.previous) && !Do(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(f), e.consume(f), s) : n(f);
  }
  function s(f) {
    if (we(f) && i.length < 5)
      return i += String.fromCodePoint(f), e.consume(f), s;
    if (f === 58) {
      const p = i.toLowerCase();
      if (p === "http" || p === "https")
        return e.consume(f), u;
    }
    return n(f);
  }
  function u(f) {
    return f === 47 ? (e.consume(f), o ? c : (o = !0, u)) : n(f);
  }
  function c(f) {
    return f === null || vr(f) || ae(f) || jt(f) || Zn(f) ? n(f) : e.attempt(Kc, e.attempt(Yc, l), n)(f);
  }
  function l(f) {
    return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(f);
  }
}
function R_(e, t, n) {
  let r = 0;
  return i;
  function i(a) {
    return (a === 87 || a === 119) && r < 3 ? (r++, e.consume(a), i) : a === 46 && r === 3 ? (e.consume(a), o) : n(a);
  }
  function o(a) {
    return a === null ? n(a) : t(a);
  }
}
function $_(e, t, n) {
  let r, i, o;
  return a;
  function a(c) {
    return c === 46 || c === 95 ? e.check(Gc, u, s)(c) : c === null || ae(c) || jt(c) || c !== 45 && Zn(c) ? u(c) : (o = !0, e.consume(c), a);
  }
  function s(c) {
    return c === 95 ? r = !0 : (i = r, r = void 0), e.consume(c), a;
  }
  function u(c) {
    return i || r || !o ? n(c) : t(c);
  }
}
function D_(e, t) {
  let n = 0, r = 0;
  return i;
  function i(a) {
    return a === 40 ? (n++, e.consume(a), i) : a === 41 && r < n ? o(a) : a === 33 || a === 34 || a === 38 || a === 39 || a === 41 || a === 42 || a === 44 || a === 46 || a === 58 || a === 59 || a === 60 || a === 63 || a === 93 || a === 95 || a === 126 ? e.check(Gc, t, o)(a) : a === null || ae(a) || jt(a) ? t(a) : (e.consume(a), i);
  }
  function o(a) {
    return a === 41 && r++, e.consume(a), i;
  }
}
function N_(e, t, n) {
  return r;
  function r(s) {
    return s === 33 || s === 34 || s === 39 || s === 41 || s === 42 || s === 44 || s === 46 || s === 58 || s === 59 || s === 63 || s === 95 || s === 126 ? (e.consume(s), r) : s === 38 ? (e.consume(s), o) : s === 93 ? (e.consume(s), i) : (
      // `<` is an end.
      s === 60 || // So is whitespace.
      s === null || ae(s) || jt(s) ? t(s) : n(s)
    );
  }
  function i(s) {
    return s === null || s === 40 || s === 91 || ae(s) || jt(s) ? t(s) : r(s);
  }
  function o(s) {
    return we(s) ? a(s) : n(s);
  }
  function a(s) {
    return s === 59 ? (e.consume(s), r) : we(s) ? (e.consume(s), a) : n(s);
  }
}
function L_(e, t, n) {
  return r;
  function r(o) {
    return e.consume(o), i;
  }
  function i(o) {
    return xe(o) ? n(o) : t(o);
  }
}
function ef(e) {
  return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || ae(e);
}
function tf(e) {
  return !we(e);
}
function nf(e) {
  return !(e === 47 || Gi(e));
}
function Gi(e) {
  return e === 43 || e === 45 || e === 46 || e === 95 || xe(e);
}
function Do(e) {
  let t = e.length, n = !1;
  for (; t--; ) {
    const r = e[t][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      n = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      n = !1;
      break;
    }
  }
  return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
const F_ = {
  tokenize: W_,
  partial: !0
};
function j_() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: V_,
        continuation: {
          tokenize: q_
        },
        exit: J_
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: U_
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: Z_,
        resolveTo: B_
      }
    }
  };
}
function Z_(e, t, n) {
  const r = this;
  let i = r.events.length;
  const o = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let a;
  for (; i--; ) {
    const u = r.events[i][1];
    if (u.type === "labelImage") {
      a = u;
      break;
    }
    if (u.type === "gfmFootnoteCall" || u.type === "labelLink" || u.type === "label" || u.type === "image" || u.type === "link")
      break;
  }
  return s;
  function s(u) {
    if (!a || !a._balanced)
      return n(u);
    const c = et(r.sliceSerialize({
      start: a.end,
      end: r.now()
    }));
    return c.codePointAt(0) !== 94 || !o.includes(c.slice(1)) ? n(u) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(u), e.exit("gfmFootnoteCallLabelMarker"), t(u));
  }
}
function B_(e, t) {
  let n = e.length;
  for (; n--; )
    if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
      e[n][1];
      break;
    }
  e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, e[n + 3][1].start),
    end: Object.assign({}, e[e.length - 1][1].end)
  }, i = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, e[n + 3][1].end),
    end: Object.assign({}, e[n + 3][1].end)
  };
  i.end.column++, i.end.offset++, i.end._bufferIndex++;
  const o = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, i.end),
    end: Object.assign({}, e[e.length - 1][1].start)
  }, a = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, o.start),
    end: Object.assign({}, o.end)
  }, s = [
    // Take the `labelImageMarker` (now `data`, the `!`)
    e[n + 1],
    e[n + 2],
    ["enter", r, t],
    // The `[`
    e[n + 3],
    e[n + 4],
    // The `^`.
    ["enter", i, t],
    ["exit", i, t],
    // Everything in between.
    ["enter", o, t],
    ["enter", a, t],
    ["exit", a, t],
    ["exit", o, t],
    // The ending (`]`, properly parsed and labelled).
    e[e.length - 2],
    e[e.length - 1],
    ["exit", r, t]
  ];
  return e.splice(n, e.length - n + 1, ...s), e;
}
function U_(e, t, n) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let o = 0, a;
  return s;
  function s(f) {
    return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(f), e.exit("gfmFootnoteCallLabelMarker"), u;
  }
  function u(f) {
    return f !== 94 ? n(f) : (e.enter("gfmFootnoteCallMarker"), e.consume(f), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", c);
  }
  function c(f) {
    if (
      // Too long.
      o > 999 || // Closing brace with nothing.
      f === 93 && !a || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      f === null || f === 91 || ae(f)
    )
      return n(f);
    if (f === 93) {
      e.exit("chunkString");
      const p = e.exit("gfmFootnoteCallString");
      return i.includes(et(r.sliceSerialize(p))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(f), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(f);
    }
    return ae(f) || (a = !0), o++, e.consume(f), f === 92 ? l : c;
  }
  function l(f) {
    return f === 91 || f === 92 || f === 93 ? (e.consume(f), o++, c) : c(f);
  }
}
function V_(e, t, n) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let o, a = 0, s;
  return u;
  function u(h) {
    return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionLabelMarker"), c;
  }
  function c(h) {
    return h === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", l) : n(h);
  }
  function l(h) {
    if (
      // Too long.
      a > 999 || // Closing brace with nothing.
      h === 93 && !s || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      h === null || h === 91 || ae(h)
    )
      return n(h);
    if (h === 93) {
      e.exit("chunkString");
      const m = e.exit("gfmFootnoteDefinitionLabelString");
      return o = et(r.sliceSerialize(m)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), p;
    }
    return ae(h) || (s = !0), a++, e.consume(h), h === 92 ? f : l;
  }
  function f(h) {
    return h === 91 || h === 92 || h === 93 ? (e.consume(h), a++, l) : l(h);
  }
  function p(h) {
    return h === 58 ? (e.enter("definitionMarker"), e.consume(h), e.exit("definitionMarker"), i.includes(o) || i.push(o), ne(e, d, "gfmFootnoteDefinitionWhitespace")) : n(h);
  }
  function d(h) {
    return t(h);
  }
}
function q_(e, t, n) {
  return e.check(Bn, t, e.attempt(F_, t, n));
}
function J_(e) {
  e.exit("gfmFootnoteDefinition");
}
function W_(e, t, n) {
  const r = this;
  return ne(e, i, "gfmFootnoteDefinitionIndent", 5);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "gfmFootnoteDefinitionIndent" && a[2].sliceSerialize(a[1], !0).length === 4 ? t(o) : n(o);
  }
}
function H_(e) {
  let n = (e || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: o,
    resolveAll: i
  };
  return n == null && (n = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function i(a, s) {
    let u = -1;
    for (; ++u < a.length; )
      if (a[u][0] === "enter" && a[u][1].type === "strikethroughSequenceTemporary" && a[u][1]._close) {
        let c = u;
        for (; c--; )
          if (a[c][0] === "exit" && a[c][1].type === "strikethroughSequenceTemporary" && a[c][1]._open && // If the sizes are the same:
          a[u][1].end.offset - a[u][1].start.offset === a[c][1].end.offset - a[c][1].start.offset) {
            a[u][1].type = "strikethroughSequence", a[c][1].type = "strikethroughSequence";
            const l = {
              type: "strikethrough",
              start: Object.assign({}, a[c][1].start),
              end: Object.assign({}, a[u][1].end)
            }, f = {
              type: "strikethroughText",
              start: Object.assign({}, a[c][1].end),
              end: Object.assign({}, a[u][1].start)
            }, p = [["enter", l, s], ["enter", a[c][1], s], ["exit", a[c][1], s], ["enter", f, s]], d = s.parser.constructs.insideSpan.null;
            d && Qe(p, p.length, 0, Pr(d, a.slice(c + 1, u), s)), Qe(p, p.length, 0, [["exit", f, s], ["enter", a[u][1], s], ["exit", a[u][1], s], ["exit", l, s]]), Qe(a, c - 1, u - c + 3, p), u = c + p.length - 2;
            break;
          }
      }
    for (u = -1; ++u < a.length; )
      a[u][1].type === "strikethroughSequenceTemporary" && (a[u][1].type = "data");
    return a;
  }
  function o(a, s, u) {
    const c = this.previous, l = this.events;
    let f = 0;
    return p;
    function p(h) {
      return c === 126 && l[l.length - 1][1].type !== "characterEscape" ? u(h) : (a.enter("strikethroughSequenceTemporary"), d(h));
    }
    function d(h) {
      const m = Et(c);
      if (h === 126)
        return f > 1 ? u(h) : (a.consume(h), f++, d);
      if (f < 2 && !n) return u(h);
      const v = a.exit("strikethroughSequenceTemporary"), g = Et(h);
      return v._open = !g || g === 2 && !!m, v._close = !m || m === 2 && !!g, s(h);
    }
  }
}
class K_ {
  /**
   * Create a new edit map.
   */
  constructor() {
    this.map = [], this.index = /* @__PURE__ */ new Map();
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  add(t, n, r) {
    Y_(this, t, n, r);
  }
  // To do: add this when moving to `micromark`.
  // /**
  //  * Create an edit: but insert `add` before existing additions.
  //  *
  //  * @param {number} index
  //  * @param {number} remove
  //  * @param {Array<Event>} add
  //  * @returns {undefined}
  //  */
  // addBefore(index, remove, add) {
  //   addImplementation(this, index, remove, add, true)
  // }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   *   List of events to apply the edits to.
   * @returns {undefined}
   *   Nothing.
   */
  consume(t) {
    if (this.map.sort(function(o, a) {
      return o[0] - a[0];
    }), this.map.length === 0)
      return;
    let n = this.map.length;
    const r = [];
    for (; n > 0; )
      n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
    r.push(t.slice()), t.length = 0;
    let i = r.pop();
    for (; i; ) {
      for (const o of i)
        t.push(o);
      i = r.pop();
    }
    this.map.length = 0, this.index.clear();
  }
}
function Y_(e, t, n, r) {
  if (n === 0 && r.length === 0)
    return;
  const i = e.index.get(t);
  if (i) {
    i[1] += n, i[2].push(...r);
    return;
  }
  const o = [t, n, r];
  e.map.push(o), e.index.set(t, o);
}
function G_(e, t) {
  let n = !1;
  const r = [];
  for (; t < e.length; ) {
    const i = e[t];
    if (n) {
      if (i[0] === "enter")
        i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
      else if (i[1].type === "tableContent") {
        if (e[t - 1][1].type === "tableDelimiterMarker") {
          const o = r.length - 1;
          r[o] = r[o] === "left" ? "center" : "right";
        }
      } else if (i[1].type === "tableDelimiterRow")
        break;
    } else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = !0);
    t += 1;
  }
  return r;
}
function X_() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: Q_,
        resolveAll: eS
      }
    }
  };
}
function Q_(e, t, n) {
  const r = this;
  let i = 0, o = 0, a;
  return s;
  function s(E) {
    let M = r.events.length - 1;
    for (; M > -1; ) {
      const {
        type: Z
      } = r.events[M][1];
      if (Z === "lineEnding" || // Note: markdown-rs uses `whitespace` instead of `linePrefix`
      Z === "linePrefix")
        M--;
      else
        break;
    }
    const L = M > -1 ? r.events[M][1].type : null, x = L === "tableHead" || L === "tableRow" ? y : u;
    return x === y && r.parser.lazy[r.now().line] ? n(E) : x(E);
  }
  function u(E) {
    return e.enter("tableHead"), e.enter("tableRow"), c(E);
  }
  function c(E) {
    return E === 124 || (a = !0, o += 1), l(E);
  }
  function l(E) {
    return E === null ? n(E) : q(E) ? o > 1 ? (o = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(E), e.exit("lineEnding"), d) : n(E) : X(E) ? ne(e, l, "whitespace")(E) : (o += 1, a && (a = !1, i += 1), E === 124 ? (e.enter("tableCellDivider"), e.consume(E), e.exit("tableCellDivider"), a = !0, l) : (e.enter("data"), f(E)));
  }
  function f(E) {
    return E === null || E === 124 || ae(E) ? (e.exit("data"), l(E)) : (e.consume(E), E === 92 ? p : f);
  }
  function p(E) {
    return E === 92 || E === 124 ? (e.consume(E), f) : f(E);
  }
  function d(E) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(E) : (e.enter("tableDelimiterRow"), a = !1, X(E) ? ne(e, h, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(E) : h(E));
  }
  function h(E) {
    return E === 45 || E === 58 ? v(E) : E === 124 ? (a = !0, e.enter("tableCellDivider"), e.consume(E), e.exit("tableCellDivider"), m) : _(E);
  }
  function m(E) {
    return X(E) ? ne(e, v, "whitespace")(E) : v(E);
  }
  function v(E) {
    return E === 58 ? (o += 1, a = !0, e.enter("tableDelimiterMarker"), e.consume(E), e.exit("tableDelimiterMarker"), g) : E === 45 ? (o += 1, g(E)) : E === null || q(E) ? S(E) : _(E);
  }
  function g(E) {
    return E === 45 ? (e.enter("tableDelimiterFiller"), w(E)) : _(E);
  }
  function w(E) {
    return E === 45 ? (e.consume(E), w) : E === 58 ? (a = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(E), e.exit("tableDelimiterMarker"), I) : (e.exit("tableDelimiterFiller"), I(E));
  }
  function I(E) {
    return X(E) ? ne(e, S, "whitespace")(E) : S(E);
  }
  function S(E) {
    return E === 124 ? h(E) : E === null || q(E) ? !a || i !== o ? _(E) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(E)) : _(E);
  }
  function _(E) {
    return n(E);
  }
  function y(E) {
    return e.enter("tableRow"), C(E);
  }
  function C(E) {
    return E === 124 ? (e.enter("tableCellDivider"), e.consume(E), e.exit("tableCellDivider"), C) : E === null || q(E) ? (e.exit("tableRow"), t(E)) : X(E) ? ne(e, C, "whitespace")(E) : (e.enter("data"), R(E));
  }
  function R(E) {
    return E === null || E === 124 || ae(E) ? (e.exit("data"), C(E)) : (e.consume(E), E === 92 ? F : R);
  }
  function F(E) {
    return E === 92 || E === 124 ? (e.consume(E), R) : R(E);
  }
}
function eS(e, t) {
  let n = -1, r = !0, i = 0, o = [0, 0, 0, 0], a = [0, 0, 0, 0], s = !1, u = 0, c, l, f;
  const p = new K_();
  for (; ++n < e.length; ) {
    const d = e[n], h = d[1];
    d[0] === "enter" ? h.type === "tableHead" ? (s = !1, u !== 0 && (js(p, t, u, c, l), l = void 0, u = 0), c = {
      type: "table",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, p.add(n, 0, [["enter", c, t]])) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (r = !0, f = void 0, o = [0, 0, 0, 0], a = [0, n + 1, 0, 0], s && (s = !1, l = {
      type: "tableBody",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, p.add(n, 0, [["enter", l, t]])), i = h.type === "tableDelimiterRow" ? 2 : l ? 3 : 1) : i && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") ? (r = !1, a[2] === 0 && (o[1] !== 0 && (a[0] = a[1], f = er(p, t, o, i, void 0, f), o = [0, 0, 0, 0]), a[2] = n)) : h.type === "tableCellDivider" && (r ? r = !1 : (o[1] !== 0 && (a[0] = a[1], f = er(p, t, o, i, void 0, f)), o = a, a = [o[1], n, 0, 0])) : h.type === "tableHead" ? (s = !0, u = n) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (u = n, o[1] !== 0 ? (a[0] = a[1], f = er(p, t, o, i, n, f)) : a[1] !== 0 && (f = er(p, t, a, i, n, f)), i = 0) : i && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") && (a[3] = n);
  }
  for (u !== 0 && js(p, t, u, c, l), p.consume(t.events), n = -1; ++n < t.events.length; ) {
    const d = t.events[n];
    d[0] === "enter" && d[1].type === "table" && (d[1]._align = G_(t.events, n));
  }
  return e;
}
function er(e, t, n, r, i, o) {
  const a = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", s = "tableContent";
  n[0] !== 0 && (o.end = Object.assign({}, Ht(t.events, n[0])), e.add(n[0], 0, [["exit", o, t]]));
  const u = Ht(t.events, n[1]);
  if (o = {
    type: a,
    start: Object.assign({}, u),
    // Note: correct end is set later.
    end: Object.assign({}, u)
  }, e.add(n[1], 0, [["enter", o, t]]), n[2] !== 0) {
    const c = Ht(t.events, n[2]), l = Ht(t.events, n[3]), f = {
      type: s,
      start: Object.assign({}, c),
      end: Object.assign({}, l)
    };
    if (e.add(n[2], 0, [["enter", f, t]]), r !== 2) {
      const p = t.events[n[2]], d = t.events[n[3]];
      if (p[1].end = Object.assign({}, d[1].end), p[1].type = "chunkText", p[1].contentType = "text", n[3] > n[2] + 1) {
        const h = n[2] + 1, m = n[3] - n[2] - 1;
        e.add(h, m, []);
      }
    }
    e.add(n[3] + 1, 0, [["exit", f, t]]);
  }
  return i !== void 0 && (o.end = Object.assign({}, Ht(t.events, i)), e.add(i, 0, [["exit", o, t]]), o = void 0), o;
}
function js(e, t, n, r, i) {
  const o = [], a = Ht(t.events, n);
  i && (i.end = Object.assign({}, a), o.push(["exit", i, t])), r.end = Object.assign({}, a), o.push(["exit", r, t]), e.add(n + 1, 0, o);
}
function Ht(e, t) {
  const n = e[t], r = n[0] === "enter" ? "start" : "end";
  return n[1][r];
}
const tS = {
  name: "tasklistCheck",
  tokenize: rS
};
function nS() {
  return {
    text: {
      91: tS
    }
  };
}
function rS(e, t, n) {
  const r = this;
  return i;
  function i(u) {
    return (
      // Exit if there’s stuff before.
      r.previous !== null || // Exit if not in the first content that is the first child of a list
      // item.
      !r._gfmTasklistFirstContentOfListItem ? n(u) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), o)
    );
  }
  function o(u) {
    return ae(u) ? (e.enter("taskListCheckValueUnchecked"), e.consume(u), e.exit("taskListCheckValueUnchecked"), a) : u === 88 || u === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(u), e.exit("taskListCheckValueChecked"), a) : n(u);
  }
  function a(u) {
    return u === 93 ? (e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), s) : n(u);
  }
  function s(u) {
    return q(u) ? t(u) : X(u) ? e.check({
      tokenize: iS
    }, t, n)(u) : n(u);
  }
}
function iS(e, t, n) {
  return ne(e, r, "whitespace");
  function r(i) {
    return i === null ? n(i) : t(i);
  }
}
function oS(e) {
  return sc([
    T_(),
    j_(),
    H_(e),
    X_(),
    nS()
  ]);
}
const aS = {};
function sS(e) {
  const t = (
    /** @type {Processor<Root>} */
    this
  ), n = e || aS, r = t.data(), i = r.micromarkExtensions || (r.micromarkExtensions = []), o = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), a = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
  i.push(oS(n)), o.push(E_()), a.push(C_(n));
}
const lS = {
  fontSize: 13,
  lineHeight: 1.6,
  wordBreak: "break-word"
}, uS = {
  padding: "1px 4px",
  borderRadius: 4,
  background: "rgba(128,128,128,0.15)",
  fontSize: 12,
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace"
}, cS = {
  margin: "8px 0",
  padding: 10,
  borderRadius: 8,
  background: "rgba(128,128,128,0.12)",
  overflowX: "auto"
}, fS = {
  borderCollapse: "collapse",
  margin: "8px 0",
  fontSize: 12
}, Zs = {
  border: "1px solid var(--border-color, #d2d2d7)",
  padding: "4px 8px"
};
function dS({ content: e }) {
  return /* @__PURE__ */ T("div", { style: lS, children: /* @__PURE__ */ T(
    $1,
    {
      remarkPlugins: [sS],
      components: {
        p: ({ children: t }) => /* @__PURE__ */ T("p", { style: { margin: "0 0 8px" }, children: t }),
        // 无 language- 标记的视为行内 code（轻量渲染的已知限制，块级统一带标记）
        code: ({ className: t, children: n }) => t != null && t.includes("language-") ? /* @__PURE__ */ T("code", { style: { fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }, children: n }) : /* @__PURE__ */ T("code", { style: uS, children: n }),
        pre: ({ children: t }) => /* @__PURE__ */ T("pre", { style: cS, children: t }),
        ul: ({ children: t }) => /* @__PURE__ */ T("ul", { style: { margin: "4px 0 8px", paddingLeft: 20 }, children: t }),
        ol: ({ children: t }) => /* @__PURE__ */ T("ol", { style: { margin: "4px 0 8px", paddingLeft: 20 }, children: t }),
        a: ({ children: t, href: n }) => /* @__PURE__ */ T("a", { href: n, style: { color: "var(--theme-color, #0a84ff)" }, target: "_blank", rel: "noreferrer", children: t }),
        table: ({ children: t }) => /* @__PURE__ */ T("table", { style: fS, children: t }),
        th: ({ children: t }) => /* @__PURE__ */ T("th", { style: Zs, children: t }),
        td: ({ children: t }) => /* @__PURE__ */ T("td", { style: Zs, children: t }),
        blockquote: ({ children: t }) => /* @__PURE__ */ T(
          "blockquote",
          {
            style: {
              margin: "8px 0",
              padding: "2px 10px",
              borderLeft: "3px solid var(--border-color, #d2d2d7)",
              color: "var(--text-secondary, #6e6e73)"
            },
            children: t
          }
        )
      },
      children: e
    }
  ) });
}
function pS(e) {
  return e.parts.filter((t) => t.type === "text").map((t) => t.text).join(`
`);
}
const hS = { display: "flex", gap: 8, marginTop: 12, alignItems: "flex-start" }, mS = {
  width: 26,
  height: 26,
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  fontSize: 10
}, bn = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 2,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex",
  alignItems: "center",
  gap: 2,
  fontSize: 11
};
function gS({ message: e, meta: t, streaming: n, actions: r, canUndo: i }) {
  var p;
  const o = e.role === "user", a = pS(e), s = (p = e.metadata) == null ? void 0 : p.displayText, [u, c] = ye(!1), l = Ve(void 0);
  qe(() => () => clearTimeout(l.current), []);
  const f = async () => {
    await navigator.clipboard.writeText(a), c(!0), clearTimeout(l.current), l.current = setTimeout(() => c(!1), 2e3);
  };
  return /* @__PURE__ */ Q("div", { style: { ...hS, flexDirection: o ? "row-reverse" : "row" }, children: [
    /* @__PURE__ */ T(
      "div",
      {
        style: {
          ...mS,
          background: o ? "var(--theme-color, #0a84ff)" : "rgba(128,128,128,0.2)",
          color: o ? "#fff" : "var(--text-secondary, #6e6e73)"
        },
        children: o ? "我" : /* @__PURE__ */ T(gi, { size: 13 })
      }
    ),
    /* @__PURE__ */ Q(
      "div",
      {
        style: {
          padding: "8px 10px",
          borderRadius: 10,
          maxWidth: "85%",
          overflow: "hidden",
          background: o ? "var(--theme-color, #0a84ff)" : "var(--bg-primary, #f5f5f7)",
          color: o ? "#fff" : "var(--text-primary, #1d1d1f)"
        },
        children: [
          o ? /* @__PURE__ */ T("p", { style: { margin: 0, fontSize: 13, whiteSpace: "pre-wrap", wordBreak: "break-word" }, children: s ?? a }) : /* @__PURE__ */ T("div", { style: { minHeight: 18 }, children: a === "" && n ? /* @__PURE__ */ T(bS, {}) : /* @__PURE__ */ Q(Nn, { children: [
            /* @__PURE__ */ T(dS, { content: a }),
            ((t == null ? void 0 : t.stopped) || ((t == null ? void 0 : t.omitted) ?? 0) > 0) && /* @__PURE__ */ T(yS, { meta: t })
          ] }) }),
          !o && a !== "" && /* @__PURE__ */ Q("div", { style: { display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 4 }, children: [
            i && (r == null ? void 0 : r.undoApply) && /* @__PURE__ */ T(
              "button",
              {
                type: "button",
                onClick: () => {
                  var d;
                  return (d = r.undoApply) == null ? void 0 : d.call(r, a);
                },
                title: "撤销本次就地应用",
                style: bn,
                children: /* @__PURE__ */ T("span", { children: "撤销应用" })
              }
            ),
            (r == null ? void 0 : r.insertAtCursor) && /* @__PURE__ */ Q("button", { type: "button", onClick: () => r.insertAtCursor(a), title: "插入到光标位置", style: bn, children: [
              /* @__PURE__ */ T(If, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "插入" })
            ] }),
            (r == null ? void 0 : r.replaceContent) && /* @__PURE__ */ Q("button", { type: "button", onClick: () => r.replaceContent(a), title: "替换整个文档内容", style: bn, children: [
              /* @__PURE__ */ T(zf, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "替换全文" })
            ] }),
            (r == null ? void 0 : r.saveAsNewFile) && /* @__PURE__ */ Q("button", { type: "button", onClick: () => r.saveAsNewFile(a), title: "另存为新文件", style: bn, children: [
              /* @__PURE__ */ T(Ef, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "另存" })
            ] }),
            /* @__PURE__ */ T("button", { type: "button", onClick: f, title: "复制内容", style: bn, children: u ? /* @__PURE__ */ T(xf, { size: 12 }) : /* @__PURE__ */ T(Sf, { size: 12 }) })
          ] })
        ]
      }
    )
  ] });
}
function yS({ meta: e }) {
  const t = [];
  return e != null && e.stopped && t.push("已停止生成"), ((e == null ? void 0 : e.omitted) ?? 0) > 0 && t.push(`上下文超限，已省略 ${e == null ? void 0 : e.omitted} 条早期消息`), /* @__PURE__ */ T("div", { style: { marginTop: 6, fontSize: 11, color: "var(--text-secondary, #6e6e73)", fontStyle: "italic" }, children: t.join("；") });
}
function bS() {
  const e = {
    width: 5,
    height: 5,
    borderRadius: "50%",
    background: "var(--text-secondary, #6e6e73)",
    display: "inline-block",
    marginRight: 3
  };
  return /* @__PURE__ */ Q("div", { style: { padding: "4px 0" }, children: [
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite" } }),
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite 0.2s" } }),
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite 0.4s" } })
  ] });
}
const rf = [
  { value: "openai-compatible", label: "OpenAI 兼容" },
  { value: "anthropic", label: "Anthropic" },
  { value: "google", label: "Google" }
], vS = () => ({
  name: "",
  provider: "openai-compatible",
  modelId: "",
  baseUrl: "",
  contextWindow: 128e3,
  apiKey: ""
});
function kS({ services: e, models: t, onSave: n, onDelete: r, onSetDefault: i, onFetchUpstream: o, onClose: a }) {
  const [s, u] = ye(null), [c, l] = ye(""), [f, p] = ye(!1), [d, h] = ye(null), [m, v] = ye(!1);
  qe(() => {
    let S = !1;
    return e.invokeBackend("getSetting", { key: $i }).then(({ value: _ }) => {
      S || v(_ === "true");
    }).catch(() => {
    }), () => {
      S = !0;
    };
  }, [e]);
  const g = () => {
    const S = !m;
    v(S), e.invokeBackend("setSetting", { key: $i, value: String(S) }).catch(() => v(!S));
  }, w = async () => {
    if (s) {
      if (!s.modelId.trim()) {
        l("请填写模型 ID");
        return;
      }
      p(!0), l("");
      try {
        await n(s), u(null);
      } catch (S) {
        l(S instanceof Error ? S.message : String(S));
      } finally {
        p(!1);
      }
    }
  }, I = async (S) => {
    if (d !== S) {
      h(S);
      return;
    }
    h(null);
    try {
      await r(S);
    } catch (_) {
      l(_ instanceof Error ? _.message : String(_));
    }
  };
  return qe(() => {
    const S = (_) => {
      _.key === "Escape" && (s ? u(null) : a());
    };
    return window.addEventListener("keydown", S), () => window.removeEventListener("keydown", S);
  }, [s, a]), /* @__PURE__ */ T(_S, { children: /* @__PURE__ */ Q("div", { style: SS, children: [
    /* @__PURE__ */ Q("div", { style: IS, children: [
      /* @__PURE__ */ T("strong", { style: { fontSize: 14 }, children: "模型设置" }),
      /* @__PURE__ */ T("button", { type: "button", onClick: a, style: tr, title: "关闭", children: /* @__PURE__ */ T(yi, { size: 14 }) })
    ] }),
    s === null ? /* @__PURE__ */ Q(Nn, { children: [
      t.length === 0 && /* @__PURE__ */ T("p", { style: { fontSize: 12, color: "var(--text-secondary, #6e6e73)", margin: "12px 0" }, children: "还没有模型，点击下方按钮添加。" }),
      t.map((S) => /* @__PURE__ */ Q("div", { style: ES, children: [
        /* @__PURE__ */ Q("div", { style: { flex: 1, minWidth: 0 }, children: [
          /* @__PURE__ */ Q("div", { style: { fontSize: 13, fontWeight: 500, display: "flex", alignItems: "center", gap: 6 }, children: [
            /* @__PURE__ */ T("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: S.name || S.modelId }),
            S.isDefault && /* @__PURE__ */ T(MS, { children: "默认" })
          ] }),
          /* @__PURE__ */ Q("div", { style: { fontSize: 11, color: "var(--text-secondary, #6e6e73)" }, children: [
            xS(S.provider),
            " · ",
            S.modelId
          ] })
        ] }),
        /* @__PURE__ */ T("button", { type: "button", onClick: () => void i(S.id), style: tr, title: "设为默认", children: /* @__PURE__ */ T(Mf, { size: 13, fill: S.isDefault ? "currentColor" : "none" }) }),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => u({
              id: S.id,
              name: S.name ?? "",
              provider: S.provider,
              modelId: S.modelId,
              baseUrl: S.baseUrl,
              contextWindow: S.contextWindow,
              apiKey: ""
            }),
            style: tr,
            title: "编辑",
            children: /* @__PURE__ */ T(Ys, { size: 13 })
          }
        ),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => void I(S.id),
            style: { ...tr, color: d === S.id ? "#e5484d" : void 0 },
            title: d === S.id ? "再点一次确认删除" : "删除",
            children: /* @__PURE__ */ T(Gs, { size: 13 })
          }
        )
      ] }, S.id)),
      /* @__PURE__ */ Q("button", { type: "button", onClick: () => u(vS()), style: No, children: [
        /* @__PURE__ */ T(Af, { size: 13 }),
        " 添加模型"
      ] }),
      /* @__PURE__ */ Q("div", { style: zS, children: [
        /* @__PURE__ */ T("div", { style: TS, children: "对话行为" }),
        /* @__PURE__ */ Q("label", { style: OS, children: [
          /* @__PURE__ */ T("input", { type: "checkbox", checked: m, onChange: g }),
          /* @__PURE__ */ T("span", { children: "生成完成后应用到文档（替换选中内容）" })
        ] }),
        /* @__PURE__ */ T("p", { style: PS, children: "开启后，编辑器右键 AI 动作的结果会自动替换文档中选中的内容" })
      ] })
    ] }) : /* @__PURE__ */ T(
      wS,
      {
        form: s,
        setForm: u,
        onSave: w,
        busy: f,
        onFetchUpstream: o
      }
    ),
    c !== "" && /* @__PURE__ */ T("p", { style: of, children: c })
  ] }) });
}
function wS({
  form: e,
  setForm: t,
  onSave: n,
  busy: r,
  onFetchUpstream: i
}) {
  const [o, a] = ye(null), [s, u] = ye(""), [c, l] = ye(!1), f = async () => {
    if (!c) {
      if (!e.baseUrl.trim()) {
        u("请先填写 Base URL（或留空使用官方默认地址）");
        return;
      }
      u(""), l(!0);
      try {
        const d = await i({
          provider: e.provider,
          baseUrl: e.baseUrl,
          apiKey: e.apiKey ?? ""
        });
        a(d), d.length === 1 && t({ ...e, modelId: d[0].id });
      } catch (d) {
        a(null), u(d instanceof Error ? d.message : String(d));
      } finally {
        l(!1);
      }
    }
  }, p = (d, h, m) => /* @__PURE__ */ Q("label", { style: { display: "block", marginBottom: 10 }, children: [
    /* @__PURE__ */ T("span", { style: CS, children: d }),
    h,
    m && /* @__PURE__ */ T("span", { style: AS, children: m })
  ] });
  return /* @__PURE__ */ Q("div", { children: [
    p(
      "名称",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.name,
          placeholder: "选填，默认显示模型 ID",
          onChange: (d) => t({ ...e, name: d.target.value })
        }
      )
    ),
    p(
      "提供商",
      /* @__PURE__ */ T("select", { style: qt, value: e.provider, onChange: (d) => t({ ...e, provider: d.target.value }), children: rf.map((d) => /* @__PURE__ */ T("option", { value: d.value, children: d.label }, d.value)) })
    ),
    p(
      "模型 ID",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.modelId,
          placeholder: "如 gpt-4o / claude-sonnet-4-5",
          onChange: (d) => t({ ...e, modelId: d.target.value })
        }
      )
    ),
    /* @__PURE__ */ Q("div", { style: { marginBottom: 10 }, children: [
      /* @__PURE__ */ T("button", { type: "button", onClick: () => void f(), style: Bs, disabled: r || c, children: c ? "拉取中…" : "拉取模型清单" }),
      s !== "" && /* @__PURE__ */ T("p", { style: of, children: s }),
      o !== null && o.length > 0 && /* @__PURE__ */ T("div", { style: { marginTop: 6, display: "flex", flexDirection: "column", gap: 4 }, children: o.map((d) => /* @__PURE__ */ Q(
        "button",
        {
          type: "button",
          onClick: () => t({ ...e, modelId: d.id }),
          style: {
            textAlign: "left",
            border: "1px solid var(--border-color, #e5e5e5)",
            background: "transparent",
            borderRadius: 6,
            padding: "5px 8px",
            fontSize: 12,
            cursor: "pointer",
            color: "var(--text-primary, #1d1d1f)"
          },
          children: [
            d.name || d.id,
            /* @__PURE__ */ T("span", { style: { marginLeft: 6, fontSize: 10, color: "var(--text-secondary, #6e6e73)" }, children: d.id })
          ]
        },
        d.id
      )) })
    ] }),
    p(
      "Base URL",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.baseUrl,
          placeholder: "留空使用官方默认地址",
          onChange: (d) => t({ ...e, baseUrl: d.target.value })
        }
      )
    ),
    p(
      "上下文窗口",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          type: "number",
          value: e.contextWindow,
          min: 0,
          onChange: (d) => t({ ...e, contextWindow: Number(d.target.value) || 0 })
        }
      ),
      "token 数，0 表示使用默认 128k"
    ),
    p(
      "API Key",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          type: "password",
          value: e.apiKey ?? "",
          placeholder: e.id ? "留空表示不修改" : "必填",
          onChange: (d) => t({ ...e, apiKey: d.target.value })
        }
      ),
      "加密存储在系统安全区，不写入数据库"
    ),
    /* @__PURE__ */ Q("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ T("button", { type: "button", onClick: () => t(null), style: Bs, disabled: r, children: "取消" }),
      /* @__PURE__ */ T("button", { type: "button", onClick: n, style: No, disabled: r, children: "保存" })
    ] })
  ] });
}
function xS(e) {
  var t;
  return ((t = rf.find((n) => n.value === e)) == null ? void 0 : t.label) ?? e;
}
function _S({ children: e }) {
  return /* @__PURE__ */ Q(Nn, { children: [
    /* @__PURE__ */ T("style", { children: `
        @keyframes swallow-ai-ms-fade-in { from { opacity: 0 } to { opacity: 1 } }
        @keyframes swallow-ai-ms-zoom-in { from { opacity: 0; transform: scale(0.95) } to { opacity: 1; transform: scale(1) } }
      ` }),
    /* @__PURE__ */ T(
      "div",
      {
        style: {
          position: "absolute",
          inset: 0,
          zIndex: 30,
          // 对齐宿主 Dialog 遮罩（bg-black/80）
          background: "rgba(0,0,0,0.8)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 12,
          animation: "swallow-ai-ms-fade-in 0.15s ease-out"
        },
        children: e
      }
    )
  ] });
}
const SS = {
  // 对齐宿主 Dialog：白底卡片 + 边框 + zoom/fade 进场
  background: "var(--bg-secondary, #fff)",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 12,
  padding: 14,
  width: "100%",
  maxHeight: "100%",
  overflowY: "auto",
  boxShadow: "0 8px 30px rgba(0,0,0,0.18)",
  animation: "swallow-ai-ms-zoom-in 0.2s ease-out"
}, IS = { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }, ES = { display: "flex", alignItems: "center", gap: 4, padding: "6px 0", borderBottom: "1px solid var(--border-color, #e5e5e5)" }, CS = { display: "block", fontSize: 11, color: "var(--text-secondary, #6e6e73)", marginBottom: 3 }, AS = { display: "block", fontSize: 10, color: "var(--text-secondary, #6e6e73)", marginTop: 2 }, of = { color: "#e5484d", fontSize: 12, margin: "8px 0 0" }, zS = {
  marginTop: 14,
  paddingTop: 12,
  borderTop: "1px solid var(--border-color, #e5e5e5)"
}, TS = { fontSize: 12, fontWeight: 500, marginBottom: 6 }, OS = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  fontSize: 12,
  cursor: "pointer"
}, PS = {
  fontSize: 11,
  color: "var(--text-secondary, #6e6e73)",
  margin: "6px 0 0"
}, qt = {
  width: "100%",
  padding: "6px 8px",
  fontSize: 12,
  borderRadius: 6,
  border: "1px solid var(--border-color, #e5e5e5)",
  // 对齐宿主 Input（bg-transparent）：白卡片上透明底描边
  background: "transparent",
  color: "var(--text-primary, #1d1d1f)",
  boxSizing: "border-box"
}, tr = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 4,
  borderRadius: 6,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex"
}, No = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  border: "none",
  borderRadius: 6,
  padding: "6px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff"
}, Bs = {
  ...No,
  // 白卡片上的次按钮用宿主外壳灰，避免白底不可见
  background: "var(--bg-primary, #f5f5f7)",
  color: "var(--text-primary, #1d1d1f)"
};
function MS({ children: e }) {
  return /* @__PURE__ */ T(
    "span",
    {
      style: {
        fontSize: 10,
        padding: "1px 5px",
        borderRadius: 4,
        // 主题色淡底（color-mix 从 --theme-color 派生，不再硬编码蓝色）
        background: "color-mix(in srgb, var(--theme-color, #0a84ff) 12%, transparent)",
        color: "var(--theme-color, #0a84ff)",
        flexShrink: 0
      },
      children: e
    }
  );
}
const RS = [
  { key: "continue_writing", label: "续写", iconName: "Edit3" },
  { key: "polish", label: "润色", iconName: "Star" },
  { key: "correct", label: "纠错", iconName: "Check" },
  { key: "outline", label: "提纲", iconName: "FileText" },
  { key: "summary", label: "摘要", iconName: "Copy" },
  { key: "format", label: "格式整理", iconName: "Code" },
  { key: "complete", label: "补全", iconName: "FilePlus" },
  { key: "rewrite", label: "改写", iconName: "RefreshCw" },
  { key: "explain", label: "解释", iconName: "Eye" }
], af = "com.swallownote.ai";
async function $S(e) {
  const t = e.path ?? "";
  if (!t || e.isDirectory) return null;
  const n = await Hs.read(t);
  return {
    type: "file-attach",
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    path: t,
    name: t.split("/").pop() ?? t,
    content: n
  };
}
function DS(e, t) {
  return `请基于以下文件内容回答我的问题（${e}）：

${t}

`;
}
async function NS(e, t, n) {
  const r = await kt.getSelection(), i = (r == null ? void 0 : r.text) ?? n.selection ?? "", o = i.length > 0, a = o ? i : await kt.getActiveContent() ?? "";
  return {
    type: "role-action",
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    roleKey: e,
    roleName: t,
    hasSelection: o,
    content: a,
    lineRange: (r == null ? void 0 : r.lineRange) ?? void 0,
    filePath: n.path ?? ""
  };
}
function LS() {
  for (const e of RS)
    Js(af, {
      id: `ai-role-${e.key}`,
      label: e.label,
      iconName: e.iconName,
      locations: ["editor"],
      onClick: (t) => {
        NS(e.key, e.label, t).then((n) => {
          Ws(n);
        });
      }
    });
}
function FS() {
  Js(af, {
    id: "ai-add-file-to-chat",
    label: "添加到 AI 对话",
    iconName: "FileText",
    locations: ["fileTree"],
    when: (e) => e.isDirectory !== !0,
    onClick: async (e) => {
      try {
        const t = await $S(e);
        t && Ws(t);
      } catch (t) {
        console.warn("[ai] 添加到 AI 对话失败：", t);
      }
    }
  });
}
function jS({ services: e, pendingRequest: t }) {
  const n = vv(e), r = kv(e), i = wv(e), [o, a] = ye(""), [s, u] = ye(!1), [c, l] = ye(!1), [f, p] = ye(null), [d, h] = ye(""), [m, v] = ye(null), g = Ve(null), [w, I] = ye(null), S = Ve(void 0), _ = be((O, U) => {
    clearTimeout(S.current), I({ text: O, tone: U }), S.current = setTimeout(() => I(null), 3e3);
  }, []);
  qe(() => () => clearTimeout(S.current), []);
  const y = Ve(!1);
  qe(() => {
    y.current || (y.current = !0, (async () => {
      const O = await e.invokeBackend("importLegacyData");
      if (!(O != null && O.imported)) return;
      const U = O.counts;
      _(
        `已导入历史数据：消息 ${(U == null ? void 0 : U.messages) ?? 0} 条 · 角色 ${(U == null ? void 0 : U.rolePrompts) ?? 0} 个 · 模型 ${(U == null ? void 0 : U.models) ?? 0} 个`
      ), await Promise.all([r.refresh(), n.refresh()]), await e.invokeBackend("finalizeLegacyImport");
    })().catch(() => {
    }));
  }, []);
  const C = Ve(null), R = Ve(null), [F, E] = ye(null), M = Gt(
    () => new gv({
      invokeBackend: e.invokeBackend,
      invokeBackendStream: e.invokeBackendStream,
      getModelId: () => n.activeModelIdRef.current,
      getApiKey: (O) => e.secureStorage.get(`model:${O}`)
    }),
    [e, n.activeModelIdRef]
  ), L = be(
    (O) => {
      const U = g.current;
      if (!U || O.isError) return;
      const Be = O.message.metadata ?? {}, zt = C.current;
      C.current = null, (async () => {
        const Vn = Ju(O.message), ln = { stopped: Be.stopped, omitted: Be.omitted };
        if (zt && zt.selectionOriginal !== "" && await US(e)) {
          const un = await kt.getSelection().catch(() => null);
          un && un.text === zt.selectionOriginal && await kt.replaceSelection(Vn).catch(() => !1) ? (ln.applied = !0, ln.selectionOriginal = zt.selectionOriginal, E({ id: O.message.id, selectionOriginal: zt.selectionOriginal }), _("已应用到文档")) : _("请先选中要修改的内容", "error");
        }
        await i.appendAssistant(U, Vn, ln), r.refresh();
      })().catch(() => {
      });
    },
    [i, r, e, _]
  ), { messages: x, sendMessage: Z, status: B, stop: Y, error: N, setMessages: H, regenerate: le, clearError: b } = hv({
    transport: M,
    onFinish: L
  }), ke = B === "submitted" || B === "streaming";
  qe(() => {
    let O = !1;
    if (r.activeId === null) {
      H([]);
      return;
    }
    return i.loadMessages(r.activeId).then((U) => {
      O || H(U);
    }).catch(() => {
    }), () => {
      O = !0;
    };
  }, [r.activeId, i, H]);
  const Ze = Ve(null);
  qe(() => {
    const O = Ze.current;
    O && (O.scrollTop = O.scrollHeight);
  }, [x]), qe(() => {
    const O = t;
    if (!(!O || typeof O != "object" || O.type !== "role-action") && R.current !== O.id) {
      if (R.current = O.id, !n.activeModelIdRef.current) {
        _("请先在设置中添加模型，再使用角色动作", "error");
        return;
      }
      (async () => {
        Y();
        let U = r.activeId;
        if (!U)
          try {
            U = await r.create();
          } catch {
            _("创建会话失败", "error");
            return;
          }
        g.current = U;
        const Be = BS(O);
        try {
          await i.appendUser(U, O.content, { roleKey: O.roleKey, displayText: Be });
        } catch {
          _("消息落库失败", "error");
          return;
        }
        r.refresh(), C.current = { selectionOriginal: O.hasSelection ? O.content : "" }, Z(
          { text: O.content, metadata: { displayText: Be, roleKey: O.roleKey } },
          { body: { roleKey: O.roleKey } }
        );
      })();
    }
  }, [t, n, r, i, Z, Y, _]), qe(() => {
    const O = t;
    if (!O || typeof O != "object" || O.type !== "file-attach" || R.current === O.id) return;
    R.current = O.id;
    const U = DS(O.path, O.content);
    a((Be) => Be ? `${Be}

${U}` : U);
  }, [t]);
  const k = Gt(
    () => ({
      insertAtCursor: (O) => {
        kt.insertAtCursor(O).then((U) => _(U ? "已插入到光标位置" : "插入失败：编辑器不可用", U ? void 0 : "error")).catch(() => _("插入失败", "error"));
      },
      replaceContent: (O) => {
        kt.replaceContent(O).then(() => _("已替换全文")).catch(() => _("替换失败", "error"));
      },
      saveAsNewFile: (O) => {
        const U = `ai-notes/${VS()}.md`;
        Hs.createNote(U, O).then(() => _(`已另存为 ${U}`)).catch(() => _("另存失败", "error"));
      },
      undoApply: (O) => {
        F && (async () => {
          const U = await kt.getSelection().catch(() => null);
          if (!U) {
            _("请先选中要撤销的内容", "error");
            return;
          }
          if (U.text !== O) {
            _("文档已变动，无法自动撤销", "error");
            return;
          }
          await kt.replaceSelection(F.selectionOriginal).catch(() => !1) ? (E(null), _("已撤销本次应用")) : _("文档已变动，无法自动撤销", "error");
        })();
      }
    }),
    [F, _]
  ), Te = async () => {
    const O = o.trim();
    if (!O || !n.activeModelId || ke) return;
    b(), C.current = null;
    let U = r.activeId;
    U || (U = await r.create()), g.current = U;
    try {
      await i.appendUser(U, O), r.refresh();
    } catch {
      return;
    }
    a(""), Z({ text: O });
  }, nt = () => {
    ke && Y();
  }, ge = r.sessions.find((O) => O.id === r.activeId) ?? null, rt = r.loaded && n.models.length === 0, Ke = async () => {
    f && d.trim() && await r.rename(f, d.trim()).catch(() => {
    }), p(null);
  }, mt = async (O) => {
    if (m !== O) {
      v(O);
      return;
    }
    v(null), nt(), await r.remove(O).catch(() => {
    });
  };
  return /* @__PURE__ */ Q("div", { style: qS, children: [
    /* @__PURE__ */ T("style", { children: "@keyframes ai-blink{0%,100%{opacity:.2}50%{opacity:1}}" }),
    /* @__PURE__ */ Q("div", { style: JS, children: [
      /* @__PURE__ */ Q(
        "button",
        {
          type: "button",
          onClick: () => {
            l((O) => !O), v(null);
          },
          style: WS,
          title: "会话列表",
          children: [
            /* @__PURE__ */ T("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 130 }, children: (ge == null ? void 0 : ge.title) ?? "新对话" }),
            /* @__PURE__ */ T(_f, { size: 12 })
          ]
        }
      ),
      /* @__PURE__ */ T("span", { style: { flex: 1 } }),
      /* @__PURE__ */ Q(
        "select",
        {
          value: n.activeModelId ?? "",
          onChange: (O) => n.setActiveModel(O.target.value),
          style: HS,
          title: "选择模型",
          children: [
            n.models.length === 0 && /* @__PURE__ */ T("option", { value: "", children: "未配置模型" }),
            n.models.map((O) => /* @__PURE__ */ T("option", { value: O.id, children: O.name || O.modelId }, O.id))
          ]
        }
      ),
      /* @__PURE__ */ T("button", { type: "button", onClick: () => u(!0), style: vn, title: "模型设置", children: /* @__PURE__ */ T(Tf, { size: 13 }) })
    ] }),
    w && /* @__PURE__ */ T(
      "div",
      {
        style: {
          ...nI,
          ...w.tone === "error" ? { background: "rgba(229,72,77,0.1)", color: "#e5484d" } : {}
        },
        children: w.text
      }
    ),
    c && /* @__PURE__ */ T(ZS, { onClose: () => l(!1), children: /* @__PURE__ */ Q("div", { style: oI, onClick: (O) => O.stopPropagation(), children: [
      /* @__PURE__ */ Q("div", { style: aI, children: [
        /* @__PURE__ */ T("strong", { style: { fontSize: 13 }, children: "会话" }),
        /* @__PURE__ */ T("button", { type: "button", onClick: () => l(!1), style: vn, title: "关闭", children: /* @__PURE__ */ T(yi, { size: 13 }) })
      ] }),
      /* @__PURE__ */ Q("div", { style: { overflowY: "auto", flex: 1 }, children: [
        r.sessions.length === 0 && /* @__PURE__ */ T("p", { style: { fontSize: 12, color: "var(--text-secondary, #6e6e73)", margin: "8px 0" }, children: "暂无会话" }),
        r.sessions.map((O) => /* @__PURE__ */ T(
          "div",
          {
            style: {
              ...sI,
              background: O.id === r.activeId ? "rgba(10,132,255,0.08)" : "transparent"
            },
            children: f === O.id ? /* @__PURE__ */ T(
              "input",
              {
                autoFocus: !0,
                style: uI,
                value: d,
                onChange: (U) => h(U.target.value),
                onBlur: () => void Ke(),
                onKeyDown: (U) => {
                  U.key === "Enter" && Ke(), U.key === "Escape" && p(null);
                }
              }
            ) : /* @__PURE__ */ Q(Nn, { children: [
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  style: lI,
                  onClick: () => {
                    nt(), r.activate(O.id), l(!1);
                  },
                  children: O.title
                }
              ),
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    p(O.id), h(O.title);
                  },
                  style: vn,
                  title: "重命名",
                  children: /* @__PURE__ */ T(Ys, { size: 12 })
                }
              ),
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  onClick: () => void mt(O.id),
                  style: { ...vn, color: m === O.id ? "#e5484d" : void 0 },
                  title: m === O.id ? "再点一次确认删除" : "删除",
                  children: /* @__PURE__ */ T(Gs, { size: 12 })
                }
              )
            ] })
          },
          O.id
        ))
      ] }),
      /* @__PURE__ */ Q(
        "button",
        {
          type: "button",
          style: Vs,
          onClick: () => {
            nt(), r.create().then(() => l(!1)).catch(() => {
            });
          },
          children: [
            /* @__PURE__ */ T(Cf, { size: 13 }),
            " 新建对话"
          ]
        }
      )
    ] }) }),
    s && /* @__PURE__ */ T(
      kS,
      {
        services: e,
        models: n.models,
        onSave: n.saveModel,
        onDelete: n.deleteModel,
        onSetDefault: n.setDefaultModel,
        onFetchUpstream: n.fetchUpstreamModels,
        onClose: () => u(!1)
      }
    ),
    /* @__PURE__ */ T("div", { ref: Ze, style: KS, children: rt ? /* @__PURE__ */ T(
      Us,
      {
        icon: /* @__PURE__ */ T(gi, { size: 26 }),
        text: "先添加一个模型开始对话",
        action: /* @__PURE__ */ T("button", { type: "button", style: Vs, onClick: () => u(!0), children: "添加模型" })
      }
    ) : x.length === 0 && !ke ? /* @__PURE__ */ T(Us, { icon: /* @__PURE__ */ T(gi, { size: 26 }), text: "有什么可以帮你？" }) : x.map((O) => /* @__PURE__ */ T(
      gS,
      {
        message: O,
        meta: O.metadata ?? void 0,
        streaming: ke,
        actions: k,
        canUndo: (F == null ? void 0 : F.id) === O.id
      },
      O.id
    )) }),
    N && /* @__PURE__ */ Q("div", { style: tI, children: [
      /* @__PURE__ */ T("span", { style: { flex: 1, overflow: "hidden", textOverflow: "ellipsis" }, children: N.message }),
      /* @__PURE__ */ T("button", { type: "button", style: rI, onClick: () => void le(), children: "重试" }),
      /* @__PURE__ */ T("button", { type: "button", style: vn, onClick: () => b(), title: "关闭", children: /* @__PURE__ */ T(yi, { size: 12 }) })
    ] }),
    /* @__PURE__ */ Q("div", { style: YS, children: [
      /* @__PURE__ */ T(
        "textarea",
        {
          style: GS,
          placeholder: rt ? "请先添加模型" : "输入消息，Enter 发送，Shift+Enter 换行",
          value: o,
          disabled: rt,
          onChange: (O) => {
            a(O.target.value);
            const U = O.target;
            U.style.height = "auto", U.style.height = Math.min(Math.max(U.scrollHeight, 50), 160) + "px";
          },
          onKeyDown: (O) => {
            O.key === "Enter" && !O.shiftKey && (O.preventDefault(), Te());
          }
        }
      ),
      /* @__PURE__ */ Q("div", { style: XS, children: [
        /* @__PURE__ */ T("span", { style: { fontSize: 11, color: "var(--text-secondary, #6e6e73)" }, children: n.activeModelId ? "" : "未配置模型" }),
        /* @__PURE__ */ T("span", { style: { flex: 1 } }),
        ke && /* @__PURE__ */ T("button", { type: "button", onClick: () => Y(), style: eI, title: "停止生成", children: /* @__PURE__ */ T(Pf, { size: 11 }) }),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => void Te(),
            disabled: rt || !o.trim() || ke,
            style: QS,
            title: "发送",
            children: "发送"
          }
        )
      ] })
    ] })
  ] });
}
function ZS({ children: e, onClose: t }) {
  return /* @__PURE__ */ T("div", { style: iI, onClick: t, children: e });
}
function Us({ icon: e, text: t, action: n }) {
  return /* @__PURE__ */ Q(
    "div",
    {
      style: {
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        color: "var(--text-secondary, #6e6e73)",
        fontSize: 13
      },
      children: [
        e,
        /* @__PURE__ */ T("span", { children: t }),
        n
      ]
    }
  );
}
function BS(e) {
  const t = e.filePath.split(/[\\/]/).pop() ?? e.filePath, n = e.lineRange ? ` (L${e.lineRange[0]}-${e.lineRange[1]})` : e.hasSelection ? "" : "（全文）";
  return `[${e.roleName}] ${t}${n}`;
}
async function US(e) {
  try {
    const { value: t } = await e.invokeBackend("getSetting", {
      key: $i
    });
    return t === "true";
  } catch {
    return !1;
  }
}
function VS() {
  const e = /* @__PURE__ */ new Date(), t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`;
}
const qS = {
  position: "relative",
  display: "flex",
  flexDirection: "column",
  height: "100%",
  // 对齐宿主面板容器背景 token（App.tsx 右侧面板同款），亮暗色及自定义主题均跟随
  background: "var(--bg-secondary-gradient, var(--bg-secondary, #fff))",
  color: "var(--text-primary, #1d1d1f)",
  overflow: "hidden"
}, JS = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  padding: "6px 10px",
  borderBottom: "1px solid var(--border-color, #e5e5ea)",
  flexShrink: 0
}, WS = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: "4px 6px",
  borderRadius: 6,
  fontSize: 12,
  color: "var(--text-primary, #1d1d1f)",
  maxWidth: 170
}, HS = {
  fontSize: 12,
  padding: "3px 4px",
  borderRadius: 6,
  border: "none",
  background: "transparent",
  color: "var(--text-secondary, #6e6e73)",
  maxWidth: 150,
  cursor: "pointer",
  outline: "none"
}, vn = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 4,
  borderRadius: 6,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex",
  alignItems: "center",
  flexShrink: 0
}, KS = {
  flex: 1,
  overflowY: "auto",
  padding: "4px 12px 12px"
}, YS = {
  flexShrink: 0,
  margin: "0 10px 10px",
  border: "1px solid var(--border-color, #d2d2d7)",
  borderRadius: 10,
  // 面板底色改为白后，输入区用宿主外壳灰（--bg-primary）保持层次对比
  background: "var(--bg-primary, #f5f5f7)"
}, GS = {
  width: "100%",
  border: "none",
  outline: "none",
  resize: "none",
  background: "transparent",
  color: "var(--text-primary, #1d1d1f)",
  fontSize: 13,
  lineHeight: 1.5,
  padding: "8px 10px 2px",
  minHeight: 50,
  maxHeight: 160,
  boxSizing: "border-box",
  fontFamily: "inherit"
}, XS = { display: "flex", alignItems: "center", gap: 6, padding: "2px 8px 8px" }, QS = {
  border: "none",
  borderRadius: 6,
  padding: "5px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff"
}, eI = {
  border: "none",
  borderRadius: 6,
  padding: 5,
  cursor: "pointer",
  background: "#e5484d",
  color: "#fff",
  display: "inline-flex"
}, tI = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  margin: "0 10px 8px",
  padding: "6px 10px",
  borderRadius: 8,
  background: "rgba(229,72,77,0.1)",
  color: "#e5484d",
  fontSize: 12,
  flexShrink: 0
}, nI = {
  margin: "6px 10px 0",
  padding: "5px 10px",
  borderRadius: 8,
  background: "rgba(10,132,255,0.08)",
  color: "var(--theme-color, #0a84ff)",
  fontSize: 12,
  flexShrink: 0
}, rI = {
  border: "none",
  borderRadius: 5,
  padding: "2px 8px",
  fontSize: 11,
  cursor: "pointer",
  background: "rgba(229,72,77,0.15)",
  color: "#e5484d",
  flexShrink: 0
}, iI = {
  position: "absolute",
  inset: 0,
  zIndex: 30,
  background: "rgba(0,0,0,0.2)",
  display: "flex",
  alignItems: "flex-start",
  justifyContent: "flex-start",
  padding: "40px 10px 10px"
}, oI = {
  background: "var(--bg-primary, #fff)",
  borderRadius: 10,
  padding: 10,
  width: "100%",
  maxHeight: "70%",
  display: "flex",
  flexDirection: "column",
  gap: 6,
  boxShadow: "0 8px 30px rgba(0,0,0,0.18)"
}, aI = { display: "flex", alignItems: "center", justifyContent: "space-between" }, sI = {
  display: "flex",
  alignItems: "center",
  gap: 2,
  borderRadius: 6,
  padding: "2px 2px 2px 6px"
}, lI = {
  flex: 1,
  textAlign: "left",
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: "6px 4px",
  fontSize: 12,
  color: "var(--text-primary, #1d1d1f)",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap"
}, uI = {
  flex: 1,
  fontSize: 12,
  padding: "5px 6px",
  borderRadius: 5,
  border: "1px solid var(--theme-color, #0a84ff)",
  outline: "none",
  background: "var(--bg-primary, #fff)",
  color: "var(--text-primary, #1d1d1f)",
  minWidth: 0
}, Vs = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 4,
  border: "none",
  borderRadius: 6,
  padding: "6px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff",
  flexShrink: 0
}, cI = "com.swallownote.ai", fI = "AI 助手", dI = "与 AI 对话并操作笔记：智能问答、内容生成、笔记整理。", pI = "0.1.5", hI = 1, mI = "SwallowNote", gI = "2026-11-12T08:18:59Z", yI = "titleBar", bI = "rightPanel", vI = 40, kI = !0, wI = !0, xI = "0.1.0", _I = "src/index.tsx", SI = [
  "storage",
  "events",
  "backend",
  "editor-write",
  "files",
  "context-menu",
  "secure-storage"
], II = {
  id: cI,
  name: fI,
  description: dI,
  version: pI,
  manifestVersion: hI,
  author: mI,
  publishedAt: gI,
  iconPosition: yI,
  contentPosition: bI,
  order: vI,
  enabled: kI,
  hasBackend: wI,
  minHostVersion: xI,
  entry: _I,
  permissions: SI
};
function EI({ size: e = 16 }) {
  return /* @__PURE__ */ T(Of, { size: e });
}
function CI(e) {
  const t = Gt(
    () => ({
      // SDK 的 invokeBackend 非泛型，这里转发为 hooks 需要的泛型签名
      invokeBackend: (n, r) => e.invokeBackend(n, r),
      invokeBackendStream: e.invokeBackendStream,
      secureStorage: e.secureStorage
    }),
    [e.invokeBackend, e.invokeBackendStream, e.secureStorage]
  );
  return /* @__PURE__ */ T(jS, { services: t, pendingRequest: e.pendingRequest });
}
const MI = pf(II, {
  icon: EI,
  panel: CI,
  // onLoad hook（flat 结构，不是嵌套在 hooks 里）：
  // 即使为空也触发 runPluginLifecycleHook 执行 setHost，
  // 使 SDK 的 openEditorTab 等 API 能转发到宿主实现
  onLoad: () => {
    LS(), FS();
  }
});
export {
  MI as default,
  TI as setHost
};
