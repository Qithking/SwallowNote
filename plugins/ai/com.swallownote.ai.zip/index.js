// @swallow-manifest {"id":"com.swallownote.ai","name":"AI 助手","description":"与 AI 对话并操作笔记：智能问答、内容生成、笔记整理。","version":"0.1.5","author":"SwallowNote","published_at":"2026-11-12T08:18:59Z","icon_position":"titleBar","content_position":"rightPanel","order":40,"enabled":true,"has_backend":true,"min_host_version":"0.1.0"}
import { jsxs as ee, jsx as T, Fragment as Dn } from "react/jsx-runtime";
import { forwardRef as Vs, createElement as mi, useRef as Ve, useCallback as ye, useSyncExternalStore as Zr, useEffect as qe, useState as ve, useMemo as Gt } from "react";
function ff(e, t) {
  return { ...e, ...t };
}
class df {
  constructor() {
    this.target = new EventTarget(), this.wrapperMap = /* @__PURE__ */ new Map();
  }
  on(t, n) {
    const r = (o) => n(o.detail);
    this.target.addEventListener(t, r);
    let i = this.wrapperMap.get(n);
    return i || (i = /* @__PURE__ */ new Map(), this.wrapperMap.set(n, i)), i.set(t, r), () => {
      this.target.removeEventListener(t, r), i.delete(t), i.size === 0 && this.wrapperMap.delete(n);
    };
  }
  off(t, n) {
    const r = this.wrapperMap.get(n), i = r == null ? void 0 : r.get(t);
    i && (this.target.removeEventListener(t, i), r.delete(t), r.size === 0 && this.wrapperMap.delete(n));
  }
  removeAllListenersForPlugin(t) {
  }
  emit(t, n) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: n }));
  }
}
const Bo = new df();
Bo.emit.bind(Bo);
class pf {
  constructor() {
    this.byPlugin = /* @__PURE__ */ new Map(), this.byLocation = {
      fileTree: [],
      fileTreeEmpty: [],
      editor: [],
      tab: [],
      tabBarEmpty: []
    };
  }
  register(t, n) {
    this.unregister(t, n.id);
    let r = this.byPlugin.get(t);
    r || (r = [], this.byPlugin.set(t, r)), r.push(n), this.indexItem(n);
  }
  unregister(t, n) {
    const r = this.byPlugin.get(t);
    if (!r)
      return;
    const i = r.findIndex((o) => o.id === n);
    i < 0 || (r.splice(i, 1), r.length === 0 && this.byPlugin.delete(t), this.rebuildIndex());
  }
  clearPlugin(t) {
    this.byPlugin.has(t) && (this.byPlugin.delete(t), this.rebuildIndex());
  }
  query(t, n) {
    const r = this.byLocation[t];
    return !r || r.length === 0 ? [] : r.filter((i) => !(i.locations && !i.locations.includes(t) || i.when && !i.when(n)));
  }
  getByLocation(t) {
    return this.byLocation[t];
  }
  indexItem(t) {
    const n = t.locations ?? [
      "fileTree",
      "fileTreeEmpty",
      "editor",
      "tab",
      "tabBarEmpty"
    ];
    for (const r of n)
      this.byLocation[r].push(t);
  }
  rebuildIndex() {
    for (const t of Object.keys(this.byLocation))
      this.byLocation[t] = [];
    for (const t of this.byPlugin.values())
      for (const n of t)
        this.indexItem(n);
  }
}
const hf = new pf();
function qs(e, t) {
  var n, r;
  ((r = (n = Xe()).registerContextMenu) == null ? void 0 : r.call(n, e, t)) ?? hf.register(e, t);
}
function Js(e) {
  var t, n;
  (n = (t = Xe()).__openPluginPanel) == null || n.call(t, e);
}
function xt(e, t) {
  console.warn(`[plugin-sdk] ${e} called but no host override is installed — ${t}. This is expected in standalone preview mode (npm run dev); in host mode the host installs the override via setHost() and enforces permissions there.`);
}
const kt = {
  insertAtCursor: async (e) => {
    const t = Xe().__editor_insertAtCursor;
    return t ? t(e) : (xt("editor.insertAtCursor", "the insert was dropped and returns false"), !1);
  },
  replaceSelection: async (e) => {
    const t = Xe().__editor_replaceSelection;
    return t ? t(e) : (xt("editor.replaceSelection", "the replace was dropped and returns false"), !1);
  },
  replaceContent: async (e) => {
    const t = Xe().__editor_replaceContent;
    if (t)
      return t(e);
    xt("editor.replaceContent", "the content replacement was dropped");
  },
  getSelection: async () => {
    const e = Xe().__editor_getSelection;
    return e ? e() : (xt("editor.getSelection", "returning null"), null);
  },
  getActiveContent: async () => {
    const e = Xe().__editor_getActiveContent;
    return e ? e() : (xt("editor.getActiveContent", "returning null"), null);
  }
}, Ws = {
  createNote: async (e, t) => {
    const n = Xe().__files_createNote;
    if (n)
      return n(e, t);
    xt("files.createNote", `the note "${e}" was not created`);
  },
  listWorkspace: async (e) => {
    const t = Xe().__files_listWorkspace;
    return t ? t(e) : (xt("files.listWorkspace", "returning an empty list"), []);
  },
  read: async (e) => {
    const t = Xe().__files_read;
    return t ? t(e) : (xt("files.read", "returning an empty string"), "");
  }
}, Kt = [];
let mf = 0;
function Xe() {
  const e = Kt[Kt.length - 1];
  return e ? e.overrides : gf;
}
const gf = Object.freeze({});
function TI(e, t) {
  const n = mf++, r = { ...Xe(), ...e };
  return Kt.push({ overrides: r, token: n, pluginId: t }), () => {
    for (let i = Kt.length - 1; i >= 0; i--)
      if (Kt[i].token === n) {
        Kt.splice(i, 1);
        return;
      }
  };
}
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const yf = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), Hs = (...e) => e.filter((t, n, r) => !!t && t.trim() !== "" && r.indexOf(t) === n).join(" ").trim();
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var bf = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const vf = Vs(
  ({
    color: e = "currentColor",
    size: t = 24,
    strokeWidth: n = 2,
    absoluteStrokeWidth: r,
    className: i = "",
    children: o,
    iconNode: a,
    ...s
  }, u) => mi(
    "svg",
    {
      ref: u,
      ...bf,
      width: t,
      height: t,
      stroke: e,
      strokeWidth: r ? Number(n) * 24 / Number(t) : n,
      className: Hs("lucide", i),
      ...s
    },
    [
      ...a.map(([c, l]) => mi(c, l)),
      ...Array.isArray(o) ? o : [o]
    ]
  )
);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Se = (e, t) => {
  const n = Vs(
    ({ className: r, ...i }, o) => mi(vf, {
      ref: o,
      iconNode: t,
      className: Hs(`lucide-${yf(e)}`, r),
      ...i
    })
  );
  return n.displayName = `${e}`, n;
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const gi = Se("Bot", [
  ["path", { d: "M12 8V4H8", key: "hb8ula" }],
  ["rect", { width: "16", height: "12", x: "4", y: "8", rx: "2", key: "enze0r" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M15 13v2", key: "1xurst" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const kf = Se("Check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const wf = Se("ChevronDown", [
  ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const xf = Se("Copy", [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const _f = Se("CornerDownRight", [
  ["polyline", { points: "15 10 20 15 15 20", key: "1q7qjw" }],
  ["path", { d: "M4 4v7a4 4 0 0 0 4 4h12", key: "z08zvw" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Sf = Se("FilePlus2", [
  ["path", { d: "M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4", key: "1pf5j1" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M3 15h6", key: "4e2qda" }],
  ["path", { d: "M6 12v6", key: "1u72j0" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const If = Se("MessageSquarePlus", [
  ["path", { d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z", key: "1lielz" }],
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ks = Se("Pencil", [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ef = Se("Plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Cf = Se("Replace", [
  ["path", { d: "M14 4a2 2 0 0 1 2-2", key: "1w2hp7" }],
  ["path", { d: "M16 10a2 2 0 0 1-2-2", key: "shjach" }],
  ["path", { d: "M20 2a2 2 0 0 1 2 2", key: "188mtx" }],
  ["path", { d: "M22 8a2 2 0 0 1-2 2", key: "ddf4tu" }],
  ["path", { d: "m3 7 3 3 3-3", key: "x25e72" }],
  ["path", { d: "M6 10V5a3 3 0 0 1 3-3h1", key: "3y3t5z" }],
  ["rect", { x: "2", y: "14", width: "8", height: "8", rx: "2", key: "4rksxw" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Af = Se("Settings", [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const zf = Se("Sparkles", [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Tf = Se("Square", [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Of = Se("Star", [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ys = Se("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const yi = Se("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]);
var Gs = "vercel.ai.error", Pf = Symbol.for(Gs), Uo, Vo, We = class Xs extends (Vo = Error, Uo = Pf, Vo) {
  /**
   * Creates an AI SDK Error.
   *
   * @param {Object} params - The parameters for creating the error.
   * @param {string} params.name - The name of the error.
   * @param {string} params.message - The error message.
   * @param {unknown} [params.cause] - The underlying cause of the error.
   */
  constructor({
    name: t,
    message: n,
    cause: r
  }) {
    super(n), this[Uo] = !0, this.name = t, this.cause = r;
  }
  /**
   * Checks if the given error is an AI SDK Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is an AI SDK Error, false otherwise.
   */
  static isInstance(t) {
    return Xs.hasMarker(t, Gs);
  }
  static hasMarker(t, n) {
    const r = Symbol.for(n);
    return t != null && typeof t == "object" && r in t && typeof t[r] == "boolean" && t[r] === !0;
  }
};
function Qs(e) {
  return e == null ? "unknown error" : typeof e == "string" ? e : e instanceof Error ? e.message : JSON.stringify(e);
}
var el = "AI_InvalidArgumentError", tl = `vercel.ai.error.${el}`, Mf = Symbol.for(tl), qo, Jo, Rf = class extends (Jo = We, qo = Mf, Jo) {
  constructor({
    message: t,
    cause: n,
    argument: r
  }) {
    super({ name: el, message: t, cause: n }), this[qo] = !0, this.argument = r;
  }
  static isInstance(t) {
    return We.hasMarker(t, tl);
  }
}, nl = "AI_JSONParseError", rl = `vercel.ai.error.${nl}`, $f = Symbol.for(rl), Wo, Ho, Ko = class extends (Ho = We, Wo = $f, Ho) {
  constructor({ text: e, cause: t }) {
    super({
      name: nl,
      message: `JSON parsing failed: Text: ${e}.
Error message: ${Qs(t)}`,
      cause: t
    }), this[Wo] = !0, this.text = e;
  }
  static isInstance(e) {
    return We.hasMarker(e, rl);
  }
}, il = "AI_TypeValidationError", ol = `vercel.ai.error.${il}`, Nf = Symbol.for(ol), Yo, Go, Xt = class bi extends (Go = We, Yo = Nf, Go) {
  constructor({
    value: t,
    cause: n,
    context: r
  }) {
    let i = "Type validation failed";
    if (r != null && r.field && (i += ` for ${r.field}`), r != null && r.entityName || r != null && r.entityId) {
      i += " (";
      const o = [];
      r.entityName && o.push(r.entityName), r.entityId && o.push(`id: "${r.entityId}"`), i += o.join(", "), i += ")";
    }
    super({
      name: il,
      message: `${i}: Value: ${JSON.stringify(t)}.
Error message: ${Qs(n)}`,
      cause: n
    }), this[Yo] = !0, this.value = t, this.context = r;
  }
  static isInstance(t) {
    return We.hasMarker(t, ol);
  }
  /**
   * Wraps an error into a TypeValidationError.
   * If the cause is already a TypeValidationError with the same value and context, it returns the cause.
   * Otherwise, it creates a new TypeValidationError.
   *
   * @param {Object} params - The parameters for wrapping the error.
   * @param {unknown} params.value - The value that failed validation.
   * @param {unknown} params.cause - The original error or cause of the validation failure.
   * @param {TypeValidationContext} params.context - Optional context about what is being validated.
   * @returns {TypeValidationError} A TypeValidationError instance.
   */
  static wrap({
    value: t,
    cause: n,
    context: r
  }) {
    var i, o, a;
    return bi.isInstance(n) && n.value === t && ((i = n.context) == null ? void 0 : i.field) === (r == null ? void 0 : r.field) && ((o = n.context) == null ? void 0 : o.entityName) === (r == null ? void 0 : r.entityName) && ((a = n.context) == null ? void 0 : a.entityId) === (r == null ? void 0 : r.entityId) ? n : new bi({ value: t, cause: n, context: r });
  }
};
function vi(e) {
  const t = Object.values(e).filter((r) => typeof r == "number");
  return Object.entries(e).filter(([r, i]) => t.indexOf(+r) === -1).map(([r, i]) => i);
}
function Xo(e, t = "|") {
  return e.map((n) => cl(n)).join(t);
}
function ki(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
class Df {
  constructor(t) {
    this._getter = t, this._value = void 0;
  }
  get value() {
    const t = this._getter;
    return t !== void 0 && (this._value = t(), this._getter = void 0), this._value;
  }
}
function Sr(e) {
  return new Df(e);
}
function Lf(e) {
  return e == null;
}
function Xi(e) {
  const t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
function Ff(e, t) {
  const n = e / t, r = Math.round(n), i = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - r) < i ? 0 : n - r;
}
const Qo = /* @__PURE__ */ Symbol("evaluating");
function jf(e, t, n) {
  let r;
  Object.defineProperty(e, t, {
    get() {
      if (r !== Qo)
        return r === void 0 && (r = Qo, r = n()), r;
    },
    set(i) {
      Object.defineProperty(e, t, {
        value: i
        // configurable: true,
      });
    },
    configurable: !0
  });
}
function ut(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function Qi(e) {
  const t = Object.getOwnPropertyDescriptor(e, "shape");
  return t != null && t.get ? t.get.raw : t == null ? void 0 : t.value;
}
function pt(e) {
  return Qi(e._zod.def) ?? e._zod.def.shape;
}
function al(e, t, n) {
  Object.defineProperty(e, t, {
    get() {
      const r = n();
      return ut(this, t, r), r;
    },
    enumerable: !0,
    configurable: !0
  });
}
function sl(e, t, n) {
  t in e ? ut(e, t, n) : e[t] = n;
}
function Nt(e, t, n, r) {
  const i = pt(t);
  for (const o of n) {
    const a = Object.getOwnPropertyDescriptor(i, o);
    a.enumerable && (a.get ? al(e, o, () => {
      const s = t._zod.def.shape[o];
      return r ? r(s, o) : s;
    }) : sl(e, o, r ? r(a.value, o) : a.value));
  }
}
function Zf(e, t) {
  for (const n of Reflect.ownKeys(t)) {
    const r = Object.getOwnPropertyDescriptor(t, n);
    r.enumerable && (r.get ? al(e, n, () => t[n]) : sl(e, n, r.value));
  }
}
function Le(...e) {
  const t = {};
  for (const n of e) {
    const r = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, r);
  }
  return Object.defineProperties({}, t);
}
function Bf(e) {
  return JSON.stringify(e);
}
function Uf(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const ll = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Pn(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const Vf = /* @__PURE__ */ Sr(() => {
  var e;
  if (tt.jitless || typeof navigator < "u" && ((e = navigator == null ? void 0 : navigator.userAgent) != null && e.includes("Cloudflare")))
    return !1;
  try {
    const t = Function;
    return new t(""), !0;
  } catch {
    return !1;
  }
});
function Qt(e) {
  if (Pn(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  const n = t.prototype;
  return !(Pn(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function ul(e) {
  return Qt(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
const qf = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function en(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Ct(e, t, n) {
  const r = new e._zod.constr(t ?? e._zod.def);
  return (!t || n != null && n.parent) && (r._zod.parent = e), r;
}
function j(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if ((t == null ? void 0 : t.message) !== void 0) {
    if ((t == null ? void 0 : t.error) !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function cl(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function Jf(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
const fl = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Wf = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Hf(e, t) {
  const n = e._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const o = {};
  return Nt(o, e, Ir(e, t)), Ct(e, Le(n, { shape: o, checks: [] }));
}
function Ir(e, t) {
  var i;
  const n = pt(e), r = [];
  for (const o of Reflect.ownKeys(t)) {
    if (!((i = Object.getOwnPropertyDescriptor(n, o)) != null && i.enumerable))
      throw new Error(`Unrecognized key: "${String(o)}"`);
    t[o] && r.push(o);
  }
  return r;
}
function Kf(e, t) {
  const n = e._zod.def, r = n.checks;
  if (r && r.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const o = new Set(Ir(e, t)), a = {};
  return Nt(a, e, Reflect.ownKeys(pt(e)).filter((s) => !o.has(s))), Ct(e, Le(n, { shape: a, checks: [] }));
}
function Yf(e, t) {
  if (!Qt(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = e._zod.def.checks;
  if (n && n.length > 0) {
    const i = pt(e);
    for (const o of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(i, o) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return Ct(e, Le(e._zod.def, { shape: dl(e, t) }));
}
function dl(e, t) {
  const n = {};
  return Nt(n, e, Reflect.ownKeys(pt(e))), Zf(n, t), n;
}
function Gf(e, t) {
  if (!Qt(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return Ct(e, Le(e._zod.def, { shape: dl(e, t) }));
}
function Xf(e, t) {
  var i, o;
  if (!((i = t == null ? void 0 : t._zod) != null && i.def))
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if ((o = e._zod.def.checks) != null && o.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  Nt(n, e, Reflect.ownKeys(pt(e))), Nt(n, t, Reflect.ownKeys(pt(t)));
  const r = Le(e._zod.def, {
    shape: n,
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return Ct(e, r);
}
function ea(e, t, n, r = "partial") {
  const o = t._zod.def.checks;
  if (o && o.length > 0)
    throw new Error(`.${r}() cannot be used on object schemas containing refinements`);
  const s = n ? new Set(Ir(t, n)) : void 0, u = {};
  return Nt(u, t, Reflect.ownKeys(pt(t)), e && ((c, l) => s && !s.has(l) ? c : new e({ type: "optional", innerType: c }))), Ct(t, Le(t._zod.def, { shape: u, checks: [] }));
}
function Qf(e, t, n) {
  const r = n ? new Set(Ir(t, n)) : void 0, i = {};
  return Nt(i, t, Reflect.ownKeys(pt(t)), (o, a) => (
    // overwrite with non-optional
    r && !r.has(a) ? o : new e({ type: "nonoptional", innerType: o })
  )), Ct(t, Le(t._zod.def, { shape: i }));
}
function dt(e, t = 0) {
  var n;
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (((n = e.issues[r]) == null ? void 0 : n.continue) !== !0)
      return !0;
  return !1;
}
function ed(e, t = 0) {
  var n;
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (((n = e.issues[r]) == null ? void 0 : n.continue) === !1)
      return !0;
  return !1;
}
function Mt(e, t) {
  return t.map((n) => {
    var r;
    return (r = n).path ?? (r.path = []), n.path.unshift(e), n;
  });
}
function pn(e) {
  return typeof e == "string" ? e : e == null ? void 0 : e.message;
}
function ta(e) {
  const t = [];
  for (const n of e ?? []) {
    const r = n._zod.def;
    if (!/_(length|size)$|_equals$/.test(r.check))
      break;
    const i = r.maximum ?? r.length ?? r.size;
    i >= 0 && t.push([i, n]);
  }
  return t;
}
function wi(e, t, n) {
  var r;
  for (let i = t; i < e.length; i++)
    (r = e[i]).schema ?? (r.schema = n);
}
function St(e, t, n) {
  var u, c, l, f, d, p, h, m, k, g;
  var r;
  const i = (c = (u = e.inst) == null ? void 0 : u._zod) == null ? void 0 : c.traits;
  i != null && i.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
  const o = e.schema !== e.inst ? (f = (l = e.schema) == null ? void 0 : l._zod.def) == null ? void 0 : f.error : void 0, a = e.message ? e.message : pn((h = (p = (d = e.inst) == null ? void 0 : d._zod.def) == null ? void 0 : p.error) == null ? void 0 : h.call(p, e)) ?? pn(o == null ? void 0 : o(e)) ?? pn((m = t == null ? void 0 : t.error) == null ? void 0 : m.call(t, e)) ?? pn((k = n.customError) == null ? void 0 : k.call(n, e)) ?? pn((g = n.localeError) == null ? void 0 : g.call(n, e)) ?? "Invalid input", s = {};
  for (const _ of Object.keys(e))
    _ === "inst" || _ === "schema" || _ === "continue" || _ === "input" || _ === "__proto__" || (s[_] = e[_]);
  return s.path ?? (s.path = []), s.message = a, t != null && t.reportInput && (s.input = e.input), s;
}
const td = /[\uD800-\uDBFF]/;
function eo(e) {
  const t = e.length;
  if (!td.test(e))
    return t;
  let n = t;
  for (let r = 0; r < t - 1; r++)
    (e.charCodeAt(r) & 64512) === 55296 && (e.charCodeAt(r + 1) & 64512) === 56320 && (n--, r++);
  return n;
}
function to(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function nd(e) {
  const t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      const n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
function Mn(...e) {
  const [t, n, r] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: r
  } : { ...t };
}
function rd(e, t) {
  for (const n in t) {
    const r = Object.getOwnPropertyDescriptor(t, n);
    r.get ? Object.defineProperty(e, n, { ...r, enumerable: !1 }) : id(e, n, r.value);
  }
}
function It(e, t, n, r = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: r, value: n }), n;
}
function no(e, t, n) {
  return It(e, t, n, !1);
}
function pl(e, t) {
  for (const n in e) {
    const r = e[n];
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return It(this, n, r(this));
      },
      set(i) {
        It(this, n, i);
      }
    });
  }
  return t;
}
function id(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : It(this, t, n.bind(this));
    },
    set(r) {
      It(this, t, r);
    }
  });
}
function od(e, t) {
  const n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
let Br, bt = !1;
const ad = {
  configurable: !0,
  get() {
    bt = !0;
  }
};
function te(e, t, n) {
  const r = Object.getPrototypeOf(e._zod);
  if (t in r && Br !== e._zod) {
    Br = void 0;
    return;
  }
  Br = e._zod, Object.defineProperty(r, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, ad);
      const i = bt;
      bt = !1;
      try {
        const o = n(this);
        return bt ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: o }), bt = bt || i, o;
      } catch (o) {
        throw delete this[t], bt = bt || i, o;
      }
    },
    set(i) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: i });
    }
  });
}
function sd(e, t, n, r) {
  const i = od(e, t);
  i && Object.defineProperty(i, t, {
    configurable: !0,
    get() {
      const o = { configurable: !0, writable: !0, enumerable: r, value: void 0 };
      return Object.defineProperty(this, t, o), o.value = n(this), Object.defineProperty(this, t, o), o.value;
    },
    set(o) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: r, value: o });
    }
  });
}
const ld = "~constantCatch";
function ud(e) {
  const t = () => e;
  return t[ld] = !0, t;
}
var na;
const Ur = { value: void 0, enumerable: !1 };
let ra = "captureStackTrace" in Error ? Error : null;
function cd(e) {
  const t = ra;
  if (t) {
    const n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return ra = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
function z(e, t, n, r) {
  const i = {};
  function o(d) {
    this.def = d, this.constr = f, this.traits = /* @__PURE__ */ new Set();
  }
  o.prototype = i;
  const a = n, s = a && /* @__PURE__ */ new WeakSet();
  function u(d, p) {
    if (d._zod) {
      if (d._zod.traits.has(e))
        return;
    } else {
      Ur.value = new o(p);
      try {
        Object.defineProperty(d, "_zod", Ur);
      } finally {
        Ur.value = void 0;
      }
    }
    if (d._zod.traits.add(e), t(d, p), s) {
      const m = Object.getPrototypeOf(d), k = d._zod.constr.prototype;
      let g = m;
      for (; g && g !== k; )
        g = Object.getPrototypeOf(g);
      const _ = g ?? m;
      s.has(_) || (s.add(_), rd(_, a));
    }
    const h = f.prototype;
    for (const m in h)
      Object.prototype.hasOwnProperty.call(h, m) && (m in d || (d[m] = h[m].bind(d)));
  }
  const c = (r == null ? void 0 : r.Parent) ?? Object;
  class l extends c {
  }
  Object.defineProperty(l, "name", { value: e });
  function f(d) {
    var k;
    const p = r != null && r.Parent ? cd(l) : this;
    u(p, d);
    const h = p._zod.deferred;
    if (h) {
      for (const g of h)
        g();
      p._zod.deferred = void 0;
    }
    const m = (k = globalThis.__zod_globalConfig) == null ? void 0 : k.postProcessor;
    return m && m(p), p;
  }
  return Object.defineProperty(f, "init", { value: u }), Object.defineProperty(f, Symbol.hasInstance, {
    value: (d) => {
      var p, h;
      return r != null && r.Parent && d instanceof r.Parent ? !0 : (h = (p = d == null ? void 0 : d._zod) == null ? void 0 : p.traits) == null ? void 0 : h.has(e);
    }
  }), Object.defineProperty(f, "name", { value: e }), f;
}
class Rt extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class hl extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
(na = globalThis).__zod_globalConfig ?? (na.__zod_globalConfig = {});
const tt = globalThis.__zod_globalConfig;
function lt(e) {
  return e && Object.assign(tt, e), tt;
}
function fd() {
  const e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, ki, 2)), e.message;
}
function dd(e) {
  this._zod.message = e;
}
const pd = {
  get: fd,
  set: dd,
  enumerable: !0,
  configurable: !0
}, Vr = { value: void 0, enumerable: !1 }, ia = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), hd = (e, t) => {
  e.name = "$ZodError", Vr.value = t, Object.defineProperty(e, "issues", Vr), Vr.value = void 0, Object.defineProperty(e, "message", pd);
  const n = Object.getPrototypeOf(e);
  ia.has(n) || (ia.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = () => this.message;
      return Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, "toString", { value: r, configurable: !0, writable: !0 });
    }
  }));
}, md = z("$ZodError", hd);
function gd(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
function yd(e, t = (n) => n.message) {
  const n = {}, r = [];
  for (const i of e.issues)
    i.path.length > 0 ? gd(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
  return { formErrors: r, fieldErrors: n };
}
function bd(e, t = (n) => n.message) {
  const n = { _errors: [] }, r = (i, o = []) => {
    for (const a of i.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((s) => r({ issues: s }, [...o, ...a.path]));
      else if (a.code === "invalid_key")
        r({ issues: a.issues }, [...o, ...a.path]);
      else if (a.code === "invalid_element")
        r({ issues: a.issues }, [...o, ...a.path]);
      else {
        const s = [...o, ...a.path];
        if (s.length === 0)
          n._errors.push(t(a));
        else {
          let u = n, c = 0;
          for (; c < s.length; ) {
            const l = s[c], f = c === s.length - 1;
            if (l === "_errors") {
              f && u._errors.push(t(a)), c++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(u, l) || Object.defineProperty(u, l, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const d = u[l];
            f && d._errors.push(t(a)), u = d, c++;
          }
        }
      }
  };
  return r(e), n;
}
function Er(e, t) {
  return { callee: (t == null ? void 0 : t.callee) ?? e, Err: t == null ? void 0 : t.Err };
}
const ro = (e) => {
  const t = (n, r, i, o) => {
    const a = i ? { ...i, async: !1 } : { async: !1 }, s = n._zod.run({ value: r, issues: [] }, a);
    if (s instanceof Promise)
      throw new Rt();
    if (s.issues.length) {
      const u = new ((o == null ? void 0 : o.Err) ?? e)(s.issues.map((c) => St(c, a, lt())));
      throw ll(u, (o == null ? void 0 : o.callee) ?? t), u;
    }
    return s.value;
  };
  return t;
}, io = (e) => {
  const t = async (n, r, i, o) => {
    const a = i ? { ...i, async: !0 } : { async: !0 };
    let s = n._zod.run({ value: r, issues: [] }, a);
    if (s instanceof Promise && (s = await s), s.issues.length) {
      const u = new ((o == null ? void 0 : o.Err) ?? e)(s.issues.map((c) => St(c, a, lt())));
      throw ll(u, (o == null ? void 0 : o.callee) ?? t), u;
    }
    return s.value;
  };
  return t;
}, oo = (e) => (t, n, r) => {
  const i = r ? { ...r, async: !1 } : { async: !1 }, o = t._zod.run({ value: n, issues: [] }, i);
  if (o instanceof Promise)
    throw new Rt();
  return o.issues.length ? ml(e, o.issues, i) : { success: !0, data: o.value };
};
function ml(e, t, n) {
  let r;
  return {
    success: !1,
    get error() {
      return r || (r = new e(t.map((i) => St(i, n, lt()))), t = void 0, n = void 0), r;
    },
    set error(i) {
      r = i, t = void 0, n = void 0;
    }
  };
}
const ao = (e) => async (t, n, r) => {
  const i = r ? { ...r, async: !0 } : { async: !0 };
  let o = t._zod.run({ value: n, issues: [] }, i);
  return o instanceof Promise && (o = await o), o.issues.length ? ml(e, o.issues, i) : { success: !0, data: o.value };
}, vd = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), kd = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), wd = (e, t, n) => {
  const r = e._zod.bag.validator;
  if (r !== void 0) {
    if (r(t) !== vd)
      return !0;
    if (r.definite === !0 && n === void 0)
      return !1;
  }
  return xd(e, t, n);
};
function xd(e, t, n) {
  const r = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, i = e._zod.bag.fallbackRun;
  let o;
  if (i ? (r[kd] = !0, o = i({ value: t, issues: [] }, r)) : o = e._zod.run({ value: t, issues: [] }, r), o instanceof Promise)
    throw new Rt();
  return o.issues.length === 0;
}
const _d = async (e, t, n) => {
  const r = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let i = e._zod.run({ value: t, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length === 0;
}, Sd = (e) => {
  const t = ro(e), n = (r, i, o, a) => {
    const s = o ? { ...o, direction: "backward" } : { direction: "backward" };
    return t(r, i, s, Er(n, a));
  };
  return n;
}, Id = (e) => {
  const t = ro(e), n = (r, i, o, a) => t(r, i, o, Er(n, a));
  return n;
}, Ed = (e) => {
  const t = io(e), n = async (r, i, o, a) => {
    const s = o ? { ...o, direction: "backward" } : { direction: "backward" };
    return await t(r, i, s, Er(n, a));
  };
  return n;
}, Cd = (e) => {
  const t = io(e), n = async (r, i, o, a) => await t(r, i, o, Er(n, a));
  return n;
}, Ad = (e) => (t, n, r) => {
  const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return oo(e)(t, n, i);
}, zd = (e) => (t, n, r) => oo(e)(t, n, r), Td = (e) => async (t, n, r) => {
  const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
  return ao(e)(t, n, i);
}, Od = (e) => async (t, n, r) => ao(e)(t, n, r), Pd = /^[cC][0-9a-z]{6,}$/, Md = /^[0-9a-z]+$/, Rd = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, $d = /^[0-9a-vA-V]{20}$/, Nd = /^[A-Za-z0-9]{27}$/, Dd = /^[a-zA-Z0-9_-]{21}$/;
function Ld(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
const Fd = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, jd = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, oa = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Zd = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Bd = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Ud() {
  return new RegExp(Bd, "u");
}
const Vd = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, qd = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Jd = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Wd = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Hd = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Kd = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, Yd = /^https?$/, Gd = /^\+[1-9]\d{6,14}$/, gl = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Xd(e) {
  return new RegExp(`^${e}$`);
}
const Qd = /* @__PURE__ */ Xd(gl);
function xi(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function ep(e) {
  return new RegExp(`^${xi(e)}$`);
}
function tp(e) {
  const t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${xi({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, r = e.local ? `${n}|${xi({ precision: e.precision })}` : n;
  return new RegExp(`^${gl}T(?:${r})$`);
}
const np = /^[\s\S]{0,}$/, rp = /^-?\d+$/, so = /^-?\d+(?:\.\d+)?$/, ip = /^(?:true|false)$/i, op = /^null$/i, ap = /^[^A-Z]*$/, sp = /^[^a-z]*$/, ze = /* @__PURE__ */ z("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), lo = (e) => {
  const t = e.value;
  return !Lf(t) && t.length !== void 0;
}, cr = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, yl = /* @__PURE__ */ z("$ZodCheckLessThan", (e, t) => {
  ze.init(e, t);
  const n = cr[typeof t.value];
  e._zod.check = (r) => {
    (t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
      origin: cr[typeof r.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: r.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), bl = /* @__PURE__ */ z("$ZodCheckGreaterThan", (e, t) => {
  ze.init(e, t);
  const n = cr[typeof t.value];
  e._zod.check = (r) => {
    (t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
      origin: cr[typeof r.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: r.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), lp = /* @__PURE__ */ z("$ZodCheckMultipleOf", (e, t) => {
  ze.init(e, t), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : Ff(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), up = /* @__PURE__ */ z("$ZodCheckNumberFormat", (e, t) => {
  var a;
  ze.init(e, t), t.format = t.format || "float64";
  const n = (a = t.format) == null ? void 0 : a.includes("int"), r = n ? "int" : "number", [i, o] = fl[t.format];
  e._zod.check = (s) => {
    const u = s.value;
    if (n) {
      if (!Number.isInteger(u)) {
        s.issues.push({
          expected: r,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? s.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: r,
          inclusive: !0,
          continue: !t.abort
        }) : s.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: r,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < i && s.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > o && s.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), cp = /* @__PURE__ */ z("$ZodCheckMaxLength", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length;
    if ((typeof i == "string" && o > t.maximum ? eo(i) : o) <= t.maximum)
      return;
    const s = to(i);
    r.issues.push({
      origin: s,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: i,
      inst: e,
      continue: !t.abort
    });
  };
}), fp = /* @__PURE__ */ z("$ZodCheckMinLength", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length;
    if ((typeof i == "string" && o >= t.minimum && o < t.minimum * 2 ? eo(i) : o) >= t.minimum)
      return;
    const s = to(i);
    r.issues.push({
      origin: s,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: i,
      inst: e,
      continue: !t.abort
    });
  };
}), dp = /* @__PURE__ */ z("$ZodCheckLengthEquals", (e, t) => {
  var n;
  ze.init(e, t), (n = e._zod.def).when ?? (n.when = lo), e._zod.check = (r) => {
    const i = r.value, o = i.length, a = typeof i == "string" && o >= t.length && o <= t.length * 2 ? eo(i) : o;
    if (a === t.length)
      return;
    const s = to(i), u = a > t.length;
    r.issues.push({
      origin: s,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Cr = /* @__PURE__ */ z("$ZodCheckStringFormat", (e, t) => {
  var n, r;
  ze.init(e, t), t.pattern ? (n = e._zod).check ?? (n.check = (i) => {
    t.pattern.lastIndex = 0, !t.pattern.test(i.value) && i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: i.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (r = e._zod).check ?? (r.check = () => {
  });
}), pp = /* @__PURE__ */ z("$ZodCheckRegex", (e, t) => {
  Cr.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), hp = /* @__PURE__ */ z("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = ap), Cr.init(e, t);
}), mp = /* @__PURE__ */ z("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = sp), Cr.init(e, t);
}), gp = /* @__PURE__ */ z("$ZodCheckIncludes", (e, t) => {
  ze.init(e, t);
  const n = en(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = r, e._zod.check = (i) => {
    i.value.includes(t.includes, t.position) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), yp = /* @__PURE__ */ z("$ZodCheckStartsWith", (e, t) => {
  ze.init(e, t);
  const n = new RegExp(`^${en(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.check = (r) => {
    r.value.startsWith(t.prefix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), bp = /* @__PURE__ */ z("$ZodCheckEndsWith", (e, t) => {
  ze.init(e, t);
  const n = new RegExp(`.*${en(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.check = (r) => {
    r.value.endsWith(t.suffix) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function aa(e, t, n) {
  e.issues.length && t.issues.push(...Mt(n, e.issues));
}
const vp = /* @__PURE__ */ z("$ZodCheckProperties", (e, t) => {
  ze.init(e, t), no(e, Symbol.iterator, function* () {
    yield e;
  });
  let n;
  e._zod.check = (r) => {
    if (r.value == null) {
      r.issues.push({ expected: "object", code: "invalid_type", input: r.value, inst: e });
      return;
    }
    n ?? (n = Reflect.ownKeys(t.shape).map((a) => [a, t.shape[a]]));
    const i = r.value;
    let o;
    for (const [a, s] of n) {
      const u = s._zod.run({ value: i[a], issues: [] }, {});
      u instanceof Promise ? (o ?? (o = []), o.push(u.then((c) => aa(c, r, a)))) : aa(u, r, a);
    }
    if (o)
      return Promise.all(o).then(() => {
      });
  };
}), kp = /* @__PURE__ */ z("$ZodCheckOverwrite", (e, t) => {
  ze.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});
class wp {
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(t) {
    this.indent += 1;
    try {
      t(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const r = t.split(`
`).filter((a) => a), i = Math.min(...r.map((a) => a.length - a.trimStart().length)), o = r.map((a) => a.slice(i)).map((a) => " ".repeat(this.indent * 2) + a);
    for (const a of o)
      this.content.push(a);
  }
  compile() {
    const t = Function, n = (this == null ? void 0 : this.content) ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const xp = {
  major: 4,
  minor: 6,
  patch: 7
}, de = /* @__PURE__ */ z("$ZodType", (e, t) => {
  var o;
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = xp;
  const r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r != null && r.length ? [...r] : [];
  for (const a of i)
    for (const s of a._zod.onattach)
      s(e);
  if (i.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), (o = e._zod.deferred) == null || o.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const a = (u, c, l) => {
      if (u.memo)
        return u;
      let f = dt(u), d;
      for (const p of c) {
        if (p._zod.def.when) {
          if (ed(u) || !p._zod.def.when(u))
            continue;
        } else if (f)
          continue;
        const h = u.issues.length, m = p._zod.check(u);
        if (m instanceof Promise && (l == null ? void 0 : l.async) === !1)
          throw new Rt();
        if (d || m instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await m, u.issues.length !== h && (wi(u.issues, h, e), f || (f = dt(u, h)));
          });
        else {
          if (u.issues.length === h)
            continue;
          wi(u.issues, h, e), f || (f = dt(u, h));
        }
      }
      return d ? d.then(() => u) : u;
    }, s = (u, c, l) => {
      if (dt(u))
        return u.aborted = !0, u;
      const f = a(c, i, l);
      if (f instanceof Promise) {
        if (l.async === !1)
          throw new Rt();
        return f.then((d) => e._zod.parse(d, l));
      }
      return e._zod.parse(f, l);
    };
    e._zod.run = (u, c) => {
      if (c.skipChecks)
        return e._zod.parse(u, c);
      if (c.direction === "backward") {
        const f = e._zod.parse({ value: u.value, issues: [] }, { ...c, skipChecks: !0 });
        return f instanceof Promise ? f.then((d) => s(d, u, c)) : s(f, u, c);
      }
      const l = e._zod.parse(u, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new Rt();
        return l.then((f) => a(f, i, c));
      }
      return a(l, i, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return no(this, "~standard", kl(this));
  },
  set "~standard"(e) {
    It(this, "~standard", e);
  }
}), vl = (e, t) => e.issues.length ? { issues: e.issues.map((n) => St(n, t, lt())) } : { value: e.value };
async function _p(e, t) {
  const n = { async: !0 };
  return vl(await e._zod.run({ value: t, issues: [] }, n), n);
}
function kl(e) {
  return {
    validate: (t) => {
      const n = { async: !1 };
      try {
        const r = e._zod.run({ value: t, issues: [] }, n);
        if (!(r instanceof Promise))
          return vl(r, n);
      } catch {
      }
      return _p(e, t);
    },
    vendor: "zod",
    version: 1
  };
}
const uo = /* @__PURE__ */ z("$ZodString", (e, t) => {
  de.init(e, t), e._zod.pattern = t.pattern ?? np, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), he = /* @__PURE__ */ z("$ZodStringFormat", (e, t) => {
  Cr.init(e, t), uo.init(e, t);
}), Sp = /* @__PURE__ */ z("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = jd), he.init(e, t);
}), Ip = /* @__PURE__ */ z("$ZodUUID", (e, t) => {
  if (t.version) {
    const r = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (r === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = oa(r));
  } else
    t.pattern ?? (t.pattern = oa());
  he.init(e, t);
}), Ep = /* @__PURE__ */ z("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Zd), he.init(e, t);
}), wl = 1, fr = 2;
function xl(e) {
  try {
    return typeof URL < "u" && typeof URL.canParse == "function" ? URL.canParse(e) : (new URL(e), !0);
  } catch {
    return !1;
  }
}
function Cp(e, t) {
  return !("normalize" in t) && !("hostname" in t) && !("protocol" in t) ? xl(e) || fr : Ap(e, t);
}
function Ap(e, t) {
  var n;
  if (!t.normalize && ((n = t.protocol) == null ? void 0 : n.source) === Yd.source && !/^https?:\/\//i.test(e))
    return wl;
  try {
    if (typeof URL < "u") {
      const r = URL;
      if (typeof r.parse == "function")
        return r.parse(e) ?? fr;
    }
    return new URL(e);
  } catch {
    return fr;
  }
}
const zp = /[\t\n\r]/g;
function sa(e) {
  return e.replace(zp, "");
}
function Tp(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
function Op(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
const Pp = /* @__PURE__ */ z("$ZodURL", (e, t) => {
  he.init(e, t), e._zod.check = (n) => {
    try {
      const r = n.value.trim(), i = Cp(r, t);
      if (i === wl) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (i === fr) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (i === !0) {
        n.value = sa(r);
        return;
      }
      t.hostname && !Tp(i, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !Op(i, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? i.href : sa(r);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Mp = /* @__PURE__ */ z("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Ud()), he.init(e, t);
}), Rp = /* @__PURE__ */ z("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? Dd : Ld(t.length)), he.init(e, t);
}), $p = /* @__PURE__ */ z("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Pd), he.init(e, t);
}), Np = /* @__PURE__ */ z("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Md), he.init(e, t);
}), Dp = /* @__PURE__ */ z("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Rd), he.init(e, t);
}), Lp = /* @__PURE__ */ z("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = $d), he.init(e, t);
}), Fp = /* @__PURE__ */ z("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Nd), he.init(e, t);
}), jp = /* @__PURE__ */ z("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = tp(t)), he.init(e, t);
}), Zp = /* @__PURE__ */ z("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Qd), he.init(e, t);
}), Bp = /* @__PURE__ */ z("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = ep(t)), he.init(e, t);
}), Up = /* @__PURE__ */ z("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Fd), he.init(e, t);
}), Vp = /* @__PURE__ */ z("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Vd), he.init(e, t);
}), qp = /^[0-9a-fA-F:.]+$/;
function _l(e) {
  return qp.test(e) ? xl(`http://[${e}]`) : !1;
}
const Jp = /* @__PURE__ */ z("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = qd), he.init(e, t), e._zod.check = (n) => {
    _l(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Wp = /* @__PURE__ */ z("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Jd), he.init(e, t);
});
function Hp(e) {
  const t = e.split("/");
  if (t.length !== 2)
    return !1;
  const [n, r] = t;
  if (!r)
    return !1;
  const i = Number(r);
  return `${i}` !== r || i < 0 || i > 128 ? !1 : _l(n);
}
const Kp = /* @__PURE__ */ z("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Wd), he.init(e, t), e._zod.check = (n) => {
    Hp(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Sl(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const Il = /^[0-9a-zA-Z+/]*={0,2}$/, Yp = /* @__PURE__ */ z("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Il), he.init(e, t), e._zod.check = (n) => {
    Sl(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), co = /^[A-Za-z0-9_-]*$/;
function Gp(e) {
  if (!co.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (r) => r === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Sl(n);
}
const Xp = /* @__PURE__ */ z("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = co), he.init(e, t), e._zod.check = (n) => {
    Gp(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Qp = /* @__PURE__ */ z("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Gd), he.init(e, t);
});
function eh(e, t = null) {
  try {
    const n = e.split(".");
    if (n.length !== 3)
      return !1;
    const [r] = n;
    if (!r)
      return !1;
    const i = JSON.parse(atob(r));
    return !("typ" in i && (i == null ? void 0 : i.typ) !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
  } catch {
    return !1;
  }
}
const th = /* @__PURE__ */ z("$ZodJWT", (e, t) => {
  he.init(e, t), e._zod.check = (n) => {
    eh(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), El = /* @__PURE__ */ z("$ZodNumber", (e, t) => {
  de.init(e, t), e._zod.pattern = so, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const i = n.value;
    if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i))
      return n;
    const o = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: i,
      inst: e,
      ...o ? { received: o } : {}
    }), n;
  };
}), nh = /* @__PURE__ */ z("$ZodNumberFormat", (e, t) => {
  up.init(e, t), El.init(e, t);
}), rh = /* @__PURE__ */ z("$ZodBoolean", (e, t) => {
  de.init(e, t), e._zod.pattern = ip, e._zod.parse = (n, r) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const i = n.value;
    return typeof i == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: i,
      inst: e
    }), n;
  };
}), ih = /* @__PURE__ */ z("$ZodNull", (e, t) => {
  de.init(e, t), e._zod.pattern = op, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, r) => {
    const i = n.value;
    return i === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: i,
      inst: e
    }), n;
  };
}), oh = /* @__PURE__ */ z("$ZodUnknown", (e, t) => {
  de.init(e, t), e._zod.parse = (n) => n;
}), ah = /* @__PURE__ */ z("$ZodNever", (e, t) => {
  de.init(e, t), e._zod.parse = (n, r) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
});
function sh(e, t) {
  const n = ta(e._zod.def.checks);
  if (!n.length)
    return;
  const r = Math.min(...n.map((o) => o[0])), i = e._zod.parse;
  e._zod.parse = (o, a) => {
    const s = t(o.value);
    if (s > r && !(a != null && a.skipChecks) && (a == null ? void 0 : a.direction) !== "backward") {
      for (const [u, c] of ta(e._zod.def.checks))
        if (s > u && c._zod.def.when(o)) {
          const l = o.issues.length;
          return c._zod.check(o), o.issues[l].continue = !1, wi(o.issues, l, e), o;
        }
    }
    return i(o, a);
  };
}
const lh = (e) => Array.isArray(e) ? e.length : -1;
function la(e, t, n) {
  e.issues.length && t.issues.push(...Mt(n, e.issues)), t.value[n] = e.value;
}
const uh = /* @__PURE__ */ z("$ZodArray", (e, t) => {
  de.init(e, t);
  const n = tt.memoizer;
  n == null || n.attach(e), e._zod.parse = (r, i) => {
    const o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    r.value = n ? n.alloc(e, r, Array(o.length), i) : Array(o.length);
    const a = [], s = i == null ? void 0 : i.abortEarly;
    for (let u = 0; u < o.length; u++) {
      const c = o[u], l = t.element._zod.run({
        value: c,
        issues: []
      }, i);
      if (l instanceof Promise)
        a.push(l.then((f) => la(f, r, u)));
      else if (la(l, r, u), s && l.issues.length !== 0 && dt(l))
        break;
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  }, sh(e, lh);
});
function dr(e, t, n, r, i, o) {
  const a = n in r, s = o === "optional";
  if (!(!a && s && i === "optional")) {
    if (e.issues.length) {
      if (i !== void 0 && s && !a)
        return;
      t.issues.push(...Mt(n, e.issues));
    }
    if (!a && i === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? (a || i === "defaulted" && !s) && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
const ch = [];
function Cl(e) {
  var a, s, u, c;
  const t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : ch, i = r.length ? [...t, ...r] : t;
  for (const l of i)
    if (!((c = (u = (s = (a = e.shape) == null ? void 0 : a[l]) == null ? void 0 : s._zod) == null ? void 0 : u.traits) != null && c.has("$ZodType")))
      throw new Error(`Invalid element at key "${String(l)}": expected a Zod schema`);
  const o = Jf(e.shape);
  return {
    ...e,
    allKeys: i,
    symbolKeys: r,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(o)
  };
}
function Al(e, t, n, r, i, o, a) {
  const s = [], u = i.keySet, c = i.catchall._zod, l = c.def.type, f = c.optin, d = c.optout;
  let p = 0;
  for (const h in t) {
    if (a && n.issues.length !== p) {
      if (dt(n, p))
        break;
      p = n.issues.length;
    }
    if (u.has(h))
      continue;
    if (h === "__proto__") {
      l === "never" && s.push(h);
      continue;
    }
    if (l === "never") {
      s.push(h);
      continue;
    }
    const m = c.run({ value: t[h], issues: [] }, r);
    m instanceof Promise ? e.push(m.then((k) => dr(k, n, h, t, f, d))) : dr(m, n, h, t, f, d);
  }
  return s.length && n.issues.push({
    code: "unrecognized_keys",
    keys: s,
    input: t,
    inst: o,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
const fh = /* @__PURE__ */ z("$ZodObject", (e, t) => {
  de.init(e, t);
  const n = Object.getOwnPropertyDescriptor(t, "shape"), r = n != null && n.get ? n.get.raw : t.shape ?? {};
  if (r) {
    const c = () => {
      const l = { ...r };
      return Object.defineProperty(t, "shape", { value: l }), c.raw = l, l;
    };
    c.raw = r, Object.defineProperty(t, "shape", { get: c });
  }
  const i = Sr(() => Cl(t));
  te(e, "propValues", (c) => {
    const l = c.def.shape, f = {};
    for (const d in l) {
      const p = l[d]._zod;
      if (p.values) {
        Object.prototype.hasOwnProperty.call(f, d) || ut(f, d, /* @__PURE__ */ new Set());
        for (const h of p.values)
          f[d].add(h);
        p.optin !== void 0 && f[d].add(void 0);
      }
    }
    return f;
  });
  const o = Pn, a = t.catchall;
  let s;
  const u = tt.memoizer;
  u == null || u.attach(e), e._zod.parse = (c, l) => {
    s ?? (s = i.value);
    const f = c.value;
    if (!o(f))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: f,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, l) : {};
    const d = [], p = s.shape, h = l == null ? void 0 : l.abortEarly;
    let m = c.issues.length;
    for (const k of s.allKeys) {
      if (h && c.issues.length !== m) {
        if (dt(c, m))
          break;
        m = c.issues.length;
      }
      if (k === "__proto__")
        continue;
      const g = p[k], _ = g._zod.optin, w = g._zod.optout, C = g._zod.run({ value: f[k], issues: [] }, l);
      C instanceof Promise ? d.push(C.then((I) => dr(I, c, k, f, _, w))) : dr(C, c, k, f, _, w);
    }
    return a ? Al(d, f, c, l, i.value, e, h === !0) : d.length ? Promise.all(d).then(() => c) : c;
  };
}), dh = /* @__PURE__ */ z("$ZodObjectJIT", (e, t) => {
  fh.init(e, t);
  const n = e._zod.parse, r = Sr(() => Cl(t)), i = tt.memoizer, o = (p) => {
    var I, y;
    const h = r.value, m = h.symbolKeys, k = new wp(["payload", "ctx"], { shape: p, inst: e, memo: i, syms: m }), g = (E) => `shape[${E}]._zod.run({ value: input[${E}], issues: [] }, ctx)`, _ = (E, R) => `
          let ${E}_ab = false;
          for (let i = 0; i < ${E}.issues.length; i++) {
            const iss = ${E}.issues[i];
            iss.path = iss.path ? [${R}, ...iss.path] : [${R}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${E}_ab = true;
          }
          if (${E}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    k.write("const input = payload.value;");
    const w = /* @__PURE__ */ Object.create(null);
    let C = 0;
    for (const E of h.allKeys)
      w[E] = `key_${C++}`;
    k.write(i ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const E of h.allKeys) {
      if (E === "__proto__")
        continue;
      const R = w[E], F = typeof E == "symbol" ? `syms[${m.indexOf(E)}]` : Bf(E), S = `${F} in input`, M = p[E], L = (I = M == null ? void 0 : M._zod) == null ? void 0 : I.optin, x = L !== void 0, Z = ((y = M == null ? void 0 : M._zod) == null ? void 0 : y.optout) === "optional";
      if (k.write(`const ${R} = ${g(F)};`), x && Z) {
        const B = L === "optional" ? `${R}_present` : `${R}.value !== undefined || ${R}_present`;
        k.write(`
        const ${R}_present = ${S};
        if (!${R}.issues.length || ${R}_present) {
          if (${R}.issues.length) {${_(R, F)}
          }

          if (${B}) {
            newResult[${F}] = ${R}.value;
          }
        }

      `);
      } else x ? (k.write(`
        if (${R}.issues.length) {${_(R, F)}
        }
      `), L === "defaulted" ? k.write(`newResult[${F}] = ${R}.value;`) : k.write(`
        if (${R}.value !== undefined || ${S}) {
          newResult[${F}] = ${R}.value;
        }
      `)) : k.write(`
        const ${R}_present = ${S};
        if (${R}.issues.length) {${_(R, F)}
        }
        if (!${R}_present && !${R}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${F}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${R}_present) {
          newResult[${F}] = ${R}.value;
        }

      `);
    }
    return k.write("payload.value = newResult;"), k.write("return payload;"), k.compile();
  };
  let a;
  const s = Pn, u = !tt.jitless, l = u && Vf.value, f = t.catchall;
  let d;
  e._zod.parse = (p, h) => {
    d ?? (d = r.value);
    const m = p.value;
    return s(m) ? u && l && (h == null ? void 0 : h.async) === !1 && h.jitless !== !0 ? (a || (a = o(t.shape)), p = a(p, h), f ? Al([], m, p, h, d, e, (h == null ? void 0 : h.abortEarly) === !0) : p) : n(p, h) : (p.issues.push({
      expected: "object",
      code: "invalid_type",
      input: m,
      inst: e
    }), p);
  };
});
function ua(e, t, n, r) {
  for (const o of e)
    if (o.issues.length === 0)
      return t.value = o.value, t;
  const i = e.filter((o) => !dt(o));
  return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((o) => o.issues.map((a) => St(a, r, lt())))
  }), t);
}
const zl = /* @__PURE__ */ z("$ZodUnion", (e, t) => {
  de.init(e, t), te(e, "optin", (r) => r.def.options.some((i) => i._zod.optin === "defaulted") ? "defaulted" : r.def.options.some((i) => i._zod.optin !== void 0) ? "optional" : void 0), te(e, "optout", (r) => r.def.options.some((i) => i._zod.optout === "optional") ? "optional" : void 0), te(e, "values", (r) => {
    if (r.def.options.every((i) => i._zod.values))
      return new Set(r.def.options.flatMap((i) => Array.from(i._zod.values)));
  }), te(e, "pattern", (r) => {
    if (r.def.options.every((i) => i._zod.pattern)) {
      const i = r.def.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${i.map((o) => Xi(o.source)).join("|")})$`);
    }
  });
  const n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (r, i) => {
    if (n)
      return n(r, i);
    let o = !1;
    const a = [];
    for (const s of t.options) {
      const u = s._zod.run({
        value: r.value,
        issues: []
      }, i);
      if (u instanceof Promise)
        a.push(u), o = !0;
      else {
        if (u.issues.length === 0)
          return u;
        a.push(u);
      }
    }
    return o ? Promise.all(a).then((s) => ua(s, r, e, i)) : ua(a, r, e, i);
  };
});
function ph(e) {
  var n;
  const t = /* @__PURE__ */ new Map();
  for (const r of e.options) {
    const i = (n = r._zod.propValues) == null ? void 0 : n[e.discriminator];
    if (!i || i.size === 0)
      throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(r)}"`);
    for (const o of i)
      if (t.has(o)) {
        if (o !== void 0)
          throw new Error(`Duplicate discriminator value "${String(o)}"`);
        t.set(o, null);
      } else
        t.set(o, r);
  }
  return t;
}
const hh = /* @__PURE__ */ z("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, zl.init(e, t);
  const n = e._zod.parse;
  te(e, "propValues", (i) => {
    var s, u;
    const o = {};
    let a = 0;
    for (const c of i.def.options) {
      const l = c._zod.propValues;
      if (!l || Object.keys(l).length === 0)
        throw new Error(`Invalid discriminated union option at index "${i.def.options.indexOf(c)}"`);
      (s = l[i.def.discriminator]) != null && s.has(void 0) && a++;
      for (const [f, d] of Object.entries(l)) {
        Object.prototype.hasOwnProperty.call(o, f) || ut(o, f, /* @__PURE__ */ new Set());
        for (const p of d)
          o[f].add(p);
      }
    }
    return !i.def.unionFallback && a > 1 && ((u = o[i.def.discriminator]) == null || u.delete(void 0)), o;
  }), t.options.forEach((i, o) => {
    const a = Qi(i._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${o}"`);
  });
  const r = Sr(() => ph(t));
  e._zod.parse = (i, o) => {
    const a = i.value;
    if (!Pn(a))
      return i.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), i;
    const s = a == null ? void 0 : a[t.discriminator], u = r.value.get(s);
    return u && (s !== void 0 || o.direction !== "backward") ? u._zod.run(i, o) : t.unionFallback || o.direction === "backward" ? n(i, o) : (i.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(r.value.keys()).filter((c) => r.value.get(c) !== null),
      input: a,
      path: [t.discriminator],
      inst: e
    }), i);
  };
}), mh = /* @__PURE__ */ z("$ZodIntersection", (e, t) => {
  de.init(e, t), e._zod.parse = (n, r) => {
    const i = n.value, o = t.left._zod.run({ value: i, issues: [] }, r), a = t.right._zod.run({ value: i, issues: [] }, r);
    return o instanceof Promise || a instanceof Promise ? Promise.all([o, a]).then(([u, c]) => ca(n, u, c)) : ca(n, o, a);
  };
});
function _i(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Qt(e) && Qt(t)) {
    const n = Object.keys(t), r = Object.keys(e).filter((o) => n.indexOf(o) !== -1), i = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
    for (const o of r) {
      if (o === "__proto__")
        continue;
      const a = _i(e[o], t[o]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      i[o] = a.data;
    }
    return { valid: !0, data: i };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let r = 0; r < e.length; r++) {
      const i = e[r], o = t[r], a = _i(i, o);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function ca(e, t, n) {
  const r = /* @__PURE__ */ new Map();
  let i;
  const o = /* @__PURE__ */ new Map(), a = (c, l) => {
    var d, p;
    let f;
    if (c.code === "unrecognized_keys" && !((d = c.path) != null && d.length))
      i ?? (i = c), f = c.keys;
    else if (c.code === "invalid_key" && c.origin === "record" && ((p = c.path) == null ? void 0 : p.length) === 1) {
      const h = String(c.path[0]);
      o.has(h) || o.set(h, c), f = [h];
    } else
      return !1;
    for (const h of f)
      r.has(h) || r.set(h, {}), r.get(h)[l] = !0;
    return !0;
  };
  for (const c of t.issues)
    a(c, "l") || e.issues.push(c);
  for (const c of n.issues)
    a(c, "r") || e.issues.push(c);
  const s = [...r].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (s.length) {
    const c = i ? s.filter((l) => i.keys.includes(l)) : [];
    c.length && e.issues.push({ ...i, keys: c });
    for (const l of s)
      !c.includes(l) && o.has(l) && e.issues.push(o.get(l));
  }
  const u = _i(t.value, n.value);
  if (!u.valid) {
    if (dt(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
  }
  return e.value = u.data, e;
}
const gh = /* @__PURE__ */ z("$ZodRecord", (e, t) => {
  de.init(e, t);
  const n = tt.memoizer;
  n == null || n.attach(e), e._zod.parse = (r, i) => {
    const o = r.value;
    if (!Qt(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    const a = [], s = t.keyType._zod.values;
    if (s && !t.partial) {
      r.value = n ? n.alloc(e, r, {}, i) : {};
      const u = /* @__PURE__ */ new Set();
      for (const l of s)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          if (u.add(typeof l == "number" ? l.toString() : l), l === "__proto__")
            continue;
          const f = t.keyType._zod.run({ value: l, issues: [] }, i);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            r.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((h) => St(h, i, lt())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          const d = f.value;
          if (d === "__proto__")
            continue;
          const p = t.valueType._zod.run({ value: o[l], issues: [] }, i);
          p instanceof Promise ? a.push(p.then((h) => {
            h.issues.length && r.issues.push(...Mt(l, h.issues)), r.value[d] = h.value;
          })) : (p.issues.length && r.issues.push(...Mt(l, p.issues)), r.value[d] = p.value);
        }
      let c;
      for (const l in o)
        if (!u.has(l))
          if (t.mode === "loose") {
            if (l === "__proto__")
              continue;
            r.value[l] = o[l];
          } else
            c = c ?? [], c.push(l);
      c && c.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: c,
        continue: !0
      });
    } else {
      r.value = n ? n.alloc(e, r, {}, i) : {};
      let u;
      for (const c of Reflect.ownKeys(o)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(o, c))
          continue;
        let l = t.keyType._zod.run({ value: c, issues: [] }, i);
        if (l instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && so.test(c) && l.issues.length) {
          const h = t.keyType._zod.run({ value: Number(c), issues: [] }, i);
          if (h instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          h.issues.length === 0 && (l = h);
        }
        if (l.issues.length) {
          t.mode === "loose" ? r.value[c] = o[c] : s ? (u = u ?? [], u.push(c)) : r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: l.issues.map((h) => St(h, i, lt())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        const d = l.value;
        if (d === "__proto__")
          continue;
        const p = t.valueType._zod.run({ value: o[c], issues: [] }, i);
        p instanceof Promise ? a.push(p.then((h) => {
          h.issues.length && r.issues.push(...Mt(c, h.issues)), r.value[d] = h.value;
        })) : (p.issues.length && r.issues.push(...Mt(c, p.issues)), r.value[d] = p.value);
      }
      u && u.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: u,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
}), yh = /* @__PURE__ */ z("$ZodEnum", (e, t) => {
  de.init(e, t);
  const n = vi(t.entries), r = new Set(n);
  e._zod.values = r, te(e, "pattern", (i) => {
    const o = vi(i.def.entries).filter((a) => qf.has(typeof a));
    return new RegExp(o.length ? `^(${o.map((a) => en(a.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (i, o) => {
    const a = i.value;
    return r.has(a) || i.issues.push({
      code: "invalid_value",
      values: n,
      input: a,
      inst: e
    }), i;
  };
}), bh = /* @__PURE__ */ z("$ZodLiteral", (e, t) => {
  de.init(e, t);
  const n = new Set(t.values);
  e._zod.values = n, te(e, "pattern", (r) => {
    const i = r.def.values;
    return new RegExp(i.length ? `^(${i.map((o) => typeof o == "string" ? en(o) : o ? en(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (r, i) => {
    const o = r.value;
    return n.has(o) || r.issues.push({
      code: "invalid_value",
      values: t.values,
      input: o,
      inst: e
    }), r;
  };
}), vh = /* @__PURE__ */ z("$ZodTransform", (e, t) => {
  var n;
  de.init(e, t), e._zod.optin = "optional", (n = tt.memoizer) == null || n.guard(e), e._zod.parse = (r, i) => {
    if (i.direction === "backward")
      throw new hl(e.constructor.name);
    const o = t.transform(r.value, r);
    if (i.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((s) => (r.value = s, r));
    if (o instanceof Promise)
      throw new Rt();
    return r.value = o, r;
  };
});
function fa(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
const Tl = /* @__PURE__ */ z("$ZodOptional", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", te(e, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? /* @__PURE__ */ new Set([...r, void 0]) : void 0;
  }), te(e, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Xi(r.source)})?$`) : void 0;
  }), e._zod.parse = (n, r) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      const i = t.innerType._zod.run({ value: n.value, issues: [] }, r);
      return i instanceof Promise ? i.then((o) => fa(n, o)) : fa(n, i);
    }
    return t.innerType._zod.run(n, r);
  };
}), kh = /* @__PURE__ */ z("$ZodExactOptional", (e, t) => {
  Tl.init(e, t), te(e, "values", (n) => n.def.innerType._zod.values), te(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, r) => t.innerType._zod.run(n, r);
}), wh = /* @__PURE__ */ z("$ZodNullable", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin), te(e, "optout", (n) => n.def.innerType._zod.optout), te(e, "pattern", (n) => {
    const r = n.def.innerType._zod.pattern;
    return r ? new RegExp(`^(${Xi(r.source)}|null)$`) : void 0;
  }), te(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, r) => n.value === null ? n : t.innerType._zod.run(n, r);
}), xh = /* @__PURE__ */ z("$ZodDefault", (e, t) => {
  de.init(e, t), e._zod.optin = "defaulted", te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => da(o, t)) : da(i, t);
  };
});
function da(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const _h = /* @__PURE__ */ z("$ZodPrefault", (e, t) => {
  de.init(e, t), e._zod.optin = "defaulted", te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => (r.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, r));
}), Sh = /* @__PURE__ */ z("$ZodNonOptional", (e, t) => {
  de.init(e, t), te(e, "values", (n) => {
    const r = n.def.innerType._zod.values;
    return r ? new Set([...r].filter((i) => i !== void 0)) : void 0;
  }), e._zod.parse = (n, r) => {
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => pa(o, e)) : pa(i, e);
  };
});
function pa(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
function ha(e, t, n, r) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((i) => St(i, r, lt()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
const Ih = /* @__PURE__ */ z("$ZodCatch", (e, t) => {
  de.init(e, t), te(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), te(e, "optout", (n) => n.def.innerType._zod.optout), te(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    const i = t.innerType._zod.run({ value: n.value, issues: [] }, r);
    return i instanceof Promise ? i.then((o) => ha(n, o, t, r)) : ha(n, i, t, r);
  };
}), Eh = /* @__PURE__ */ z("$ZodPipe", (e, t) => {
  de.init(e, t), te(e, "values", (n) => n.def.in._zod.values), te(e, "optin", (n) => n.def.in._zod.optin), te(e, "optout", (n) => n.def.out._zod.optout), te(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, r) => {
    if (r.direction === "backward") {
      const o = t.out._zod.run(n, r);
      return o instanceof Promise ? o.then((a) => qn(a, t.in, r)) : qn(o, t.in, r);
    }
    const i = t.in._zod.run(n, r);
    return i instanceof Promise ? i.then((o) => qn(o, t.out, r)) : qn(i, t.out, r);
  };
});
function qn(e, t, n) {
  return e.issues.some((r) => r.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
const Ch = /* @__PURE__ */ z("$ZodReadonly", (e, t) => {
  de.init(e, t), te(e, "propValues", (n) => n.def.innerType._zod.propValues), te(e, "values", (n) => n.def.innerType._zod.values), te(e, "optin", (n) => {
    var r, i;
    return (i = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optin;
  }), te(e, "optout", (n) => {
    var r, i;
    return (i = (r = n.def.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optout;
  }), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      return t.innerType._zod.run(n, r);
    const i = t.innerType._zod.run(n, r);
    return i instanceof Promise ? i.then(ma) : ma(i);
  };
});
function ma(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
const Ah = /* @__PURE__ */ z("$ZodLazy", (e, t) => {
  de.init(e, t), jf(e._zod, "innerType", () => {
    const n = t;
    return n._cachedInner || (n._cachedInner = t.getter()), n._cachedInner;
  }), te(e, "pattern", (n) => {
    var r, i;
    return (i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.pattern;
  }), te(e, "propValues", (n) => {
    var r, i;
    return (i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.propValues;
  }), te(e, "optin", (n) => {
    var r, i;
    return ((i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optin) ?? void 0;
  }), te(e, "optout", (n) => {
    var r, i;
    return ((i = (r = n.innerType) == null ? void 0 : r._zod) == null ? void 0 : i.optout) ?? void 0;
  }), e._zod.parse = (n, r) => e._zod.innerType._zod.run(n, r);
}), zh = /* @__PURE__ */ z("$ZodCustom", (e, t) => {
  ze.init(e, t), de.init(e, t), e._zod.parse = (n, r) => n, e._zod.check = (n) => {
    const r = n.value, i = t.fn(r);
    if (i instanceof Promise)
      return i.then((o) => ga(o, n, r, e));
    ga(i, n, r, e);
  };
});
function ga(e, t, n, r) {
  if (!e) {
    const i = {
      code: "custom",
      input: n,
      inst: r,
      // incorporates params.error into issue reporting
      path: [...r._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !r._zod.def.abort
      // params: inst._zod.def.params,
    };
    r._zod.def.params && (i.params = r._zod.def.params), t.issues.push(Mn(i));
  }
}
class Th extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const Si = "~memo", ya = [];
function Ol(e) {
  return e !== null && typeof e == "object";
}
function qr(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
const Pl = /* @__PURE__ */ new WeakMap(), kn = 0, nr = 1, In = 2;
function rr(e, t, n) {
  const r = Pl.get(e);
  if (r !== void 0)
    return r ? In : kn;
  if (t.has(e))
    return In;
  t.add(e);
  let i = kn;
  const o = (l) => {
    if (i !== In && (l != null && l._zod)) {
      const f = rr(l, t);
      f > i && (i = f);
    }
  }, a = (l, f) => {
    var p;
    let d = kn;
    for (const h of Reflect.ownKeys(l)) {
      const m = Object.getOwnPropertyDescriptor(l, h);
      if (!m.enumerable)
        continue;
      const k = m.get ? nr : (p = m.value) != null && p._zod ? rr(m.value, t) : kn;
      k > d && (d = k);
    }
    return d;
  }, s = (l) => {
    l > i && (i = l);
  }, u = e._zod.def;
  switch (u.type) {
    case "object": {
      const l = Qi(u);
      s(l ? a(l) : nr), o(u.catchall);
      break;
    }
    case "array":
      o(u.element);
      break;
    case "tuple":
      for (const l of u.items)
        o(l);
      o(u.rest);
      break;
    case "record":
    case "map":
      o(u.keyType), o(u.valueType);
      break;
    case "set":
      o(u.valueType);
      break;
    case "union":
      for (const l of u.options)
        o(l);
      break;
    case "intersection":
      o(u.left), o(u.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      o(u.innerType);
      break;
    case "pipe":
      o(u.in), o(u.out);
      break;
    case "function":
      o(u.input), o(u.output);
      break;
    case "lazy": {
      const l = u._cachedInner ?? void 0;
      s(l ? rr(l, t) : nr);
      break;
    }
    case "template_literal":
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const l in u) {
        const f = Object.getOwnPropertyDescriptor(u, l);
        if (!f || f.get)
          continue;
        const d = f.value;
        if (!(!d || typeof d != "object")) {
          if (d._zod)
            o(d);
          else if (Array.isArray(d))
            for (const p of d)
              o(p);
        }
      }
  }
  return t.delete(e), Oh(e, i);
}
function Oh(e, t) {
  return t !== nr && Pl.set(e, t === In), t;
}
function Ph(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new WeakMap(), e.buckets.set(t, n)), n;
}
let Jn;
const Wn = [], Mh = {
  alloc(e, t, n) {
    const r = Jn;
    if (!r)
      return n;
    Jn = void 0;
    const i = { value: n, issues: null };
    return r.set(t.value, i), Wn.push(i), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const n = e._zod.parse, r = (i, o) => {
        if (o.direction !== "backward" && $h(o, i.value))
          throw new Th();
        return n(i, o);
      };
      e._zod.parse = r, e._zod.run === n && (e._zod.run = r);
    });
  },
  attach(e) {
    var t;
    let n, r = !1, i, o;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const a = e._zod.parse, s = (u, c) => {
        if (n === void 0) {
          const g = rr(e, /* @__PURE__ */ new Set());
          if (g === kn)
            return e._zod.parse = a, e._zod.run === s && (e._zod.run = a), a(u, c);
          g === In || r ? n = !0 : r = !0;
        }
        const l = u.value;
        if (!Ol(l))
          return a(u, c);
        let f = c[Si];
        f || (f = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, c[Si] = f);
        let d;
        i === c ? d = o : (d = Ph(f, e), i = c, o = d);
        const p = d.get(l);
        if (p)
          return u.value = p.value, p.issues ? p.issues.length && u.issues.push(...qr(p.issues)) : (u.memo = !0, f.backEdges ?? (f.backEdges = /* @__PURE__ */ new WeakSet()), f.backEdges.add(p.value)), u;
        Jn = d;
        const h = Wn.length, m = a(u, c);
        Jn = void 0;
        const k = Wn.length > h ? Wn.pop() : void 0;
        return m instanceof Promise ? m.then((g) => (k && (k.issues = g.issues.length ? qr(g.issues) : ya), g)) : (k && (k.issues = m.issues.length ? qr(m.issues) : ya), m);
      };
      e._zod.parse = s, e._zod.run === a && (e._zod.run = s);
    });
  }
};
function Rh() {
  return Mh;
}
function $h(e, t) {
  var r;
  const n = (r = e[Si]) == null ? void 0 : r.backEdges;
  return n !== void 0 && Ol(t) && n.has(t);
}
const Nh = () => {
  const e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(o) {
    return e[o] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, r = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function i(o, a) {
    return o === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : r[o] ?? o;
  }
  return (o) => {
    switch (o.code) {
      case "invalid_type": {
        const a = i(o.expected), s = nd(o.input), u = i(s, o.input);
        return `Invalid input: expected ${a}, received ${u}`;
      }
      case "invalid_value":
        return o.values.length === 1 ? `Invalid input: expected ${cl(o.values[0])}` : `Invalid option: expected one of ${Xo(o.values, "|")}`;
      case "too_big": {
        const a = o.exact ? "exactly " : o.inclusive ? "<=" : "<", s = t(o.origin);
        return s ? `Too big: expected ${o.origin ?? "value"} to have ${a}${o.maximum.toString()} ${s.unit ?? "elements"}` : `Too big: expected ${o.origin ?? "value"} to be ${a}${o.maximum.toString()}`;
      }
      case "too_small": {
        const a = o.exact ? "exactly " : o.inclusive ? ">=" : ">", s = t(o.origin);
        return s ? `Too small: expected ${o.origin} to have ${a}${o.minimum.toString()} ${s.unit}` : `Too small: expected ${o.origin} to be ${a}${o.minimum.toString()}`;
      }
      case "invalid_format": {
        const a = o;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${n[a.format] ?? o.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${o.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${o.keys.length > 1 ? "s" : ""}: ${Xo(o.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${o.origin}`;
      case "invalid_union":
        return o.options && Array.isArray(o.options) && o.options.length > 0 ? `Invalid discriminator value. Expected ${o.options.map((s) => `'${s}'`).join(" | ")}` : o.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${o.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function Dh() {
  return {
    localeError: Nh()
  };
}
var ba;
class Lh {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    const r = n[0];
    return this._map.set(t, r), r && typeof r == "object" && "id" in r && this._idmap.set(r.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    const n = t._zod.parent;
    if (n) {
      const r = { ...this.get(n) ?? {} };
      delete r.id;
      const i = { ...r, ...this._map.get(t) };
      return Object.keys(i).length ? i : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function Fh() {
  return new Lh();
}
(ba = globalThis).__zod_globalRegistry ?? (ba.__zod_globalRegistry = Fh());
const wn = globalThis.__zod_globalRegistry;
function Ml(e) {
  return e.checks && (e.checks = [...e.checks]), e;
}
// @__NO_SIDE_EFFECTS__
function jh(e, t) {
  return new e(Ml({ type: "string", ...j(t) }));
}
// @__NO_SIDE_EFFECTS__
function Zh(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Bh(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Uh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Vh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function qh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Jh(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Wh(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Hh(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Kh(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Yh(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Gh(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Xh(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Qh(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function em(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function tm(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function nm(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function rm(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function im(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function om(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function am(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function sm(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function lm(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function um(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function cm(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function fm(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function dm(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function pm(e, t) {
  return new e(Ml({ type: "number", checks: [], ...j(t) }));
}
// @__NO_SIDE_EFFECTS__
function hm(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function mm(e, t) {
  return new e({
    type: "boolean",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function gm(e, t) {
  return new e({
    type: "null",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function ym(e) {
  return new e({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function bm(e, t) {
  return new e({
    type: "never",
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function va(e, t) {
  return new yl({
    check: "less_than",
    ...j(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Jr(e, t) {
  return new yl({
    check: "less_than",
    ...j(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function ka(e, t) {
  return new bl({
    check: "greater_than",
    ...j(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Wr(e, t) {
  return new bl({
    check: "greater_than",
    ...j(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function wa(e, t) {
  return new lp({
    check: "multiple_of",
    ...j(t),
    value: e
  });
}
// @__NO_SIDE_EFFECTS__
function Rl(e, t) {
  return new cp({
    check: "max_length",
    ...j(t),
    maximum: e
  });
}
// @__NO_SIDE_EFFECTS__
function pr(e, t) {
  return new fp({
    check: "min_length",
    ...j(t),
    minimum: e
  });
}
// @__NO_SIDE_EFFECTS__
function $l(e, t) {
  return new dp({
    check: "length_equals",
    ...j(t),
    length: e
  });
}
// @__NO_SIDE_EFFECTS__
function vm(e, t) {
  return new pp({
    check: "string_format",
    format: "regex",
    ...j(t),
    pattern: e
  });
}
// @__NO_SIDE_EFFECTS__
function km(e) {
  return new hp({
    check: "string_format",
    format: "lowercase",
    ...j(e)
  });
}
// @__NO_SIDE_EFFECTS__
function wm(e) {
  return new mp({
    check: "string_format",
    format: "uppercase",
    ...j(e)
  });
}
// @__NO_SIDE_EFFECTS__
function xm(e, t) {
  return new gp({
    check: "string_format",
    format: "includes",
    ...j(t),
    includes: e
  });
}
// @__NO_SIDE_EFFECTS__
function _m(e, t) {
  return new yp({
    check: "string_format",
    format: "starts_with",
    ...j(t),
    prefix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Sm(e, t) {
  return new bp({
    check: "string_format",
    format: "ends_with",
    ...j(t),
    suffix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Im(e, t) {
  return new vp({
    check: "properties",
    shape: e,
    ...j(t)
  });
}
// @__NO_SIDE_EFFECTS__
function rn(e) {
  return new kp({
    check: "overwrite",
    tx: e
  });
}
// @__NO_SIDE_EFFECTS__
function Em(e) {
  return /* @__PURE__ */ rn((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Cm() {
  return /* @__PURE__ */ rn((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function Am() {
  return /* @__PURE__ */ rn((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function zm() {
  return /* @__PURE__ */ rn((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Tm() {
  return /* @__PURE__ */ rn((e) => Uf(e));
}
// @__NO_SIDE_EFFECTS__
function Om(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...j(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Pm(e, t, n) {
  const r = j(n);
  return r.abort ?? (r.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...r
  });
}
// @__NO_SIDE_EFFECTS__
function Mm(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...j(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Rm(e, t) {
  const n = /* @__PURE__ */ $m((r) => (r.addIssue = (i) => {
    if (typeof i == "string")
      r.issues.push(Mn(i, r.value, n._zod.def));
    else {
      const o = i;
      o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), "input" in o || (o.input = r.value), o.inst ?? (o.inst = n), o.continue ?? (o.continue = !n._zod.def.abort), r.issues.push(Mn(o));
    }
  }, e(r.value, r)), t);
  return n;
}
// @__NO_SIDE_EFFECTS__
function $m(e, t) {
  const n = new ze({
    check: "custom",
    ...j(t)
  });
  return n._zod.check = e, n;
}
function En(e, ...t) {
  for (const n of t)
    for (const r of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, r) && ut(e, r, n[r]);
  return e;
}
function hr(e) {
  let t = (e == null ? void 0 : e.target) ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: (e == null ? void 0 : e.metadata) ?? wn,
    target: t,
    unrepresentable: (e == null ? void 0 : e.unrepresentable) ?? "throw",
    override: (e == null ? void 0 : e.override) ?? (() => {
    }),
    io: (e == null ? void 0 : e.io) ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: (e == null ? void 0 : e.cycles) ?? "ref",
    reused: (e == null ? void 0 : e.reused) ?? "inline",
    intersections: [],
    deferred: [],
    external: (e == null ? void 0 : e.external) ?? void 0
  };
}
function _e(e, t, n, r, i) {
  const o = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: r.path, message: i }) : t.unrepresentable;
  if (o === "any")
    return !1;
  if (o === void 0 || o === "throw")
    throw new Error(i);
  return Object.assign(n, o), !0;
}
function se(e, t, n = { path: [], schemaPath: [] }) {
  var l, f;
  var r;
  const i = e._zod.def, o = t.seen.get(e);
  if (o)
    return o.count++, n.schemaPath.includes(e) && (o.cycle = n.path), o.schema;
  const a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, a), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  const s = (f = (l = e._zod).toJSONSchema) == null ? void 0 : f.call(l);
  if (s)
    a.schema = s;
  else {
    const d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, d);
    else {
      const h = a.schema, m = t.processors[i.type];
      if (!m)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
      m(e, t, h, d);
    }
    const p = e._zod.parent;
    p && (a.ref || (a.ref = p), se(p, t, d), t.seen.get(p).isParent = !0);
  }
  const u = t.metadataRegistry.get(e);
  return u && En(a.schema, u), t.io === "input" && Ee(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && "_prefault" in a.schema && ((r = a.schema).default ?? (r.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
function xa(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function mr(e, t) {
  var a, s, u, c;
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  const r = /* @__PURE__ */ new Map();
  for (const l of e.seen.entries()) {
    const f = (a = e.metadataRegistry.get(l[0])) == null ? void 0 : a.id;
    if (f) {
      const d = r.get(f);
      if (d && d !== l[0])
        throw new Error(`Duplicate schema id "${f}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      r.set(f, l[0]);
    }
  }
  const i = (l) => {
    var m;
    const f = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      const k = (m = e.external.registry.get(l[0])) == null ? void 0 : m.id, g = e.external.uri ?? ((w) => w);
      if (k)
        return { ref: g(k) };
      const _ = l[1].defId ?? l[1].schema.id ?? `schema${e.counter++}`;
      return l[1].defId = _, { defId: _, ref: `${g("__shared")}#/${f}/${xa(_)}` };
    }
    const d = "#", p = `${d}/${f}/`;
    if (l[1] === n && !l[1].schema.id)
      return { ref: d };
    const h = l[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: h, ref: p + xa(h) };
  }, o = (l) => {
    if (l[1].schema.$ref)
      return;
    const f = l[1], { ref: d, defId: p } = i(l);
    f.def = { ...f.schema }, p && (f.defId = p);
    const h = f.schema;
    for (const m in h)
      delete h[m];
    h.$ref = d;
  };
  if (e.cycles === "throw")
    for (const l of e.seen.entries()) {
      const f = l[1];
      if (f.cycle)
        throw new Error(`Cycle detected: #/${(s = f.cycle) == null ? void 0 : s.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const l of e.seen.entries()) {
    const f = l[1];
    if (t === l[0]) {
      o(l);
      continue;
    }
    if (e.external) {
      const p = (u = e.external.registry.get(l[0])) == null ? void 0 : u.id;
      if (t !== l[0] && p) {
        o(l);
        continue;
      }
    }
    if ((c = e.metadataRegistry.get(l[0])) == null ? void 0 : c.id) {
      o(l);
      continue;
    }
    if (f.cycle) {
      o(l);
      continue;
    }
    f.count > 1 && e.reused === "ref" && o(l);
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
function Nl(e) {
  const t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  const n = [];
  for (const r of t) {
    if (!r || typeof r != "object")
      return;
    Nl(r);
    const i = Object.keys(r);
    if (i.length !== 1 || i[0] !== "type")
      return;
    const o = r.type;
    for (const a of Array.isArray(o) ? o : [o]) {
      if (typeof a != "string")
        return;
      n.includes(a) || n.push(a);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
const Dl = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), _a = ["oneOf", "anyOf"];
function Sa(e) {
  const t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
function Ii(e) {
  var o;
  const t = [];
  for (const a of e) {
    if (typeof a != "object" || a.type !== "object")
      return null;
    for (const s in a)
      if (!Dl.has(s))
        return null;
    t.push(a);
  }
  const n = {}, r = /* @__PURE__ */ new Set();
  for (const a of t) {
    for (const s in a.properties) {
      if (Object.prototype.hasOwnProperty.call(n, s))
        continue;
      const u = [];
      for (const l of t) {
        const f = ((o = l.properties) == null ? void 0 : o[s]) ?? Sa(l);
        f != null && (u.some((d) => JSON.stringify(d) === JSON.stringify(f)) || u.push(f));
      }
      const c = u.length === 1 ? u[0] : Ii(u) ?? { allOf: u };
      ut(n, s, c);
    }
    for (const s of a.required ?? [])
      r.add(s);
  }
  const i = { type: "object", properties: n };
  if (r.size && (i.required = [...r]), t.every((a) => a.additionalProperties === !1))
    i.additionalProperties = !1;
  else {
    const a = [];
    for (const s of t) {
      const u = Sa(s);
      u && !a.some((c) => JSON.stringify(c) === JSON.stringify(u)) && a.push(u);
    }
    a.length === 1 ? i.additionalProperties = a[0] : a.length > 1 && (i.additionalProperties = { allOf: a });
  }
  return i;
}
function Nm(e) {
  const t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (const i of Dl)
    if (i in e)
      return;
  const n = t.filter((i) => _a.some((o) => Array.isArray(i[o])));
  let r = null;
  if (!n.length)
    r = Ii(t);
  else {
    const i = n[0], o = _a.find((u) => Array.isArray(i[u]));
    if (Object.keys(i).length !== 1)
      return;
    const a = t.filter((u) => u !== i), s = i[o].map((u) => Ii([...a, u]));
    if (s.some((u) => !u))
      return;
    r = { [o]: s };
  }
  r && (delete e.allOf, En(e, r));
}
function gr(e, t) {
  var s, u, c, l;
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const r = (f) => {
    const d = e.seen.get(f);
    if (d.ref === null)
      return;
    const p = d.def ?? d.schema, h = { ...p }, m = d.ref;
    if (d.ref = null, m) {
      r(m);
      const g = e.seen.get(m), _ = g.schema;
      if (_.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (p.allOf = p.allOf ?? [], p.allOf.push(_)) : En(p, _), En(p, h), f._zod.parent === m)
        for (const C in p)
          C === "$ref" || C === "allOf" || C in h || delete p[C];
      if (_.$ref && g.def)
        for (const C in p)
          C === "$ref" || C === "allOf" || C in g.def && JSON.stringify(p[C]) === JSON.stringify(g.def[C]) && delete p[C];
    }
    const k = f._zod.parent;
    if (k && k !== m) {
      r(k);
      const g = e.seen.get(k);
      if (g != null && g.schema.$ref && (p.$ref = g.schema.$ref, g.def))
        for (const _ in p)
          _ === "$ref" || _ === "allOf" || _ in g.def && JSON.stringify(p[_]) === JSON.stringify(g.def[_]) && delete p[_];
    }
    e.override({
      zodSchema: f,
      jsonSchema: p,
      path: d.path ?? []
    });
  };
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (const f of [...e.seen.entries()].reverse())
      r(f[0]);
    if (e.target !== "openapi-3.0")
      for (const f of e.seen.entries())
        Nl(f[1].def ?? f[1].schema);
    for (const f of e.deferred)
      f();
    if (e.intersections.length) {
      const f = /* @__PURE__ */ new Map();
      for (const d of e.seen.values())
        for (const p of [d.schema, d.def]) {
          const h = p == null ? void 0 : p.allOf;
          if (!Array.isArray(h))
            continue;
          const m = f.get(h);
          m ? m.push(p) : f.set(h, [p]);
        }
      for (const d of e.intersections)
        for (const p of f.get(d) ?? [])
          Nm(p);
    }
  }
  const i = {};
  if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, (s = e.external) != null && s.uri) {
    const f = (u = e.external.registry.get(t)) == null ? void 0 : u.id;
    if (!f)
      throw new Error("Schema is missing an `id` property");
    i.$id = e.external.uri(f);
  }
  En(i, n.defId ? n.schema : n.def ?? n.schema);
  const o = (c = e.metadataRegistry.get(t)) == null ? void 0 : c.id;
  o !== void 0 && i.id === o && delete i.id;
  const a = ((l = e.external) == null ? void 0 : l.defs) ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (const f of e.seen.entries()) {
      const d = f[1];
      d.def && d.defId && (d.def.id === d.defId && delete d.def.id, ut(a, d.defId, d.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? i.$defs = a : i.definitions = a);
  try {
    const f = JSON.parse(JSON.stringify(i));
    return Object.defineProperty(f, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: yr(t, "input", e.processors),
          output: yr(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), f;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function Ee(e, t) {
  const n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  const r = e._zod.def;
  if (r.type === "transform")
    return !0;
  if (r.type === "array")
    return Ee(r.element, n);
  if (r.type === "set")
    return Ee(r.valueType, n);
  if (r.type === "lazy")
    return Ee(r.getter(), n);
  if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch")
    return Ee(r.innerType, n);
  if (r.type === "intersection")
    return Ee(r.left, n) || Ee(r.right, n);
  if (r.type === "record" || r.type === "map")
    return Ee(r.keyType, n) || Ee(r.valueType, n);
  if (r.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : Ee(r.in, n) || Ee(r.out, n);
  if (r.type === "object") {
    for (const i in r.shape)
      if (Ee(r.shape[i], n))
        return !0;
    return !1;
  }
  if (r.type === "union") {
    for (const i of r.options)
      if (Ee(i, n))
        return !0;
    return !1;
  }
  if (r.type === "tuple") {
    for (const i of r.items)
      if (Ee(i, n))
        return !0;
    return !!(r.rest && Ee(r.rest, n));
  }
  return !1;
}
const Dm = (e, t = {}) => (n) => {
  const r = hr({ ...n, processors: t });
  return se(e, r), mr(r, e), gr(r, e);
}, yr = (e, t, n = {}) => (r) => {
  const { libraryOptions: i, target: o } = r ?? {}, a = hr({ ...i ?? {}, target: o, io: t, processors: n });
  return se(e, a), mr(a, e), gr(a, e);
}, tn = (e, t, n) => {
  (e[t] === void 0 || n > e[t]) && (e[t] = n);
}, nn = (e, t, n) => {
  (e[t] === void 0 || n < e[t]) && (e[t] = n);
}, Ia = (e, t) => {
  tn(e, "minimum", t), nn(e, "maximum", t);
}, Ll = (e, t) => {
  e.multipleOf ?? (e.multipleOf = []), e.multipleOf.includes(t) || e.multipleOf.push(t);
}, Fl = (e, t) => {
  e.patterns ?? (e.patterns = /* @__PURE__ */ new Set()), e.patterns.add(t);
}, jl = (e, t) => {
  e.mime = e.mime ? e.mime.filter((n) => t.includes(n)) : [...t];
}, Zl = (e, t) => {
  e.format = t, t.includes("int") && (e.isInt = !0);
}, Ea = (e, t) => tn(e, "minimum", t.minimum), Ca = (e, t) => nn(e, "maximum", t.maximum), Aa = (e) => (t, n) => {
  Zl(t, n.format);
  const [r, i] = e[n.format];
  tn(t, "minimum", r), nn(t, "maximum", i);
}, Hr = {
  greater_than: (e, t) => tn(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
  less_than: (e, t) => nn(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
  multiple_of: (e, t) => Ll(e, t.value),
  number_format: Aa(fl),
  bigint_format: Aa(Wf),
  min_length: Ea,
  max_length: Ca,
  length_equals: (e, t) => Ia(e, t.length),
  min_size: Ea,
  max_size: Ca,
  size_equals: (e, t) => Ia(e, t.size),
  string_format: (e, t) => {
    Zl(e, t.format), t.pattern && Fl(e, t.pattern), (t.format === "base64" || t.format === "base64url") && (e.contentEncoding = t.format), (t.local || t.precision === -1) && (e.laxFormat = !0);
  },
  mime_type: (e, t) => jl(e, t.mime)
};
function Fe(e) {
  var o;
  const t = {}, n = e._zod.def, r = e._zod.traits.has("$ZodCheck") ? [e, ...n.checks ?? []] : n.checks ?? [];
  for (const a of r)
    (o = Hr[a._zod.def.check]) == null || o.call(Hr, t, a._zod.def);
  const i = e._zod.bag;
  i.minimum !== void 0 && tn(t, "minimum", i.minimum), i.exclusiveMinimum !== void 0 && tn(t, "exclusiveMinimum", i.exclusiveMinimum), i.maximum !== void 0 && nn(t, "maximum", i.maximum), i.exclusiveMaximum !== void 0 && nn(t, "exclusiveMaximum", i.exclusiveMaximum), i.multipleOf !== void 0 && Ll(t, i.multipleOf), i.format !== void 0 && (t.format ?? (t.format = i.format), i.format.includes("int") && (t.isInt = !0)), i.mime && jl(t, i.mime);
  for (const a of i.patterns ?? [])
    Fl(t, a);
  return t;
}
const Lm = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Fm = /* @__PURE__ */ new Map([
  [Il, Hd],
  [co, Kd]
]), Bl = (e) => Fm.get(e) ?? e, Ul = (e, t, n, r) => {
  const i = n;
  i.type = "string";
  const { minimum: o, maximum: a, format: s, patterns: u, contentEncoding: c, laxFormat: l } = Fe(e);
  if (typeof o == "number" && (i.minLength = o), typeof a == "number" && (i.maxLength = a), s && (i.format = Lm[s] ?? s, i.format === "" && delete i.format, (s === "time" || l) && delete i.format), c && (i.contentEncoding = c), u && u.size > 0) {
    const f = [...u].map(Bl);
    f.length === 1 ? i.pattern = f[0].source : f.length > 1 && (i.allOf = [
      ...f.map((d) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: d.source
      }))
    ]);
  }
}, Vl = (e, t, n, r) => {
  const i = n, { minimum: o, maximum: a, multipleOf: s, exclusiveMaximum: u, exclusiveMinimum: c, isInt: l } = Fe(e);
  i.type = l ? "integer" : "number";
  const f = typeof c == "number" && c >= (o ?? Number.NEGATIVE_INFINITY), d = typeof u == "number" && u <= (a ?? Number.POSITIVE_INFINITY), p = t.target === "draft-04" || t.target === "openapi-3.0";
  if (f ? p ? (i.minimum = c, i.exclusiveMinimum = !0) : i.exclusiveMinimum = c : typeof o == "number" && (i.minimum = o), d ? p ? (i.maximum = u, i.exclusiveMaximum = !0) : i.exclusiveMaximum = u : typeof a == "number" && (i.maximum = a), s) {
    const h = /* @__PURE__ */ new Set();
    for (const g of s)
      Number.isFinite(g) && g !== 0 ? h.add(Math.abs(g)) : _e(e, t, i, r, `A multipleOf divisor of ${g} cannot be represented in JSON Schema`);
    const [m, ...k] = h;
    m !== void 0 && (i.multipleOf = m), k.length && (i.allOf = [...i.allOf ?? [], ...k.map((g) => ({ multipleOf: g }))]);
  }
}, ql = (e, t, n, r) => {
  n.type = "boolean";
}, jm = (e, t, n, r) => {
  _e(e, t, n, r, "BigInt cannot be represented in JSON Schema");
}, Zm = (e, t, n, r) => {
  _e(e, t, n, r, "Symbols cannot be represented in JSON Schema");
}, Jl = (e, t, n, r) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, Bm = (e, t, n, r) => {
  _e(e, t, n, r, "Undefined cannot be represented in JSON Schema");
}, Um = (e, t, n, r) => {
  _e(e, t, n, r, "Void cannot be represented in JSON Schema");
}, Wl = (e, t, n, r) => {
  n.not = {};
}, Vm = (e, t, n, r) => {
}, Hl = (e, t, n, r) => {
}, qm = (e, t, n, r) => {
  _e(e, t, n, r, "Date cannot be represented in JSON Schema");
}, Kl = (e, t, n, r) => {
  const i = e._zod.def, o = vi(i.entries);
  if (o.length === 0) {
    n.not = {};
    return;
  }
  o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), n.enum = o;
}, Yl = (e, t, n, r) => {
  const i = e._zod.def;
  if (i.values.length === 0) {
    n.not = {};
    return;
  }
  const o = [];
  for (const a of i.values)
    if (a === void 0) {
      if (_e(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (_e(e, t, n, r, "BigInt literals cannot be represented in JSON Schema"))
        return;
      o.push(Number(a));
    } else
      o.push(a);
  if (o.length !== 0) if (o.length === 1) {
    const a = o[0];
    n.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
  } else
    o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), o.every((a) => typeof a == "boolean") && (n.type = "boolean"), o.every((a) => a === null) && (n.type = "null"), n.enum = o;
}, Jm = (e, t, n, r) => {
  _e(e, t, n, r, "NaN cannot be represented in JSON Schema");
}, Wm = (e, t, n, r) => {
  const i = n, o = e._zod.pattern;
  if (!o)
    throw new Error("Pattern not found in template literal");
  i.type = "string", i.pattern = o.source;
}, Hm = (e, t, n, r) => {
  const i = n;
  i.type = "string", i.format = "binary", i.contentEncoding = "binary";
  const { minimum: o, maximum: a, mime: s } = Fe(e);
  o !== void 0 && (i.minLength = o), a !== void 0 && (i.maxLength = a), s && (s.length === 0 ? i.not = {} : s.length === 1 ? i.contentMediaType = s[0] : i.anyOf = s.map((u) => ({ contentMediaType: u })));
}, Km = (e, t, n, r) => {
  n.type = "boolean";
}, Gl = (e, t, n, r) => {
  _e(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, Ym = (e, t, n, r) => {
  _e(e, t, n, r, "Function types cannot be represented in JSON Schema");
}, Xl = (e, t, n, r) => {
  _e(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, Gm = (e, t, n, r) => {
  _e(e, t, n, r, "Map cannot be represented in JSON Schema");
}, Xm = (e, t, n, r) => {
  _e(e, t, n, r, "Set cannot be represented in JSON Schema");
}, Ql = (e, t, n, r) => {
  const i = n, o = e._zod.def, { minimum: a, maximum: s } = Fe(e);
  typeof a == "number" && (i.minItems = a), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = se(o.element, t, {
    ...r,
    path: [...r.path, "items"]
  });
};
function Rn(e) {
  const t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? Rn(t.out) : t.type === "catch" ? Rn(t.innerType) : e._zod.optin;
}
const eu = (e, t, n, r) => {
  var c;
  const i = n, o = e._zod.def, a = o.shape;
  if (Object.getOwnPropertySymbols(a).length && _e(e, t, i, r, "Symbol keys cannot be represented in JSON Schema"))
    return;
  i.type = "object", i.properties = {};
  for (const l in a)
    ut(i.properties, l, se(a[l], t, {
      ...r,
      path: [...r.path, "properties", l]
    }));
  const u = [];
  for (const l of Object.keys(a)) {
    const f = o.shape[l];
    (t.io === "input" ? Rn(f) === void 0 : f._zod.optout === void 0) && u.push(l);
  }
  u.length > 0 && (i.required = u), ((c = o.catchall) == null ? void 0 : c._zod.def.type) === "never" ? i.additionalProperties = !1 : o.catchall ? o.catchall && (i.additionalProperties = se(o.catchall, t, {
    ...r,
    path: [...r.path, "additionalProperties"]
  })) : t.io === "output" && (i.additionalProperties = !1);
}, tu = (e, t, n, r) => {
  const i = e._zod.def, o = i.inclusive === !1, a = i.options.map((s, u) => se(s, t, {
    ...r,
    path: [...r.path, o ? "oneOf" : "anyOf", u]
  }));
  o ? n.oneOf = a : n.anyOf = a;
}, nu = (e, t, n, r) => {
  const i = e._zod.def, o = se(i.left, t, {
    ...r,
    path: [...r.path, "allOf", 0]
  }), a = se(i.right, t, {
    ...r,
    path: [...r.path, "allOf", 1]
  }), s = (c) => "allOf" in c && Object.keys(c).length === 1, u = [
    ...s(o) ? o.allOf : [o],
    ...s(a) ? a.allOf : [a]
  ];
  n.allOf = u, t.intersections.push(u);
}, Qm = (e, t, n, r) => {
  const i = n, o = e._zod.def;
  i.type = "array";
  const a = t.target === "draft-2020-12" ? "prefixItems" : "items", s = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = o.items.map((m, k) => se(m, t, {
    ...r,
    path: [...r.path, a, k]
  })), c = o.rest ? se(o.rest, t, {
    ...r,
    path: [...r.path, s, ...t.target === "openapi-3.0" ? [o.items.length] : []]
  }) : null;
  let l = o.items.length;
  for (; l > 0; ) {
    const m = o.items[l - 1];
    if (!(t.io === "input" ? Rn(m) !== void 0 : m._zod.optout === "optional"))
      break;
    l--;
  }
  const f = o.items.length, d = !o.rest;
  t.target === "draft-2020-12" ? (i.prefixItems = u, d ? i.items = !1 : c && (i.items = c), l > 0 && (i.minItems = l), d && (i.maxItems = f)) : t.target === "openapi-3.0" ? (i.items = {
    anyOf: u
  }, c && i.items.anyOf.push(c), l > 0 && (i.minItems = l), d && (i.maxItems = f)) : (i.items = u, d ? i.additionalItems = !1 : c && (i.additionalItems = c), l > 0 && (i.minItems = l), d && (i.maxItems = f));
  const { minimum: p, maximum: h } = Fe(e);
  typeof p == "number" && (i.minItems = p), typeof h == "number" && (i.maxItems = h);
};
function Ei(e, t, n) {
  var h;
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    const m = (h = e.get(t)) == null ? void 0 : h.def;
    if (!m)
      return t;
    const k = Ei(e, m, n);
    return k === m ? t : k;
  }
  for (const m of ["anyOf", "oneOf"]) {
    const k = t[m];
    if (!Array.isArray(k))
      continue;
    const g = k.map((_) => Ei(e, _, n));
    g.some((_, w) => _ !== k[w]) && (t = { ...t, [m]: g });
  }
  const r = Array.isArray(t.type) ? t.type : [t.type], i = !r.includes("string") && r.some((m) => m === "number" || m === "integer"), o = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!i && !(o != null && o.some((m) => typeof m == "number")))
    return t;
  const { minimum: a, maximum: s, exclusiveMinimum: u, exclusiveMaximum: c, multipleOf: l, format: f, id: d, ...p } = t;
  return p.enum ? p.enum = p.enum.map((m) => typeof m == "number" ? String(m) : m) : typeof p.const == "number" && (p.const = String(p.const)), i && (p.type = "string", o || (p.pattern = (r.includes("number") ? so : rp).source)), p;
}
const Ci = /* @__PURE__ */ new WeakMap();
function eg(e) {
  var r;
  const t = /* @__PURE__ */ new Map();
  for (const i of e.seen.values())
    i.def && !t.has(i.schema) && t.set(i.schema, i);
  const n = /* @__PURE__ */ new Map();
  for (const i of Ci.get(e) ?? []) {
    const o = e.seen.get(i), a = (r = (o == null ? void 0 : o.def) ?? (o == null ? void 0 : o.schema)) == null ? void 0 : r.propertyNames;
    if (!a || a === !0 || n.has(a))
      continue;
    const s = Ei(t, a, /* @__PURE__ */ new Set());
    s !== a && n.set(a, s);
  }
  if (n.size)
    for (const i of e.seen.values())
      for (const o of [i.schema, i.def]) {
        const a = o && n.get(o.propertyNames);
        a && (o.propertyNames = a);
      }
}
const ru = (e, t, n, r) => {
  const i = n, o = e._zod.def;
  i.type = "object";
  const a = o.keyType, s = Fe(a).patterns;
  if (o.mode === "loose" && s && s.size > 0) {
    const l = se(o.valueType, t, {
      ...r,
      path: [...r.path, "patternProperties", "*"]
    });
    i.patternProperties = {};
    for (const f of s)
      ut(i.patternProperties, Bl(f).source, l);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      i.propertyNames = se(o.keyType, t, {
        ...r,
        path: [...r.path, "propertyNames"]
      });
      let l = Ci.get(t);
      l || (l = [], Ci.set(t, l), t.deferred.push(() => eg(t))), l.push(e);
    }
    i.additionalProperties = se(o.valueType, t, {
      ...r,
      path: [...r.path, "additionalProperties"]
    });
  }
  const u = a._zod.values, c = t.io === "input" && Rn(o.valueType) !== void 0;
  if (u && !o.partial && !c) {
    const l = [...u].filter((f) => typeof f == "string" || typeof f == "number");
    l.length > 0 && (i.required = l.map(String));
  }
}, iu = (e, t, n, r) => {
  const i = e._zod.def, o = se(i.innerType, t, r), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = i.innerType, n.nullable = !0) : n.anyOf = [o, { type: "null" }];
}, ou = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, fo = Symbol();
function au(e, t, n, r, i) {
  let o = !1;
  const a = JSON.stringify(e, (s, u) => typeof u != "bigint" ? u : (o = !0, null));
  return o ? (_e(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), fo) : JSON.parse(a);
}
const su = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
  const a = au(i.defaultValue, e, t, n, r);
  a !== fo && (n.default = a);
}, lu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  if (o.ref = i.innerType, t.io !== "input")
    return;
  const a = au(i.defaultValue, e, t, n, r);
  a !== fo && (n._prefault = a);
}, uu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
  let a;
  try {
    a = i.catchValue(void 0);
  } catch {
    _e(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = a;
}, cu = (e, t, n, r) => {
  const i = e._zod.def, o = i.in._zod.traits.has("$ZodTransform"), a = t.io === "input" ? o ? i.out : i.in : i.out;
  se(a, t, r);
  const s = t.seen.get(e);
  s.ref = a;
}, fu = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType, n.readOnly = !0;
}, tg = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, po = (e, t, n, r) => {
  const i = e._zod.def;
  se(i.innerType, t, r);
  const o = t.seen.get(e);
  o.ref = i.innerType;
}, du = (e, t, n, r) => {
  const i = e._zod.innerType;
  se(i, t, r);
  const o = t.seen.get(e);
  o.ref = i;
}, za = {
  string: Ul,
  number: Vl,
  boolean: ql,
  bigint: jm,
  symbol: Zm,
  null: Jl,
  undefined: Bm,
  void: Um,
  never: Wl,
  any: Vm,
  unknown: Hl,
  date: qm,
  enum: Kl,
  literal: Yl,
  nan: Jm,
  template_literal: Wm,
  file: Hm,
  success: Km,
  custom: Gl,
  function: Ym,
  transform: Xl,
  map: Gm,
  set: Xm,
  array: Ql,
  object: eu,
  union: tu,
  intersection: nu,
  tuple: Qm,
  record: ru,
  nullable: iu,
  nonoptional: ou,
  default: su,
  prefault: lu,
  catch: uu,
  pipe: cu,
  readonly: fu,
  promise: tg,
  optional: po,
  lazy: du
};
function ng(e, t) {
  if ("_idmap" in e) {
    const r = e, i = hr({ ...t, processors: za }), o = {};
    for (const u of r._idmap.entries()) {
      const [c, l] = u;
      se(l, i);
    }
    const a = {}, s = {
      registry: r,
      uri: t == null ? void 0 : t.uri,
      defs: o
    };
    i.external = s;
    for (const u of r._idmap.entries()) {
      const [c, l] = u;
      mr(i, l), ut(a, c, gr(i, l));
    }
    if (Object.keys(o).length > 0) {
      const u = i.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [u]: o
      };
    }
    return { schemas: a };
  }
  const n = hr({ ...t, processors: za });
  return se(e, n), mr(n, e), gr(n, e);
}
const Ta = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Hn(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      const r = n(this);
      return Object.defineProperty(this, t, { value: r, configurable: !0, writable: !0 }), r;
    },
    set(r) {
      Object.defineProperty(this, t, { value: r, configurable: !0, writable: !0 });
    }
  });
}
const rg = (e, t) => {
  md.init(e, t), e.name = "ZodError";
  const n = Object.getPrototypeOf(e);
  Ta.has(n) || (Ta.add(n), Hn(n, "format", (r) => (i) => bd(r, i)), Hn(n, "flatten", (r) => (i) => yd(r, i)), Hn(n, "addIssue", (r) => (i) => {
    r.issues.push(i), r.message = JSON.stringify(r.issues, ki, 2);
  }), Hn(n, "addIssues", (r) => (i) => {
    r.issues.push(...i), r.message = JSON.stringify(r.issues, ki, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, He = /* @__PURE__ */ z("ZodError", rg, void 0, {
  Parent: Error
}), ig = /* @__PURE__ */ ro(He), og = /* @__PURE__ */ io(He), ag = /* @__PURE__ */ oo(He), pu = /* @__PURE__ */ ao(He), sg = /* @__PURE__ */ Sd(He), lg = /* @__PURE__ */ Id(He), ug = /* @__PURE__ */ Ed(He), cg = /* @__PURE__ */ Cd(He), fg = /* @__PURE__ */ Ad(He), dg = /* @__PURE__ */ zd(He), pg = /* @__PURE__ */ Td(He), hg = /* @__PURE__ */ Od(He);
function mg() {
  tt.localeError || lt(Dh());
}
function Ar() {
  tt.memoizer || lt({ memoizer: Rh() });
}
const pe = /* @__PURE__ */ z("ZodType", (e, t) => (mg(), de.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    const t = this.def;
    return this.clone(Le(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return Ct(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(my(e, t));
  },
  superRefine(e, t) {
    return this.check(gy(e, t));
  },
  overwrite(e) {
    return this.check(/* @__PURE__ */ rn(e));
  },
  optional() {
    return Ma(this);
  },
  exactOptional() {
    return ty(this);
  },
  nullable() {
    return Ra(this);
  },
  nullish() {
    return Ma(Ra(this));
  },
  nonoptional(e) {
    return sy(this, e);
  },
  array() {
    return on(this);
  },
  or(e) {
    return Ae([this, e]);
  },
  and(e) {
    return Gg(this, e);
  },
  transform(e) {
    return $a(this, ey(e));
  },
  default(e) {
    return iy(this, e);
  },
  prefault(e) {
    return ay(this, e);
  },
  catch(e) {
    return uy(this, e);
  },
  pipe(e) {
    return $a(this, e);
  },
  readonly() {
    return dy(this);
  },
  describe(e) {
    const t = this.clone();
    return wn.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return wn.get(this);
    const t = this.clone();
    return wn.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return no(this, "~standard", {
      ...kl(this),
      jsonSchema: {
        input: yr(this, "input"),
        output: yr(this, "output")
      }
    });
  },
  set "~standard"(e) {
    It(this, "~standard", e);
  },
  parse: function e(t, n) {
    return ig(this, t, n, { callee: e });
  },
  parseAsync: async function e(t, n) {
    return await og(this, t, n, { callee: e });
  },
  safeParse(e, t) {
    return ag(this, e, t);
  },
  async safeParseAsync(e, t) {
    return pu(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this == null ? void 0 : this.safeParseAsync;
  },
  set spa(e) {
    It(this, "spa", e);
  },
  validate(e, t) {
    return wd(this, e, t);
  },
  validateAsync(e, t) {
    return _d(this, e, t);
  },
  encode: function e(t, n) {
    return sg(this, t, n, { callee: e });
  },
  decode: function e(t, n) {
    return lg(this, t, n, { callee: e });
  },
  encodeAsync: async function e(t, n) {
    return await ug(this, t, n, { callee: e });
  },
  decodeAsync: async function e(t, n) {
    return await cg(this, t, n, { callee: e });
  },
  safeEncode(e, t) {
    return fg(this, e, t);
  },
  safeDecode(e, t) {
    return dg(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return pg(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return hg(this, e, t);
  },
  toJSONSchema(e) {
    return Dm(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    var e;
    return (e = wn.get(this)) == null ? void 0 : e.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), hu = /* @__PURE__ */ z(
  "_ZodString",
  (e, t) => {
    uo.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Ul(e, n, r);
  },
  /* @__PURE__ */ pl({
    format: (e) => Fe(e).format ?? null,
    minLength: (e) => Fe(e).minimum ?? null,
    maxLength: (e) => Fe(e).maximum ?? null
  }, {
    regex(...e) {
      return this.check(/* @__PURE__ */ vm(...e));
    },
    includes(...e) {
      return this.check(/* @__PURE__ */ xm(...e));
    },
    startsWith(...e) {
      return this.check(/* @__PURE__ */ _m(...e));
    },
    endsWith(...e) {
      return this.check(/* @__PURE__ */ Sm(...e));
    },
    min(...e) {
      return this.check(/* @__PURE__ */ pr(...e));
    },
    max(...e) {
      return this.check(/* @__PURE__ */ Rl(...e));
    },
    length(...e) {
      return this.check(/* @__PURE__ */ $l(...e));
    },
    nonempty(...e) {
      return this.check(/* @__PURE__ */ pr(1, ...e));
    },
    lowercase(e) {
      return this.check(/* @__PURE__ */ km(e));
    },
    uppercase(e) {
      return this.check(/* @__PURE__ */ wm(e));
    },
    trim() {
      return this.check(/* @__PURE__ */ Cm());
    },
    normalize(...e) {
      return this.check(/* @__PURE__ */ Em(...e));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ Am());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ zm());
    },
    slugify() {
      return this.check(/* @__PURE__ */ Tm());
    }
  })
), gg = /* @__PURE__ */ z("ZodString", (e, t) => {
  uo.init(e, t), hu.init(e, t);
}, {
  email(e) {
    return this.check(/* @__PURE__ */ Zh(wg, e));
  },
  url(e) {
    return this.check(/* @__PURE__ */ Wh(_g, e));
  },
  jwt(e) {
    return this.check(/* @__PURE__ */ lm(Lg, e));
  },
  emoji(e) {
    return this.check(/* @__PURE__ */ Hh(Sg, e));
  },
  guid(e) {
    return this.check(/* @__PURE__ */ Bh(xg, e));
  },
  uuid(e) {
    return this.check(/* @__PURE__ */ Uh(Kn, e));
  },
  uuidv4(e) {
    return this.check(/* @__PURE__ */ Vh(Kn, e));
  },
  uuidv6(e) {
    return this.check(/* @__PURE__ */ qh(Kn, e));
  },
  uuidv7(e) {
    return this.check(/* @__PURE__ */ Jh(Kn, e));
  },
  nanoid(e) {
    return this.check(/* @__PURE__ */ Kh(Ig, e));
  },
  cuid(e) {
    return this.check(/* @__PURE__ */ Yh(Eg, e));
  },
  cuid2(e) {
    return this.check(/* @__PURE__ */ Gh(Cg, e));
  },
  ulid(e) {
    return this.check(/* @__PURE__ */ Xh(Ag, e));
  },
  base64(e) {
    return this.check(/* @__PURE__ */ om($g, e));
  },
  base64url(e) {
    return this.check(/* @__PURE__ */ am(Ng, e));
  },
  xid(e) {
    return this.check(/* @__PURE__ */ Qh(zg, e));
  },
  ksuid(e) {
    return this.check(/* @__PURE__ */ em(Tg, e));
  },
  ipv4(e) {
    return this.check(/* @__PURE__ */ tm(Og, e));
  },
  ipv6(e) {
    return this.check(/* @__PURE__ */ nm(Pg, e));
  },
  cidrv4(e) {
    return this.check(/* @__PURE__ */ rm(Mg, e));
  },
  cidrv6(e) {
    return this.check(/* @__PURE__ */ im(Rg, e));
  },
  e164(e) {
    return this.check(/* @__PURE__ */ sm(Dg, e));
  },
  datetime(e) {
    return this.check(/* @__PURE__ */ um(yg, e));
  },
  date(e) {
    return this.check(/* @__PURE__ */ cm(bg, e));
  },
  time(e) {
    return this.check(/* @__PURE__ */ fm(vg, e));
  },
  duration(e) {
    return this.check(/* @__PURE__ */ dm(kg, e));
  }
});
function $(e) {
  return /* @__PURE__ */ jh(gg, e);
}
const me = /* @__PURE__ */ z("ZodStringFormat", (e, t) => {
  he.init(e, t), hu.init(e, t);
}), yg = /* @__PURE__ */ z("ZodISODateTime", (e, t) => {
  jp.init(e, t), me.init(e, t);
}), bg = /* @__PURE__ */ z("ZodISODate", (e, t) => {
  Zp.init(e, t), me.init(e, t);
}), vg = /* @__PURE__ */ z("ZodISOTime", (e, t) => {
  Bp.init(e, t), me.init(e, t);
}), kg = /* @__PURE__ */ z("ZodISODuration", (e, t) => {
  Up.init(e, t), me.init(e, t);
}), wg = /* @__PURE__ */ z("ZodEmail", (e, t) => {
  Ep.init(e, t), me.init(e, t);
}), xg = /* @__PURE__ */ z("ZodGUID", (e, t) => {
  Sp.init(e, t), me.init(e, t);
}), Kn = /* @__PURE__ */ z("ZodUUID", (e, t) => {
  Ip.init(e, t), me.init(e, t);
}), _g = /* @__PURE__ */ z("ZodURL", (e, t) => {
  Pp.init(e, t), me.init(e, t);
}), Sg = /* @__PURE__ */ z("ZodEmoji", (e, t) => {
  Mp.init(e, t), me.init(e, t);
}), Ig = /* @__PURE__ */ z("ZodNanoID", (e, t) => {
  Rp.init(e, t), me.init(e, t);
}), Eg = /* @__PURE__ */ z("ZodCUID", (e, t) => {
  $p.init(e, t), me.init(e, t);
}), Cg = /* @__PURE__ */ z("ZodCUID2", (e, t) => {
  Np.init(e, t), me.init(e, t);
}), Ag = /* @__PURE__ */ z("ZodULID", (e, t) => {
  Dp.init(e, t), me.init(e, t);
}), zg = /* @__PURE__ */ z("ZodXID", (e, t) => {
  Lp.init(e, t), me.init(e, t);
}), Tg = /* @__PURE__ */ z("ZodKSUID", (e, t) => {
  Fp.init(e, t), me.init(e, t);
}), Og = /* @__PURE__ */ z("ZodIPv4", (e, t) => {
  Vp.init(e, t), me.init(e, t);
}), Pg = /* @__PURE__ */ z("ZodIPv6", (e, t) => {
  Jp.init(e, t), me.init(e, t);
}), Mg = /* @__PURE__ */ z("ZodCIDRv4", (e, t) => {
  Wp.init(e, t), me.init(e, t);
}), Rg = /* @__PURE__ */ z("ZodCIDRv6", (e, t) => {
  Kp.init(e, t), me.init(e, t);
}), $g = /* @__PURE__ */ z("ZodBase64", (e, t) => {
  Yp.init(e, t), me.init(e, t);
}), Ng = /* @__PURE__ */ z("ZodBase64URL", (e, t) => {
  Xp.init(e, t), me.init(e, t);
}), Dg = /* @__PURE__ */ z("ZodE164", (e, t) => {
  Qp.init(e, t), me.init(e, t);
}), Lg = /* @__PURE__ */ z("ZodJWT", (e, t) => {
  th.init(e, t), me.init(e, t);
}), mu = /* @__PURE__ */ z(
  "ZodNumber",
  (e, t) => {
    El.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Vl(e, n, r, i), e.isFinite = !0;
  },
  /* @__PURE__ */ pl({
    minValue: (e) => {
      const { minimum: t, exclusiveMinimum: n } = Fe(e);
      return Math.max(t ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (e) => {
      const { maximum: t, exclusiveMaximum: n } = Fe(e);
      return Math.min(t ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (e) => {
      const { isInt: t, multipleOf: n } = Fe(e);
      return !!t || !!(n != null && n.some(Number.isSafeInteger));
    },
    format: (e) => Fe(e).format ?? null
  }, {
    gt(e, t) {
      return this.check(/* @__PURE__ */ ka(e, t));
    },
    gte(e, t) {
      return this.check(/* @__PURE__ */ Wr(e, t));
    },
    min(e, t) {
      return this.check(/* @__PURE__ */ Wr(e, t));
    },
    lt(e, t) {
      return this.check(/* @__PURE__ */ va(e, t));
    },
    lte(e, t) {
      return this.check(/* @__PURE__ */ Jr(e, t));
    },
    max(e, t) {
      return this.check(/* @__PURE__ */ Jr(e, t));
    },
    int(e) {
      return this.check(Oa(e));
    },
    safe(e) {
      return this.check(Oa(e));
    },
    positive(e) {
      return this.check(/* @__PURE__ */ ka(0, e));
    },
    nonnegative(e) {
      return this.check(/* @__PURE__ */ Wr(0, e));
    },
    negative(e) {
      return this.check(/* @__PURE__ */ va(0, e));
    },
    nonpositive(e) {
      return this.check(/* @__PURE__ */ Jr(0, e));
    },
    multipleOf(e, t) {
      return this.check(/* @__PURE__ */ wa(e, t));
    },
    step(e, t) {
      return this.check(/* @__PURE__ */ wa(e, t));
    },
    finite() {
      return this;
    }
  })
);
function Fg(e) {
  return /* @__PURE__ */ pm(mu, e);
}
const jg = /* @__PURE__ */ z("ZodNumberFormat", (e, t) => {
  nh.init(e, t), mu.init(e, t);
});
function Oa(e) {
  return /* @__PURE__ */ hm(jg, e);
}
const Zg = /* @__PURE__ */ z("ZodBoolean", (e, t) => {
  rh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ql(e, n, r);
});
function Ce(e) {
  return /* @__PURE__ */ mm(Zg, e);
}
const Bg = /* @__PURE__ */ z("ZodNull", (e, t) => {
  ih.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Jl(e, n, r);
});
function Ug(e) {
  return /* @__PURE__ */ gm(Bg, e);
}
const Vg = /* @__PURE__ */ z("ZodUnknown", (e, t) => {
  oh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Hl();
});
function Re() {
  return /* @__PURE__ */ ym(Vg);
}
const qg = /* @__PURE__ */ z("ZodNever", (e, t) => {
  ah.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Wl(e, n, r);
});
function Jg(e) {
  return /* @__PURE__ */ bm(qg, e);
}
const Wg = /* @__PURE__ */ z("ZodArray", (e, t) => {
  Ar(), uh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Ql(e, n, r, i), e.element = t.element;
}, {
  min(e, t) {
    return this.check(/* @__PURE__ */ pr(e, t));
  },
  nonempty(e) {
    return this.check(/* @__PURE__ */ pr(1, e));
  },
  max(e, t) {
    return this.check(/* @__PURE__ */ Rl(e, t));
  },
  length(e, t) {
    return this.check(/* @__PURE__ */ $l(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function on(e, t) {
  return /* @__PURE__ */ Om(Wg, e, t);
}
const gu = /* @__PURE__ */ z("ZodObject", (e, t) => {
  Ar(), dh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => eu(e, n, r, i), sd(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return zi(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone(Le(this._zod.def, { catchall: e }));
  },
  passthrough() {
    return this.clone(Le(this._zod.def, { catchall: Re() }));
  },
  loose() {
    return this.clone(Le(this._zod.def, { catchall: Re() }));
  },
  strict() {
    return this.clone(Le(this._zod.def, { catchall: Jg() }));
  },
  strip() {
    return this.clone(Le(this._zod.def, { catchall: void 0 }));
  },
  extend(e) {
    return Yf(this, e);
  },
  safeExtend(e) {
    return Gf(this, e);
  },
  merge(e) {
    return Xf(this, e);
  },
  pick(e) {
    return Hf(this, e);
  },
  omit(e) {
    return Kf(this, e);
  },
  partial(...e) {
    return ea(bu, this, e[0]);
  },
  exactPartial(...e) {
    return ea(vu, this, e[0], "exactPartial");
  },
  required(...e) {
    return Qf(ku, this, e[0]);
  }
});
function oe(e, t) {
  const n = {
    type: "object",
    shape: e ?? {},
    ...j(t)
  };
  return new gu(n);
}
function ce(e, t) {
  return new gu({
    type: "object",
    shape: e,
    catchall: Re(),
    ...j(t)
  });
}
const yu = /* @__PURE__ */ z("ZodUnion", (e, t) => {
  zl.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => tu(e, n, r, i), e.options = t.options;
});
function Ae(e, t) {
  return new yu({
    type: "union",
    options: e,
    ...j(t)
  });
}
const Hg = /* @__PURE__ */ z("ZodDiscriminatedUnion", (e, t) => {
  yu.init(e, t), hh.init(e, t);
});
function Kg(e, t, n) {
  return new Hg({
    type: "union",
    options: t,
    discriminator: e,
    ...j(n)
  });
}
const Yg = /* @__PURE__ */ z("ZodIntersection", (e, t) => {
  mh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => nu(e, n, r, i);
});
function Gg(e, t) {
  return new Yg({
    type: "intersection",
    left: e,
    right: t
  });
}
const Pa = /* @__PURE__ */ z("ZodRecord", (e, t) => {
  Ar(), gh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ru(e, n, r, i), e.keyType = t.keyType, e.valueType = t.valueType;
});
function Dt(e, t, n) {
  return !t || !t._zod ? new Pa({
    type: "record",
    keyType: $(),
    valueType: e,
    ...j(t)
  }) : new Pa({
    type: "record",
    keyType: e,
    valueType: t,
    ...j(n)
  });
}
const Ai = /* @__PURE__ */ z("ZodEnum", (e, t) => {
  yh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (r, i, o) => Kl(e, r, i), e.enum = t.entries, e.options = [...e._zod.values];
  const n = new Set(Object.keys(t.entries));
  e.extract = (r, i) => {
    const o = {};
    for (const a of r)
      if (n.has(a))
        o[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Ai({
      ...t,
      checks: [],
      ...j(i),
      entries: o
    });
  }, e.exclude = (r, i) => {
    const o = { ...t.entries };
    for (const a of r)
      if (n.has(a))
        delete o[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Ai({
      ...t,
      checks: [],
      ...j(i),
      entries: o
    });
  };
});
function zi(e, t) {
  const n = Array.isArray(e) ? Object.fromEntries(e.map((r) => [r, r])) : e;
  return new Ai({
    type: "enum",
    entries: n,
    ...j(t)
  });
}
const Xg = /* @__PURE__ */ z("ZodLiteral", (e, t) => {
  bh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Yl(e, n, r, i), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function V(e, t) {
  return new Xg({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...j(t)
  });
}
const Qg = /* @__PURE__ */ z("ZodTransform", (e, t) => {
  Ar(), vh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Xl(e, n, r, i), e._zod.parse = (n, r) => {
    if (r.direction === "backward")
      throw new hl(e.constructor.name);
    n.addIssue = (o) => {
      if (typeof o == "string")
        n.issues.push(Mn(o, n.value, t));
      else {
        const a = o;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = n.value), a.inst ?? (a.inst = e), n.issues.push(Mn(a));
      }
    };
    const i = t.transform(n.value, n);
    return i instanceof Promise ? i.then((o) => (n.value = o, n)) : (n.value = i, n);
  };
});
function ey(e) {
  return new Qg({
    type: "transform",
    transform: e
  });
}
const bu = /* @__PURE__ */ z("ZodOptional", (e, t) => {
  Tl.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => po(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function Ma(e) {
  return new bu({
    type: "optional",
    innerType: e
  });
}
const vu = /* @__PURE__ */ z("ZodExactOptional", (e, t) => {
  kh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => po(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function ty(e) {
  return new vu({
    type: "optional",
    innerType: e
  });
}
const ny = /* @__PURE__ */ z("ZodNullable", (e, t) => {
  wh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => iu(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function Ra(e) {
  return new ny({
    type: "nullable",
    innerType: e
  });
}
const ry = /* @__PURE__ */ z("ZodDefault", (e, t) => {
  xh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => su(e, n, r, i), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function iy(e, t) {
  return new ry({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : ul(t);
    }
  });
}
const oy = /* @__PURE__ */ z("ZodPrefault", (e, t) => {
  _h.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => lu(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function ay(e, t) {
  return new oy({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : ul(t);
    }
  });
}
const ku = /* @__PURE__ */ z("ZodNonOptional", (e, t) => {
  Sh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => ou(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function sy(e, t) {
  return new ku({
    type: "nonoptional",
    innerType: e,
    ...j(t)
  });
}
const ly = /* @__PURE__ */ z("ZodCatch", (e, t) => {
  Ih.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => uu(e, n, r, i), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function uy(e, t) {
  return new ly({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : ud(t)
  });
}
const cy = /* @__PURE__ */ z("ZodPipe", (e, t) => {
  Eh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => cu(e, n, r, i), e.in = t.in, e.out = t.out;
});
function $a(e, t) {
  return new cy({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const fy = /* @__PURE__ */ z("ZodReadonly", (e, t) => {
  Ch.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => fu(e, n, r, i), e.unwrap = () => e._zod.def.innerType;
});
function dy(e) {
  return new fy({
    type: "readonly",
    innerType: e
  });
}
const py = /* @__PURE__ */ z("ZodLazy", (e, t) => {
  Ah.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => du(e, n, r, i), e.unwrap = () => e._zod.def.getter();
});
function hy(e) {
  return new py({
    type: "lazy",
    getter: e
  });
}
const ho = /* @__PURE__ */ z("ZodCustom", (e, t) => {
  zh.init(e, t), pe.init(e, t), e._zod.processJSONSchema = (n, r, i) => Gl(e, n, r, i);
});
function ir(e, t) {
  return /* @__PURE__ */ Pm(ho, e ?? (() => !0), t);
}
function my(e, t = {}) {
  return /* @__PURE__ */ Mm(ho, e, t);
}
function gy(e, t) {
  return /* @__PURE__ */ Rm(e, t);
}
const yy = /* @__PURE__ */ z("ZodInstanceOf", (e, t) => {
  ho.init(e, t);
}, {
  properties(e, t) {
    return this.check(/* @__PURE__ */ Im(e, t));
  }
});
function wu(e, t = {}) {
  const n = new yy({
    type: "custom",
    check: "custom",
    fn: (r) => r instanceof e,
    abort: !0,
    ...j(t)
  });
  return n._zod.bag.Class = e, n._zod.check = (r) => {
    r.value instanceof e || r.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: r.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
var K;
(function(e) {
  e.ZodString = "ZodString", e.ZodNumber = "ZodNumber", e.ZodNaN = "ZodNaN", e.ZodBigInt = "ZodBigInt", e.ZodBoolean = "ZodBoolean", e.ZodDate = "ZodDate", e.ZodSymbol = "ZodSymbol", e.ZodUndefined = "ZodUndefined", e.ZodNull = "ZodNull", e.ZodAny = "ZodAny", e.ZodUnknown = "ZodUnknown", e.ZodNever = "ZodNever", e.ZodVoid = "ZodVoid", e.ZodArray = "ZodArray", e.ZodObject = "ZodObject", e.ZodUnion = "ZodUnion", e.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", e.ZodIntersection = "ZodIntersection", e.ZodTuple = "ZodTuple", e.ZodRecord = "ZodRecord", e.ZodMap = "ZodMap", e.ZodSet = "ZodSet", e.ZodFunction = "ZodFunction", e.ZodLazy = "ZodLazy", e.ZodLiteral = "ZodLiteral", e.ZodEnum = "ZodEnum", e.ZodEffects = "ZodEffects", e.ZodNativeEnum = "ZodNativeEnum", e.ZodOptional = "ZodOptional", e.ZodNullable = "ZodNullable", e.ZodDefault = "ZodDefault", e.ZodCatch = "ZodCatch", e.ZodPromise = "ZodPromise", e.ZodBranded = "ZodBranded", e.ZodPipeline = "ZodPipeline", e.ZodReadonly = "ZodReadonly";
})(K || (K = {}));
class Kr extends Error {
  constructor(t, n) {
    super(t), this.name = "ParseError", this.type = n.type, this.field = n.field, this.value = n.value, this.line = n.line;
  }
}
const Na = 10, by = 13, Tt = 32;
function Yr(e) {
}
function vy(e) {
  if (typeof e == "function")
    throw new TypeError(
      "`config` must be an object, got a function instead. Did you mean `createParser({onEvent: fn})`?"
    );
  const { onEvent: t = Yr, onError: n = Yr, onRetry: r = Yr, onComment: i, maxBufferSize: o } = e, a = [];
  let s = 0, u = !0, c, l = "", f = 0, d, p = !1;
  function h(I) {
    if (p)
      throw new Error(
        "Cannot feed parser: it was terminated after exceeding the configured max buffer size. Call `reset()` to resume parsing."
      );
    if (u && (u = !1, I.charCodeAt(0) === 239 && I.charCodeAt(1) === 187 && I.charCodeAt(2) === 191 && (I = I.slice(3))), a.length === 0) {
      const R = k(I);
      R !== "" && (a.push(R), s = R.length), m();
      return;
    }
    if (I.indexOf(`
`) === -1 && I.indexOf("\r") === -1) {
      a.push(I), s += I.length, m();
      return;
    }
    a.push(I);
    const y = a.join("");
    a.length = 0, s = 0;
    const E = k(y);
    E !== "" && (a.push(E), s = E.length), m();
  }
  function m() {
    o !== void 0 && (s + l.length <= o || (p = !0, a.length = 0, s = 0, c = void 0, l = "", f = 0, d = void 0, n(
      new Kr(`Buffered data exceeded max buffer size of ${o} characters`, {
        type: "max-buffer-size-exceeded"
      })
    )));
  }
  function k(I) {
    let y = 0;
    if (I.indexOf("\r") === -1) {
      let E = I.indexOf(`
`, y);
      for (; E !== -1; ) {
        if (y === E) {
          f > 0 && t({ id: c, event: d, data: l }), c = void 0, l = "", f = 0, d = void 0, y = E + 1, E = I.indexOf(`
`, y);
          continue;
        }
        const R = I.charCodeAt(y);
        if (Da(I, y, R)) {
          const F = I.charCodeAt(y + 5) === Tt ? y + 6 : y + 5, S = I.slice(F, E);
          if (f === 0 && I.charCodeAt(E + 1) === Na) {
            t({ id: c, event: d, data: S }), c = void 0, l = "", d = void 0, y = E + 2, E = I.indexOf(`
`, y);
            continue;
          }
          l = f === 0 ? S : `${l}
${S}`, f++;
        } else La(I, y, R) ? d = I.slice(
          I.charCodeAt(y + 6) === Tt ? y + 7 : y + 6,
          E
        ) || void 0 : g(I, y, E);
        y = E + 1, E = I.indexOf(`
`, y);
      }
      return I.slice(y);
    }
    for (; y < I.length; ) {
      const E = I.indexOf("\r", y), R = I.indexOf(`
`, y);
      let F = -1;
      if (E !== -1 && R !== -1 ? F = E < R ? E : R : E !== -1 ? E === I.length - 1 ? F = -1 : F = E : R !== -1 && (F = R), F === -1)
        break;
      g(I, y, F), y = F + 1, I.charCodeAt(y - 1) === by && I.charCodeAt(y) === Na && y++;
    }
    return I.slice(y);
  }
  function g(I, y, E) {
    if (y === E) {
      w();
      return;
    }
    const R = I.charCodeAt(y);
    if (Da(I, y, R)) {
      const Z = I.charCodeAt(y + 5) === Tt ? y + 6 : y + 5, B = I.slice(Z, E);
      l = f === 0 ? B : `${l}
${B}`, f++;
      return;
    }
    if (La(I, y, R)) {
      d = I.slice(I.charCodeAt(y + 6) === Tt ? y + 7 : y + 6, E) || void 0;
      return;
    }
    if (R === 105 && I.charCodeAt(y + 1) === 100 && I.charCodeAt(y + 2) === 58) {
      const Z = I.slice(I.charCodeAt(y + 3) === Tt ? y + 4 : y + 3, E);
      Z.includes("\0") || (c = Z);
      return;
    }
    if (R === 58) {
      if (i) {
        const Z = I.slice(y, E);
        i(Z.slice(I.charCodeAt(y + 1) === Tt ? 2 : 1));
      }
      return;
    }
    const F = I.slice(y, E), S = F.indexOf(":");
    if (S === -1) {
      _(F, "", F);
      return;
    }
    const M = F.slice(0, S), L = F.charCodeAt(S + 1) === Tt ? 2 : 1, x = F.slice(S + L);
    _(M, x, F);
  }
  function _(I, y, E) {
    switch (I) {
      case "event":
        d = y || void 0;
        break;
      case "data":
        l = f === 0 ? y : `${l}
${y}`, f++;
        break;
      case "id":
        y.includes("\0") || (c = y);
        break;
      case "retry":
        /^\d+$/.test(y) ? r(parseInt(y, 10)) : n(
          new Kr(`Invalid \`retry\` value: "${y}"`, {
            type: "invalid-retry",
            value: y,
            line: E
          })
        );
        break;
      default:
        n(
          new Kr(
            `Unknown field "${I.length > 20 ? `${I.slice(0, 20)}…` : I}"`,
            { type: "unknown-field", field: I, value: y, line: E }
          )
        );
        break;
    }
  }
  function w() {
    f > 0 && t({
      id: c,
      event: d,
      data: l
    }), c = void 0, l = "", f = 0, d = void 0;
  }
  function C(I = {}) {
    if (I.consume && a.length > 0) {
      const y = a.join("");
      g(y, 0, y.length);
    }
    u = !0, c = void 0, l = "", f = 0, d = void 0, a.length = 0, s = 0, p = !1;
  }
  return { feed: h, reset: C };
}
function Da(e, t, n) {
  return n === 100 && e.charCodeAt(t + 1) === 97 && e.charCodeAt(t + 2) === 116 && e.charCodeAt(t + 3) === 97 && e.charCodeAt(t + 4) === 58;
}
function La(e, t, n) {
  return n === 101 && e.charCodeAt(t + 1) === 118 && e.charCodeAt(t + 2) === 101 && e.charCodeAt(t + 3) === 110 && e.charCodeAt(t + 4) === 116 && e.charCodeAt(t + 5) === 58;
}
class ky extends TransformStream {
  constructor({ onError: t, onRetry: n, onComment: r, maxBufferSize: i } = {}) {
    let o;
    super({
      start(a) {
        o = vy({
          onEvent: (s) => {
            a.enqueue(s);
          },
          onError(s) {
            typeof t == "function" && t(s), (t === "terminate" || s.type === "max-buffer-size-exceeded") && a.error(s);
          },
          onRetry: n,
          onComment: r,
          maxBufferSize: i
        });
      },
      transform(a) {
        o.feed(a);
      }
    });
  }
}
var wy = Object.getOwnPropertyDescriptor(
  Object.getPrototypeOf(Uint8Array.prototype),
  Symbol.toStringTag
).get, xy = Object.getOwnPropertyDescriptor(
  ArrayBuffer.prototype,
  "byteLength"
).get;
function _y(e) {
  return ArrayBuffer.isView(e) && wy.call(e) === "Uint8Array";
}
function Sy(e) {
  if (typeof e != "object" || e === null || !("byteLength" in e))
    return !1;
  try {
    return xy.call(e), !0;
  } catch {
    return !1;
  }
}
var Ln = ({
  prefix: e,
  size: t = 16,
  alphabet: n = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
  separator: r = "-"
} = {}) => {
  const i = () => {
    const o = n.length, a = new Array(t);
    for (let s = 0; s < t; s++)
      a[s] = n[Math.random() * o | 0];
    return a.join("");
  };
  if (e == null)
    return i;
  if (n.includes(r))
    throw new Rf({
      argument: "separator",
      message: `The separator "${r}" must not be part of the alphabet "${n}".`
    });
  return () => `${e}${r}${i()}`;
}, Iy = Ln();
function Ut(e) {
  if (e == null)
    return {};
  const t = {};
  if (e instanceof Headers)
    e.forEach((n, r) => {
      t[r.toLowerCase()] = n;
    });
  else {
    Array.isArray(e) || (e = Object.entries(e));
    for (const [n, r] of e)
      r != null && (t[n.toLowerCase()] = r);
  }
  return t;
}
var Ey = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/, Cy = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
function Fa(e) {
  const t = JSON.parse(e);
  return t === null || typeof t != "object" || Ey.test(e) === !1 && Cy.test(e) === !1 ? t : Ay(t);
}
function Ay(e) {
  let t = [e];
  for (; t.length; ) {
    const n = t;
    t = [];
    for (const r of n) {
      if (Object.prototype.hasOwnProperty.call(r, "__proto__"))
        throw new SyntaxError("Object contains forbidden prototype property");
      if (Object.prototype.hasOwnProperty.call(r, "constructor") && r.constructor !== null && typeof r.constructor == "object" && Object.prototype.hasOwnProperty.call(r.constructor, "prototype"))
        throw new SyntaxError("Object contains forbidden prototype property");
      for (const i in r) {
        const o = r[i];
        o && typeof o == "object" && t.push(o);
      }
    }
  }
  return e;
}
function zy(e) {
  const { stackTraceLimit: t } = Error;
  try {
    Error.stackTraceLimit = 0;
  } catch {
    return Fa(e);
  }
  try {
    return Fa(e);
  } finally {
    Error.stackTraceLimit = t;
  }
}
function mo(e) {
  if (e.type === "object" || Array.isArray(e.type) && e.type.includes("object")) {
    const { additionalProperties: n } = e;
    e.additionalProperties = n != null && typeof n != "boolean" ? gt(n) : !1;
    const { properties: r } = e;
    if (r != null)
      for (const i of Object.keys(r))
        r[i] = gt(r[i]);
  }
  e.items != null && (e.items = Array.isArray(e.items) ? e.items.map(gt) : gt(e.items)), e.anyOf != null && (e.anyOf = e.anyOf.map(gt)), e.allOf != null && (e.allOf = e.allOf.map(gt)), e.oneOf != null && (e.oneOf = e.oneOf.map(gt));
  const { definitions: t } = e;
  if (t != null)
    for (const n of Object.keys(t))
      t[n] = gt(t[n]);
  return e;
}
function gt(e) {
  return typeof e == "boolean" ? e : mo(e);
}
var Ty = /* @__PURE__ */ Symbol(
  "Let zodToJsonSchema decide on which parser to use"
), ja = {
  name: void 0,
  $refStrategy: "root",
  basePath: ["#"],
  effectStrategy: "input",
  pipeStrategy: "all",
  dateStrategy: "format:date-time",
  mapStrategy: "entries",
  removeAdditionalStrategy: "passthrough",
  allowedAdditionalProperties: !0,
  rejectedAdditionalProperties: !1,
  definitionPath: "definitions",
  strictUnions: !1,
  definitions: {},
  errorMessages: !1,
  patternStrategy: "escape",
  applyRegexFlags: !1,
  emailStrategy: "format:email",
  base64Strategy: "contentEncoding:base64",
  nameStrategy: "ref"
}, Oy = (e) => typeof e == "string" ? {
  ...ja,
  name: e
} : {
  ...ja,
  ...e
};
function je() {
  return {};
}
function Py(e, t) {
  var n, r, i;
  const o = {
    type: "array"
  };
  return (n = e.type) != null && n._def && ((i = (r = e.type) == null ? void 0 : r._def) == null ? void 0 : i.typeName) !== K.ZodAny && (o.items = re(e.type._def, {
    ...t,
    currentPath: [...t.currentPath, "items"]
  })), e.minLength && (o.minItems = e.minLength.value), e.maxLength && (o.maxItems = e.maxLength.value), e.exactLength && (o.minItems = e.exactLength.value, o.maxItems = e.exactLength.value), o;
}
function My(e) {
  const t = {
    type: "integer",
    format: "int64"
  };
  if (!e.checks) return t;
  for (const n of e.checks)
    switch (n.kind) {
      case "min":
        n.inclusive ? t.minimum = n.value : t.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? t.maximum = n.value : t.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        t.multipleOf = n.value;
        break;
    }
  return t;
}
function Ry() {
  return { type: "boolean" };
}
function xu(e, t) {
  return re(e.type._def, t);
}
var $y = (e, t) => re(e.innerType._def, t);
function _u(e, t, n) {
  const r = n ?? t.dateStrategy;
  if (Array.isArray(r))
    return {
      anyOf: r.map((i, o) => _u(e, t, i))
    };
  switch (r) {
    case "string":
    case "format:date-time":
      return {
        type: "string",
        format: "date-time"
      };
    case "format:date":
      return {
        type: "string",
        format: "date"
      };
    case "integer":
      return Ny(e);
  }
}
var Ny = (e) => {
  const t = {
    type: "integer",
    format: "unix-time"
  };
  for (const n of e.checks)
    switch (n.kind) {
      case "min":
        t.minimum = n.value;
        break;
      case "max":
        t.maximum = n.value;
        break;
    }
  return t;
};
function Dy(e, t) {
  return {
    ...re(e.innerType._def, t),
    default: e.defaultValue()
  };
}
function Ly(e, t) {
  return t.effectStrategy === "input" ? re(e.schema._def, t) : je();
}
function Fy(e) {
  return {
    type: "string",
    enum: Array.from(e.values)
  };
}
var jy = (e) => "type" in e && e.type === "string" ? !1 : "allOf" in e;
function Zy(e, t) {
  const n = [
    re(e.left._def, {
      ...t,
      currentPath: [...t.currentPath, "allOf", "0"]
    }),
    re(e.right._def, {
      ...t,
      currentPath: [...t.currentPath, "allOf", "1"]
    })
  ].filter((i) => !!i), r = [];
  return n.forEach((i) => {
    if (jy(i))
      r.push(...i.allOf);
    else {
      let o = i;
      if ("additionalProperties" in i && i.additionalProperties === !1) {
        const { additionalProperties: a, ...s } = i;
        o = s;
      }
      r.push(o);
    }
  }), r.length ? { allOf: r } : void 0;
}
function By(e) {
  const t = typeof e.value;
  return t !== "bigint" && t !== "number" && t !== "boolean" && t !== "string" ? {
    type: Array.isArray(e.value) ? "array" : "object"
  } : {
    type: t === "bigint" ? "integer" : t,
    const: e.value
  };
}
var Gr = void 0, Ye = {
  /**
   * `c` was changed to `[cC]` to replicate /i flag
   */
  cuid: /^[cC][^\s-]{8,}$/,
  cuid2: /^[0-9a-z]+$/,
  ulid: /^[0-9A-HJKMNP-TV-Z]{26}$/,
  /**
   * `a-z` was added to replicate /i flag
   */
  email: /^(?!\.)(?!.*\.\.)([a-zA-Z0-9_'+\-.]*)[a-zA-Z0-9_+-]@([a-zA-Z0-9][a-zA-Z0-9-]*\.)+[a-zA-Z]{2,}$/,
  /**
   * Constructed a valid Unicode RegExp
   *
   * Lazily instantiate since this type of regex isn't supported
   * in all envs (e.g. React Native).
   *
   * See:
   * https://github.com/colinhacks/zod/issues/2433
   * Fix in Zod:
   * https://github.com/colinhacks/zod/commit/9340fd51e48576a75adc919bff65dbc4a5d4c99b
   */
  emoji: () => (Gr === void 0 && (Gr = RegExp(
    "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$",
    "u"
  )), Gr),
  /**
   * Unused
   */
  uuid: /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/,
  /**
   * Unused
   */
  ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
  ipv4Cidr: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,
  /**
   * Unused
   */
  ipv6: /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,
  ipv6Cidr: /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
  base64: /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,
  base64url: /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,
  nanoid: /^[a-zA-Z0-9_-]{21}$/,
  jwt: /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/
};
function Su(e, t) {
  const n = {
    type: "string"
  };
  if (e.checks)
    for (const r of e.checks)
      switch (r.kind) {
        case "min":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value;
          break;
        case "max":
          n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "email":
          switch (t.emailStrategy) {
            case "format:email":
              Ge(n, "email", r.message, t);
              break;
            case "format:idn-email":
              Ge(n, "idn-email", r.message, t);
              break;
            case "pattern:zod":
              Ie(n, Ye.email, r.message, t);
              break;
          }
          break;
        case "url":
          Ge(n, "uri", r.message, t);
          break;
        case "uuid":
          Ge(n, "uuid", r.message, t);
          break;
        case "regex":
          Ie(n, r.regex, r.message, t);
          break;
        case "cuid":
          Ie(n, Ye.cuid, r.message, t);
          break;
        case "cuid2":
          Ie(n, Ye.cuid2, r.message, t);
          break;
        case "startsWith":
          Ie(
            n,
            RegExp(`^${Xr(r.value, t)}`),
            r.message,
            t
          );
          break;
        case "endsWith":
          Ie(
            n,
            RegExp(`${Xr(r.value, t)}$`),
            r.message,
            t
          );
          break;
        case "datetime":
          Ge(n, "date-time", r.message, t);
          break;
        case "date":
          Ge(n, "date", r.message, t);
          break;
        case "time":
          Ge(n, "time", r.message, t);
          break;
        case "duration":
          Ge(n, "duration", r.message, t);
          break;
        case "length":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value, n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "includes": {
          Ie(
            n,
            RegExp(Xr(r.value, t)),
            r.message,
            t
          );
          break;
        }
        case "ip": {
          r.version !== "v6" && Ge(n, "ipv4", r.message, t), r.version !== "v4" && Ge(n, "ipv6", r.message, t);
          break;
        }
        case "base64url":
          Ie(n, Ye.base64url, r.message, t);
          break;
        case "jwt":
          Ie(n, Ye.jwt, r.message, t);
          break;
        case "cidr": {
          r.version !== "v6" && Ie(n, Ye.ipv4Cidr, r.message, t), r.version !== "v4" && Ie(n, Ye.ipv6Cidr, r.message, t);
          break;
        }
        case "emoji":
          Ie(n, Ye.emoji(), r.message, t);
          break;
        case "ulid": {
          Ie(n, Ye.ulid, r.message, t);
          break;
        }
        case "base64": {
          switch (t.base64Strategy) {
            case "format:binary": {
              Ge(n, "binary", r.message, t);
              break;
            }
            case "contentEncoding:base64": {
              n.contentEncoding = "base64";
              break;
            }
            case "pattern:zod": {
              Ie(n, Ye.base64, r.message, t);
              break;
            }
          }
          break;
        }
        case "nanoid":
          Ie(n, Ye.nanoid, r.message, t);
      }
  return n;
}
function Xr(e, t) {
  return t.patternStrategy === "escape" ? Vy(e) : e;
}
var Uy = new Set(
  "ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789"
);
function Vy(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    Uy.has(e[n]) || (t += "\\"), t += e[n];
  return t;
}
function Ge(e, t, n, r) {
  var i;
  e.format || (i = e.anyOf) != null && i.some((o) => o.format) ? (e.anyOf || (e.anyOf = []), e.format && (e.anyOf.push({
    format: e.format
  }), delete e.format), e.anyOf.push({
    format: t,
    ...n && r.errorMessages && { errorMessage: { format: n } }
  })) : e.format = t;
}
function Ie(e, t, n, r) {
  var i;
  e.pattern || (i = e.allOf) != null && i.some((o) => o.pattern) ? (e.allOf || (e.allOf = []), e.pattern && (e.allOf.push({
    pattern: e.pattern
  }), delete e.pattern), e.allOf.push({
    pattern: Za(t, r),
    ...n && r.errorMessages && { errorMessage: { pattern: n } }
  })) : e.pattern = Za(t, r);
}
function Za(e, t) {
  var n;
  if (!t.applyRegexFlags || !e.flags)
    return e.source;
  const r = {
    i: e.flags.includes("i"),
    // Case-insensitive
    m: e.flags.includes("m"),
    // `^` and `$` matches adjacent to newline characters
    s: e.flags.includes("s")
    // `.` matches newlines
  }, i = r.i ? e.source.toLowerCase() : e.source;
  let o = "", a = !1, s = !1, u = !1;
  for (let c = 0; c < i.length; c++) {
    if (a) {
      o += i[c], a = !1;
      continue;
    }
    if (r.i) {
      if (s) {
        if (i[c].match(/[a-z]/)) {
          u ? (o += i[c], o += `${i[c - 2]}-${i[c]}`.toUpperCase(), u = !1) : i[c + 1] === "-" && ((n = i[c + 2]) != null && n.match(/[a-z]/)) ? (o += i[c], u = !0) : o += `${i[c]}${i[c].toUpperCase()}`;
          continue;
        }
      } else if (i[c].match(/[a-z]/)) {
        o += `[${i[c]}${i[c].toUpperCase()}]`;
        continue;
      }
    }
    if (r.m) {
      if (i[c] === "^") {
        o += `(^|(?<=[\r
]))`;
        continue;
      } else if (i[c] === "$") {
        o += `($|(?=[\r
]))`;
        continue;
      }
    }
    if (r.s && i[c] === ".") {
      o += s ? `${i[c]}\r
` : `[${i[c]}\r
]`;
      continue;
    }
    o += i[c], i[c] === "\\" ? a = !0 : s && i[c] === "]" ? s = !1 : !s && i[c] === "[" && (s = !0);
  }
  try {
    new RegExp(o);
  } catch {
    return console.warn(
      `Could not convert regex pattern at ${t.currentPath.join(
        "/"
      )} to a flag-independent form! Falling back to the flag-ignorant source`
    ), e.source;
  }
  return o;
}
function Iu(e, t) {
  var n, r, i, o, a, s;
  const u = {
    type: "object",
    additionalProperties: (n = re(e.valueType._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalProperties"]
    })) != null ? n : t.allowedAdditionalProperties
  };
  if (((r = e.keyType) == null ? void 0 : r._def.typeName) === K.ZodString && ((i = e.keyType._def.checks) != null && i.length)) {
    const { type: c, ...l } = Su(e.keyType._def, t);
    return {
      ...u,
      propertyNames: l
    };
  } else {
    if (((o = e.keyType) == null ? void 0 : o._def.typeName) === K.ZodEnum)
      return {
        ...u,
        propertyNames: {
          enum: e.keyType._def.values
        }
      };
    if (((a = e.keyType) == null ? void 0 : a._def.typeName) === K.ZodBranded && e.keyType._def.type._def.typeName === K.ZodString && ((s = e.keyType._def.type._def.checks) != null && s.length)) {
      const { type: c, ...l } = xu(
        e.keyType._def,
        t
      );
      return {
        ...u,
        propertyNames: l
      };
    }
  }
  return u;
}
function qy(e, t) {
  if (t.mapStrategy === "record")
    return Iu(e, t);
  const n = re(e.keyType._def, {
    ...t,
    currentPath: [...t.currentPath, "items", "items", "0"]
  }) || je(), r = re(e.valueType._def, {
    ...t,
    currentPath: [...t.currentPath, "items", "items", "1"]
  }) || je();
  return {
    type: "array",
    maxItems: 125,
    items: {
      type: "array",
      items: [n, r],
      minItems: 2,
      maxItems: 2
    }
  };
}
function Jy(e) {
  const t = e.values, r = Object.keys(e.values).filter((o) => typeof t[t[o]] != "number").map((o) => t[o]), i = Array.from(
    new Set(r.map((o) => typeof o))
  );
  return {
    type: i.length === 1 ? i[0] === "string" ? "string" : "number" : ["string", "number"],
    enum: r
  };
}
function Wy() {
  return { not: je() };
}
function Hy() {
  return {
    type: "null"
  };
}
var Ti = {
  ZodString: "string",
  ZodNumber: "number",
  ZodBigInt: "integer",
  ZodBoolean: "boolean",
  ZodNull: "null"
};
function Ky(e, t) {
  const n = e.options instanceof Map ? Array.from(e.options.values()) : e.options;
  if (n.every(
    (r) => r._def.typeName in Ti && (!r._def.checks || !r._def.checks.length)
  )) {
    const r = n.reduce((i, o) => {
      const a = Ti[o._def.typeName];
      return a && !i.includes(a) ? [...i, a] : i;
    }, []);
    return {
      type: r.length > 1 ? r : r[0]
    };
  } else if (n.every((r) => r._def.typeName === "ZodLiteral" && !r.description)) {
    const r = n.reduce(
      (i, o) => {
        const a = typeof o._def.value;
        switch (a) {
          case "string":
          case "number":
          case "boolean":
            return [...i, a];
          case "bigint":
            return [...i, "integer"];
          case "object":
            if (o._def.value === null) return [...i, "null"];
          case "symbol":
          case "undefined":
          case "function":
          default:
            return i;
        }
      },
      []
    );
    if (r.length === n.length) {
      const i = r.filter((o, a, s) => s.indexOf(o) === a);
      return {
        type: i.length > 1 ? i : i[0],
        enum: n.reduce(
          (o, a) => o.includes(a._def.value) ? o : [...o, a._def.value],
          []
        )
      };
    }
  } else if (n.every((r) => r._def.typeName === "ZodEnum"))
    return {
      type: "string",
      enum: n.reduce(
        (r, i) => [
          ...r,
          ...i._def.values.filter((o) => !r.includes(o))
        ],
        []
      )
    };
  return Yy(e, t);
}
var Yy = (e, t) => {
  const n = (e.options instanceof Map ? Array.from(e.options.values()) : e.options).map(
    (r, i) => re(r._def, {
      ...t,
      currentPath: [...t.currentPath, "anyOf", `${i}`]
    })
  ).filter(
    (r) => !!r && (!t.strictUnions || typeof r == "object" && Object.keys(r).length > 0)
  );
  return n.length ? { anyOf: n } : void 0;
};
function Gy(e, t) {
  if (["ZodString", "ZodNumber", "ZodBigInt", "ZodBoolean", "ZodNull"].includes(
    e.innerType._def.typeName
  ) && (!e.innerType._def.checks || !e.innerType._def.checks.length))
    return {
      type: [
        Ti[e.innerType._def.typeName],
        "null"
      ]
    };
  const n = re(e.innerType._def, {
    ...t,
    currentPath: [...t.currentPath, "anyOf", "0"]
  });
  return n && { anyOf: [n, { type: "null" }] };
}
function Xy(e) {
  const t = {
    type: "number"
  };
  if (!e.checks) return t;
  for (const n of e.checks)
    switch (n.kind) {
      case "int":
        t.type = "integer";
        break;
      case "min":
        n.inclusive ? t.minimum = n.value : t.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? t.maximum = n.value : t.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        t.multipleOf = n.value;
        break;
    }
  return t;
}
function Qy(e, t) {
  const n = {
    type: "object",
    properties: {}
  }, r = [], i = e.shape();
  for (const a in i) {
    let s = i[a];
    if (s === void 0 || s._def === void 0)
      continue;
    const u = tb(s), c = re(s._def, {
      ...t,
      currentPath: [...t.currentPath, "properties", a],
      propertyPath: [...t.currentPath, "properties", a]
    });
    c !== void 0 && (n.properties[a] = c, u || r.push(a));
  }
  r.length && (n.required = r);
  const o = eb(e, t);
  return o !== void 0 && (n.additionalProperties = o), n;
}
function eb(e, t) {
  if (e.catchall._def.typeName !== "ZodNever")
    return re(e.catchall._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalProperties"]
    });
  switch (e.unknownKeys) {
    case "passthrough":
      return t.allowedAdditionalProperties;
    case "strict":
      return t.rejectedAdditionalProperties;
    case "strip":
      return t.removeAdditionalStrategy === "strict" ? t.allowedAdditionalProperties : t.rejectedAdditionalProperties;
  }
}
function tb(e) {
  try {
    return e.isOptional();
  } catch {
    return !0;
  }
}
var nb = (e, t) => {
  var n;
  if (t.currentPath.toString() === ((n = t.propertyPath) == null ? void 0 : n.toString()))
    return re(e.innerType._def, t);
  const r = re(e.innerType._def, {
    ...t,
    currentPath: [...t.currentPath, "anyOf", "1"]
  });
  return r ? { anyOf: [{ not: je() }, r] } : je();
}, rb = (e, t) => {
  if (t.pipeStrategy === "input")
    return re(e.in._def, t);
  if (t.pipeStrategy === "output")
    return re(e.out._def, t);
  const n = re(e.in._def, {
    ...t,
    currentPath: [...t.currentPath, "allOf", "0"]
  }), r = re(e.out._def, {
    ...t,
    currentPath: [...t.currentPath, "allOf", n ? "1" : "0"]
  });
  return {
    allOf: [n, r].filter((i) => i !== void 0)
  };
};
function ib(e, t) {
  return re(e.type._def, t);
}
function ob(e, t) {
  const r = {
    type: "array",
    uniqueItems: !0,
    items: re(e.valueType._def, {
      ...t,
      currentPath: [...t.currentPath, "items"]
    })
  };
  return e.minSize && (r.minItems = e.minSize.value), e.maxSize && (r.maxItems = e.maxSize.value), r;
}
function ab(e, t) {
  return e.rest ? {
    type: "array",
    minItems: e.items.length,
    items: e.items.map(
      (n, r) => re(n._def, {
        ...t,
        currentPath: [...t.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    ),
    additionalItems: re(e.rest._def, {
      ...t,
      currentPath: [...t.currentPath, "additionalItems"]
    })
  } : {
    type: "array",
    minItems: e.items.length,
    maxItems: e.items.length,
    items: e.items.map(
      (n, r) => re(n._def, {
        ...t,
        currentPath: [...t.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    )
  };
}
function sb() {
  return {
    not: je()
  };
}
function lb() {
  return je();
}
var ub = (e, t) => re(e.innerType._def, t), cb = (e, t, n) => {
  switch (t) {
    case K.ZodString:
      return Su(e, n);
    case K.ZodNumber:
      return Xy(e);
    case K.ZodObject:
      return Qy(e, n);
    case K.ZodBigInt:
      return My(e);
    case K.ZodBoolean:
      return Ry();
    case K.ZodDate:
      return _u(e, n);
    case K.ZodUndefined:
      return sb();
    case K.ZodNull:
      return Hy();
    case K.ZodArray:
      return Py(e, n);
    case K.ZodUnion:
    case K.ZodDiscriminatedUnion:
      return Ky(e, n);
    case K.ZodIntersection:
      return Zy(e, n);
    case K.ZodTuple:
      return ab(e, n);
    case K.ZodRecord:
      return Iu(e, n);
    case K.ZodLiteral:
      return By(e);
    case K.ZodEnum:
      return Fy(e);
    case K.ZodNativeEnum:
      return Jy(e);
    case K.ZodNullable:
      return Gy(e, n);
    case K.ZodOptional:
      return nb(e, n);
    case K.ZodMap:
      return qy(e, n);
    case K.ZodSet:
      return ob(e, n);
    case K.ZodLazy:
      return () => e.getter()._def;
    case K.ZodPromise:
      return ib(e, n);
    case K.ZodNaN:
    case K.ZodNever:
      return Wy();
    case K.ZodEffects:
      return Ly(e, n);
    case K.ZodAny:
      return je();
    case K.ZodUnknown:
      return lb();
    case K.ZodDefault:
      return Dy(e, n);
    case K.ZodBranded:
      return xu(e, n);
    case K.ZodReadonly:
      return ub(e, n);
    case K.ZodCatch:
      return $y(e, n);
    case K.ZodPipeline:
      return rb(e, n);
    case K.ZodFunction:
    case K.ZodVoid:
    case K.ZodSymbol:
      return;
    default:
      return /* @__PURE__ */ ((r) => {
      })();
  }
}, fb = (e, t) => {
  let n = 0;
  for (; n < e.length && n < t.length && e[n] === t[n]; n++)
    ;
  return [(e.length - n).toString(), ...t.slice(n)].join("/");
};
function re(e, t, n = !1) {
  var r;
  const i = t.seen.get(e);
  if (t.override) {
    const u = (r = t.override) == null ? void 0 : r.call(
      t,
      e,
      t,
      i,
      n
    );
    if (u !== Ty)
      return u;
  }
  if (i && !n) {
    const u = db(i, t);
    if (u !== void 0)
      return u;
  }
  const o = { def: e, path: t.currentPath, jsonSchema: void 0 };
  t.seen.set(e, o);
  const a = cb(e, e.typeName, t), s = typeof a == "function" ? re(a(), t) : a;
  if (s && pb(e, t, s), t.postProcess) {
    const u = t.postProcess(s, e, t);
    return o.jsonSchema = s, u;
  }
  return o.jsonSchema = s, s;
}
var db = (e, t) => {
  switch (t.$refStrategy) {
    case "root":
      return { $ref: e.path.join("/") };
    case "relative":
      return { $ref: fb(t.currentPath, e.path) };
    case "none":
    case "seen":
      return e.path.length < t.currentPath.length && e.path.every((n, r) => t.currentPath[r] === n) ? (console.warn(
        `Recursive reference detected at ${t.currentPath.join(
          "/"
        )}! Defaulting to any`
      ), je()) : t.$refStrategy === "seen" ? je() : void 0;
  }
}, pb = (e, t, n) => (e.description && (n.description = e.description), n), hb = (e) => {
  const t = Oy(e), n = t.name !== void 0 ? [...t.basePath, t.definitionPath, t.name] : t.basePath;
  return {
    ...t,
    currentPath: n,
    propertyPath: void 0,
    seen: new Map(
      Object.entries(t.definitions).map(([r, i]) => [
        i._def,
        {
          def: i._def,
          path: [...t.basePath, t.definitionPath, r],
          // Resolution of references will be forced even though seen, so it's ok that the schema is undefined here for now.
          jsonSchema: void 0
        }
      ])
    )
  };
}, mb = (e, t) => {
  var n;
  const r = hb(t);
  let i = typeof t == "object" && t.definitions ? Object.entries(t.definitions).reduce(
    (c, [l, f]) => {
      var d;
      return {
        ...c,
        [l]: (d = re(
          f._def,
          {
            ...r,
            currentPath: [...r.basePath, r.definitionPath, l]
          },
          !0
        )) != null ? d : je()
      };
    },
    {}
  ) : void 0;
  const o = typeof t == "string" ? t : (t == null ? void 0 : t.nameStrategy) === "title" || t == null ? void 0 : t.name, a = (n = re(
    e._def,
    o === void 0 ? r : {
      ...r,
      currentPath: [...r.basePath, r.definitionPath, o]
    },
    !1
  )) != null ? n : je(), s = typeof t == "object" && t.name !== void 0 && t.nameStrategy === "title" ? t.name : void 0;
  s !== void 0 && (a.title = s);
  const u = o === void 0 ? i ? {
    ...a,
    [r.definitionPath]: i
  } : a : {
    $ref: [
      ...r.$refStrategy === "relative" ? [] : r.basePath,
      r.definitionPath,
      o
    ].join("/"),
    [r.definitionPath]: {
      ...i,
      [o]: a
    }
  };
  return u.$schema = "http://json-schema.org/draft-07/schema#", u;
}, Oi = /* @__PURE__ */ Symbol.for("vercel.ai.schema");
function gb(e) {
  let t;
  return () => (t == null && (t = e()), t);
}
function zr(e, {
  validate: t
} = {}) {
  return {
    [Oi]: !0,
    _type: void 0,
    // should never be used directly
    get jsonSchema() {
      return typeof e == "function" && (e = e()), e;
    },
    validate: t
  };
}
function yb(e) {
  return typeof e == "object" && e !== null && Oi in e && e[Oi] === !0 && "jsonSchema" in e && "validate" in e;
}
function go(e) {
  return e == null ? zr({
    type: "object",
    properties: {},
    additionalProperties: !1
  }) : yb(e) ? e : "~standard" in e ? e["~standard"].vendor === "zod" ? Eu(e) : bb(e) : e();
}
function bb(e) {
  return zr(
    () => {
      if (!vb(e))
        throw new Error(
          `Standard schema vendor '${e["~standard"].vendor}' does not support JSON Schema conversion.`
        );
      return mo(
        e["~standard"].jsonSchema.input({
          target: "draft-07"
        })
      );
    },
    {
      validate: async (t) => {
        const n = await e["~standard"].validate(t);
        return "value" in n ? { success: !0, value: n.value } : {
          success: !1,
          error: new Xt({
            value: t,
            cause: n.issues
          })
        };
      }
    }
  );
}
function vb(e) {
  return e["~standard"].jsonSchema != null;
}
function kb(e, t) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return zr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => mb(e, {
      $refStrategy: r ? "root" : "none"
    }),
    {
      validate: async (i) => {
        const o = await e.safeParseAsync(i);
        return o.success ? { success: !0, value: o.data } : { success: !1, error: o.error };
      }
    }
  );
}
function wb(e, t) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return zr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => mo(
      ng(e, {
        target: "draft-7",
        io: "input",
        reused: r ? "ref" : "inline"
      })
    ),
    {
      validate: async (i) => {
        const o = await pu(e, i);
        return o.success ? { success: !0, value: o.data } : { success: !1, error: o.error };
      }
    }
  );
}
function xb(e) {
  return "_zod" in e;
}
function Eu(e, t) {
  return xb(e) ? wb(e) : kb(e);
}
async function Ba({
  value: e,
  schema: t,
  context: n
}) {
  const r = await $n({ value: e, schema: t, context: n });
  if (!r.success)
    throw Xt.wrap({ value: e, cause: r.error, context: n });
  return r.value;
}
async function $n({
  value: e,
  schema: t,
  context: n
}) {
  const r = go(t);
  try {
    if (r.validate == null)
      return { success: !0, value: e, rawValue: e };
    const i = await r.validate(e);
    return i.success ? { success: !0, value: i.value, rawValue: e } : {
      success: !1,
      error: Xt.wrap({ value: e, cause: i.error, context: n }),
      rawValue: e
    };
  } catch (i) {
    return {
      success: !1,
      error: Xt.wrap({ value: e, cause: i, context: n }),
      rawValue: e
    };
  }
}
async function Lt({
  text: e,
  schema: t
}) {
  try {
    const n = zy(e);
    return t == null ? { success: !0, value: n, rawValue: n } : await $n({ value: n, schema: t });
  } catch (n) {
    return {
      success: !1,
      error: Ko.isInstance(n) ? n : new Ko({ text: e, cause: n }),
      rawValue: void 0
    };
  }
}
function _b({
  stream: e,
  schema: t
}) {
  return e.pipeThrough(new TextDecoderStream()).pipeThrough(new ky()).pipeThrough(
    new TransformStream({
      async transform({ data: n }, r) {
        n !== "[DONE]" && r.enqueue(await Lt({ text: n, schema: t }));
      }
    })
  );
}
async function wt(e) {
  return typeof e == "function" && (e = e()), e;
}
new TextDecoder();
function Cu(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Sb = Object.defineProperty, Ib = (e, t) => {
  for (var n in t)
    Sb(e, n, { get: t[n], enumerable: !0 });
}, Au = "AI_InvalidArgumentError", zu = `vercel.ai.error.${Au}`, Eb = Symbol.for(zu), Tu, Cb = class extends We {
  constructor({
    parameter: e,
    value: t,
    message: n
  }) {
    super({
      name: Au,
      message: `Invalid argument for parameter ${e}: ${n}`
    }), this[Tu] = !0, this.parameter = e, this.value = t;
  }
  static isInstance(e) {
    return We.hasMarker(e, zu);
  }
};
Tu = Eb;
var Ou = "AI_NoObjectGeneratedError", Pu = `vercel.ai.error.${Ou}`, Ab = Symbol.for(Pu), Mu, _t = class extends We {
  constructor({
    message: e = "No object generated.",
    cause: t,
    text: n,
    response: r,
    usage: i,
    finishReason: o
  }) {
    super({ name: Ou, message: e, cause: t }), this[Mu] = !0, this.text = n, this.response = r, this.usage = i, this.finishReason = o;
  }
  static isInstance(e) {
    return We.hasMarker(e, Pu);
  }
};
Mu = Ab;
var Ru = "AI_UIMessageStreamError", $u = `vercel.ai.error.${Ru}`, zb = Symbol.for($u), Nu, Vt = class extends We {
  constructor({
    chunkType: e,
    chunkId: t,
    message: n
  }) {
    super({ name: Ru, message: n }), this[Nu] = !0, this.chunkType = e, this.chunkId = t;
  }
  static isInstance(e) {
    return We.hasMarker(e, $u);
  }
};
Nu = zb;
function Du(e, t) {
  if (e === void 0 && t === void 0)
    return;
  if (e === void 0)
    return t;
  if (t === void 0)
    return e;
  const n = { ...e };
  for (const r in t)
    if (!(r === "__proto__" || r === "constructor" || r === "prototype") && Object.prototype.hasOwnProperty.call(t, r)) {
      const i = t[r];
      if (i === void 0)
        continue;
      const o = r in e ? e[r] : void 0, a = i !== null && typeof i == "object" && !Array.isArray(i) && !(i instanceof Date) && !(i instanceof RegExp), s = o != null && typeof o == "object" && !Array.isArray(o) && !(o instanceof Date) && !(o instanceof RegExp);
      a && s ? n[r] = Du(
        o,
        i
      ) : n[r] = i;
    }
  return n;
}
var Lu = Ae([
  $(),
  ir(_y, { message: "Must be a Uint8Array" }),
  ir(Sy, { message: "Must be an ArrayBuffer" }),
  ir(
    // Buffer might not be available in some environments such as CloudFlare:
    (e) => {
      var t, n;
      return (n = (t = globalThis.Buffer) == null ? void 0 : t.isBuffer(e)) != null ? n : !1;
    },
    { message: "Must be a Buffer" }
  )
]), Ft = hy(
  () => Ae([
    Ug(),
    $(),
    Fg(),
    Ce(),
    Dt($(), Ft.optional()),
    on(Ft)
  ])
), Q = Dt(
  $(),
  Dt($(), Ft.optional())
), Fu = oe({
  type: V("text"),
  text: $(),
  providerOptions: Q.optional()
}), Tb = oe({
  type: V("image"),
  image: Ae([Lu, wu(URL)]),
  mediaType: $().optional(),
  providerOptions: Q.optional()
}), ju = oe({
  type: V("file"),
  data: Ae([Lu, wu(URL)]),
  filename: $().optional(),
  mediaType: $(),
  providerOptions: Q.optional()
}), Ob = oe({
  type: V("reasoning"),
  text: $(),
  providerOptions: Q.optional()
}), Pb = oe({
  type: V("tool-call"),
  toolCallId: $(),
  toolName: $(),
  input: Re(),
  providerOptions: Q.optional(),
  providerExecuted: Ce().optional()
}), Mb = Kg(
  "type",
  [
    oe({
      type: V("text"),
      value: $(),
      providerOptions: Q.optional()
    }),
    oe({
      type: V("json"),
      value: Ft,
      providerOptions: Q.optional()
    }),
    oe({
      type: V("execution-denied"),
      reason: $().optional(),
      providerOptions: Q.optional()
    }),
    oe({
      type: V("error-text"),
      value: $(),
      providerOptions: Q.optional()
    }),
    oe({
      type: V("error-json"),
      value: Ft,
      providerOptions: Q.optional()
    }),
    oe({
      type: V("content"),
      value: on(
        Ae([
          oe({
            type: V("text"),
            text: $(),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("media"),
            data: $(),
            mediaType: $()
          }),
          oe({
            type: V("file-data"),
            data: $(),
            mediaType: $(),
            filename: $().optional(),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("file-url"),
            url: $(),
            mediaType: $().optional(),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("file-id"),
            fileId: Ae([$(), Dt($(), $())]),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("image-data"),
            data: $(),
            mediaType: $(),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("image-url"),
            url: $(),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("image-file-id"),
            fileId: Ae([$(), Dt($(), $())]),
            providerOptions: Q.optional()
          }),
          oe({
            type: V("custom"),
            providerOptions: Q.optional()
          })
        ])
      )
    })
  ]
), Zu = oe({
  type: V("tool-result"),
  toolCallId: $(),
  toolName: $(),
  output: Mb,
  providerOptions: Q.optional()
}), Rb = oe({
  type: V("tool-approval-request"),
  approvalId: $(),
  toolCallId: $(),
  signature: $().optional(),
  inputSchemaInput: Re().optional()
}), $b = oe({
  type: V("tool-approval-response"),
  approvalId: $(),
  approved: Ce(),
  reason: $().optional()
}), Nb = oe(
  {
    role: V("system"),
    content: $(),
    providerOptions: Q.optional()
  }
), Db = oe({
  role: V("user"),
  content: Ae([
    $(),
    on(Ae([Fu, Tb, ju]))
  ]),
  providerOptions: Q.optional()
}), Lb = oe({
  role: V("assistant"),
  content: Ae([
    $(),
    on(
      Ae([
        Fu,
        ju,
        Ob,
        Pb,
        Zu,
        Rb
      ])
    )
  ]),
  providerOptions: Q.optional()
}), Fb = oe({
  role: V("tool"),
  content: on(Ae([Zu, $b])),
  providerOptions: Q.optional()
});
Ae([
  Nb,
  Db,
  Lb,
  Fb
]);
new TextEncoder();
var jb = {};
Ib(jb, {
  array: () => Vb,
  choice: () => qb,
  json: () => Jb,
  object: () => Ub,
  text: () => Bb
});
function Zb(e) {
  const t = ["ROOT"];
  let n = -1, r = null, i = 0;
  function o(l) {
    return l >= "0" && l <= "9" || l >= "A" && l <= "F" || l >= "a" && l <= "f";
  }
  function a(l, f, d) {
    switch (l) {
      case '"': {
        n = f, t.pop(), t.push(d), t.push("INSIDE_STRING");
        break;
      }
      case "f":
      case "t":
      case "n": {
        n = f, r = f, t.pop(), t.push(d), t.push("INSIDE_LITERAL");
        break;
      }
      case "-": {
        t.pop(), t.push(d), t.push("INSIDE_NUMBER");
        break;
      }
      case "0":
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9": {
        n = f, t.pop(), t.push(d), t.push("INSIDE_NUMBER");
        break;
      }
      case "{": {
        n = f, t.pop(), t.push(d), t.push("INSIDE_OBJECT_START");
        break;
      }
      case "[": {
        n = f, t.pop(), t.push(d), t.push("INSIDE_ARRAY_START");
        break;
      }
    }
  }
  function s(l, f) {
    switch (l) {
      case ",": {
        t.pop(), t.push("INSIDE_OBJECT_AFTER_COMMA");
        break;
      }
      case "}": {
        n = f, t.pop();
        break;
      }
    }
  }
  function u(l, f) {
    switch (l) {
      case ",": {
        t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
        break;
      }
      case "]": {
        n = f, t.pop();
        break;
      }
    }
  }
  for (let l = 0; l < e.length; l++) {
    const f = e[l];
    switch (t[t.length - 1]) {
      case "ROOT":
        a(f, l, "FINISH");
        break;
      case "INSIDE_OBJECT_START": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_KEY");
            break;
          }
          case "}": {
            n = l, t.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_COMMA": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_KEY": {
        switch (f) {
          case '"': {
            t.pop(), t.push("INSIDE_OBJECT_AFTER_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_KEY": {
        switch (f) {
          case ":": {
            t.pop(), t.push("INSIDE_OBJECT_BEFORE_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_BEFORE_VALUE": {
        a(f, l, "INSIDE_OBJECT_AFTER_VALUE");
        break;
      }
      case "INSIDE_OBJECT_AFTER_VALUE": {
        s(f, l);
        break;
      }
      case "INSIDE_STRING": {
        switch (f) {
          case '"': {
            t.pop(), n = l;
            break;
          }
          case "\\": {
            t.push("INSIDE_STRING_ESCAPE");
            break;
          }
          default:
            n = l;
        }
        break;
      }
      case "INSIDE_ARRAY_START": {
        switch (f) {
          case "]": {
            n = l, t.pop();
            break;
          }
          default: {
            n = l, a(f, l, "INSIDE_ARRAY_AFTER_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_VALUE": {
        switch (f) {
          case ",": {
            t.pop(), t.push("INSIDE_ARRAY_AFTER_COMMA");
            break;
          }
          case "]": {
            n = l, t.pop();
            break;
          }
          default: {
            n = l;
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_COMMA": {
        a(f, l, "INSIDE_ARRAY_AFTER_VALUE");
        break;
      }
      case "INSIDE_STRING_ESCAPE": {
        t.pop(), f === "u" ? (i = 0, t.push("INSIDE_STRING_UNICODE_ESCAPE")) : n = l;
        break;
      }
      case "INSIDE_STRING_UNICODE_ESCAPE": {
        o(f) && (i++, i === 4 && (t.pop(), n = l));
        break;
      }
      case "INSIDE_NUMBER": {
        switch (f) {
          case "0":
          case "1":
          case "2":
          case "3":
          case "4":
          case "5":
          case "6":
          case "7":
          case "8":
          case "9": {
            n = l;
            break;
          }
          case "e":
          case "E":
          case "-":
          case ".":
            break;
          case ",": {
            t.pop(), t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && s(f, l);
            break;
          }
          case "}": {
            t.pop(), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && s(f, l);
            break;
          }
          case "]": {
            t.pop(), t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l);
            break;
          }
          default: {
            t.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_LITERAL": {
        const p = e.substring(r, l + 1);
        !"false".startsWith(p) && !"true".startsWith(p) && !"null".startsWith(p) ? (t.pop(), t[t.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" ? s(f, l) : t[t.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && u(f, l)) : n = l;
        break;
      }
    }
  }
  let c = e.slice(0, n + 1);
  for (let l = t.length - 1; l >= 0; l--)
    switch (t[l]) {
      case "INSIDE_STRING": {
        c += '"';
        break;
      }
      case "INSIDE_OBJECT_KEY":
      case "INSIDE_OBJECT_AFTER_KEY":
      case "INSIDE_OBJECT_AFTER_COMMA":
      case "INSIDE_OBJECT_START":
      case "INSIDE_OBJECT_BEFORE_VALUE":
      case "INSIDE_OBJECT_AFTER_VALUE": {
        c += "}";
        break;
      }
      case "INSIDE_ARRAY_START":
      case "INSIDE_ARRAY_AFTER_COMMA":
      case "INSIDE_ARRAY_AFTER_VALUE": {
        c += "]";
        break;
      }
      case "INSIDE_LITERAL": {
        const d = e.substring(r, e.length);
        "true".startsWith(d) ? c += "true".slice(d.length) : "false".startsWith(d) ? c += "false".slice(d.length) : "null".startsWith(d) && (c += "null".slice(d.length));
      }
    }
  return c;
}
async function Fn(e) {
  if (e === void 0)
    return { value: void 0, state: "undefined-input" };
  let t = await Lt({ text: e });
  return t.success ? { value: t.value, state: "successful-parse" } : (t = await Lt({ text: Zb(e) }), t.success ? { value: t.value, state: "repaired-parse" } : { value: void 0, state: "failed-parse" });
}
var Bb = () => ({
  name: "text",
  responseFormat: Promise.resolve({ type: "text" }),
  async parseCompleteOutput({ text: e }) {
    return e;
  },
  async parsePartialOutput({ text: e }) {
    return { partial: e };
  },
  createElementStreamTransform() {
  }
}), Ub = ({
  schema: e,
  name: t,
  description: n
}) => {
  const r = go(e);
  return {
    name: "object",
    responseFormat: wt(r.jsonSchema).then((i) => ({
      type: "json",
      schema: i,
      ...t != null && { name: t },
      ...n != null && { description: n }
    })),
    async parseCompleteOutput({ text: i }, o) {
      const a = await Lt({ text: i });
      if (!a.success)
        throw new _t({
          message: "No object generated: could not parse the response.",
          cause: a.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const s = await $n({
        value: a.value,
        schema: r
      });
      if (!s.success)
        throw new _t({
          message: "No object generated: response did not match schema.",
          cause: s.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      return s.value;
    },
    async parsePartialOutput({ text: i }) {
      const o = await Fn(i);
      switch (o.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse":
          return {
            // Note: currently no validation of partial results:
            partial: o.value
          };
      }
    },
    createElementStreamTransform() {
    }
  };
}, Vb = ({
  element: e,
  name: t,
  description: n
}) => {
  const r = go(e);
  return {
    name: "array",
    // JSON schema that describes an array of elements:
    responseFormat: wt(r.jsonSchema).then((i) => {
      const { $schema: o, ...a } = i;
      return {
        type: "json",
        schema: {
          $schema: "http://json-schema.org/draft-07/schema#",
          type: "object",
          properties: {
            elements: { type: "array", items: a }
          },
          required: ["elements"],
          additionalProperties: !1
        },
        ...t != null && { name: t },
        ...n != null && { description: n }
      };
    }),
    async parseCompleteOutput({ text: i }, o) {
      const a = await Lt({ text: i });
      if (!a.success)
        throw new _t({
          message: "No object generated: could not parse the response.",
          cause: a.error,
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const s = a.value;
      if (s == null || typeof s != "object" || !("elements" in s) || !Array.isArray(s.elements))
        throw new _t({
          message: "No object generated: response did not match schema.",
          cause: new Xt({
            value: s,
            cause: "response must be an object with an elements array"
          }),
          text: i,
          response: o.response,
          usage: o.usage,
          finishReason: o.finishReason
        });
      const u = [];
      for (const c of s.elements) {
        const l = await $n({
          value: c,
          schema: r
        });
        if (!l.success)
          throw new _t({
            message: "No object generated: response did not match schema.",
            cause: l.error,
            text: i,
            response: o.response,
            usage: o.usage,
            finishReason: o.finishReason
          });
        u.push(l.value);
      }
      return u;
    },
    async parsePartialOutput({ text: i }) {
      const o = await Fn(i);
      switch (o.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse": {
          const a = o.value;
          if (a == null || typeof a != "object" || !("elements" in a) || !Array.isArray(a.elements))
            return;
          const s = o.state === "repaired-parse" && a.elements.length > 0 ? a.elements.slice(0, -1) : a.elements, u = [];
          for (const c of s) {
            const l = await $n({
              value: c,
              schema: r
            });
            l.success && u.push(l.value);
          }
          return { partial: u };
        }
      }
    },
    createElementStreamTransform() {
      let i = 0;
      return new TransformStream({
        transform({ partialOutput: o }, a) {
          if (o != null)
            for (; i < o.length; i++)
              a.enqueue(o[i]);
        }
      });
    }
  };
}, qb = ({
  options: e,
  name: t,
  description: n
}) => ({
  name: "choice",
  // JSON schema that describes an enumeration:
  responseFormat: Promise.resolve({
    type: "json",
    schema: {
      $schema: "http://json-schema.org/draft-07/schema#",
      type: "object",
      properties: {
        result: { type: "string", enum: e }
      },
      required: ["result"],
      additionalProperties: !1
    },
    ...t != null && { name: t },
    ...n != null && { description: n }
  }),
  async parseCompleteOutput({ text: r }, i) {
    const o = await Lt({ text: r });
    if (!o.success)
      throw new _t({
        message: "No object generated: could not parse the response.",
        cause: o.error,
        text: r,
        response: i.response,
        usage: i.usage,
        finishReason: i.finishReason
      });
    const a = o.value;
    if (a == null || typeof a != "object" || !("result" in a) || typeof a.result != "string" || !e.includes(a.result))
      throw new _t({
        message: "No object generated: response did not match schema.",
        cause: new Xt({
          value: a,
          cause: "response must be an object that contains a choice value."
        }),
        text: r,
        response: i.response,
        usage: i.usage,
        finishReason: i.finishReason
      });
    return a.result;
  },
  async parsePartialOutput({ text: r }) {
    const i = await Fn(r);
    switch (i.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse": {
        const o = i.value;
        if (o == null || typeof o != "object" || !("result" in o) || typeof o.result != "string")
          return;
        const a = e.filter(
          (s) => s.startsWith(o.result)
        );
        return i.state === "successful-parse" ? a.includes(o.result) ? { partial: o.result } : void 0 : a.length === 1 ? { partial: a[0] } : void 0;
      }
    }
  },
  createElementStreamTransform() {
  }
}), Jb = ({
  name: e,
  description: t
} = {}) => ({
  name: "json",
  responseFormat: Promise.resolve({
    type: "json",
    ...e != null && { name: e },
    ...t != null && { description: t }
  }),
  async parseCompleteOutput({ text: n }, r) {
    const i = await Lt({ text: n });
    if (!i.success)
      throw new _t({
        message: "No object generated: could not parse the response.",
        cause: i.error,
        text: n,
        response: r.response,
        usage: r.usage,
        finishReason: r.finishReason
      });
    return i.value;
  },
  async parsePartialOutput({ text: n }) {
    const r = await Fn(n);
    switch (r.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse":
        return r.value === void 0 ? void 0 : { partial: r.value };
    }
  },
  createElementStreamTransform() {
  }
});
Ln({
  prefix: "aitxt",
  size: 24
});
(class extends TransformStream {
  constructor() {
    super({
      transform(e, t) {
        t.enqueue(`data: ${JSON.stringify(e)}

`);
      },
      flush(e) {
        e.enqueue(`data: [DONE]

`);
      }
    });
  }
});
var hn = Dt(
  $(),
  Ft.optional()
), Wb = gb(
  () => Eu(
    Ae([
      ce({
        type: V("text-start"),
        id: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("text-delta"),
        id: $(),
        delta: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("text-end"),
        id: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("error"),
        errorText: $()
      }),
      ce({
        type: V("tool-input-start"),
        toolCallId: $(),
        toolName: $(),
        inputEncoding: zi(["json", "text"]).optional(),
        providerExecuted: Ce().optional(),
        providerMetadata: Q.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        title: $().optional()
      }),
      ce({
        type: V("tool-input-delta"),
        toolCallId: $(),
        inputTextDelta: $()
      }),
      ce({
        type: V("tool-input-available"),
        toolCallId: $(),
        toolName: $(),
        input: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: Q.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        title: $().optional()
      }),
      ce({
        type: V("tool-input-error"),
        toolCallId: $(),
        toolName: $(),
        input: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: Q.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        errorText: $(),
        title: $().optional()
      }),
      ce({
        type: V("tool-approval-request"),
        approvalId: $(),
        toolCallId: $(),
        approvalDescriptor: Re().optional(),
        inputSchemaInput: Re().optional(),
        signature: $().optional()
      }),
      ce({
        type: V("tool-output-available"),
        toolCallId: $(),
        output: Re(),
        providerExecuted: Ce().optional(),
        providerMetadata: Q.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional(),
        preliminary: Ce().optional()
      }),
      ce({
        type: V("tool-output-error"),
        toolCallId: $(),
        errorText: $(),
        providerExecuted: Ce().optional(),
        providerMetadata: Q.optional(),
        toolMetadata: hn.optional(),
        dynamic: Ce().optional()
      }),
      ce({
        type: V("tool-output-denied"),
        toolCallId: $()
      }),
      ce({
        type: V("reasoning-start"),
        id: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("reasoning-delta"),
        id: $(),
        delta: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("reasoning-end"),
        id: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("source-url"),
        sourceId: $(),
        url: $(),
        title: $().optional(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("source-document"),
        sourceId: $(),
        mediaType: $(),
        title: $(),
        filename: $().optional(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: V("file"),
        url: $(),
        mediaType: $(),
        providerMetadata: Q.optional()
      }),
      ce({
        type: ir(
          (e) => typeof e == "string" && e.startsWith("data-"),
          { message: 'Type must start with "data-"' }
        ),
        id: $().optional(),
        data: Re(),
        transient: Ce().optional()
      }),
      ce({
        type: V("start-step")
      }),
      ce({
        type: V("finish-step")
      }),
      ce({
        type: V("start"),
        messageId: $().optional(),
        messageMetadata: Re().optional()
      }),
      ce({
        type: V("finish"),
        finishReason: zi([
          "stop",
          "length",
          "content-filter",
          "tool-calls",
          "error",
          "other"
        ]).optional(),
        messageMetadata: Re().optional()
      }),
      ce({
        type: V("abort"),
        reason: $().optional()
      }),
      ce({
        type: V("message-metadata"),
        messageMetadata: Re()
      })
    ])
  )
);
function Hb(e) {
  return e.type.startsWith("data-");
}
function Cn() {
  return /* @__PURE__ */ Object.create(null);
}
function br(e) {
  return e.type.startsWith("tool-");
}
function Kb(e) {
  return e.type === "dynamic-tool";
}
function st(e) {
  return br(e) || Kb(e);
}
function Pi(e) {
  return e.type.split("-").slice(1).join("-");
}
function Bu({
  lastMessage: e,
  messageId: t
}) {
  var n;
  const r = (e == null ? void 0 : e.role) === "assistant" ? e : {
    id: t,
    metadata: void 0,
    role: "assistant",
    parts: []
  }, i = Cn(), o = r.parts.findLastIndex(
    (s) => s.type === "step-start"
  );
  let a = 0;
  for (const s of r.parts.slice(o + 1)) {
    if (!st(s))
      continue;
    const u = a;
    br(s) && a++, s.state === "input-streaming" && (i[s.toolCallId] = {
      text: (n = s.rawInput) != null ? n : "",
      inputEncoding: s.inputEncoding,
      index: u,
      toolName: s.type === "dynamic-tool" ? s.toolName : Pi(s),
      dynamic: s.type === "dynamic-tool",
      title: s.title,
      toolMetadata: s.toolMetadata
    });
  }
  return {
    message: r,
    activeTextParts: Cn(),
    activeReasoningParts: Cn(),
    partialToolCalls: i
  };
}
function Yb({
  stream: e,
  messageMetadataSchema: t,
  dataPartSchemas: n,
  runUpdateMessageJob: r,
  onError: i,
  onToolCall: o,
  onData: a,
  resetStateOnMessageIdChange: s = !1,
  resetStateOnFirstMessageStart: u = !1
}) {
  let c = !0;
  return e.pipeThrough(
    new TransformStream({
      async transform(l, f) {
        await r(async ({ state: d, write: p }) => {
          var h, m, k, g, _, w, C, I, y;
          function E() {
            const x = d.message.parts;
            let Z = x.length - 1;
            for (; Z >= 0 && x[Z].type !== "step-start"; )
              Z--;
            return x.slice(Z + 1);
          }
          function R() {
            return E().filter(st);
          }
          function F(x) {
            let B = R().find(
              (Y) => Y.toolCallId === x
            );
            if (B == null) {
              const Y = d.message.parts;
              for (let D = Y.length - 1; D >= 0; D--) {
                const H = Y[D];
                if (st(H) && H.toolCallId === x) {
                  B = H;
                  break;
                }
              }
            }
            if (B == null)
              throw new Vt({
                chunkType: "tool-invocation",
                chunkId: x,
                message: `No tool invocation found for tool call ID "${x}".`
              });
            return B;
          }
          function S(x, Z) {
            var B;
            const Y = Z ?? E().find(
              (le) => br(le) && le.toolCallId === x.toolCallId
            ), D = x, H = Y;
            if (Y != null) {
              Y.state = x.state, H.type = `tool-${x.toolName}`, H.input = D.input, H.output = D.output, H.errorText = D.errorText, H.rawInput = D.rawInput, D.inputEncoding != null ? H.inputEncoding = D.inputEncoding : delete H.inputEncoding, H.preliminary = D.preliminary, x.title !== void 0 && (H.title = x.title), x.toolMetadata !== void 0 && (H.toolMetadata = x.toolMetadata), H.providerExecuted = (B = D.providerExecuted) != null ? B : Y.providerExecuted;
              const le = D.providerMetadata;
              if (le != null)
                if (x.state === "output-available" || x.state === "output-error") {
                  const b = Y;
                  b.resultProviderMetadata = le;
                } else
                  Y.callProviderMetadata = le;
            } else
              d.message.parts.push({
                type: `tool-${x.toolName}`,
                toolCallId: x.toolCallId,
                state: x.state,
                title: x.title,
                ...x.toolMetadata !== void 0 ? { toolMetadata: x.toolMetadata } : {},
                input: D.input,
                ...D.inputEncoding != null ? { inputEncoding: D.inputEncoding } : {},
                output: D.output,
                rawInput: D.rawInput,
                errorText: D.errorText,
                providerExecuted: D.providerExecuted,
                preliminary: D.preliminary,
                ...D.providerMetadata != null && (x.state === "output-available" || x.state === "output-error") ? { resultProviderMetadata: D.providerMetadata } : {},
                ...D.providerMetadata != null && !(x.state === "output-available" || x.state === "output-error") ? { callProviderMetadata: D.providerMetadata } : {}
              });
          }
          function M(x, Z) {
            var B;
            const Y = Z ?? E().find(
              (le) => le.type === "dynamic-tool" && le.toolCallId === x.toolCallId
            ), D = x, H = Y;
            if (Y != null) {
              Y.state = x.state, H.toolName = x.toolName, H.input = D.input, H.output = D.output, H.errorText = D.errorText, H.rawInput = D.rawInput, D.inputEncoding != null ? H.inputEncoding = D.inputEncoding : delete H.inputEncoding, H.preliminary = D.preliminary, x.title !== void 0 && (H.title = x.title), x.toolMetadata !== void 0 && (H.toolMetadata = x.toolMetadata), H.providerExecuted = (B = D.providerExecuted) != null ? B : Y.providerExecuted;
              const le = D.providerMetadata;
              if (le != null)
                if (x.state === "output-available" || x.state === "output-error") {
                  const b = Y;
                  b.resultProviderMetadata = le;
                } else
                  Y.callProviderMetadata = le;
            } else
              d.message.parts.push({
                type: "dynamic-tool",
                toolName: x.toolName,
                toolCallId: x.toolCallId,
                state: x.state,
                input: D.input,
                ...D.inputEncoding != null ? { inputEncoding: D.inputEncoding } : {},
                output: D.output,
                errorText: D.errorText,
                preliminary: D.preliminary,
                providerExecuted: D.providerExecuted,
                title: x.title,
                ...x.toolMetadata !== void 0 ? { toolMetadata: x.toolMetadata } : {},
                ...D.providerMetadata != null && (x.state === "output-available" || x.state === "output-error") ? { resultProviderMetadata: D.providerMetadata } : {},
                ...D.providerMetadata != null && !(x.state === "output-available" || x.state === "output-error") ? { callProviderMetadata: D.providerMetadata } : {}
              });
          }
          async function L(x) {
            if (x != null) {
              const Z = d.message.metadata != null ? Du(d.message.metadata, x) : x;
              t != null && await Ba({
                value: Z,
                schema: t,
                context: {
                  field: "message.metadata",
                  entityId: d.message.id
                }
              }), d.message.metadata = Z;
            }
          }
          switch (l.type) {
            case "text-start": {
              const x = {
                type: "text",
                text: "",
                providerMetadata: l.providerMetadata,
                state: "streaming"
              };
              d.activeTextParts[l.id] = x, d.message.parts.push(x), p();
              break;
            }
            case "text-delta": {
              const x = d.activeTextParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "text-delta",
                  chunkId: l.id,
                  message: `Received text-delta for missing text part with ID "${l.id}". Ensure a "text-start" chunk is sent before any "text-delta" chunks.`
                });
              x.text += l.delta, x.providerMetadata = (h = l.providerMetadata) != null ? h : x.providerMetadata, p();
              break;
            }
            case "text-end": {
              const x = d.activeTextParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "text-end",
                  chunkId: l.id,
                  message: `Received text-end for missing text part with ID "${l.id}". Ensure a "text-start" chunk is sent before any "text-end" chunks.`
                });
              x.state = "done", x.providerMetadata = (m = l.providerMetadata) != null ? m : x.providerMetadata, delete d.activeTextParts[l.id], p();
              break;
            }
            case "reasoning-start": {
              const x = {
                type: "reasoning",
                id: l.id,
                text: "",
                providerMetadata: l.providerMetadata,
                state: "streaming"
              };
              d.activeReasoningParts[l.id] = x, d.message.parts.push(x), p();
              break;
            }
            case "reasoning-delta": {
              const x = d.activeReasoningParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "reasoning-delta",
                  chunkId: l.id,
                  message: `Received reasoning-delta for missing reasoning part with ID "${l.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-delta" chunks.`
                });
              x.text += l.delta, x.providerMetadata = (k = l.providerMetadata) != null ? k : x.providerMetadata, p();
              break;
            }
            case "reasoning-end": {
              const x = d.activeReasoningParts[l.id];
              if (x == null)
                throw new Vt({
                  chunkType: "reasoning-end",
                  chunkId: l.id,
                  message: `Received reasoning-end for missing reasoning part with ID "${l.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-end" chunks.`
                });
              x.providerMetadata = (g = l.providerMetadata) != null ? g : x.providerMetadata, x.state = "done", delete d.activeReasoningParts[l.id], p();
              break;
            }
            case "file": {
              d.message.parts.push({
                type: "file",
                mediaType: l.mediaType,
                url: l.url,
                ...l.providerMetadata != null ? { providerMetadata: l.providerMetadata } : {}
              }), p();
              break;
            }
            case "source-url": {
              d.message.parts.push({
                type: "source-url",
                sourceId: l.sourceId,
                url: l.url,
                title: l.title,
                providerMetadata: l.providerMetadata
              }), p();
              break;
            }
            case "source-document": {
              d.message.parts.push({
                type: "source-document",
                sourceId: l.sourceId,
                mediaType: l.mediaType,
                title: l.title,
                filename: l.filename,
                providerMetadata: l.providerMetadata
              }), p();
              break;
            }
            case "tool-input-start": {
              const x = E().filter(br);
              d.partialToolCalls[l.toolCallId] = {
                text: "",
                inputEncoding: l.inputEncoding,
                toolName: l.toolName,
                index: x.length,
                dynamic: l.dynamic,
                title: l.title,
                toolMetadata: l.toolMetadata
              }, l.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-streaming",
                inputEncoding: l.inputEncoding,
                input: void 0,
                providerExecuted: l.providerExecuted,
                title: l.title,
                toolMetadata: l.toolMetadata,
                providerMetadata: l.providerMetadata
              }) : S({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-streaming",
                inputEncoding: l.inputEncoding,
                input: void 0,
                providerExecuted: l.providerExecuted,
                title: l.title,
                toolMetadata: l.toolMetadata,
                providerMetadata: l.providerMetadata
              }), p();
              break;
            }
            case "tool-input-delta": {
              const x = d.partialToolCalls[l.toolCallId];
              if (x == null)
                throw new Vt({
                  chunkType: "tool-input-delta",
                  chunkId: l.toolCallId,
                  message: `Received tool-input-delta for missing tool call with ID "${l.toolCallId}". Ensure a "tool-input-start" chunk is sent before any "tool-input-delta" chunks.`
                });
              x.text += l.inputTextDelta;
              const Z = x.inputEncoding === "text" ? x.text : (await Fn(x.text)).value;
              x.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: x.toolName,
                state: "input-streaming",
                inputEncoding: x.inputEncoding,
                input: Z,
                rawInput: x.text,
                title: x.title,
                toolMetadata: x.toolMetadata
              }) : S({
                toolCallId: l.toolCallId,
                toolName: x.toolName,
                state: "input-streaming",
                inputEncoding: x.inputEncoding,
                input: Z,
                rawInput: x.text,
                title: x.title,
                toolMetadata: x.toolMetadata
              }), p();
              break;
            }
            case "tool-input-available": {
              l.dynamic ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-available",
                input: l.input,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                title: l.title,
                toolMetadata: l.toolMetadata
              }) : S({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "input-available",
                input: l.input,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                title: l.title,
                toolMetadata: l.toolMetadata
              }), p(), o && !l.providerExecuted && await o({
                toolCall: l
              });
              break;
            }
            case "tool-input-error": {
              const x = E().filter(st).find((B) => B.toolCallId === l.toolCallId);
              (x != null ? x.type === "dynamic-tool" : !!l.dynamic) ? M({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "output-error",
                input: l.input,
                errorText: l.errorText,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                toolMetadata: l.toolMetadata
              }) : S({
                toolCallId: l.toolCallId,
                toolName: l.toolName,
                state: "output-error",
                input: void 0,
                rawInput: l.input,
                errorText: l.errorText,
                providerExecuted: l.providerExecuted,
                providerMetadata: l.providerMetadata,
                toolMetadata: l.toolMetadata
              }), p();
              break;
            }
            case "tool-approval-request": {
              const x = F(l.toolCallId);
              x.state = "approval-requested", x.approval = {
                id: l.approvalId,
                ...l.approvalDescriptor != null ? { descriptor: l.approvalDescriptor } : {},
                ...Object.prototype.hasOwnProperty.call(
                  l,
                  "inputSchemaInput"
                ) ? { inputSchemaInput: l.inputSchemaInput } : {},
                ...l.signature != null ? { signature: l.signature } : {}
              }, p();
              break;
            }
            case "tool-output-denied": {
              const x = F(l.toolCallId);
              x.state = "output-denied", p();
              break;
            }
            case "tool-output-available": {
              const x = F(l.toolCallId);
              x.type === "dynamic-tool" ? M(
                {
                  toolCallId: l.toolCallId,
                  toolName: x.toolName,
                  state: "output-available",
                  input: x.input,
                  output: l.output,
                  preliminary: l.preliminary,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (_ = l.toolMetadata) != null ? _ : x.toolMetadata
                },
                x
              ) : S(
                {
                  toolCallId: l.toolCallId,
                  toolName: Pi(x),
                  state: "output-available",
                  input: x.input,
                  output: l.output,
                  providerExecuted: l.providerExecuted,
                  preliminary: l.preliminary,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (w = l.toolMetadata) != null ? w : x.toolMetadata
                },
                x
              ), p();
              break;
            }
            case "tool-output-error": {
              const x = F(l.toolCallId);
              x.type === "dynamic-tool" ? M(
                {
                  toolCallId: l.toolCallId,
                  toolName: x.toolName,
                  state: "output-error",
                  input: x.input,
                  errorText: l.errorText,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (C = l.toolMetadata) != null ? C : x.toolMetadata
                },
                x
              ) : S(
                {
                  toolCallId: l.toolCallId,
                  toolName: Pi(x),
                  state: "output-error",
                  input: x.input,
                  rawInput: x.rawInput,
                  errorText: l.errorText,
                  providerExecuted: l.providerExecuted,
                  providerMetadata: l.providerMetadata,
                  title: x.title,
                  toolMetadata: (I = l.toolMetadata) != null ? I : x.toolMetadata
                },
                x
              ), p();
              break;
            }
            case "start-step": {
              d.message.parts.push({ type: "step-start" });
              break;
            }
            case "finish-step": {
              d.activeTextParts = Cn(), d.activeReasoningParts = Cn();
              break;
            }
            case "start": {
              const x = u && c || s && l.messageId != null && l.messageId !== d.message.id;
              c = !1, x && Object.assign(
                d,
                Bu({
                  lastMessage: void 0,
                  messageId: (y = l.messageId) != null ? y : d.message.id
                }),
                { finishReason: void 0 }
              ), l.messageId != null && (d.message.id = l.messageId), await L(l.messageMetadata), (x || l.messageId != null || l.messageMetadata != null) && p({ updateStatus: !1 });
              break;
            }
            case "finish": {
              l.finishReason != null && (d.finishReason = l.finishReason), await L(l.messageMetadata), l.messageMetadata != null && p();
              break;
            }
            case "message-metadata": {
              await L(l.messageMetadata), l.messageMetadata != null && p();
              break;
            }
            case "error": {
              i == null || i(new Error(l.errorText));
              break;
            }
            default:
              if (Hb(l)) {
                if ((n == null ? void 0 : n[l.type]) != null) {
                  const B = d.message.parts.findIndex(
                    (D) => "id" in D && "data" in D && D.id === l.id && D.type === l.type
                  ), Y = B >= 0 ? B : d.message.parts.length;
                  await Ba({
                    value: l.data,
                    schema: n[l.type],
                    context: {
                      field: `message.parts[${Y}].data`,
                      entityName: l.type,
                      entityId: l.id
                    }
                  });
                }
                const x = l;
                if (x.transient) {
                  a == null || a(x);
                  break;
                }
                const Z = x.id != null ? d.message.parts.find(
                  (B) => x.type === B.type && x.id === B.id
                ) : void 0;
                Z != null ? Z.data = x.data : d.message.parts.push(x), a == null || a(x), p();
              }
          }
          f.enqueue(l);
        });
      }
    })
  );
}
async function Gb({
  stream: e,
  onError: t,
  abortSignal: n
}) {
  const r = e.getReader(), i = () => {
    r.cancel().catch(() => {
    });
  };
  n != null && n.aborted ? i() : n == null || n.addEventListener("abort", i, { once: !0 });
  try {
    for (; ; ) {
      const { done: o } = await r.read();
      if (o)
        break;
    }
  } catch (o) {
    t == null || t(o);
  } finally {
    n == null || n.removeEventListener("abort", i), r.releaseLock();
  }
}
function Xb() {
  let e, t;
  return {
    promise: new Promise((r, i) => {
      e = r, t = i;
    }),
    resolve: e,
    reject: t
  };
}
Ln({
  prefix: "aitxt",
  size: 24
});
Dt(
  $(),
  Ft.optional()
);
new TextEncoder();
Ln({ prefix: "aiobj", size: 24 });
var Qb = class {
  constructor() {
    this.queue = [], this.isProcessing = !1, this.idleWaiters = [];
  }
  async processQueue() {
    if (!this.isProcessing) {
      this.isProcessing = !0;
      try {
        for (; this.queue.length > 0; )
          await this.queue[0](), this.queue.shift();
      } finally {
        this.isProcessing = !1;
        for (const e of this.idleWaiters.splice(0))
          e();
      }
    }
  }
  async run(e) {
    return new Promise((t, n) => {
      this.queue.push(async () => {
        try {
          await e(), t();
        } catch (r) {
          n(r);
        }
      }), this.processQueue();
    });
  }
  async waitForIdle() {
    !this.isProcessing && this.queue.length === 0 || await new Promise((e) => {
      this.idleWaiters.push(e);
    });
  }
};
Ln({ prefix: "aiobj", size: 24 });
async function ev(e) {
  if (e == null)
    return [];
  if (!globalThis.FileList || !(e instanceof globalThis.FileList))
    throw new Error("FileList is not supported in the current environment");
  return Promise.all(
    Array.from(e).map(async (t) => {
      const { name: n, type: r } = t, i = await new Promise((o, a) => {
        const s = new FileReader();
        s.onload = (u) => {
          var c;
          o((c = u.target) == null ? void 0 : c.result);
        }, s.onerror = (u) => a(u), s.readAsDataURL(t);
      });
      return {
        type: "file",
        mediaType: r,
        filename: n,
        url: i
      };
    })
  );
}
function tv(e, t) {
  const n = e.search(/[?#]/), r = n === -1 ? e : e.slice(0, n), i = n === -1 ? "" : e.slice(n);
  return `${r.endsWith("/") && t.startsWith("/") ? r.slice(0, -1) : r}${t}${i}`;
}
var nv = class {
  constructor({
    api: e = "/api/chat",
    credentials: t,
    headers: n,
    body: r,
    fetch: i,
    prepareSendMessagesRequest: o,
    prepareReconnectToStreamRequest: a
  }) {
    this.api = e, this.credentials = t, this.headers = n, this.body = r, this.fetch = i, this.prepareSendMessagesRequest = o, this.prepareReconnectToStreamRequest = a;
  }
  async sendMessages({
    abortSignal: e,
    ...t
  }) {
    var n, r, i, o, a;
    const s = await wt(this.body), u = await wt(this.headers), c = await wt(this.credentials), l = {
      ...Ut(u),
      ...Ut(t.headers)
    }, f = await ((n = this.prepareSendMessagesRequest) == null ? void 0 : n.call(this, {
      api: this.api,
      id: t.chatId,
      messages: t.messages,
      body: { ...s, ...t.body },
      headers: l,
      credentials: c,
      requestMetadata: t.metadata,
      trigger: t.trigger,
      messageId: t.messageId
    })), d = (r = f == null ? void 0 : f.api) != null ? r : this.api, p = (f == null ? void 0 : f.headers) !== void 0 ? Ut(f.headers) : l, h = (f == null ? void 0 : f.body) !== void 0 ? f.body : {
      ...s,
      ...t.body,
      id: t.chatId,
      messages: t.messages,
      trigger: t.trigger,
      messageId: t.messageId
    }, m = (i = f == null ? void 0 : f.credentials) != null ? i : c, g = await ((o = this.fetch) != null ? o : globalThis.fetch)(d, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...p
      },
      body: JSON.stringify(h),
      credentials: m,
      signal: e
    });
    if (!g.ok)
      throw new Error(
        (a = await g.text()) != null ? a : "Failed to fetch the chat response."
      );
    if (!g.body)
      throw new Error("The response body is empty.");
    return this.processResponseStream(g.body);
  }
  async reconnectToStream(e) {
    var t, n, r, i;
    const o = await wt(this.body), a = await wt(this.headers), s = await wt(this.credentials), u = {
      ...Ut(a),
      ...Ut(e.headers)
    }, c = await ((t = this.prepareReconnectToStreamRequest) == null ? void 0 : t.call(this, {
      api: this.api,
      id: e.chatId,
      body: { ...o, ...e.body },
      headers: u,
      credentials: s,
      requestMetadata: e.metadata
    }));
    let l = c == null ? void 0 : c.api;
    if (l == null) {
      if (e.chatId === "." || e.chatId === "..")
        throw new Cb({
          parameter: "chatId",
          value: e.chatId,
          message: 'Chat IDs must not be "." or ".." when using the default reconnect URL.'
        });
      l = tv(
        this.api,
        `/${encodeURIComponent(e.chatId)}/stream`
      );
    }
    const f = (c == null ? void 0 : c.headers) !== void 0 ? Ut(c.headers) : u, d = (n = c == null ? void 0 : c.credentials) != null ? n : s, h = await ((r = this.fetch) != null ? r : globalThis.fetch)(l, {
      method: "GET",
      headers: f,
      credentials: d,
      signal: e.abortSignal
    });
    if (h.status === 204)
      return null;
    if (!h.ok)
      throw new Error(
        (i = await h.text()) != null ? i : "Failed to fetch the chat response."
      );
    if (!h.body)
      throw new Error("The response body is empty.");
    return this.processResponseStream(h.body);
  }
}, Uu = class extends nv {
  constructor({
    resumeStreamIsReplay: e = !0,
    ...t
  } = {}) {
    super(t), this.resumeStreamIsReplay = e;
  }
  processResponseStream(e) {
    return _b({
      stream: e,
      schema: Wb
    }).pipeThrough(
      new TransformStream({
        async transform(t, n) {
          if (!t.success)
            throw t.error;
          n.enqueue(t.value);
        }
      })
    );
  }
}, rv = class {
  constructor({
    generateId: e = Iy,
    id: t = e(),
    transport: n = new Uu(),
    messageMetadataSchema: r,
    dataPartSchemas: i,
    state: o,
    onError: a,
    onToolCall: s,
    onFinish: u,
    onData: c,
    sendAutomaticallyWhen: l
  }) {
    this.activeResponse = void 0, this.activeResumeRequest = void 0, this.resumableStreamState = void 0, this.jobExecutor = new Qb(), this.activeStopCount = 0, this.stopGeneration = 0, this.sendMessage = async (f, d) => {
      var p, h, m, k;
      if (f == null) {
        let _ = this.pendingApprovalMessageId;
        if (_ == null) {
          _ = (p = this.lastMessage) == null ? void 0 : p.id;
          for (let I = this.state.messages.length - 1; I >= 0; I--) {
            const y = this.state.messages[I];
            if (y.role === "assistant" && y.parts.some(
              (E) => st(E) && E.state === "approval-responded"
            )) {
              _ = y.id;
              break;
            }
          }
        }
        const C = _ != null && _ === this.pendingApprovalMessageId ? this.state.messages.findIndex((I) => I.id === _) : -1;
        await this.makeRequestForToolApproval({
          messageId: _,
          messageIndex: C,
          ...d
        });
        return;
      }
      let g;
      if ("text" in f || "files" in f ? g = {
        parts: [
          ...Array.isArray(f.files) ? f.files : await ev(f.files),
          ..."text" in f && f.text != null ? [{ type: "text", text: f.text }] : []
        ]
      } : g = f, f.messageId != null) {
        const _ = this.state.messages.findIndex(
          (w) => w.id === f.messageId
        );
        if (_ === -1)
          throw new Error(`message with id ${f.messageId} not found`);
        if (this.state.messages[_].role !== "user")
          throw new Error(
            `message with id ${f.messageId} is not a user message`
          );
        this.state.messages = this.state.messages.slice(0, _ + 1), this.state.replaceMessage(_, {
          ...g,
          id: f.messageId,
          role: (h = g.role) != null ? h : "user",
          metadata: f.metadata
        });
      } else
        this.state.pushMessage({
          ...g,
          id: (m = g.id) != null ? m : this.generateId(),
          role: (k = g.role) != null ? k : "user",
          metadata: f.metadata
        });
      await this.makeRequest({
        trigger: "submit-message",
        messageId: f.messageId,
        ...d
      });
    }, this.regenerate = async ({
      messageId: f,
      ...d
    } = {}) => {
      const p = f == null ? this.state.messages.length - 1 : this.state.messages.findIndex((h) => h.id === f);
      if (p === -1)
        throw new Error(`message ${f} not found`);
      this.state.messages = this.state.messages.slice(
        0,
        // if the message is a user message, we need to include it in the request:
        this.messages[p].role === "assistant" ? p : p + 1
      ), await this.makeRequest({
        trigger: "regenerate-message",
        messageId: f,
        ...d
      });
    }, this.resumeStream = async (f = {}) => {
      await this.makeRequest({ trigger: "resume-stream", ...f });
    }, this["~resumeStreamIfDisconnected"] = async ({
      shouldResume: f = () => !0
    } = {}) => {
      const d = this.activeResponse;
      this.resumableStreamState == null && d != null && (await d.completionPromise, this.resumableStreamState !== d.state) || this.resumableStreamState != null && f() && await this.resumeStream();
    }, this.clearError = () => {
      this.status === "error" && (this.state.error = void 0, this.setStatus({ status: "ready" }));
    }, this.addToolApprovalResponse = async ({
      id: f,
      approved: d,
      reason: p,
      options: h
    }) => this.jobExecutor.run(async () => {
      const m = this.state.messages, k = (_) => st(_) && _.state === "approval-requested" && _.approval.id === f ? {
        ..._,
        state: "approval-responded",
        approval: { ..._.approval, id: f, approved: d, reason: p }
      } : _, g = m.findIndex(
        (_) => _.parts.some(
          (w) => st(w) && w.state === "approval-requested" && w.approval.id === f
        )
      );
      if (g !== -1) {
        const _ = m[g];
        this.state.replaceMessage(g, {
          ..._,
          parts: _.parts.map(k)
        }), this.pendingApprovalMessageId = _.id;
      }
      if (this.activeResponse && (this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(k)), this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) {
        const _ = await this.shouldSendAutomatically();
        _ && this.runAutomaticRequest(() => {
          var w;
          const C = g === -1 ? (w = this.lastMessage) == null ? void 0 : w.id : m[g].id;
          return this.makeRequestForToolApproval({
            messageId: C,
            messageIndex: g,
            ...h
          });
        }, _);
      }
    }), this.addToolOutput = async ({
      state: f = "output-available",
      toolCallId: d,
      output: p,
      errorText: h,
      options: m
    }) => this.jobExecutor.run(async () => {
      const k = this.state.messages, g = (w) => st(w) && w.toolCallId === d ? { ...w, state: f, output: p, errorText: h } : w, _ = k.findIndex(
        (w) => w.parts.some(
          (C) => st(C) && C.toolCallId === d
        )
      );
      if (_ !== -1) {
        const w = k[_];
        this.state.replaceMessage(_, {
          ...w,
          parts: w.parts.map(g)
        });
      }
      if (this.activeResponse && (this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(g)), _ !== -1 && this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) {
        const w = await this.shouldSendAutomatically();
        w && this.runAutomaticRequest(
          () => this.makeRequest({
            trigger: "submit-message",
            messageId: k[_].id,
            ...m
          }),
          w
        );
      }
    }), this.addToolResult = this.addToolOutput, this.stop = async () => {
      this.activeStopCount++, this.stopGeneration++;
      try {
        const f = this.activeResumeRequest, d = this.activeResponse;
        f == null || f.abortController.abort(), d == null || d.abortController.abort(), await Promise.all([
          f == null ? void 0 : f.completionPromise,
          d == null ? void 0 : d.completionPromise
        ]), await this.jobExecutor.waitForIdle();
      } finally {
        this.activeStopCount--;
      }
    }, this.id = t, this.transport = n, this.generateId = e, this.messageMetadataSchema = r, this.dataPartSchemas = i, this.state = o, this.onError = a, this.onToolCall = s, this.onFinish = u, this.onData = c, this.sendAutomaticallyWhen = l;
  }
  /**
   * Hook status:
   *
   * - `submitted`: The message has been sent to the API and we're awaiting the start of the response stream.
   * - `streaming`: The response is actively streaming in from the API, receiving chunks of data.
   * - `ready`: The full response has been received and processed; a new user message can be submitted.
   * - `error`: An error occurred during the API request, preventing successful completion.
   */
  get status() {
    return this.state.status;
  }
  setStatus({
    status: e,
    error: t
  }) {
    if (this.status === e) {
      this.error !== t && (this.state.error = t);
      return;
    }
    this.state.status = e, this.state.error = t;
  }
  get error() {
    return this.state.error;
  }
  get messages() {
    return this.state.messages;
  }
  get lastMessage() {
    return this.state.messages[this.state.messages.length - 1];
  }
  set messages(e) {
    this.state.messages = e;
  }
  async shouldSendAutomatically() {
    if (!this.sendAutomaticallyWhen)
      return !1;
    const e = this.sendAutomaticallyWhen({
      messages: this.state.messages
    });
    return e && typeof e == "object" && "then" in e ? await e : e;
  }
  async runAutomaticRequest(e, t) {
    const n = this.stopGeneration, r = this.activeStopCount > 0;
    (t ?? await this.shouldSendAutomatically()) && (r || n !== this.stopGeneration || this.activeStopCount > 0 || await e());
  }
  async makeRequestForToolApproval({
    messageId: e,
    messageIndex: t,
    ...n
  }) {
    var r, i;
    const o = e != null && e === this.pendingApprovalMessageId;
    o && (this.pendingApprovalMessageId = void 0), await this.makeRequest({
      trigger: "submit-message",
      messageId: e,
      ...n
    }), o && this.status === "error" && this.pendingApprovalMessageId == null && (this.pendingApprovalMessageId = (i = (r = this.state.messages[t]) == null ? void 0 : r.id) != null ? i : e);
  }
  async makeRequest(e) {
    const t = Xb();
    try {
      await this.makeRequestImpl({
        ...e,
        completionPromise: t.promise
      });
    } finally {
      t.resolve();
    }
  }
  async makeRequestImpl({
    trigger: e,
    metadata: t,
    headers: n,
    body: r,
    messageId: i,
    completionPromise: o
  }) {
    var a, s;
    e !== "resume-stream" && (this.resumableStreamState = void 0);
    const u = new AbortController(), c = e === "resume-stream" ? { abortController: u, completionPromise: o } : void 0;
    c && ((a = this.activeResumeRequest) == null || a.abortController.abort(), this.activeResumeRequest = c);
    const l = () => c == null || this.activeResumeRequest === c, f = () => {
      this.activeResumeRequest === c && (this.activeResumeRequest = void 0);
    };
    let d;
    if (e === "resume-stream")
      try {
        const E = await this.transport.reconnectToStream({
          chatId: this.id,
          abortSignal: u.signal,
          metadata: t,
          headers: n,
          body: r
        });
        if (u.signal.aborted || !l()) {
          await (E == null ? void 0 : E.cancel().catch(() => {
          })), l() && (this.setStatus({ status: "ready" }), this.resumableStreamState = void 0), f();
          return;
        }
        if (E == null) {
          this.setStatus({ status: "ready" }), this.resumableStreamState = void 0, f();
          return;
        }
        d = E;
      } catch (E) {
        if (u.signal.aborted || E.name === "AbortError") {
          l() && (this.setStatus({ status: "ready" }), this.resumableStreamState = void 0), f();
          return;
        }
        if (!l())
          return;
        this.onError && E instanceof Error && this.onError(E), this.setStatus({ status: "error", error: E }), f();
        return;
      }
    this.setStatus({ status: "submitted", error: void 0 });
    const p = this.lastMessage, h = e === "submit-message" && i != null ? this.state.messages.findIndex((E) => E.id === i) : this.state.messages.length - 1, m = h === -1 ? p : this.state.messages[h], k = m == null ? void 0 : m.id, g = e === "resume-stream" && (m == null ? void 0 : m.role) === "assistant" && m.parts.some(
      (E) => st(E) && E.state === "input-streaming"
    ) ? this.state.snapshot(m) : void 0, _ = h !== -1 && h < this.state.messages.length - 1 && (m == null ? void 0 : m.role) === "assistant";
    let w = !1, C = !1, I = !1, y;
    try {
      const E = {
        state: e === "resume-stream" && this.resumableStreamState != null ? this.resumableStreamState : Bu({
          lastMessage: e === "resume-stream" ? g : e === "regenerate-message" ? void 0 : this.state.snapshot(m),
          messageId: this.generateId()
        }),
        abortController: u,
        completionPromise: o
      };
      y = E, E.abortController.signal.addEventListener("abort", () => {
        w = !0;
      }), this.activeResponse = E;
      let R;
      e === "resume-stream" ? R = d : R = await this.transport.sendMessages({
        chatId: this.id,
        messages: this.state.messages,
        abortSignal: E.abortController.signal,
        metadata: t,
        headers: n,
        body: r,
        trigger: e,
        messageId: i
      });
      const F = (S) => (
        // serialize the job execution to avoid race conditions:
        this.jobExecutor.run(() => E.abortController.signal.aborted ? Promise.resolve() : S({
          state: E.state,
          write: ({ updateStatus: M = !0 } = {}) => {
            if (E.abortController.signal.aborted)
              return;
            M && this.setStatus({ status: "streaming" });
            const L = this.state.messages.findLastIndex(
              (x) => x.id === E.state.message.id
            );
            if (L !== -1)
              this.state.replaceMessage(
                L,
                E.state.message
              );
            else if (_) {
              const x = this.state.messages.findLastIndex(
                (Z) => Z.id === k
              );
              x !== -1 ? this.state.replaceMessage(
                x,
                E.state.message
              ) : this.state.pushMessage(E.state.message);
            } else
              this.state.pushMessage(E.state.message);
          }
        }))
      );
      if (await Gb({
        stream: Yb({
          stream: R,
          resetStateOnMessageIdChange: e === "resume-stream",
          resetStateOnFirstMessageStart: e === "resume-stream" && this.transport.resumeStreamIsReplay,
          onToolCall: this.onToolCall,
          onData: this.onData,
          messageMetadataSchema: this.messageMetadataSchema,
          dataPartSchemas: this.dataPartSchemas,
          runUpdateMessageJob: F,
          onError: (S) => {
            throw S;
          }
        }),
        abortSignal: E.abortController.signal,
        onError: (S) => {
          throw S;
        }
      }), w)
        return l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === E.state && (this.resumableStreamState = void 0)), null;
      l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === E.state && (this.resumableStreamState = void 0));
    } catch (E) {
      if (w || E.name === "AbortError")
        return w = !0, l() && (this.setStatus({ status: "ready" }), this.resumableStreamState === (y == null ? void 0 : y.state) && (this.resumableStreamState = void 0)), null;
      if (!l())
        return null;
      I = !0, E instanceof TypeError && (E.message.toLowerCase().includes("fetch") || E.message.toLowerCase().includes("network")) && (C = !0), C ? this.resumableStreamState = y == null ? void 0 : y.state : this.resumableStreamState === (y == null ? void 0 : y.state) && (this.resumableStreamState = void 0), this.onError && E instanceof Error && this.onError(E), this.setStatus({ status: "error", error: E });
    } finally {
      try {
        y && ((s = this.onFinish) == null || s.call(this, {
          message: y.state.message,
          messages: this.state.messages,
          isAbort: w,
          isDisconnect: C,
          isError: I,
          finishReason: y.state.finishReason
        }));
      } finally {
        this.activeResponse === y && (this.activeResponse = void 0), f();
      }
    }
    !w && !I && await this.runAutomaticRequest(
      () => {
        var E;
        return this.makeRequest({
          trigger: "submit-message",
          messageId: (E = this.lastMessage) == null ? void 0 : E.id,
          metadata: t,
          headers: n,
          body: r
        });
      }
    );
  }
};
function iv(e, t) {
  if (typeof e != "function")
    throw new TypeError(`Expected the first argument to be a \`function\`, got \`${typeof e}\`.`);
  let n, r = 0;
  return function(...o) {
    clearTimeout(n);
    const a = Date.now(), s = a - r, u = t - s;
    u <= 0 ? (r = a, e.apply(this, o)) : n = setTimeout(() => {
      r = Date.now(), e.apply(this, o);
    }, u);
  };
}
var ov = iv;
const av = /* @__PURE__ */ Cu(ov);
var Vu = (e, t, n) => {
  if (!t.has(e))
    throw TypeError("Cannot " + n);
}, fe = (e, t, n) => (Vu(e, t, "read from private field"), n ? n.call(e) : t.get(e)), ot = (e, t, n) => {
  if (t.has(e))
    throw TypeError("Cannot add the same private member more than once");
  t instanceof WeakSet ? t.add(e) : t.set(e, n);
}, vt = (e, t, n, r) => (Vu(e, t, "write to private field"), t.set(e, n), n);
function sv(e, t) {
  return t != null ? av(e, t) : e;
}
function lv(e) {
  return Array.isArray(e) ? [...e] : e != null && typeof e == "object" && (Object.getPrototypeOf(e) === Object.prototype || Object.getPrototypeOf(e) === null) ? { ...e } : e;
}
var Ue, or, ar, xn, _n, Sn, Jt, Mi, Ri, uv = class {
  constructor(e = []) {
    ot(this, Ue, void 0), ot(this, or, "ready"), ot(this, ar, void 0), ot(this, xn, /* @__PURE__ */ new Set()), ot(this, _n, /* @__PURE__ */ new Set()), ot(this, Sn, /* @__PURE__ */ new Set()), this.pushMessage = (t) => {
      vt(this, Ue, fe(this, Ue).concat(t)), fe(this, Jt).call(this);
    }, this.popMessage = () => {
      vt(this, Ue, fe(this, Ue).slice(0, -1)), fe(this, Jt).call(this);
    }, this.replaceMessage = (t, n) => {
      vt(this, Ue, [
        ...fe(this, Ue).slice(0, t),
        this.snapshot(n),
        ...fe(this, Ue).slice(t + 1)
      ]), fe(this, Jt).call(this);
    }, this.snapshot = (t) => {
      if (t == null || typeof t != "object" || !("parts" in t) || !Array.isArray(t.parts))
        return t;
      const n = t, r = {
        ...n,
        parts: n.parts.map((i) => ({ ...i }))
      };
      return "metadata" in n && (r.metadata = lv(n.metadata)), r;
    }, this["~registerMessagesCallback"] = (t, n) => {
      const r = n ? sv(t, n) : t;
      return fe(this, xn).add(r), () => {
        fe(this, xn).delete(r);
      };
    }, this["~registerStatusCallback"] = (t) => (fe(this, _n).add(t), () => {
      fe(this, _n).delete(t);
    }), this["~registerErrorCallback"] = (t) => (fe(this, Sn).add(t), () => {
      fe(this, Sn).delete(t);
    }), ot(this, Jt, () => {
      fe(this, xn).forEach((t) => t());
    }), ot(this, Mi, () => {
      fe(this, _n).forEach((t) => t());
    }), ot(this, Ri, () => {
      fe(this, Sn).forEach((t) => t());
    }), vt(this, Ue, e);
  }
  get status() {
    return fe(this, or);
  }
  set status(e) {
    vt(this, or, e), fe(this, Mi).call(this);
  }
  get error() {
    return fe(this, ar);
  }
  set error(e) {
    vt(this, ar, e), fe(this, Ri).call(this);
  }
  get messages() {
    return fe(this, Ue);
  }
  set messages(e) {
    vt(this, Ue, [...e]), fe(this, Jt).call(this);
  }
};
Ue = /* @__PURE__ */ new WeakMap();
or = /* @__PURE__ */ new WeakMap();
ar = /* @__PURE__ */ new WeakMap();
xn = /* @__PURE__ */ new WeakMap();
_n = /* @__PURE__ */ new WeakMap();
Sn = /* @__PURE__ */ new WeakMap();
Jt = /* @__PURE__ */ new WeakMap();
Mi = /* @__PURE__ */ new WeakMap();
Ri = /* @__PURE__ */ new WeakMap();
var Wt, Ua = class extends rv {
  constructor({ messages: e, ...t }) {
    const n = new uv(e);
    super({ ...t, state: n }), ot(this, Wt, void 0), this["~registerMessagesCallback"] = (r, i) => fe(this, Wt)["~registerMessagesCallback"](r, i), this["~registerStatusCallback"] = (r) => fe(this, Wt)["~registerStatusCallback"](r), this["~registerErrorCallback"] = (r) => fe(this, Wt)["~registerErrorCallback"](r), vt(this, Wt, n);
  }
};
Wt = /* @__PURE__ */ new WeakMap();
var sr = /* @__PURE__ */ new WeakMap();
function cv({
  chat: e,
  state: t
}) {
  if (document.visibilityState !== "visible" || t.pendingVisibilityResume != null)
    return;
  const n = () => sr.get(e) === t && t.registrations.size > 0, r = () => {
    t.pendingVisibilityResume = void 0;
  }, i = e;
  t.pendingVisibilityResume = i["~resumeStreamIfDisconnected"]({
    shouldResume: () => n() && document.visibilityState === "visible"
  }).then(r, r);
}
function fv({
  chat: e,
  registration: t
}) {
  let n = sr.get(e);
  if (n == null) {
    const o = { registrations: /* @__PURE__ */ new Set() };
    if (sr.set(e, o), n = o, typeof document < "u") {
      const a = () => cv({ chat: e, state: o });
      document.addEventListener("visibilitychange", a), o.cleanupVisibilityListener = () => {
        document.removeEventListener("visibilitychange", a);
      };
    }
  }
  const { registrations: r } = n, i = r.size === 0;
  return r.add(t), i && e.status !== "submitted" && e.status !== "streaming" && e.resumeStream(), () => {
    var o;
    r.delete(t), r.size === 0 && ((o = n.cleanupVisibilityListener) == null || o.call(n), sr.delete(e));
  };
}
function dv({
  experimental_throttle: e,
  resume: t = !1,
  ...n
} = {}) {
  const r = Ve({}), i = Ve({});
  "chat" in n || (i.current = {
    onToolCall: n.onToolCall,
    onData: n.onData,
    onFinish: n.onFinish,
    onError: n.onError,
    sendAutomaticallyWhen: n.sendAutomaticallyWhen,
    transport: n.transport
  });
  let o;
  const a = () => {
    var C;
    return (C = i.current.transport) != null ? C : o ?? (o = new Uu());
  }, s = {
    ...n,
    transport: {
      sendMessages: (C) => a().sendMessages(C),
      reconnectToStream: (C) => a().reconnectToStream(C)
    },
    onToolCall: (C) => {
      var I, y;
      return (y = (I = i.current).onToolCall) == null ? void 0 : y.call(I, C);
    },
    onData: (C) => {
      var I, y;
      return (y = (I = i.current).onData) == null ? void 0 : y.call(I, C);
    },
    onFinish: (C) => {
      var I, y;
      return (y = (I = i.current).onFinish) == null ? void 0 : y.call(I, C);
    },
    onError: (C) => {
      var I, y;
      return (y = (I = i.current).onError) == null ? void 0 : y.call(I, C);
    },
    sendAutomaticallyWhen: (C) => {
      var I, y, E;
      return (E = (y = (I = i.current).sendAutomaticallyWhen) == null ? void 0 : y.call(I, C)) != null ? E : !1;
    }
  }, u = Ve(
    "chat" in n ? n.chat : new Ua(s)
  );
  ("chat" in n && n.chat !== u.current || "id" in n && n.id != null && u.current.id !== n.id) && (u.current = "chat" in n ? n.chat : new Ua(s));
  const l = u.current, f = Ve({
    chat: l,
    messages: l.messages
  });
  f.current.chat !== l && (f.current = { chat: l, messages: l.messages });
  const d = ye(
    (C) => {
      let I = !0;
      const y = () => {
        !I || f.current.chat !== l || (f.current = { chat: l, messages: l.messages }, C());
      }, E = l["~registerMessagesCallback"](
        y,
        e
      );
      return f.current = { chat: l, messages: l.messages }, () => {
        I = !1, E();
      };
    },
    [l, e]
  ), p = ye(
    () => f.current.messages,
    []
  ), h = Zr(
    d,
    p,
    p
  ), m = ye(
    (C) => l["~registerStatusCallback"](() => {
      f.current.chat === l && ((l.status === "ready" || l.status === "error") && (f.current = { chat: l, messages: l.messages }), C());
    }),
    [l]
  ), k = ye(() => l.status, [l]), g = Zr(
    m,
    k,
    k
  ), _ = Zr(
    u.current["~registerErrorCallback"],
    () => u.current.error,
    () => u.current.error
  ), w = ye(
    (C) => {
      typeof C == "function" && (C = C(u.current.messages)), u.current.messages = C;
    },
    [u]
  );
  return qe(() => {
    if (t)
      return fv({
        chat: l,
        registration: r.current
      });
  }, [t, l]), {
    id: u.current.id,
    messages: h,
    setMessages: w,
    sendMessage: u.current.sendMessage,
    regenerate: u.current.regenerate,
    clearError: u.current.clearError,
    stop: u.current.stop,
    error: _,
    resumeStream: u.current.resumeStream,
    status: g,
    /**
     * @deprecated Use `addToolOutput` instead.
     */
    addToolResult: u.current.addToolOutput,
    addToolOutput: u.current.addToolOutput,
    addToolApprovalResponse: u.current.addToolApprovalResponse
  };
}
function qu(e) {
  return e.parts.filter((t) => t.type === "text").map((t) => t.text).join(`
`);
}
function pv(e) {
  return e.map((t) => ({ role: t.role, content: qu(t) }));
}
const Qr = "reply";
class hv {
  constructor(t) {
    this.deps = t;
  }
  async sendMessages(t) {
    const { messages: n, abortSignal: r, body: i } = t, o = this.deps.getModelId();
    if (!o)
      throw new Error("请先在设置中添加模型");
    const a = await this.deps.getApiKey(o) ?? "";
    let s, u = !1;
    const c = () => {
      s !== void 0 && this.deps.invokeBackend("stopStream", { requestId: s }).catch(() => {
      });
    };
    r == null || r.addEventListener(
      "abort",
      () => {
        u = !0, c();
      },
      { once: !0 }
    );
    const l = {
      // 首块超时 90s（方案 D14：适配推理模型首 token 常超 30s）
      firstChunkTimeoutSecs: 90,
      onStart: (f) => {
        s = f.requestId, u && c();
      }
    };
    return new ReadableStream({
      start: async (f) => {
        const d = (m) => f.enqueue(m);
        d({ type: "start" });
        let p = !1;
        const h = () => {
          p && (d({ type: "text-end", id: Qr }), p = !1);
        };
        try {
          const m = await this.deps.invokeBackendStream(
            "streamChat",
            {
              modelId: o,
              apiKey: a,
              messages: pv(n),
              // 角色动作：roleKey 进 streamChat 参数（后端解析透传，P2.6 拼装双层提示词）
              ...i != null && i.roleKey ? { roleKey: i.roleKey } : {}
            },
            (k) => {
              const g = (k == null ? void 0 : k.text) ?? "";
              g !== "" && (p || (d({ type: "text-start", id: Qr }), p = !0), d({ type: "text-delta", id: Qr, delta: g }));
            },
            l
          );
          h(), d({
            type: "message-metadata",
            messageMetadata: { stopped: m == null ? void 0 : m.stopped, omitted: m == null ? void 0 : m.omitted }
          }), d({ type: "finish" }), f.close();
        } catch (m) {
          h(), d({
            type: "error",
            errorText: m instanceof Error ? m.message : String(m)
          }), f.close();
        }
      },
      // 中途取消读取（useChat.stop 已先触发 abortSignal → stopStream）
      cancel() {
      }
    });
  }
  /** 无重连语义：刷新/切换会话历史直接从数据库加载 */
  async reconnectToStream() {
    return null;
  }
}
const Va = "activeSessionId", qa = "activeModelId", $i = "applyInline";
function mv(e) {
  return e.displayText && e.displayText !== "" ? e.displayText : e.content;
}
function gv(e) {
  return e.map((t) => ({
    id: t.id,
    role: t.role === "assistant" ? "assistant" : t.role === "system" ? "system" : "user",
    metadata: {
      displayText: t.displayText ?? void 0,
      roleKey: t.roleKey ?? void 0
    },
    parts: [{ type: "text", text: mv(t) }]
  }));
}
function yv(e) {
  const [t, n] = ve([]), [r, i] = ve(null), o = Ve(null), a = ye((d) => {
    o.current = d, i(d);
  }, []), s = ye(async () => {
    var m, k;
    const { models: d } = await e.invokeBackend("listModels");
    n(d);
    const { value: p } = await e.invokeBackend("getSetting", {
      key: qa
    }), h = p && d.some((g) => g.id === p) ? p : ((m = d.find((g) => g.isDefault)) == null ? void 0 : m.id) ?? ((k = d[0]) == null ? void 0 : k.id) ?? null;
    a(h);
  }, [e, a]), u = ye(
    (d) => {
      a(d), e.invokeBackend("setSetting", { key: qa, value: d }).catch(() => {
      });
    },
    [e, a]
  ), c = ye(
    async (d) => {
      const { id: p } = await e.invokeBackend("saveModel", {
        id: d.id,
        name: d.name,
        provider: d.provider,
        modelId: d.modelId,
        baseUrl: d.baseUrl,
        contextWindow: d.contextWindow
      });
      return d.apiKey && d.apiKey !== "" && await e.secureStorage.set(`model:${p}`, d.apiKey), await s(), p;
    },
    [e, s]
  ), l = ye(
    async (d) => {
      await e.invokeBackend("deleteModel", { id: d }), await e.secureStorage.delete(`model:${d}`).catch(() => {
      }), await s();
    },
    [e, s]
  ), f = ye(
    async (d) => {
      await e.invokeBackend("setDefaultModel", { id: d }), await s();
    },
    [e, s]
  );
  return qe(() => {
    s().catch(() => {
    });
  }, [s]), Gt(
    () => ({
      models: t,
      activeModelId: r,
      activeModelIdRef: o,
      setActiveModel: u,
      saveModel: c,
      deleteModel: l,
      setDefaultModel: f,
      refresh: s
    }),
    [t, r, o, u, c, l, f, s]
  );
}
function bv(e) {
  const [t, n] = ve([]), [r, i] = ve(null), [o, a] = ve(!1), s = ye(async () => {
    const { sessions: d } = await e.invokeBackend("listSessions");
    n(d);
  }, [e]), u = ye(
    (d) => {
      i(d), d !== null && e.invokeBackend("setSetting", { key: Va, value: d }).catch(() => {
      });
    },
    [e]
  );
  qe(() => {
    let d = !1;
    return (async () => {
      var p;
      try {
        const { sessions: h } = await e.invokeBackend("listSessions");
        if (d) return;
        n(h);
        const { value: m } = await e.invokeBackend("getSetting", {
          key: Va
        });
        if (d) return;
        const k = m && h.some((g) => g.id === m) ? m : ((p = h[0]) == null ? void 0 : p.id) ?? null;
        k !== null && i(k);
      } catch {
      } finally {
        d || a(!0);
      }
    })(), () => {
      d = !0;
    };
  }, [e]);
  const c = ye(
    async (d) => {
      const { id: p } = await e.invokeBackend("createSession", {
        title: d ?? ""
      });
      return await s(), u(p), p;
    },
    [e, s, u]
  ), l = ye(
    async (d, p) => {
      await e.invokeBackend("renameSession", { id: d, title: p }), await s();
    },
    [e, s]
  ), f = ye(
    async (d) => {
      var h;
      await e.invokeBackend("deleteSession", { id: d });
      const p = t.filter((m) => m.id !== d);
      n(p), r === d && u(((h = p[0]) == null ? void 0 : h.id) ?? null);
    },
    [e, t, r, u]
  );
  return Gt(
    () => ({ sessions: t, activeId: r, loaded: o, activate: u, create: c, rename: l, remove: f, refresh: s }),
    [t, r, o, u, c, l, f, s]
  );
}
function vv(e) {
  const t = ye(
    async (i, o, a) => {
      await e.invokeBackend("appendMessage", {
        sessionId: i,
        role: "user",
        content: o,
        ...a != null && a.roleKey ? { roleKey: a.roleKey } : {},
        ...a != null && a.displayText ? { displayText: a.displayText } : {},
        ...a != null && a.metaJson ? { metaJson: a.metaJson } : {}
      });
    },
    [e]
  ), n = ye(
    async (i, o, a) => {
      const s = {};
      a.stopped && (s.stopped = !0), typeof a.omitted == "number" && a.omitted > 0 && (s.omitted = a.omitted), a.applied && (s.applied = !0, a.selectionOriginal && (s.selectionOriginal = a.selectionOriginal));
      const u = Object.keys(s).length > 0 ? JSON.stringify(s) : void 0;
      await e.invokeBackend("appendMessage", {
        sessionId: i,
        role: "assistant",
        content: o,
        metaJson: u
      });
    },
    [e]
  ), r = ye(
    async (i) => {
      const { messages: o } = await e.invokeBackend("listMessages", {
        sessionId: i
      });
      return gv(o);
    },
    [e]
  );
  return Gt(
    () => ({ appendUser: t, appendAssistant: n, loadMessages: r }),
    [t, n, r]
  );
}
function kv(e, t) {
  const n = {};
  return (e[e.length - 1] === "" ? [...e, ""] : e).join(
    (n.padRight ? " " : "") + "," + (n.padLeft === !1 ? "" : " ")
  ).trim();
}
const wv = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, xv = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, _v = {};
function Ja(e, t) {
  return (_v.jsx ? xv : wv).test(e);
}
const Sv = /[ \t\n\f\r]/g;
function Iv(e) {
  return typeof e == "object" ? e.type === "text" ? Wa(e.value) : !1 : Wa(e);
}
function Wa(e) {
  return e.replace(Sv, "") === "";
}
class jn {
  /**
   * @param {SchemaType['property']} property
   *   Property.
   * @param {SchemaType['normal']} normal
   *   Normal.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Schema.
   */
  constructor(t, n, r) {
    this.normal = n, this.property = t, r && (this.space = r);
  }
}
jn.prototype.normal = {};
jn.prototype.property = {};
jn.prototype.space = void 0;
function Ju(e, t) {
  const n = {}, r = {};
  for (const i of e)
    Object.assign(n, i.property), Object.assign(r, i.normal);
  return new jn(n, r, t);
}
function Ni(e) {
  return e.toLowerCase();
}
class $e {
  /**
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @returns
   *   Info.
   */
  constructor(t, n) {
    this.attribute = n, this.property = t;
  }
}
$e.prototype.attribute = "";
$e.prototype.booleanish = !1;
$e.prototype.boolean = !1;
$e.prototype.commaOrSpaceSeparated = !1;
$e.prototype.commaSeparated = !1;
$e.prototype.defined = !1;
$e.prototype.mustUseProperty = !1;
$e.prototype.number = !1;
$e.prototype.overloadedBoolean = !1;
$e.prototype.property = "";
$e.prototype.spaceSeparated = !1;
$e.prototype.space = void 0;
let Ev = 0;
const J = Zt(), be = Zt(), Di = Zt(), P = Zt(), ie = Zt(), $t = Zt(), De = Zt();
function Zt() {
  return 2 ** ++Ev;
}
const Li = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  boolean: J,
  booleanish: be,
  commaOrSpaceSeparated: De,
  commaSeparated: $t,
  number: P,
  overloadedBoolean: Di,
  spaceSeparated: ie
}, Symbol.toStringTag, { value: "Module" })), ei = (
  /** @type {ReadonlyArray<keyof typeof types>} */
  Object.keys(Li)
);
class yo extends $e {
  /**
   * @constructor
   * @param {string} property
   *   Property.
   * @param {string} attribute
   *   Attribute.
   * @param {number | null | undefined} [mask]
   *   Mask.
   * @param {Space | undefined} [space]
   *   Space.
   * @returns
   *   Info.
   */
  constructor(t, n, r, i) {
    let o = -1;
    if (super(t, n), Ha(this, "space", i), typeof r == "number")
      for (; ++o < ei.length; ) {
        const a = ei[o];
        Ha(this, ei[o], (r & Li[a]) === Li[a]);
      }
  }
}
yo.prototype.defined = !0;
function Ha(e, t, n) {
  n && (e[t] = n);
}
function an(e) {
  const t = {}, n = {};
  for (const [r, i] of Object.entries(e.properties)) {
    const o = new yo(
      r,
      e.transform(e.attributes || {}, r),
      i,
      e.space
    );
    e.mustUseProperty && e.mustUseProperty.includes(r) && (o.mustUseProperty = !0), t[r] = o, n[Ni(r)] = r, n[Ni(o.attribute)] = r;
  }
  return new jn(t, n, e.space);
}
const Wu = an({
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: be,
    ariaAutoComplete: null,
    ariaBusy: be,
    ariaChecked: be,
    ariaColCount: P,
    ariaColIndex: P,
    ariaColSpan: P,
    ariaControls: ie,
    ariaCurrent: null,
    ariaDescribedBy: ie,
    ariaDetails: null,
    ariaDisabled: be,
    ariaDropEffect: ie,
    ariaErrorMessage: null,
    ariaExpanded: be,
    ariaFlowTo: ie,
    ariaGrabbed: be,
    ariaHasPopup: null,
    ariaHidden: be,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: ie,
    ariaLevel: P,
    ariaLive: null,
    ariaModal: be,
    ariaMultiLine: be,
    ariaMultiSelectable: be,
    ariaOrientation: null,
    ariaOwns: ie,
    ariaPlaceholder: null,
    ariaPosInSet: P,
    ariaPressed: be,
    ariaReadOnly: be,
    ariaRelevant: null,
    ariaRequired: be,
    ariaRoleDescription: ie,
    ariaRowCount: P,
    ariaRowIndex: P,
    ariaRowSpan: P,
    ariaSelected: be,
    ariaSetSize: P,
    ariaSort: null,
    ariaValueMax: P,
    ariaValueMin: P,
    ariaValueNow: P,
    ariaValueText: null,
    role: null
  },
  transform(e, t) {
    return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
  }
});
function Hu(e, t) {
  return t in e ? e[t] : t;
}
function Ku(e, t) {
  return Hu(e, t.toLowerCase());
}
const Cv = an({
  attributes: {
    acceptcharset: "accept-charset",
    classname: "class",
    htmlfor: "for",
    httpequiv: "http-equiv"
  },
  mustUseProperty: ["checked", "multiple", "muted", "selected"],
  properties: {
    // Standard Properties.
    abbr: null,
    accept: $t,
    acceptCharset: ie,
    accessKey: ie,
    action: null,
    allow: null,
    allowFullScreen: J,
    allowPaymentRequest: J,
    allowUserMedia: J,
    alpha: J,
    alt: null,
    as: null,
    async: J,
    autoCapitalize: null,
    autoComplete: ie,
    autoFocus: J,
    autoPlay: J,
    blocking: ie,
    capture: null,
    charSet: null,
    checked: J,
    cite: null,
    className: ie,
    closedBy: null,
    colorSpace: null,
    cols: P,
    colSpan: P,
    command: null,
    commandFor: null,
    content: null,
    contentEditable: be,
    controls: J,
    controlsList: ie,
    coords: P | $t,
    crossOrigin: null,
    data: null,
    dateTime: null,
    decoding: null,
    default: J,
    defer: J,
    dir: null,
    dirName: null,
    disabled: J,
    download: Di,
    draggable: be,
    encType: null,
    enterKeyHint: null,
    fetchPriority: null,
    form: null,
    formAction: null,
    formEncType: null,
    formMethod: null,
    formNoValidate: J,
    formTarget: null,
    headers: ie,
    height: P,
    hidden: Di,
    high: P,
    href: null,
    hrefLang: null,
    htmlFor: ie,
    httpEquiv: ie,
    id: null,
    imageSizes: null,
    imageSrcSet: null,
    inert: J,
    inputMode: null,
    integrity: null,
    is: null,
    isMap: J,
    itemId: null,
    itemProp: ie,
    itemRef: ie,
    itemScope: J,
    itemType: ie,
    kind: null,
    label: null,
    lang: null,
    language: null,
    list: null,
    loading: null,
    loop: J,
    low: P,
    manifest: null,
    max: null,
    maxLength: P,
    media: null,
    method: null,
    min: null,
    minLength: P,
    multiple: J,
    muted: J,
    name: null,
    nonce: null,
    noModule: J,
    noValidate: J,
    onAbort: null,
    onAfterPrint: null,
    onAuxClick: null,
    onBeforeMatch: null,
    onBeforePrint: null,
    onBeforeToggle: null,
    onBeforeUnload: null,
    onBlur: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onContextLost: null,
    onContextMenu: null,
    onContextRestored: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFormData: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLanguageChange: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadEnd: null,
    onLoadStart: null,
    onMessage: null,
    onMessageError: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRejectionHandled: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onScrollEnd: null,
    onSecurityPolicyViolation: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onSlotChange: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnhandledRejection: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onWheel: null,
    open: J,
    optimum: P,
    pattern: null,
    ping: ie,
    placeholder: null,
    playsInline: J,
    popover: null,
    popoverTarget: null,
    popoverTargetAction: null,
    poster: null,
    preload: null,
    readOnly: J,
    referrerPolicy: null,
    rel: ie,
    required: J,
    reversed: J,
    rows: P,
    rowSpan: P,
    sandbox: ie,
    scope: null,
    scoped: J,
    seamless: J,
    selected: J,
    shadowRootClonable: J,
    shadowRootCustomElementRegistry: J,
    shadowRootDelegatesFocus: J,
    shadowRootMode: null,
    shadowRootSerializable: J,
    shape: null,
    size: P,
    sizes: null,
    slot: null,
    span: P,
    spellCheck: be,
    src: null,
    srcDoc: null,
    srcLang: null,
    srcSet: null,
    start: P,
    step: null,
    style: null,
    tabIndex: P,
    target: null,
    title: null,
    translate: null,
    type: null,
    typeMustMatch: J,
    useMap: null,
    value: be,
    width: P,
    wrap: null,
    writingSuggestions: null,
    // Legacy.
    // See: https://html.spec.whatwg.org/#other-elements,-attributes-and-apis
    align: null,
    // Several. Use CSS `text-align` instead,
    aLink: null,
    // `<body>`. Use CSS `a:active {color}` instead
    archive: ie,
    // `<object>`. List of URIs to archives
    axis: null,
    // `<td>` and `<th>`. Use `scope` on `<th>`
    background: null,
    // `<body>`. Use CSS `background-image` instead
    bgColor: null,
    // `<body>` and table elements. Use CSS `background-color` instead
    border: P,
    // `<table>`. Use CSS `border-width` instead,
    borderColor: null,
    // `<table>`. Use CSS `border-color` instead,
    bottomMargin: P,
    // `<body>`
    cellPadding: null,
    // `<table>`
    cellSpacing: null,
    // `<table>`
    char: null,
    // Several table elements. When `align=char`, sets the character to align on
    charOff: null,
    // Several table elements. When `char`, offsets the alignment
    classId: null,
    // `<object>`
    clear: null,
    // `<br>`. Use CSS `clear` instead
    code: null,
    // `<object>`
    codeBase: null,
    // `<object>`
    codeType: null,
    // `<object>`
    color: null,
    // `<font>` and `<hr>`. Use CSS instead
    compact: J,
    // Lists. Use CSS to reduce space between items instead
    declare: J,
    // `<object>`
    event: null,
    // `<script>`
    face: null,
    // `<font>`. Use CSS instead
    frame: null,
    // `<table>`
    frameBorder: null,
    // `<iframe>`. Use CSS `border` instead
    hSpace: P,
    // `<img>` and `<object>`
    leftMargin: P,
    // `<body>`
    link: null,
    // `<body>`. Use CSS `a:link {color: *}` instead
    longDesc: null,
    // `<frame>`, `<iframe>`, and `<img>`. Use an `<a>`
    lowSrc: null,
    // `<img>`. Use a `<picture>`
    marginHeight: P,
    // `<body>`
    marginWidth: P,
    // `<body>`
    noResize: J,
    // `<frame>`
    noHref: J,
    // `<area>`. Use no href instead of an explicit `nohref`
    noShade: J,
    // `<hr>`. Use background-color and height instead of borders
    noWrap: J,
    // `<td>` and `<th>`
    object: null,
    // `<applet>`
    profile: null,
    // `<head>`
    prompt: null,
    // `<isindex>`
    rev: null,
    // `<link>`
    rightMargin: P,
    // `<body>`
    rules: null,
    // `<table>`
    scheme: null,
    // `<meta>`
    scrolling: be,
    // `<frame>`. Use overflow in the child context
    standby: null,
    // `<object>`
    summary: null,
    // `<table>`
    text: null,
    // `<body>`. Use CSS `color` instead
    topMargin: P,
    // `<body>`
    valueType: null,
    // `<param>`
    version: null,
    // `<html>`. Use a doctype.
    vAlign: null,
    // Several. Use CSS `vertical-align` instead
    vLink: null,
    // `<body>`. Use CSS `a:visited {color}` instead
    vSpace: P,
    // `<img>` and `<object>`
    // Non-standard Properties.
    allowTransparency: null,
    autoCorrect: null,
    autoSave: null,
    credentialless: J,
    disablePictureInPicture: J,
    disableRemotePlayback: J,
    exportParts: $t,
    part: ie,
    prefix: null,
    property: null,
    results: P,
    security: null,
    unselectable: null
  },
  space: "html",
  transform: Ku
}), Av = an({
  attributes: {
    accentHeight: "accent-height",
    alignmentBaseline: "alignment-baseline",
    arabicForm: "arabic-form",
    baselineShift: "baseline-shift",
    capHeight: "cap-height",
    className: "class",
    clipPath: "clip-path",
    clipRule: "clip-rule",
    colorInterpolation: "color-interpolation",
    colorInterpolationFilters: "color-interpolation-filters",
    colorProfile: "color-profile",
    colorRendering: "color-rendering",
    crossOrigin: "crossorigin",
    dataType: "datatype",
    dominantBaseline: "dominant-baseline",
    enableBackground: "enable-background",
    fillOpacity: "fill-opacity",
    fillRule: "fill-rule",
    floodColor: "flood-color",
    floodOpacity: "flood-opacity",
    fontFamily: "font-family",
    fontSize: "font-size",
    fontSizeAdjust: "font-size-adjust",
    fontStretch: "font-stretch",
    fontStyle: "font-style",
    fontVariant: "font-variant",
    fontWeight: "font-weight",
    glyphName: "glyph-name",
    glyphOrientationHorizontal: "glyph-orientation-horizontal",
    glyphOrientationVertical: "glyph-orientation-vertical",
    hrefLang: "hreflang",
    horizAdvX: "horiz-adv-x",
    horizOriginX: "horiz-origin-x",
    horizOriginY: "horiz-origin-y",
    imageRendering: "image-rendering",
    letterSpacing: "letter-spacing",
    lightingColor: "lighting-color",
    markerEnd: "marker-end",
    markerMid: "marker-mid",
    markerStart: "marker-start",
    maskType: "mask-type",
    navDown: "nav-down",
    navDownLeft: "nav-down-left",
    navDownRight: "nav-down-right",
    navLeft: "nav-left",
    navNext: "nav-next",
    navPrev: "nav-prev",
    navRight: "nav-right",
    navUp: "nav-up",
    navUpLeft: "nav-up-left",
    navUpRight: "nav-up-right",
    onAbort: "onabort",
    onActivate: "onactivate",
    onAfterPrint: "onafterprint",
    onBeforePrint: "onbeforeprint",
    onBegin: "onbegin",
    onCancel: "oncancel",
    onCanPlay: "oncanplay",
    onCanPlayThrough: "oncanplaythrough",
    onChange: "onchange",
    onClick: "onclick",
    onClose: "onclose",
    onCopy: "oncopy",
    onCueChange: "oncuechange",
    onCut: "oncut",
    onDblClick: "ondblclick",
    onDrag: "ondrag",
    onDragEnd: "ondragend",
    onDragEnter: "ondragenter",
    onDragExit: "ondragexit",
    onDragLeave: "ondragleave",
    onDragOver: "ondragover",
    onDragStart: "ondragstart",
    onDrop: "ondrop",
    onDurationChange: "ondurationchange",
    onEmptied: "onemptied",
    onEnd: "onend",
    onEnded: "onended",
    onError: "onerror",
    onFocus: "onfocus",
    onFocusIn: "onfocusin",
    onFocusOut: "onfocusout",
    onHashChange: "onhashchange",
    onInput: "oninput",
    onInvalid: "oninvalid",
    onKeyDown: "onkeydown",
    onKeyPress: "onkeypress",
    onKeyUp: "onkeyup",
    onLoad: "onload",
    onLoadedData: "onloadeddata",
    onLoadedMetadata: "onloadedmetadata",
    onLoadStart: "onloadstart",
    onMessage: "onmessage",
    onMouseDown: "onmousedown",
    onMouseEnter: "onmouseenter",
    onMouseLeave: "onmouseleave",
    onMouseMove: "onmousemove",
    onMouseOut: "onmouseout",
    onMouseOver: "onmouseover",
    onMouseUp: "onmouseup",
    onMouseWheel: "onmousewheel",
    onOffline: "onoffline",
    onOnline: "ononline",
    onPageHide: "onpagehide",
    onPageShow: "onpageshow",
    onPaste: "onpaste",
    onPause: "onpause",
    onPlay: "onplay",
    onPlaying: "onplaying",
    onPopState: "onpopstate",
    onProgress: "onprogress",
    onRateChange: "onratechange",
    onRepeat: "onrepeat",
    onReset: "onreset",
    onResize: "onresize",
    onScroll: "onscroll",
    onSeeked: "onseeked",
    onSeeking: "onseeking",
    onSelect: "onselect",
    onShow: "onshow",
    onStalled: "onstalled",
    onStorage: "onstorage",
    onSubmit: "onsubmit",
    onSuspend: "onsuspend",
    onTimeUpdate: "ontimeupdate",
    onToggle: "ontoggle",
    onUnload: "onunload",
    onVolumeChange: "onvolumechange",
    onWaiting: "onwaiting",
    onZoom: "onzoom",
    overlinePosition: "overline-position",
    overlineThickness: "overline-thickness",
    paintOrder: "paint-order",
    panose1: "panose-1",
    pointerEvents: "pointer-events",
    referrerPolicy: "referrerpolicy",
    renderingIntent: "rendering-intent",
    shapeRendering: "shape-rendering",
    stopColor: "stop-color",
    stopOpacity: "stop-opacity",
    strikethroughPosition: "strikethrough-position",
    strikethroughThickness: "strikethrough-thickness",
    strokeDashArray: "stroke-dasharray",
    strokeDashOffset: "stroke-dashoffset",
    strokeLineCap: "stroke-linecap",
    strokeLineJoin: "stroke-linejoin",
    strokeMiterLimit: "stroke-miterlimit",
    strokeOpacity: "stroke-opacity",
    strokeWidth: "stroke-width",
    tabIndex: "tabindex",
    textAnchor: "text-anchor",
    textDecoration: "text-decoration",
    textRendering: "text-rendering",
    transformOrigin: "transform-origin",
    typeOf: "typeof",
    underlinePosition: "underline-position",
    underlineThickness: "underline-thickness",
    unicodeBidi: "unicode-bidi",
    unicodeRange: "unicode-range",
    unitsPerEm: "units-per-em",
    vAlphabetic: "v-alphabetic",
    vHanging: "v-hanging",
    vIdeographic: "v-ideographic",
    vMathematical: "v-mathematical",
    vectorEffect: "vector-effect",
    vertAdvY: "vert-adv-y",
    vertOriginX: "vert-origin-x",
    vertOriginY: "vert-origin-y",
    wordSpacing: "word-spacing",
    writingMode: "writing-mode",
    xHeight: "x-height",
    // These were camelcased in Tiny. Now lowercased in SVG 2
    playbackOrder: "playbackorder",
    timelineBegin: "timelinebegin"
  },
  properties: {
    about: De,
    accentHeight: P,
    accumulate: null,
    additive: null,
    alignmentBaseline: null,
    alphabetic: P,
    amplitude: P,
    arabicForm: null,
    ascent: P,
    attributeName: null,
    attributeType: null,
    azimuth: P,
    bandwidth: null,
    baselineShift: null,
    baseFrequency: null,
    baseProfile: null,
    bbox: null,
    begin: null,
    bias: P,
    by: null,
    calcMode: null,
    capHeight: P,
    className: ie,
    clip: null,
    clipPath: null,
    clipPathUnits: null,
    clipRule: null,
    color: null,
    colorInterpolation: null,
    colorInterpolationFilters: null,
    colorProfile: null,
    colorRendering: null,
    content: null,
    contentScriptType: null,
    contentStyleType: null,
    crossOrigin: null,
    cursor: null,
    cx: null,
    cy: null,
    d: null,
    dataType: null,
    defaultAction: null,
    descent: P,
    diffuseConstant: P,
    direction: null,
    display: null,
    dur: null,
    divisor: P,
    dominantBaseline: null,
    download: J,
    dx: null,
    dy: null,
    edgeMode: null,
    editable: null,
    elevation: P,
    enableBackground: null,
    end: null,
    event: null,
    exponent: P,
    externalResourcesRequired: null,
    fill: null,
    fillOpacity: P,
    fillRule: null,
    filter: null,
    filterRes: null,
    filterUnits: null,
    floodColor: null,
    floodOpacity: null,
    focusable: null,
    focusHighlight: null,
    fontFamily: null,
    fontSize: null,
    fontSizeAdjust: null,
    fontStretch: null,
    fontStyle: null,
    fontVariant: null,
    fontWeight: null,
    format: null,
    fr: null,
    from: null,
    fx: null,
    fy: null,
    g1: $t,
    g2: $t,
    glyphName: $t,
    glyphOrientationHorizontal: null,
    glyphOrientationVertical: null,
    glyphRef: null,
    gradientTransform: null,
    gradientUnits: null,
    handler: null,
    hanging: P,
    hatchContentUnits: null,
    hatchUnits: null,
    height: null,
    href: null,
    hrefLang: null,
    horizAdvX: P,
    horizOriginX: P,
    horizOriginY: P,
    id: null,
    ideographic: P,
    imageRendering: null,
    initialVisibility: null,
    in: null,
    in2: null,
    intercept: P,
    k: P,
    k1: P,
    k2: P,
    k3: P,
    k4: P,
    kernelMatrix: De,
    kernelUnitLength: null,
    keyPoints: null,
    // SEMI_COLON_SEPARATED
    keySplines: null,
    // SEMI_COLON_SEPARATED
    keyTimes: null,
    // SEMI_COLON_SEPARATED
    kerning: null,
    lang: null,
    lengthAdjust: null,
    letterSpacing: null,
    lightingColor: null,
    limitingConeAngle: P,
    local: null,
    markerEnd: null,
    markerMid: null,
    markerStart: null,
    markerHeight: null,
    markerUnits: null,
    markerWidth: null,
    mask: null,
    maskContentUnits: null,
    maskType: null,
    maskUnits: null,
    mathematical: null,
    max: null,
    media: null,
    mediaCharacterEncoding: null,
    mediaContentEncodings: null,
    mediaSize: P,
    mediaTime: null,
    method: null,
    min: null,
    mode: null,
    name: null,
    navDown: null,
    navDownLeft: null,
    navDownRight: null,
    navLeft: null,
    navNext: null,
    navPrev: null,
    navRight: null,
    navUp: null,
    navUpLeft: null,
    navUpRight: null,
    numOctaves: null,
    observer: null,
    offset: null,
    onAbort: null,
    onActivate: null,
    onAfterPrint: null,
    onBeforePrint: null,
    onBegin: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnd: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFocusIn: null,
    onFocusOut: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadStart: null,
    onMessage: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onMouseWheel: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRepeat: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onShow: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onZoom: null,
    opacity: null,
    operator: null,
    order: null,
    orient: null,
    orientation: null,
    origin: null,
    overflow: null,
    overlay: null,
    overlinePosition: P,
    overlineThickness: P,
    paintOrder: null,
    panose1: null,
    path: null,
    pathLength: P,
    patternContentUnits: null,
    patternTransform: null,
    patternUnits: null,
    phase: null,
    ping: ie,
    pitch: null,
    playbackOrder: null,
    pointerEvents: null,
    points: null,
    pointsAtX: P,
    pointsAtY: P,
    pointsAtZ: P,
    preserveAlpha: null,
    preserveAspectRatio: null,
    primitiveUnits: null,
    propagate: null,
    property: De,
    r: null,
    radius: null,
    referrerPolicy: null,
    refX: null,
    refY: null,
    rel: De,
    rev: De,
    renderingIntent: null,
    repeatCount: null,
    repeatDur: null,
    requiredExtensions: De,
    requiredFeatures: De,
    requiredFonts: De,
    requiredFormats: De,
    resource: null,
    restart: null,
    result: null,
    rotate: null,
    rx: null,
    ry: null,
    scale: null,
    seed: null,
    shapeRendering: null,
    side: null,
    slope: null,
    snapshotTime: null,
    specularConstant: P,
    specularExponent: P,
    spreadMethod: null,
    spacing: null,
    startOffset: null,
    stdDeviation: null,
    stemh: null,
    stemv: null,
    stitchTiles: null,
    stopColor: null,
    stopOpacity: null,
    strikethroughPosition: P,
    strikethroughThickness: P,
    string: null,
    stroke: null,
    strokeDashArray: De,
    strokeDashOffset: null,
    strokeLineCap: null,
    strokeLineJoin: null,
    strokeMiterLimit: P,
    strokeOpacity: P,
    strokeWidth: null,
    style: null,
    surfaceScale: P,
    syncBehavior: null,
    syncBehaviorDefault: null,
    syncMaster: null,
    syncTolerance: null,
    syncToleranceDefault: null,
    systemLanguage: De,
    tabIndex: P,
    tableValues: null,
    target: null,
    targetX: P,
    targetY: P,
    textAnchor: null,
    textDecoration: null,
    textRendering: null,
    textLength: null,
    timelineBegin: null,
    title: null,
    transformBehavior: null,
    type: null,
    typeOf: De,
    to: null,
    transform: null,
    transformOrigin: null,
    u1: null,
    u2: null,
    underlinePosition: P,
    underlineThickness: P,
    unicode: null,
    unicodeBidi: null,
    unicodeRange: null,
    unitsPerEm: P,
    values: null,
    vAlphabetic: P,
    vMathematical: P,
    vectorEffect: null,
    vHanging: P,
    vIdeographic: P,
    version: null,
    vertAdvY: P,
    vertOriginX: P,
    vertOriginY: P,
    viewBox: null,
    viewTarget: null,
    visibility: null,
    width: null,
    widths: null,
    wordSpacing: null,
    writingMode: null,
    x: null,
    x1: null,
    x2: null,
    xChannelSelector: null,
    xHeight: P,
    y: null,
    y1: null,
    y2: null,
    yChannelSelector: null,
    z: null,
    zoomAndPan: null
  },
  space: "svg",
  transform: Hu
}), Yu = an({
  properties: {
    xLinkActuate: null,
    xLinkArcRole: null,
    xLinkHref: null,
    xLinkRole: null,
    xLinkShow: null,
    xLinkTitle: null,
    xLinkType: null
  },
  space: "xlink",
  transform(e, t) {
    return "xlink:" + t.slice(5).toLowerCase();
  }
}), Gu = an({
  attributes: { xmlnsxlink: "xmlns:xlink" },
  properties: { xmlnsXLink: null, xmlns: null },
  space: "xmlns",
  transform: Ku
}), Xu = an({
  properties: { xmlBase: null, xmlLang: null, xmlSpace: null },
  space: "xml",
  transform(e, t) {
    return "xml:" + t.slice(3).toLowerCase();
  }
}), zv = {
  classId: "classID",
  dataType: "datatype",
  itemId: "itemID",
  strokeDashArray: "strokeDasharray",
  strokeDashOffset: "strokeDashoffset",
  strokeLineCap: "strokeLinecap",
  strokeLineJoin: "strokeLinejoin",
  strokeMiterLimit: "strokeMiterlimit",
  typeOf: "typeof",
  xLinkActuate: "xlinkActuate",
  xLinkArcRole: "xlinkArcrole",
  xLinkHref: "xlinkHref",
  xLinkRole: "xlinkRole",
  xLinkShow: "xlinkShow",
  xLinkTitle: "xlinkTitle",
  xLinkType: "xlinkType",
  xmlnsXLink: "xmlnsXlink"
}, Tv = /[A-Z]/g, Ka = /-[a-z]/g, Ov = /^data[-\w.:]+$/i;
function Pv(e, t) {
  const n = Ni(t);
  let r = t, i = $e;
  if (n in e.normal)
    return e.property[e.normal[n]];
  if (n.length > 4 && n.slice(0, 4) === "data" && Ov.test(t)) {
    if (t.charAt(4) === "-") {
      const o = t.slice(5).replace(Ka, Rv);
      r = "data" + o.charAt(0).toUpperCase() + o.slice(1);
    } else {
      const o = t.slice(4);
      if (!Ka.test(o)) {
        let a = o.replace(Tv, Mv);
        a.charAt(0) !== "-" && (a = "-" + a), t = "data" + a;
      }
    }
    i = yo;
  }
  return new i(r, t);
}
function Mv(e) {
  return "-" + e.toLowerCase();
}
function Rv(e) {
  return e.charAt(1).toUpperCase();
}
const $v = Ju([Wu, Cv, Yu, Gu, Xu], "html"), bo = Ju([Wu, Av, Yu, Gu, Xu], "svg");
function Nv(e) {
  return e.join(" ").trim();
}
var Ya = /\/\*(?:[^*]|\*(?!\/))*\*\//g, Dv = /\n/g, Lv = /^\s*/, Fv = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, jv = /^:\s*/, Zv = /^((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|url\((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|[^)]*)\)|[^};])+)/, Bv = /^[;\s]*/, Uv = `
`, Ga = "/", Xa = "*", mn = "", Vv = "comment", qv = "declaration";
function Jv(e, t) {
  if (typeof e != "string")
    throw new TypeError("First argument must be a string");
  if (!e) return [];
  t = t || {};
  var n = 1, r = 1;
  function i(h) {
    var m = h.match(Dv);
    m && (n += m.length);
    var k = h.lastIndexOf(Uv);
    r = ~k ? h.length - k : r + h.length;
  }
  function o() {
    var h = { line: n, column: r };
    return function(m) {
      return m.position = new a(h), c(), m;
    };
  }
  function a(h) {
    this.start = h, this.end = { line: n, column: r }, this.source = t.source;
  }
  a.prototype.content = e;
  function s(h) {
    var m = new Error(
      t.source + ":" + n + ":" + r + ": " + h
    );
    if (m.reason = h, m.filename = t.source, m.line = n, m.column = r, m.source = e, !t.silent) throw m;
  }
  function u(h) {
    var m = h.exec(e);
    if (m) {
      var k = m[0];
      return i(k), e = e.slice(k.length), m;
    }
  }
  function c() {
    u(Lv);
  }
  function l(h) {
    for (var m; m = f(); )
      h.push(m);
    return h;
  }
  function f() {
    var h = o();
    if (!(Ga != e.charAt(0) || Xa != e.charAt(1))) {
      for (var m = 2; mn != e.charAt(m) && (Xa != e.charAt(m) || Ga != e.charAt(m + 1)); )
        ++m;
      if (m += 2, mn === e.charAt(m - 1))
        return s("End of comment missing");
      var k = e.slice(2, m - 2);
      return r += 2, i(k), e = e.slice(m), r += 2, h({
        type: Vv,
        comment: k
      });
    }
  }
  function d() {
    var h = o(), m = u(Fv);
    if (m) {
      if (f(), !u(jv)) return s("property missing ':'");
      var k = u(Zv), g = h({
        type: qv,
        property: m[0].replace(Ya, mn).trim(),
        value: k ? k[0].replace(Ya, mn).trim() : mn
      });
      return u(Bv), g;
    }
  }
  function p() {
    var h = [];
    l(h);
    for (var m; m = d(); )
      h.push(m), l(h);
    return h;
  }
  return c(), p();
}
function Wv(e, t) {
  let n = null;
  if (!e || typeof e != "string") return n;
  const r = Jv(e), i = typeof t == "function";
  return r.forEach((o) => {
    if (o.type !== "declaration") return;
    const { property: a, value: s } = o;
    i ? t(a, s, o) : s && (n = n ?? {}, n[a] = s);
  }), n;
}
const Qu = ec("end"), vo = ec("start");
function ec(e) {
  return t;
  function t(n) {
    const r = n && n.position && n.position[e] || {};
    if (typeof r.line == "number" && r.line > 0 && typeof r.column == "number" && r.column > 0)
      return {
        line: r.line,
        column: r.column,
        offset: typeof r.offset == "number" && r.offset > -1 ? r.offset : void 0
      };
  }
}
function Hv(e) {
  const t = vo(e), n = Qu(e);
  if (t && n)
    return { start: t, end: n };
}
function An(e) {
  return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? Qa(e.position) : "start" in e || "end" in e ? Qa(e) : "line" in e || "column" in e ? Fi(e) : "";
}
function Fi(e) {
  return es(e && e.line) + ":" + es(e && e.column);
}
function Qa(e) {
  return Fi(e && e.start) + "-" + Fi(e && e.end);
}
function es(e) {
  return e && typeof e == "number" ? e : 1;
}
class Tr extends Error {
  /**
   * Create a message for `reason`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Options | null | undefined} [options]
   *   Configuration (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | null | undefined} parent
   *   Node or node-like, used for `ancestors` and `place`.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {Point | Position | null | undefined} place
   *   Place of message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {string} reason
   *   Reason for message, should use markdown.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {Node | NodeLike | null | undefined} parent
   *   Node or node-like, used for `ancestors` and `place`.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {Point | Position | null | undefined} place
   *   Place of message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @overload
   * @param {Error | VFileMessage} cause
   *   Original error cause of the message.
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (optional).
   * @returns
   *   Instance of `VFileMessage`.
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | Options | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns
   *   Instance of `VFileMessage`.
   */
  // eslint-disable-next-line complexity
  constructor(t, n, r) {
    super(), typeof n == "string" && (r = n, n = void 0);
    let i = "", o = {}, a = !1;
    if (n && ("line" in n && "column" in n ? o = { place: n } : "start" in n && "end" in n ? o = { place: n } : "type" in n ? o = {
      ancestors: [n],
      place: n.position
    } : o = { ...n }), typeof t == "string" ? i = t : !o.cause && t && (a = !0, i = t.message, o.cause = t), !o.ruleId && !o.source && typeof r == "string") {
      const u = r.indexOf(":");
      u === -1 ? o.ruleId = r : (o.source = r.slice(0, u), o.ruleId = r.slice(u + 1));
    }
    if (!o.place && o.ancestors) {
      const u = o.ancestors[o.ancestors.length - 1];
      u && (o.place = u.position);
    }
    const s = o.place && "start" in o.place ? o.place.start : o.place;
    this.ancestors = o.ancestors || void 0, this.cause = o.cause || void 0, this.column = s ? s.column : void 0, this.fatal = void 0, this.file = "", this.message = i, this.line = s ? s.line : void 0, this.name = An(o.place) || "1:1", this.place = o.place || void 0, this.reason = this.message, this.ruleId = o.ruleId || void 0, this.source = o.source || void 0, this.stack = a && o.cause && typeof o.cause.stack == "string" ? o.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
  }
}
Object.defineProperties(Tr.prototype, {
  file: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  name: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  reason: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  message: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  stack: { configurable: !0, enumerable: !0, value: "", writable: !0 },
  column: { configurable: !0, enumerable: !0, writable: !0 },
  line: { configurable: !0, enumerable: !0, writable: !0 },
  ancestors: { configurable: !0, enumerable: !0, writable: !0 },
  cause: { configurable: !0, enumerable: !0, writable: !0 },
  fatal: { configurable: !0, enumerable: !0, writable: !0 },
  place: { configurable: !0, enumerable: !0, writable: !0 },
  ruleId: { configurable: !0, enumerable: !0, writable: !0 },
  source: { configurable: !0, enumerable: !0, writable: !0 }
});
const ko = {}.hasOwnProperty, Kv = /* @__PURE__ */ new Map(), Yv = /[A-Z]/g, Gv = /-([a-z])/g, Xv = /* @__PURE__ */ new Set(["table", "tbody", "thead", "tfoot", "tr"]), Qv = /* @__PURE__ */ new Set(["td", "th"]), tc = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function ek(e, t) {
  if (!t || t.Fragment === void 0)
    throw new TypeError("Expected `Fragment` in options");
  const n = t.filePath || void 0;
  let r;
  if (t.development) {
    if (typeof t.jsxDEV != "function")
      throw new TypeError(
        "Expected `jsxDEV` in options when `development: true`"
      );
    r = lk(n, t.jsxDEV);
  } else {
    if (typeof t.jsx != "function")
      throw new TypeError("Expected `jsx` in production options");
    if (typeof t.jsxs != "function")
      throw new TypeError("Expected `jsxs` in production options");
    r = sk(n, t.jsx, t.jsxs);
  }
  const i = {
    Fragment: t.Fragment,
    ancestors: [],
    components: t.components || {},
    create: r,
    elementAttributeNameCase: t.elementAttributeNameCase || "react",
    evaluater: t.createEvaluater ? t.createEvaluater() : void 0,
    filePath: n,
    ignoreInvalidStyle: t.ignoreInvalidStyle || !1,
    passKeys: t.passKeys !== !1,
    passNode: t.passNode || !1,
    schema: t.space === "svg" ? bo : $v,
    stylePropertyNameCase: t.stylePropertyNameCase || "dom",
    tableCellAlignToStyle: t.tableCellAlignToStyle !== !1
  }, o = nc(i, e, void 0);
  return o && typeof o != "string" ? o : i.create(
    e,
    i.Fragment,
    { children: o || void 0 },
    void 0
  );
}
function nc(e, t, n) {
  if (t.type === "element")
    return tk(e, t, n);
  if (t.type === "mdxFlowExpression" || t.type === "mdxTextExpression")
    return nk(e, t);
  if (t.type === "mdxJsxFlowElement" || t.type === "mdxJsxTextElement")
    return ik(e, t, n);
  if (t.type === "mdxjsEsm")
    return rk(e, t);
  if (t.type === "root")
    return ok(e, t, n);
  if (t.type === "text")
    return ak(e, t);
}
function tk(e, t, n) {
  const r = e.schema;
  let i = r;
  t.tagName.toLowerCase() === "svg" && r.space === "html" && (i = bo, e.schema = i), e.ancestors.push(t);
  const o = ic(e, t.tagName, !1), a = uk(e, t);
  let s = xo(e, t);
  return Xv.has(t.tagName) && (s = s.filter(function(u) {
    return typeof u == "string" ? !Iv(u) : !0;
  })), rc(e, a, o, t), wo(a, s), e.ancestors.pop(), e.schema = r, e.create(t, o, a, n);
}
function nk(e, t) {
  if (t.data && t.data.estree && e.evaluater) {
    const r = t.data.estree.body[0];
    return r.type, /** @type {Child | undefined} */
    e.evaluater.evaluateExpression(r.expression);
  }
  Nn(e, t.position);
}
function rk(e, t) {
  if (t.data && t.data.estree && e.evaluater)
    return (
      /** @type {Child | undefined} */
      e.evaluater.evaluateProgram(t.data.estree)
    );
  Nn(e, t.position);
}
function ik(e, t, n) {
  const r = e.schema;
  let i = r;
  t.name === "svg" && r.space === "html" && (i = bo, e.schema = i), e.ancestors.push(t);
  const o = t.name === null ? e.Fragment : ic(e, t.name, !0), a = ck(e, t), s = xo(e, t);
  return rc(e, a, o, t), wo(a, s), e.ancestors.pop(), e.schema = r, e.create(t, o, a, n);
}
function ok(e, t, n) {
  const r = {};
  return wo(r, xo(e, t)), e.create(t, e.Fragment, r, n);
}
function ak(e, t) {
  return t.value;
}
function rc(e, t, n, r) {
  typeof n != "string" && n !== e.Fragment && e.passNode && (t.node = r);
}
function wo(e, t) {
  if (t.length > 0) {
    const n = t.length > 1 ? t : t[0];
    n && (e.children = n);
  }
}
function sk(e, t, n) {
  return r;
  function r(i, o, a, s) {
    const c = Array.isArray(a.children) ? n : t;
    return s ? c(o, a, s) : c(o, a);
  }
}
function lk(e, t) {
  return n;
  function n(r, i, o, a) {
    const s = Array.isArray(o.children), u = vo(r);
    return t(
      i,
      o,
      a,
      s,
      {
        columnNumber: u ? u.column - 1 : void 0,
        fileName: e,
        lineNumber: u ? u.line : void 0
      },
      void 0
    );
  }
}
function uk(e, t) {
  const n = {};
  let r, i;
  for (i in t.properties)
    if (i !== "children" && ko.call(t.properties, i)) {
      const o = fk(e, i, t.properties[i]);
      if (o) {
        const [a, s] = o;
        e.tableCellAlignToStyle && a === "align" && typeof s == "string" && Qv.has(t.tagName) ? r = s : n[a] = s;
      }
    }
  if (r) {
    const o = (
      /** @type {Style} */
      n.style || (n.style = {})
    );
    o[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = r;
  }
  return n;
}
function ck(e, t) {
  const n = {};
  for (const r of t.attributes)
    if (r.type === "mdxJsxExpressionAttribute")
      if (r.data && r.data.estree && e.evaluater) {
        const o = r.data.estree.body[0];
        o.type;
        const a = o.expression;
        a.type;
        const s = a.properties[0];
        s.type, Object.assign(
          n,
          e.evaluater.evaluateExpression(s.argument)
        );
      } else
        Nn(e, t.position);
    else {
      const { name: i } = r;
      let o;
      if (r.value && typeof r.value == "object")
        if (r.value.data && r.value.data.estree && e.evaluater) {
          const s = r.value.data.estree.body[0];
          s.type, o = e.evaluater.evaluateExpression(s.expression);
        } else
          Nn(e, t.position);
      else
        o = r.value === null ? !0 : r.value;
      n[i] = /** @type {Props[keyof Props]} */
      o;
    }
  return n;
}
function xo(e, t) {
  const n = [];
  let r = -1;
  const i = e.passKeys ? /* @__PURE__ */ new Map() : Kv;
  for (; ++r < t.children.length; ) {
    const o = t.children[r];
    let a;
    if (e.passKeys) {
      const u = o.type === "element" ? o.tagName : o.type === "mdxJsxFlowElement" || o.type === "mdxJsxTextElement" ? o.name : void 0;
      if (u) {
        const c = i.get(u) || 0;
        a = u + "-" + c, i.set(u, c + 1);
      }
    }
    const s = nc(e, o, a);
    s !== void 0 && n.push(s);
  }
  return n;
}
function fk(e, t, n) {
  if (n == null || typeof n == "number" && Number.isNaN(n))
    return;
  const r = Pv(e.schema, t);
  return Array.isArray(n) && (n = r.commaSeparated ? kv(n) : Nv(n)), r.property === "style" ? ["style", typeof n == "object" ? e.stylePropertyNameCase === "dom" ? n : pk(n) : dk(e, String(n))] : [
    e.elementAttributeNameCase === "react" && r.space ? zv[r.property] || r.property : r.attribute,
    n
  ];
}
function dk(e, t) {
  const n = {};
  try {
    Wv(t, function(r, i) {
      if (r && i) {
        let o = r;
        o.slice(0, 2) !== "--" && (o = o.toLowerCase(), e.stylePropertyNameCase === "dom" && (o.slice(0, 4) === "-ms-" && (o = o.slice(1)), o = o.replace(Gv, gk))), n[o] = i;
      }
    });
  } catch (r) {
    if (e.ignoreInvalidStyle)
      return {};
    const i = (
      /** @type {Error} */
      r
    ), o = new Tr("Cannot parse `style` attribute", {
      ancestors: e.ancestors,
      cause: i,
      ruleId: "style",
      source: "hast-util-to-jsx-runtime"
    });
    throw o.file = e.filePath || void 0, o.url = tc + "#cannot-parse-style-attribute", o;
  }
  return n;
}
function ic(e, t, n) {
  let r;
  if (!n)
    r = { type: "Literal", value: t };
  else if (t.includes(".")) {
    const i = t.split(".");
    let o = -1, a;
    for (; ++o < i.length; ) {
      const s = Ja(i[o]) ? { type: "Identifier", name: i[o] } : { type: "Literal", value: i[o] };
      a = a ? {
        type: "MemberExpression",
        object: a,
        property: s,
        computed: !!(o && s.type === "Literal"),
        optional: !1
      } : s;
    }
    r = a;
  } else
    r = Ja(t) && !/^[a-z]/.test(t) ? { type: "Identifier", name: t } : { type: "Literal", value: t };
  if (r.type === "Literal") {
    const i = (
      /** @type {string | number} */
      r.value
    );
    return ko.call(e.components, i) ? e.components[i] : i;
  }
  if (e.evaluater)
    return e.evaluater.evaluateExpression(r);
  Nn(e);
}
function Nn(e, t) {
  const n = new Tr(
    "Cannot handle MDX estrees without `createEvaluater`",
    {
      ancestors: e.ancestors,
      place: t,
      ruleId: "mdx-estree",
      source: "hast-util-to-jsx-runtime"
    }
  );
  throw n.file = e.filePath || void 0, n.url = tc + "#cannot-handle-mdx-estrees-without-createevaluater", n;
}
function pk(e) {
  const t = {};
  let n;
  for (n in e)
    ko.call(e, n) && (t[hk(n)] = e[n]);
  return t;
}
function hk(e) {
  if (e.slice(0, 2) === "--") return e;
  let t = e.replace(Yv, mk);
  return t.slice(0, 3) === "ms-" && (t = "-" + t), t;
}
function mk(e) {
  return "-" + e.toLowerCase();
}
function gk(e, t) {
  return t.toUpperCase();
}
const ti = {
  action: ["form"],
  cite: ["blockquote", "del", "ins", "q"],
  data: ["object"],
  formAction: ["button", "input"],
  href: ["a", "area", "base", "link"],
  icon: ["menuitem"],
  itemId: null,
  manifest: ["html"],
  ping: ["a", "area"],
  poster: ["video"],
  src: [
    "audio",
    "embed",
    "iframe",
    "img",
    "input",
    "script",
    "source",
    "track",
    "video"
  ]
}, yk = {};
function Or(e, t) {
  const n = yk, r = typeof n.includeImageAlt == "boolean" ? n.includeImageAlt : !0, i = typeof n.includeHtml == "boolean" ? n.includeHtml : !0;
  return oc(e, r, i);
}
function oc(e, t, n) {
  if (bk(e)) {
    if ("value" in e)
      return e.type === "html" && !n ? "" : e.value;
    if (t && "alt" in e && e.alt)
      return e.alt;
    if ("children" in e)
      return ts(e.children, t, n);
  }
  return Array.isArray(e) ? ts(e, t, n) : "";
}
function ts(e, t, n) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; )
    r[i] = oc(e[i], t, n);
  return r.join("");
}
function bk(e) {
  return !!(e && typeof e == "object");
}
const ns = document.createElement("i");
function _o(e) {
  const t = "&" + e + ";";
  ns.innerHTML = t;
  const n = ns.textContent;
  return n.charCodeAt(n.length - 1) === 59 && e !== "semi" || n === t ? !1 : n;
}
function Qe(e, t, n, r) {
  const i = e.length;
  let o = 0, a;
  if (t < 0 ? t = -t > i ? 0 : i + t : t = t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4)
    a = Array.from(r), a.unshift(t, n), e.splice(...a);
  else
    for (n && e.splice(t, n); o < r.length; )
      a = r.slice(o, o + 1e4), a.unshift(t, 0), e.splice(...a), o += 1e4, t += 1e4;
}
function Je(e, t) {
  return e.length > 0 ? (Qe(e, e.length, 0, t), e) : t;
}
const rs = {}.hasOwnProperty;
function ac(e) {
  const t = {};
  let n = -1;
  for (; ++n < e.length; )
    vk(t, e[n]);
  return t;
}
function vk(e, t) {
  let n;
  for (n in t) {
    const i = (rs.call(e, n) ? e[n] : void 0) || (e[n] = {}), o = t[n];
    let a;
    if (o)
      for (a in o) {
        rs.call(i, a) || (i[a] = []);
        const s = o[a];
        kk(
          // @ts-expect-error Looks like a list.
          i[a],
          Array.isArray(s) ? s : s ? [s] : []
        );
      }
  }
}
function kk(e, t) {
  let n = -1;
  const r = [];
  for (; ++n < t.length; )
    (t[n].add === "after" ? e : r).push(t[n]);
  Qe(e, 0, 0, r);
}
function sc(e, t) {
  const n = Number.parseInt(e, t);
  return (
    // C0 except for HT, LF, FF, CR, space.
    n < 9 || n === 11 || n > 13 && n < 32 || // Control character (DEL) of C0, and C1 controls.
    n > 126 && n < 160 || // Lone high surrogates and low surrogates.
    n > 55295 && n < 57344 || // Noncharacters.
    n > 64975 && n < 65008 || /* eslint-disable no-bitwise */
    (n & 65535) === 65535 || (n & 65535) === 65534 || /* eslint-enable no-bitwise */
    // Out of range
    n > 1114111 ? "�" : String.fromCodePoint(n)
  );
}
function et(e) {
  return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
const we = At(/[A-Za-z]/), xe = At(/[\dA-Za-z]/), wk = At(/[#-'*+\--9=?A-Z^-~]/);
function vr(e) {
  return (
    // Special whitespace codes (which have negative values), C0 and Control
    // character DEL
    e !== null && (e < 32 || e === 127)
  );
}
const ji = At(/\d/), xk = At(/[\dA-Fa-f]/), lc = At(/[!-/:-@[-`{-~]/);
function q(e) {
  return e !== null && e < -2;
}
function ae(e) {
  return e !== null && (e < 0 || e === 32);
}
function X(e) {
  return e === -2 || e === -1 || e === 32;
}
const Zn = At(new RegExp("\\p{P}|\\p{S}", "u")), jt = At(/\s/);
function At(e) {
  return t;
  function t(n) {
    return n !== null && n > -1 && e.test(String.fromCharCode(n));
  }
}
function sn(e) {
  const t = [];
  let n = -1, r = 0, i = 0;
  for (; ++n < e.length; ) {
    const o = e.charCodeAt(n);
    let a = "";
    if (o === 37 && xe(e.charCodeAt(n + 1)) && xe(e.charCodeAt(n + 2)))
      i = 2;
    else if (o < 128)
      /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) || (a = String.fromCharCode(o));
    else if (o > 55295 && o < 57344) {
      const s = e.charCodeAt(n + 1);
      o < 56320 && s > 56319 && s < 57344 ? (a = String.fromCharCode(o, s), i = 1) : a = "�";
    } else
      a = String.fromCharCode(o);
    a && (t.push(e.slice(r, n), encodeURIComponent(a)), r = n + i + 1, a = ""), i && (n += i, i = 0);
  }
  return t.join("") + e.slice(r);
}
function ne(e, t, n, r) {
  const i = r ? r - 1 : 1 / 0;
  let o = 0;
  return a;
  function a(u) {
    return X(u) ? (e.enter(n), s(u)) : t(u);
  }
  function s(u) {
    return X(u) && o++ < i ? (e.consume(u), s) : (e.exit(n), t(u));
  }
}
function uc(e, t, n, r, i, o) {
  let a = 0;
  return s;
  function s(l) {
    return X(l) ? (e.enter(r), u(l)) : c(l);
  }
  function u(l) {
    return X(l) && a < o ? (e.consume(l), a++, u) : (e.exit(r), c(l));
  }
  function c(l) {
    return a >= i ? t(l) : n(l);
  }
}
const _k = {
  tokenize: Sk
};
function Sk(e) {
  const t = e.attempt(this.parser.constructs.contentInitial, r, i);
  let n;
  return t;
  function r(s) {
    if (s === null) {
      e.consume(s);
      return;
    }
    return e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), ne(e, t, "linePrefix");
  }
  function i(s) {
    return e.enter("paragraph"), o(s);
  }
  function o(s) {
    const u = e.enter("chunkText", {
      contentType: "text",
      previous: n
    });
    return n && (n.next = u), n = u, a(s);
  }
  function a(s) {
    if (s === null) {
      e.exit("chunkText"), e.exit("paragraph"), e.consume(s);
      return;
    }
    return q(s) ? (e.consume(s), e.exit("chunkText"), o) : (e.consume(s), a);
  }
}
let kr = class {
  /**
   * Create a new edit map.
   *
   * @returns
   *   New instance.
   */
  constructor() {
    this.index = /* @__PURE__ */ new Map(), this.map = [];
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  add(t, n, r) {
    is(this, t, n, r, !1);
  }
  /**
   * Create an edit: but insert `add` before existing additions, instead of
   * after them.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  addBefore(t, n, r) {
    is(this, t, n, r, !0);
  }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   *   List of events to apply the edits to.
   * @returns {undefined}
   *   Nothing.
   */
  consume(t) {
    if (this.map.sort(function(o, a) {
      return o[0] - a[0];
    }), this.map.length === 0)
      return;
    let n = this.map.length;
    const r = [];
    for (; n > 0; )
      n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
    r.push(t.slice()), t.length = 0;
    let i = r.pop();
    for (; i; ) {
      for (const o of i)
        t.push(o);
      i = r.pop();
    }
    this.map.length = 0, this.index.clear();
  }
};
function is(e, t, n, r, i) {
  if (n === 0 && r.length === 0)
    return;
  const o = e.index.get(t);
  if (o) {
    o[1] += n, i ? (r.push(...o[2]), o[2] = r) : o[2].push(...r);
    return;
  }
  const a = [t, n, r];
  e.map.push(a), e.index.set(t, a);
}
const Ik = {
  tokenize: Ek
}, os = {
  tokenize: Ck
};
function Ek(e) {
  const t = this, n = [];
  let r = 0, i, o, a;
  return s;
  function s(w) {
    if (r < n.length) {
      const C = n[r];
      return t.containerState = C[1], e.attempt(C[0].continuation, u, c)(w);
    }
    return c(w);
  }
  function u(w) {
    if (r++, t.containerState._closeFlow) {
      t.containerState._closeFlow = void 0, i && _();
      const C = t.events.length;
      let I = C, y;
      for (; I--; )
        if (t.events[I][0] === "exit" && t.events[I][1].type === "chunkFlow") {
          y = t.events[I][1].end;
          break;
        }
      g(r);
      let E = C;
      for (; E < t.events.length; )
        t.events[E][1].end = {
          ...y
        }, E++;
      const R = new kr();
      return R.add(I + 1, 0, t.events.slice(C)), R.add(C, E - C, []), R.consume(t.events), c(w);
    }
    return s(w);
  }
  function c(w) {
    if (r === n.length) {
      if (!i)
        return d(w);
      if (i.currentConstruct && i.currentConstruct.concrete)
        return h(w);
      t.interrupt = !!(i.currentConstruct && !i._gfmTableDynamicInterruptHack);
    }
    return t.containerState = {}, e.check(os, l, f)(w);
  }
  function l(w) {
    return i && _(), g(r), d(w);
  }
  function f(w) {
    return t.parser.lazy[t.now().line] = r !== n.length, a = t.now().offset, h(w);
  }
  function d(w) {
    return t.containerState = {}, e.attempt(os, p, h)(w);
  }
  function p(w) {
    return r++, n.push([t.currentConstruct, t.containerState]), d(w);
  }
  function h(w) {
    if (w === null) {
      i && _(), g(0), e.consume(w);
      return;
    }
    return i = i || t.parser.flow(t.now()), e.enter("chunkFlow", {
      _tokenizer: i,
      contentType: "flow",
      previous: o
    }), m(w);
  }
  function m(w) {
    if (w === null) {
      k(e.exit("chunkFlow"), !0), g(0), e.consume(w);
      return;
    }
    return q(w) ? (e.consume(w), k(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(w), m);
  }
  function k(w, C) {
    const I = t.sliceStream(w);
    if (C && I.push(null), w.previous = o, o && (o.next = w), o = w, i.defineSkip(w.start), i.write(I), t.parser.lazy[w.start.line]) {
      let y = i.events.length;
      for (; y--; )
        if (
          // The token starts before the line ending…
          i.events[y][1].start.offset < a && // …and either is not ended yet…
          (!i.events[y][1].end || // …or ends after it.
          i.events[y][1].end.offset > a)
        )
          return;
      const E = t.events.length;
      let R = E, F, S;
      for (; R--; )
        if (t.events[R][0] === "exit" && t.events[R][1].type === "chunkFlow") {
          if (F) {
            S = t.events[R][1].end;
            break;
          }
          F = !0;
        }
      for (g(r), y = E; y < t.events.length; )
        t.events[y][1].end = {
          ...S
        }, y++;
      const M = new kr();
      M.add(R + 1, 0, t.events.slice(E)), M.add(E, y - E, []), M.consume(t.events);
    }
  }
  function g(w) {
    let C = n.length;
    for (; C-- > w; ) {
      const I = n[C];
      t.containerState = I[1], I[0].exit.call(t, e);
    }
    n.length = w;
  }
  function _() {
    i.write([null]), o = void 0, i = void 0, t.containerState._closeFlow = void 0;
  }
}
function Ck(e, t, n) {
  return ne(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
function Et(e) {
  if (e === null || ae(e) || jt(e))
    return 1;
  if (Zn(e))
    return 2;
}
function Pr(e, t, n) {
  const r = [];
  let i = -1;
  for (; ++i < e.length; ) {
    const o = e[i].resolveAll;
    o && !r.includes(o) && (t = o(t, n), r.push(o));
  }
  return t;
}
const Zi = {
  name: "attention",
  resolveAll: Ak,
  tokenize: zk
};
function Ak(e, t) {
  let n = -1, r;
  for (; ++n < e.length; )
    if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
      let i = n;
      for (; i--; )
        if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && // If the markers are the same:
        t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
          if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3))
            continue;
          const o = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, a = {
            ...e[i][1].end
          }, s = {
            ...e[n][1].start
          };
          as(a, -o), as(s, o);
          const u = {
            type: o > 1 ? "strongSequence" : "emphasisSequence",
            start: a,
            end: {
              ...e[i][1].end
            }
          }, c = {
            type: o > 1 ? "strongSequence" : "emphasisSequence",
            start: {
              ...e[n][1].start
            },
            end: s
          }, l = {
            type: o > 1 ? "strongText" : "emphasisText",
            start: {
              ...e[i][1].end
            },
            end: {
              ...e[n][1].start
            }
          }, f = {
            type: o > 1 ? "strong" : "emphasis",
            start: {
              ...u.start
            },
            end: {
              ...c.end
            }
          };
          e[i][1].end = {
            ...u.start
          }, e[n][1].start = {
            ...c.end
          }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = Je(r, [["enter", e[i][1], t], ["exit", e[i][1], t]])), r = Je(r, [["enter", f, t], ["enter", u, t], ["exit", u, t], ["enter", l, t]]), r = Je(r, Pr(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = Je(r, [["exit", l, t], ["enter", c, t], ["exit", c, t], ["exit", f, t]]);
          let d = 0;
          e[n][1].end.offset - e[n][1].start.offset && (d = 2, r = Je(r, [["enter", e[n][1], t], ["exit", e[n][1], t]])), Qe(e, i - 1, n - i + 3, r), n = i + r.length - d - 2;
          break;
        }
    }
  for (n = -1; ++n < e.length; )
    e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
  return e;
}
function zk(e, t) {
  const n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = Et(r);
  let o;
  return a;
  function a(u) {
    return o = u, e.enter("attentionSequence"), s(u);
  }
  function s(u) {
    if (u === o)
      return e.consume(u), s;
    const c = e.exit("attentionSequence"), l = Et(u), f = !l || l === 2 && i || n.includes(u) && u !== 42 && u !== 95, d = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
    return c._open = !!(o === 42 ? f : f && (i || !d)), c._close = !!(o === 42 ? d : d && (l || !f)), t(u);
  }
}
function as(e, t) {
  e.column += t, e.offset += t, e._bufferIndex += t;
}
const Tk = {
  name: "autolink",
  tokenize: Ok
};
function Ok(e, t, n) {
  let r = 0;
  return i;
  function i(p) {
    return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(p), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), o;
  }
  function o(p) {
    return we(p) ? (e.consume(p), a) : p === 64 ? n(p) : c(p);
  }
  function a(p) {
    return p === 43 || p === 45 || p === 46 || xe(p) ? (r = 1, s(p)) : c(p);
  }
  function s(p) {
    return p === 58 ? (e.consume(p), r = 0, u) : (p === 43 || p === 45 || p === 46 || xe(p)) && r++ < 32 ? (e.consume(p), s) : (r = 0, c(p));
  }
  function u(p) {
    return p === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(p), e.exit("autolinkMarker"), e.exit("autolink"), t) : p === null || p === 32 || p === 60 || vr(p) ? n(p) : (e.consume(p), u);
  }
  function c(p) {
    return p === 64 ? (e.consume(p), l) : wk(p) ? (e.consume(p), c) : n(p);
  }
  function l(p) {
    return xe(p) ? f(p) : n(p);
  }
  function f(p) {
    return p === 46 ? (e.consume(p), r = 0, l) : p === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(p), e.exit("autolinkMarker"), e.exit("autolink"), t) : d(p);
  }
  function d(p) {
    if ((p === 45 || xe(p)) && r++ < 63) {
      const h = p === 45 ? d : f;
      return e.consume(p), h;
    }
    return n(p);
  }
}
const Bn = {
  partial: !0,
  tokenize: Pk
};
function Pk(e, t, n) {
  return r;
  function r(o) {
    return X(o) ? ne(e, i, "linePrefix")(o) : i(o);
  }
  function i(o) {
    return o === null || q(o) ? t(o) : n(o);
  }
}
const cc = {
  continuation: {
    tokenize: Rk
  },
  exit: $k,
  name: "blockQuote",
  tokenize: Mk
};
function Mk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    if (a === 62) {
      const s = r.containerState;
      return s.open || (e.enter("blockQuote", {
        _container: !0
      }), s.open = !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(a), e.exit("blockQuoteMarker"), o;
    }
    return n(a);
  }
  function o(a) {
    return X(a) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(a), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(a));
  }
}
function Rk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return X(a) ? ne(e, o, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(a) : o(a);
  }
  function o(a) {
    return e.attempt(cc, t, n)(a);
  }
}
function $k(e) {
  e.exit("blockQuote");
}
const fc = {
  name: "characterEscape",
  tokenize: Nk
};
function Nk(e, t, n) {
  return r;
  function r(o) {
    return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(o), e.exit("escapeMarker"), i;
  }
  function i(o) {
    return lc(o) ? (e.enter("characterEscapeValue"), e.consume(o), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(o);
  }
}
const dc = {
  name: "characterReference",
  tokenize: Dk
};
function Dk(e, t, n) {
  const r = this;
  let i = 0, o, a;
  return s;
  function s(f) {
    return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(f), e.exit("characterReferenceMarker"), u;
  }
  function u(f) {
    return f === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(f), e.exit("characterReferenceMarkerNumeric"), c) : (e.enter("characterReferenceValue"), o = 31, a = xe, l(f));
  }
  function c(f) {
    return f === 88 || f === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(f), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), o = 6, a = xk, l) : (e.enter("characterReferenceValue"), o = 7, a = ji, l(f));
  }
  function l(f) {
    if (f === 59 && i) {
      const d = e.exit("characterReferenceValue");
      return a === xe && !_o(r.sliceSerialize(d)) ? n(f) : (e.enter("characterReferenceMarker"), e.consume(f), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
    }
    return a(f) && i++ < o ? (e.consume(f), l) : n(f);
  }
}
const Bi = {
  partial: !0,
  tokenize: Lk
};
function Lk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return a === null ? n(a) : (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), o);
  }
  function o(a) {
    return r.parser.lazy[r.now().line] ? n(a) : t(a);
  }
}
const ss = {
  concrete: !0,
  name: "codeFenced",
  tokenize: Fk
};
function Fk(e, t, n) {
  const r = this, i = {
    partial: !0,
    tokenize: I
  };
  let o = 0, a = 0, s;
  return u;
  function u(y) {
    return c(y);
  }
  function c(y) {
    const E = r.events[r.events.length - 1];
    return o = E && E[1].type === "linePrefix" ? E[2].sliceSerialize(E[1], !0).length : 0, s = y, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), l(y);
  }
  function l(y) {
    return y === s ? (a++, e.consume(y), l) : a < 3 ? n(y) : (e.exit("codeFencedFenceSequence"), X(y) ? ne(e, f, "whitespace")(y) : f(y));
  }
  function f(y) {
    return y === null || q(y) ? (e.exit("codeFencedFence"), r.interrupt ? t(y) : e.check(Bi, m, C)(y)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
      contentType: "string"
    }), d(y));
  }
  function d(y) {
    return y === null || q(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), f(y)) : X(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), ne(e, p, "whitespace")(y)) : y === 96 && y === s ? n(y) : (e.consume(y), d);
  }
  function p(y) {
    return y === null || q(y) ? f(y) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
      contentType: "string"
    }), h(y));
  }
  function h(y) {
    return y === null || q(y) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), f(y)) : y === 96 && y === s ? n(y) : (e.consume(y), h);
  }
  function m(y) {
    return e.attempt(i, C, k)(y);
  }
  function k(y) {
    return e.enter("lineEnding"), e.consume(y), e.exit("lineEnding"), g;
  }
  function g(y) {
    return o > 0 && X(y) ? ne(e, _, "linePrefix", o + 1)(y) : _(y);
  }
  function _(y) {
    return y === null || q(y) ? e.check(Bi, m, C)(y) : (e.enter("codeFlowValue"), w(y));
  }
  function w(y) {
    return y === null || q(y) ? (e.exit("codeFlowValue"), _(y)) : (e.consume(y), w);
  }
  function C(y) {
    return e.exit("codeFenced"), t(y);
  }
  function I(y, E, R) {
    let F = 0;
    return S;
    function S(B) {
      return y.enter("lineEnding"), y.consume(B), y.exit("lineEnding"), M;
    }
    function M(B) {
      return y.enter("codeFencedFence"), X(B) ? ne(y, L, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(B) : L(B);
    }
    function L(B) {
      return B === s ? (y.enter("codeFencedFenceSequence"), x(B)) : R(B);
    }
    function x(B) {
      return B === s ? (F++, y.consume(B), x) : F >= a ? (y.exit("codeFencedFenceSequence"), X(B) ? ne(y, Z, "whitespace")(B) : Z(B)) : R(B);
    }
    function Z(B) {
      return B === null || q(B) ? (y.exit("codeFencedFence"), E(B)) : R(B);
    }
  }
}
const ni = {
  name: "codeIndented",
  tokenize: Zk
}, jk = {
  partial: !0,
  tokenize: Bk
};
function Zk(e, t, n) {
  return r;
  function r(s) {
    return e.enter("codeIndented"), uc(e, i, n, "linePrefix", 4, 4)(s);
  }
  function i(s) {
    return s === null ? a(s) : q(s) ? e.attempt(jk, i, a)(s) : (e.enter("codeFlowValue"), o(s));
  }
  function o(s) {
    return s === null || q(s) ? (e.exit("codeFlowValue"), i(s)) : (e.consume(s), o);
  }
  function a(s) {
    return e.exit("codeIndented"), t(s);
  }
}
function Bk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return r.parser.lazy[r.now().line] ? n(a) : q(a) ? (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), i) : uc(e, t, o, "linePrefix", 4, 4)(a);
  }
  function o(a) {
    return q(a) ? i(a) : n(a);
  }
}
const Uk = {
  name: "codeText",
  previous: qk,
  resolve: Vk,
  tokenize: Jk
};
function Vk(e) {
  let t = e.length - 4, n = 3, r, i;
  if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
    for (r = n; ++r < t; )
      if (e[r][1].type === "codeTextData") {
        e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
        break;
      }
  }
  for (r = n - 1, t++; ++r <= t; )
    i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
  return e;
}
function qk(e) {
  return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function Jk(e, t, n) {
  let r = 0, i, o;
  return a;
  function a(f) {
    return e.enter("codeText"), e.enter("codeTextSequence"), s(f);
  }
  function s(f) {
    return f === 96 ? (e.consume(f), r++, s) : (e.exit("codeTextSequence"), u(f));
  }
  function u(f) {
    return f === null ? n(f) : f === 32 ? (e.enter("space"), e.consume(f), e.exit("space"), u) : f === 96 ? (o = e.enter("codeTextSequence"), i = 0, l(f)) : q(f) ? (e.enter("lineEnding"), e.consume(f), e.exit("lineEnding"), u) : (e.enter("codeTextData"), c(f));
  }
  function c(f) {
    return f === null || f === 32 || f === 96 || q(f) ? (e.exit("codeTextData"), u(f)) : (e.consume(f), c);
  }
  function l(f) {
    return f === 96 ? (e.consume(f), i++, l) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(f)) : (o.type = "codeTextData", c(f));
  }
}
class Wk {
  /**
   * @param {ReadonlyArray<T> | null | undefined} [initial]
   *   Initial items (optional).
   * @returns
   *   Splice buffer.
   */
  constructor(t) {
    this.left = t ? [...t] : [], this.right = [];
  }
  /**
   * Array access;
   * does not move the cursor.
   *
   * @param {number} index
   *   Index.
   * @return {T}
   *   Item.
   */
  get(t) {
    if (t < 0 || t >= this.left.length + this.right.length)
      throw new RangeError("Cannot access index `" + t + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    return t < this.left.length ? this.left[t] : this.right[this.right.length - t + this.left.length - 1];
  }
  /**
   * The length of the splice buffer, one greater than the largest index in the
   * array.
   */
  get length() {
    return this.left.length + this.right.length;
  }
  /**
   * Remove and return `list[0]`;
   * moves the cursor to `0`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  shift() {
    return this.setCursor(0), this.right.pop();
  }
  /**
   * Slice the buffer to get an array;
   * does not move the cursor.
   *
   * @param {number} start
   *   Start.
   * @param {number | null | undefined} [end]
   *   End (optional).
   * @returns {Array<T>}
   *   Array of items.
   */
  slice(t, n) {
    const r = n ?? Number.POSITIVE_INFINITY;
    return r < this.left.length ? this.left.slice(t, r) : t > this.left.length ? this.right.slice(this.right.length - r + this.left.length, this.right.length - t + this.left.length).reverse() : this.left.slice(t).concat(this.right.slice(this.right.length - r + this.left.length).reverse());
  }
  /**
   * Mimics the behavior of Array.prototype.splice() except for the change of
   * interface necessary to avoid segfaults when patching in very large arrays.
   *
   * This operation moves cursor is moved to `start` and results in the cursor
   * placed after any inserted items.
   *
   * @param {number} start
   *   Start;
   *   zero-based index at which to start changing the array;
   *   negative numbers count backwards from the end of the array and values
   *   that are out-of bounds are clamped to the appropriate end of the array.
   * @param {number | null | undefined} [deleteCount=0]
   *   Delete count (default: `0`);
   *   maximum number of elements to delete, starting from start.
   * @param {Array<T> | null | undefined} [items=[]]
   *   Items to include in place of the deleted items (default: `[]`).
   * @return {Array<T>}
   *   Any removed items.
   */
  splice(t, n, r) {
    const i = n || 0;
    this.setCursor(Math.trunc(t));
    const o = this.right.splice(this.right.length - i, Number.POSITIVE_INFINITY);
    return r && gn(this.left, r), o.reverse();
  }
  /**
   * Remove and return the highest-numbered item in the array, so
   * `list[list.length - 1]`;
   * Moves the cursor to `length`.
   *
   * @returns {T | undefined}
   *   Item, optional.
   */
  pop() {
    return this.setCursor(Number.POSITIVE_INFINITY), this.left.pop();
  }
  /**
   * Inserts a single item to the high-numbered side of the array;
   * moves the cursor to `length`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  push(t) {
    this.setCursor(Number.POSITIVE_INFINITY), this.left.push(t);
  }
  /**
   * Inserts many items to the high-numbered side of the array.
   * Moves the cursor to `length`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  pushMany(t) {
    this.setCursor(Number.POSITIVE_INFINITY), gn(this.left, t);
  }
  /**
   * Inserts a single item to the low-numbered side of the array;
   * Moves the cursor to `0`.
   *
   * @param {T} item
   *   Item.
   * @returns {undefined}
   *   Nothing.
   */
  unshift(t) {
    this.setCursor(0), this.right.push(t);
  }
  /**
   * Inserts many items to the low-numbered side of the array;
   * moves the cursor to `0`.
   *
   * @param {Array<T>} items
   *   Items.
   * @returns {undefined}
   *   Nothing.
   */
  unshiftMany(t) {
    this.setCursor(0), gn(this.right, t.reverse());
  }
  /**
   * Move the cursor to a specific position in the array. Requires
   * time proportional to the distance moved.
   *
   * If `n < 0`, the cursor will end up at the beginning.
   * If `n > length`, the cursor will end up at the end.
   *
   * @param {number} n
   *   Position.
   * @return {undefined}
   *   Nothing.
   */
  setCursor(t) {
    if (!(t === this.left.length || t > this.left.length && this.right.length === 0 || t < 0 && this.left.length === 0))
      if (t < this.left.length) {
        const n = this.left.splice(t, Number.POSITIVE_INFINITY);
        gn(this.right, n.reverse());
      } else {
        const n = this.right.splice(this.left.length + this.right.length - t, Number.POSITIVE_INFINITY);
        gn(this.left, n.reverse());
      }
  }
}
function gn(e, t) {
  let n = 0;
  if (t.length < 1e4)
    e.push(...t);
  else
    for (; n < t.length; )
      e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
function pc(e) {
  const t = {};
  let n = -1, r, i, o, a, s, u, c;
  const l = new Wk(e);
  for (; ++n < l.length; ) {
    for (; n in t; )
      n = t[n];
    if (r = l.get(n), n && r[1].type === "chunkFlow" && l.get(n - 1)[1].type === "listItemPrefix" && (u = r[1]._tokenizer.events, o = 0, o < u.length && u[o][1].type === "lineEndingBlank" && (o += 2), o < u.length && u[o][1].type === "content"))
      for (; ++o < u.length && u[o][1].type !== "content"; )
        u[o][1].type === "chunkText" && (u[o][1]._isInFirstContentOfListItem = !0, o++);
    if (r[0] === "enter")
      r[1].contentType && (Object.assign(t, Hk(l, n)), n = t[n], c = !0);
    else if (r[1]._container) {
      for (o = n, i = void 0; o--; )
        if (a = l.get(o), a[1].type === "lineEnding" || a[1].type === "lineEndingBlank")
          a[0] === "enter" && (i && (l.get(i)[1].type = "lineEndingBlank"), a[1].type = "lineEnding", i = o);
        else if (!(a[1].type === "linePrefix" || a[1].type === "listItemIndent")) break;
      i && (r[1].end = {
        ...l.get(i)[1].start
      }, s = l.slice(i, n), s.unshift(r), l.splice(i, n - i + 1, s));
    }
  }
  return Qe(e, 0, Number.POSITIVE_INFINITY, l.slice(0)), !c;
}
function Hk(e, t) {
  const n = e.get(t)[1], r = e.get(t)[2];
  let i = t - 1;
  const o = [];
  let a = n._tokenizer;
  a || (a = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (a._contentTypeTextTrailing = !0));
  const s = a.events, u = [], c = {};
  let l, f, d = -1, p = n, h = 0, m = 0;
  const k = [m];
  for (; p; ) {
    for (; e.get(++i)[1] !== p; )
      ;
    o.push(i), p._tokenizer || (l = r.sliceStream(p), p.next || l.push(null), f && a.defineSkip(p.start), p._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = !0), a.write(l), p._isInFirstContentOfListItem && (a._gfmTasklistFirstContentOfListItem = void 0)), f = p, p = p.next;
  }
  for (p = n; ++d < s.length; )
    // Find a void token that includes a break.
    s[d][0] === "exit" && s[d - 1][0] === "enter" && s[d][1].type === s[d - 1][1].type && s[d][1].start.line !== s[d][1].end.line && (m = d + 1, k.push(m), p._tokenizer = void 0, p.previous = void 0, p = p.next);
  for (a.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : k.pop(), d = k.length; d--; ) {
    const g = s.slice(k[d], k[d + 1]), _ = o.pop();
    u.push([_, _ + g.length - 1]), e.splice(_, 2, g);
  }
  for (u.reverse(), d = -1; ++d < u.length; )
    c[h + u[d][0]] = h + u[d][1], h += u[d][1] - u[d][0] - 1;
  return c;
}
const Kk = {
  resolve: Gk,
  tokenize: Xk
}, Yk = {
  partial: !0,
  tokenize: Qk
};
function Gk(e) {
  return pc(e), e;
}
function Xk(e, t) {
  let n;
  return r;
  function r(s) {
    return e.enter("content"), n = e.enter("chunkContent", {
      contentType: "content"
    }), i(s);
  }
  function i(s) {
    return s === null ? o(s) : q(s) ? e.check(Yk, a, o)(s) : (e.consume(s), i);
  }
  function o(s) {
    return e.exit("chunkContent"), e.exit("content"), t(s);
  }
  function a(s) {
    return e.consume(s), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
      contentType: "content",
      previous: n
    }), n = n.next, i;
  }
}
function Qk(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), ne(e, o, "linePrefix");
  }
  function o(a) {
    if (a === null || q(a))
      return n(a);
    const s = r.events[r.events.length - 1];
    return !r.parser.constructs.disable.null.includes("codeIndented") && s && s[1].type === "linePrefix" && s[2].sliceSerialize(s[1], !0).length >= 4 ? t(a) : e.interrupt(r.parser.constructs.flow, n, t)(a);
  }
}
function hc(e, t, n, r, i, o, a, s, u) {
  const c = u || Number.POSITIVE_INFINITY;
  let l = 0;
  return f;
  function f(g) {
    return g === 60 ? (e.enter(r), e.enter(i), e.enter(o), e.consume(g), e.exit(o), d) : g === null || g === 32 || g === 41 || vr(g) ? n(g) : (e.enter(r), e.enter(a), e.enter(s), e.enter("chunkString", {
      contentType: "string"
    }), m(g));
  }
  function d(g) {
    return g === 62 ? (e.enter(o), e.consume(g), e.exit(o), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", {
      contentType: "string"
    }), p(g));
  }
  function p(g) {
    return g === 62 ? (e.exit("chunkString"), e.exit(s), d(g)) : g === null || g === 60 || q(g) ? n(g) : (e.consume(g), g === 92 ? h : p);
  }
  function h(g) {
    return g === 60 || g === 62 || g === 92 ? (e.consume(g), p) : p(g);
  }
  function m(g) {
    return !l && (g === null || g === 41 || ae(g)) ? (e.exit("chunkString"), e.exit(s), e.exit(a), e.exit(r), t(g)) : l < c && g === 40 ? (e.consume(g), l++, m) : g === 41 ? (e.consume(g), l--, m) : g === null || g === 32 || g === 40 || vr(g) ? n(g) : (e.consume(g), g === 92 ? k : m);
  }
  function k(g) {
    return g === 40 || g === 41 || g === 92 ? (e.consume(g), m) : m(g);
  }
}
function mc(e, t, n, r, i, o) {
  const a = this;
  let s = 0, u;
  return c;
  function c(p) {
    return e.enter(r), e.enter(i), e.consume(p), e.exit(i), e.enter(o), l;
  }
  function l(p) {
    return s > 999 || p === null || p === 91 || p === 93 && !u || // To do: remove in the future once we’ve switched from
    // `micromark-extension-footnote` to `micromark-extension-gfm-footnote`,
    // which doesn’t need this.
    // Hidden footnotes hook.
    /* c8 ignore next 3 */
    p === 94 && !s && "_hiddenFootnoteSupport" in a.parser.constructs ? n(p) : p === 93 ? (e.exit(o), e.enter(i), e.consume(p), e.exit(i), e.exit(r), t) : q(p) ? (e.enter("lineEnding"), e.consume(p), e.exit("lineEnding"), l) : (e.enter("chunkString", {
      contentType: "string"
    }), f(p));
  }
  function f(p) {
    return p === null || p === 91 || p === 93 || q(p) || s++ > 999 ? (e.exit("chunkString"), l(p)) : (e.consume(p), u || (u = !X(p)), p === 92 ? d : f);
  }
  function d(p) {
    return p === 91 || p === 92 || p === 93 ? (e.consume(p), s++, f) : f(p);
  }
}
function gc(e, t, n, r, i, o) {
  let a;
  return s;
  function s(d) {
    return d === 34 || d === 39 || d === 40 ? (e.enter(r), e.enter(i), e.consume(d), e.exit(i), a = d === 40 ? 41 : d, u) : n(d);
  }
  function u(d) {
    return d === a ? (e.enter(i), e.consume(d), e.exit(i), e.exit(r), t) : (e.enter(o), c(d));
  }
  function c(d) {
    return d === a ? (e.exit(o), u(a)) : d === null ? n(d) : q(d) ? (e.enter("lineEnding"), e.consume(d), e.exit("lineEnding"), ne(e, c, "linePrefix")) : (e.enter("chunkString", {
      contentType: "string"
    }), l(d));
  }
  function l(d) {
    return d === a || d === null || q(d) ? (e.exit("chunkString"), c(d)) : (e.consume(d), d === 92 ? f : l);
  }
  function f(d) {
    return d === a || d === 92 ? (e.consume(d), l) : l(d);
  }
}
function zn(e, t) {
  let n;
  return r;
  function r(i) {
    return q(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : X(i) ? ne(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
  }
}
const ew = {
  name: "definition",
  tokenize: nw
}, tw = {
  partial: !0,
  tokenize: rw
};
function nw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(p) {
    return e.enter("definition"), a(p);
  }
  function a(p) {
    return mc.call(
      r,
      e,
      s,
      // Note: we don’t need to reset the way `markdown-rs` does.
      n,
      "definitionLabel",
      "definitionLabelMarker",
      "definitionLabelString"
    )(p);
  }
  function s(p) {
    return i = et(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), p === 58 ? (e.enter("definitionMarker"), e.consume(p), e.exit("definitionMarker"), u) : n(p);
  }
  function u(p) {
    return ae(p) ? zn(e, c)(p) : c(p);
  }
  function c(p) {
    return hc(
      e,
      l,
      // Note: we don’t need to reset the way `markdown-rs` does.
      n,
      "definitionDestination",
      "definitionDestinationLiteral",
      "definitionDestinationLiteralMarker",
      "definitionDestinationRaw",
      "definitionDestinationString"
    )(p);
  }
  function l(p) {
    return e.attempt(tw, f, f)(p);
  }
  function f(p) {
    return X(p) ? ne(e, d, "whitespace")(p) : d(p);
  }
  function d(p) {
    return p === null || q(p) ? (e.exit("definition"), r.parser.defined.push(i), t(p)) : n(p);
  }
}
function rw(e, t, n) {
  return r;
  function r(s) {
    return ae(s) ? zn(e, i)(s) : n(s);
  }
  function i(s) {
    return gc(e, o, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(s);
  }
  function o(s) {
    return X(s) ? ne(e, a, "whitespace")(s) : a(s);
  }
  function a(s) {
    return s === null || q(s) ? t(s) : n(s);
  }
}
const iw = {
  name: "hardBreakEscape",
  tokenize: ow
};
function ow(e, t, n) {
  return r;
  function r(o) {
    return e.enter("hardBreakEscape"), e.consume(o), i;
  }
  function i(o) {
    return q(o) ? (e.exit("hardBreakEscape"), t(o)) : n(o);
  }
}
const aw = {
  name: "headingAtx",
  resolve: sw,
  tokenize: lw
};
function sw(e, t) {
  let n = e.length - 2, r = 3;
  if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
    const i = {
      type: "atxHeadingText",
      start: e[r][1].start,
      end: e[n][1].end
    }, o = {
      type: "chunkText",
      start: e[r][1].start,
      end: e[n][1].end,
      contentType: "text"
    };
    Qe(e, r, n - r + 1, [["enter", i, t], ["enter", o, t], ["exit", o, t], ["exit", i, t]]);
  }
  return e;
}
function lw(e, t, n) {
  let r = 0;
  return i;
  function i(l) {
    return e.enter("atxHeading"), o(l);
  }
  function o(l) {
    return e.enter("atxHeadingSequence"), a(l);
  }
  function a(l) {
    return l === 35 && r++ < 6 ? (e.consume(l), a) : l === null || ae(l) ? (e.exit("atxHeadingSequence"), s(l)) : n(l);
  }
  function s(l) {
    return l === 35 ? (e.enter("atxHeadingSequence"), u(l)) : l === null || q(l) ? (e.exit("atxHeading"), t(l)) : X(l) ? ne(e, s, "whitespace")(l) : (e.enter("atxHeadingText"), c(l));
  }
  function u(l) {
    return l === 35 ? (e.consume(l), u) : (e.exit("atxHeadingSequence"), s(l));
  }
  function c(l) {
    return l === null || l === 35 || ae(l) ? (e.exit("atxHeadingText"), s(l)) : (e.consume(l), c);
  }
}
const yc = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
], Ui = ["pre", "script", "style", "textarea"], uw = {
  concrete: !0,
  name: "htmlFlow",
  resolveTo: fw,
  tokenize: dw
}, cw = {
  partial: !0,
  tokenize: pw
};
function fw(e) {
  let t = e.length;
  for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"); )
    ;
  return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function dw(e, t, n) {
  const r = this;
  let i, o, a, s, u;
  return c;
  function c(v) {
    return l(v);
  }
  function l(v) {
    return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(v), f;
  }
  function f(v) {
    return v === 33 ? (e.consume(v), d) : v === 47 ? (e.consume(v), o = !0, m) : v === 63 ? (e.consume(v), i = 3, r.interrupt ? t : b) : we(v) ? (e.consume(v), a = String.fromCharCode(v), k) : n(v);
  }
  function d(v) {
    return v === 45 ? (e.consume(v), i = 2, p) : v === 91 ? (e.consume(v), i = 5, s = 0, h) : we(v) ? (e.consume(v), i = 4, r.interrupt ? t : b) : n(v);
  }
  function p(v) {
    return v === 45 ? (e.consume(v), r.interrupt ? t : b) : n(v);
  }
  function h(v) {
    const Te = "CDATA[";
    return v === Te.charCodeAt(s++) ? (e.consume(v), s === Te.length ? r.interrupt ? t : L : h) : n(v);
  }
  function m(v) {
    return we(v) ? (e.consume(v), a = String.fromCharCode(v), k) : n(v);
  }
  function k(v) {
    if (v === null || v === 47 || v === 62 || ae(v)) {
      const Te = v === 47, nt = a.toLowerCase();
      return !Te && !o && Ui.includes(nt) ? (i = 1, r.interrupt ? t(v) : L(v)) : yc.includes(a.toLowerCase()) ? (i = 6, Te ? (e.consume(v), g) : r.interrupt ? t(v) : L(v)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(v) : o ? _(v) : w(v));
    }
    return v === 45 || xe(v) ? (e.consume(v), a += String.fromCharCode(v), k) : n(v);
  }
  function g(v) {
    return v === 62 ? (e.consume(v), r.interrupt ? t : L) : n(v);
  }
  function _(v) {
    return X(v) ? (e.consume(v), _) : S(v);
  }
  function w(v) {
    return v === 47 ? (e.consume(v), S) : v === 58 || v === 95 || we(v) ? (e.consume(v), C) : X(v) ? (e.consume(v), w) : S(v);
  }
  function C(v) {
    return v === 45 || v === 46 || v === 58 || v === 95 || xe(v) ? (e.consume(v), C) : I(v);
  }
  function I(v) {
    return v === 61 ? (e.consume(v), y) : X(v) ? (e.consume(v), I) : w(v);
  }
  function y(v) {
    return v === null || v === 60 || v === 61 || v === 62 || v === 96 ? n(v) : v === 34 || v === 39 ? (e.consume(v), u = v, E) : X(v) ? (e.consume(v), y) : R(v);
  }
  function E(v) {
    return v === u ? (e.consume(v), u = null, F) : v === null || q(v) ? n(v) : (e.consume(v), E);
  }
  function R(v) {
    return v === null || v === 34 || v === 39 || v === 47 || v === 60 || v === 61 || v === 62 || v === 96 || ae(v) ? I(v) : (e.consume(v), R);
  }
  function F(v) {
    return v === 47 || v === 62 || X(v) ? w(v) : n(v);
  }
  function S(v) {
    return v === 62 ? (e.consume(v), M) : n(v);
  }
  function M(v) {
    return v === null || q(v) ? L(v) : X(v) ? (e.consume(v), M) : n(v);
  }
  function L(v) {
    return v === 45 && i === 2 ? (e.consume(v), Y) : v === 60 && i === 1 ? (e.consume(v), D) : v === 62 && i === 4 ? (e.consume(v), ke) : v === 63 && i === 3 ? (e.consume(v), b) : v === 93 && i === 5 ? (e.consume(v), le) : q(v) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(cw, Ze, x)(v)) : v === null || q(v) ? (e.exit("htmlFlowData"), x(v)) : (e.consume(v), L);
  }
  function x(v) {
    return e.check(Bi, Z, Ze)(v);
  }
  function Z(v) {
    return e.enter("lineEnding"), e.consume(v), e.exit("lineEnding"), B;
  }
  function B(v) {
    return v === null || q(v) ? x(v) : (e.enter("htmlFlowData"), L(v));
  }
  function Y(v) {
    return v === 45 ? (e.consume(v), b) : L(v);
  }
  function D(v) {
    return v === 47 ? (e.consume(v), a = "", H) : L(v);
  }
  function H(v) {
    if (v === 62) {
      const Te = a.toLowerCase();
      return Ui.includes(Te) ? (e.consume(v), ke) : L(v);
    }
    return we(v) && a.length < 8 ? (e.consume(v), a += String.fromCharCode(v), H) : L(v);
  }
  function le(v) {
    return v === 93 ? (e.consume(v), b) : L(v);
  }
  function b(v) {
    return v === 62 ? (e.consume(v), ke) : v === 45 && i === 2 ? (e.consume(v), b) : L(v);
  }
  function ke(v) {
    return v === null || q(v) ? (e.exit("htmlFlowData"), Ze(v)) : (e.consume(v), ke);
  }
  function Ze(v) {
    return e.exit("htmlFlow"), t(v);
  }
}
function pw(e, t, n) {
  return r;
  function r(i) {
    return e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), e.attempt(Bn, t, n);
  }
}
const hw = {
  name: "htmlText",
  tokenize: mw
};
function mw(e, t, n) {
  const r = this;
  let i, o, a;
  return s;
  function s(b) {
    return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(b), u;
  }
  function u(b) {
    return b === 33 ? (e.consume(b), c) : b === 47 ? (e.consume(b), I) : b === 63 ? (e.consume(b), w) : we(b) ? (e.consume(b), R) : n(b);
  }
  function c(b) {
    return b === 45 ? (e.consume(b), l) : b === 91 ? (e.consume(b), o = 0, h) : we(b) ? (e.consume(b), _) : n(b);
  }
  function l(b) {
    return b === 45 ? (e.consume(b), p) : n(b);
  }
  function f(b) {
    return b === null ? n(b) : b === 45 ? (e.consume(b), d) : q(b) ? (a = f, D(b)) : (e.consume(b), f);
  }
  function d(b) {
    return b === 45 ? (e.consume(b), p) : f(b);
  }
  function p(b) {
    return b === 62 ? Y(b) : b === 45 ? d(b) : f(b);
  }
  function h(b) {
    const ke = "CDATA[";
    return b === ke.charCodeAt(o++) ? (e.consume(b), o === ke.length ? m : h) : n(b);
  }
  function m(b) {
    return b === null ? n(b) : b === 93 ? (e.consume(b), k) : q(b) ? (a = m, D(b)) : (e.consume(b), m);
  }
  function k(b) {
    return b === 93 ? (e.consume(b), g) : m(b);
  }
  function g(b) {
    return b === 62 ? Y(b) : b === 93 ? (e.consume(b), g) : m(b);
  }
  function _(b) {
    return b === null || b === 62 ? Y(b) : q(b) ? (a = _, D(b)) : (e.consume(b), _);
  }
  function w(b) {
    return b === null ? n(b) : b === 63 ? (e.consume(b), C) : q(b) ? (a = w, D(b)) : (e.consume(b), w);
  }
  function C(b) {
    return b === 62 ? Y(b) : w(b);
  }
  function I(b) {
    return we(b) ? (e.consume(b), y) : n(b);
  }
  function y(b) {
    return b === 45 || xe(b) ? (e.consume(b), y) : E(b);
  }
  function E(b) {
    return q(b) ? (a = E, D(b)) : X(b) ? (e.consume(b), E) : Y(b);
  }
  function R(b) {
    return b === 45 || xe(b) ? (e.consume(b), R) : b === 47 || b === 62 || ae(b) ? F(b) : n(b);
  }
  function F(b) {
    return b === 47 ? (e.consume(b), Y) : b === 58 || b === 95 || we(b) ? (e.consume(b), S) : q(b) ? (a = F, D(b)) : X(b) ? (e.consume(b), F) : Y(b);
  }
  function S(b) {
    return b === 45 || b === 46 || b === 58 || b === 95 || xe(b) ? (e.consume(b), S) : M(b);
  }
  function M(b) {
    return b === 61 ? (e.consume(b), L) : q(b) ? (a = M, D(b)) : X(b) ? (e.consume(b), M) : F(b);
  }
  function L(b) {
    return b === null || b === 60 || b === 61 || b === 62 || b === 96 ? n(b) : b === 34 || b === 39 ? (e.consume(b), i = b, x) : q(b) ? (a = L, D(b)) : X(b) ? (e.consume(b), L) : (e.consume(b), Z);
  }
  function x(b) {
    return b === i ? (e.consume(b), i = void 0, B) : b === null ? n(b) : q(b) ? (a = x, D(b)) : (e.consume(b), x);
  }
  function Z(b) {
    return b === null || b === 34 || b === 39 || b === 60 || b === 61 || b === 96 ? n(b) : b === 47 || b === 62 || ae(b) ? F(b) : (e.consume(b), Z);
  }
  function B(b) {
    return b === 47 || b === 62 || ae(b) ? F(b) : n(b);
  }
  function Y(b) {
    return b === 62 ? (e.consume(b), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(b);
  }
  function D(b) {
    return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(b), e.exit("lineEnding"), H;
  }
  function H(b) {
    return X(b) ? ne(e, le, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(b) : le(b);
  }
  function le(b) {
    return e.enter("htmlTextData"), a(b);
  }
}
const So = {
  name: "labelEnd",
  resolveAll: vw,
  resolveTo: kw,
  tokenize: ww
}, gw = {
  tokenize: xw
}, yw = {
  tokenize: _w
}, bw = {
  tokenize: Sw
};
function vw(e) {
  let t = -1;
  const n = [];
  for (; ++t < e.length; ) {
    const r = e[t][1];
    if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
      const i = r.type === "labelImage" ? 4 : 2;
      r.type = "data", t += i;
    }
  }
  return e.length !== n.length && Qe(e, 0, e.length, n), e;
}
function kw(e, t) {
  let n = e.length, r = 0, i, o, a;
  for (; n--; ) {
    const l = e[n][1];
    if (i) {
      if (l.type === "link" || l.type === "labelLink" && l._inactive)
        break;
      e[n][0] === "enter" && l.type === "labelLink" && (l._inactive = !0);
    } else if (o) {
      if (e[n][0] === "enter" && (l.type === "labelImage" || l.type === "labelLink") && !l._balanced && (i = n, l.type !== "labelLink")) {
        r = 2;
        break;
      }
    } else l.type === "labelEnd" && (o = n);
  }
  const s = {
    type: e[i][1].type === "labelLink" ? "link" : "image",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  }, u = {
    type: "label",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[o][1].end
    }
  }, c = {
    type: "labelText",
    start: {
      ...e[i + r + 2][1].end
    },
    end: {
      ...e[o - 2][1].start
    }
  };
  return a = [["enter", s, t], ["enter", u, t]], a = Je(a, e.slice(i + 1, i + r + 3)), a = Je(a, [["enter", c, t]]), a = Je(a, Pr(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, o - 3), t)), a = Je(a, [["exit", c, t], e[o - 2], e[o - 1], ["exit", u, t]]), a = Je(a, e.slice(o + 1)), a = Je(a, [["exit", s, t]]), Qe(e, i, e.length, a), e;
}
function ww(e, t, n) {
  const r = this, i = r._labelStarts;
  let o, a;
  if (i) {
    for (; i.length > 0 && i[i.length - 1]._balanced; )
      i.pop();
    o = i[i.length - 1];
  }
  return s;
  function s(d) {
    return o ? o._inactive ? f(d) : (a = r.parser.defined.includes(et(r.sliceSerialize({
      start: o.end,
      end: r.now()
    }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(d), e.exit("labelMarker"), e.exit("labelEnd"), u) : n(d);
  }
  function u(d) {
    return d === 40 ? e.attempt(gw, l, a ? l : f)(d) : d === 91 ? e.attempt(yw, l, a ? c : f)(d) : a ? l(d) : f(d);
  }
  function c(d) {
    return e.attempt(bw, l, f)(d);
  }
  function l(d) {
    return i.pop(), t(d);
  }
  function f(d) {
    return o._balanced = !0, n(d);
  }
}
function xw(e, t, n) {
  return r;
  function r(f) {
    return e.enter("resource"), e.enter("resourceMarker"), e.consume(f), e.exit("resourceMarker"), i;
  }
  function i(f) {
    return ae(f) ? zn(e, o)(f) : o(f);
  }
  function o(f) {
    return f === 41 ? l(f) : hc(e, a, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(f);
  }
  function a(f) {
    return ae(f) ? zn(e, u)(f) : l(f);
  }
  function s(f) {
    return n(f);
  }
  function u(f) {
    return f === 34 || f === 39 || f === 40 ? gc(e, c, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(f) : l(f);
  }
  function c(f) {
    return ae(f) ? zn(e, l)(f) : l(f);
  }
  function l(f) {
    return f === 41 ? (e.enter("resourceMarker"), e.consume(f), e.exit("resourceMarker"), e.exit("resource"), t) : n(f);
  }
}
function _w(e, t, n) {
  const r = this;
  return i;
  function i(s) {
    return mc.call(r, e, o, a, "reference", "referenceMarker", "referenceString")(s);
  }
  function o(s) {
    return r.parser.defined.includes(et(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(s) : n(s);
  }
  function a(s) {
    return n(s);
  }
}
function Sw(e, t, n) {
  return r;
  function r(o) {
    return e.enter("reference"), e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), i;
  }
  function i(o) {
    return o === 93 ? (e.enter("referenceMarker"), e.consume(o), e.exit("referenceMarker"), e.exit("reference"), t) : n(o);
  }
}
const Iw = {
  name: "labelStartImage",
  resolveAll: So.resolveAll,
  tokenize: Ew
};
function Ew(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(u) {
    return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(u), e.exit("labelImageMarker"), a;
  }
  function a(u) {
    return u === 91 ? (e.enter("labelMarker"), e.consume(u), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(u);
  }
  function s(u) {
    return u === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(u) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(u));
  }
}
const Cw = {
  name: "labelStartLink",
  resolveAll: So.resolveAll,
  tokenize: Aw
};
function Aw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(s) {
    return e.enter("labelLink"), e.enter("labelMarker"), e.consume(s), e.exit("labelMarker"), i = e.exit("labelLink"), a;
  }
  function a(s) {
    return s === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(s) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(s));
  }
}
const ri = {
  name: "lineEnding",
  tokenize: zw
};
function zw(e, t) {
  return n;
  function n(r) {
    return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), ne(e, t, "linePrefix");
  }
}
const lr = {
  name: "thematicBreak",
  tokenize: Tw
};
function Tw(e, t, n) {
  let r = 0, i;
  return o;
  function o(c) {
    return e.enter("thematicBreak"), a(c);
  }
  function a(c) {
    return i = c, s(c);
  }
  function s(c) {
    return c === i ? (e.enter("thematicBreakSequence"), u(c)) : r >= 3 && (c === null || q(c)) ? (e.exit("thematicBreak"), t(c)) : n(c);
  }
  function u(c) {
    return c === i ? (e.consume(c), r++, u) : (e.exit("thematicBreakSequence"), X(c) ? ne(e, s, "whitespace")(c) : s(c));
  }
}
const Me = {
  continuation: {
    tokenize: Rw
  },
  exit: Nw,
  name: "list",
  tokenize: Mw
}, Ow = {
  partial: !0,
  tokenize: Dw
}, Pw = {
  partial: !0,
  tokenize: $w
};
function Mw(e, t, n) {
  const r = this, i = r.events[r.events.length - 1];
  let o = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, a = 0;
  return s;
  function s(p) {
    const h = r.containerState.type || (p === 42 || p === 43 || p === 45 ? "listUnordered" : "listOrdered");
    if (h === "listUnordered" ? !r.containerState.marker || p === r.containerState.marker : ji(p)) {
      if (r.containerState.type || (r.containerState.type = h, e.enter(h, {
        _container: !0
      })), h === "listUnordered")
        return e.enter("listItemPrefix"), p === 42 || p === 45 ? e.check(lr, n, c)(p) : c(p);
      if (!r.interrupt || p === 49)
        return e.enter("listItemPrefix"), e.enter("listItemValue"), u(p);
    }
    return n(p);
  }
  function u(p) {
    return ji(p) && ++a < 10 ? (e.consume(p), u) : (!r.interrupt || a < 2) && (r.containerState.marker ? p === r.containerState.marker : p === 41 || p === 46) ? (e.exit("listItemValue"), c(p)) : n(p);
  }
  function c(p) {
    return e.enter("listItemMarker"), e.consume(p), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || p, e.check(
      Bn,
      // Can’t be empty when interrupting.
      r.interrupt ? n : l,
      e.attempt(Ow, d, f)
    );
  }
  function l(p) {
    return r.containerState.initialBlankLine = !0, o++, d(p);
  }
  function f(p) {
    return X(p) ? (e.enter("listItemPrefixWhitespace"), e.consume(p), e.exit("listItemPrefixWhitespace"), d) : n(p);
  }
  function d(p) {
    return r.containerState.size = o + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(p);
  }
}
function Rw(e, t, n) {
  const r = this;
  return r.containerState._closeFlow = void 0, e.check(Bn, i, o);
  function i(s) {
    return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, ne(e, t, "listItemIndent", r.containerState.size + 1)(s);
  }
  function o(s) {
    return r.containerState.furtherBlankLines || !X(s) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, a(s)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(Pw, t, a)(s));
  }
  function a(s) {
    return r.containerState._closeFlow = !0, r.interrupt = void 0, ne(e, e.attempt(Me, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(s);
  }
}
function $w(e, t, n) {
  const r = this;
  return ne(e, i, "listItemIndent", r.containerState.size + 1);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "listItemIndent" && a[2].sliceSerialize(a[1], !0).length === r.containerState.size ? t(o) : n(o);
  }
}
function Nw(e) {
  e.exit(this.containerState.type);
}
function Dw(e, t, n) {
  const r = this;
  return ne(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return !X(o) && a && a[1].type === "listItemPrefixWhitespace" ? t(o) : n(o);
  }
}
const ls = {
  name: "setextUnderline",
  resolveTo: Lw,
  tokenize: Fw
};
function Lw(e, t) {
  const n = new kr();
  let r = e.length, i, o, a;
  for (; r--; )
    if (e[r][0] === "enter") {
      if (e[r][1].type === "content") {
        i = r;
        break;
      }
      e[r][1].type === "paragraph" && (o = r);
    } else
      e[r][1].type === "content" && n.add(r, 1, []), !a && e[r][1].type === "definition" && (a = r);
  const s = {
    type: "setextHeading",
    start: {
      ...e[i][1].start
    },
    end: {
      ...e[e.length - 1][1].end
    }
  };
  return e[o][1].type = "setextHeadingText", a ? (n.add(o, 0, [["enter", s, t]]), n.add(a + 1, 0, [["exit", e[i][1], t]]), e[i][1].end = {
    ...e[a][1].end
  }) : e[i][1] = s, n.add(e.length, 0, [["exit", s, t]]), n.consume(e), e;
}
function Fw(e, t, n) {
  const r = this;
  let i;
  return o;
  function o(c) {
    let l = r.events.length, f;
    for (; l--; )
      if (r.events[l][1].type !== "lineEnding" && r.events[l][1].type !== "linePrefix" && r.events[l][1].type !== "content") {
        f = r.events[l][1].type === "paragraph";
        break;
      }
    return !r.parser.lazy[r.now().line] && (r.interrupt || f) ? (e.enter("setextHeadingLine"), i = c, a(c)) : n(c);
  }
  function a(c) {
    return e.enter("setextHeadingLineSequence"), s(c);
  }
  function s(c) {
    return c === i ? (e.consume(c), s) : (e.exit("setextHeadingLineSequence"), X(c) ? ne(e, u, "lineSuffix")(c) : u(c));
  }
  function u(c) {
    return c === null || q(c) ? (e.exit("setextHeadingLine"), t(c)) : n(c);
  }
}
const jw = {
  tokenize: Zw
};
function Zw(e) {
  const t = this, n = e.attempt(
    // Try to parse a blank line.
    Bn,
    r,
    // Try to parse initial flow (essentially, only code).
    e.attempt(this.parser.constructs.flowInitial, i, ne(e, e.attempt(this.parser.constructs.flow, i, e.attempt(Kk, i)), "linePrefix"))
  );
  return n;
  function r(o) {
    if (o === null) {
      e.consume(o);
      return;
    }
    return e.enter("lineEndingBlank"), e.consume(o), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
  }
  function i(o) {
    if (o === null) {
      e.consume(o);
      return;
    }
    return e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), t.currentConstruct = void 0, n;
  }
}
const Bw = {
  resolveAll: vc()
}, Uw = bc("string"), Vw = bc("text");
function bc(e) {
  return {
    resolveAll: vc(e === "text" ? qw : void 0),
    tokenize: t
  };
  function t(n) {
    const r = this, i = this.parser.constructs[e], o = n.attempt(i, a, s);
    return a;
    function a(l) {
      return c(l) ? o(l) : s(l);
    }
    function s(l) {
      if (l === null) {
        n.consume(l);
        return;
      }
      return n.enter("data"), n.consume(l), u;
    }
    function u(l) {
      return c(l) ? (n.exit("data"), o(l)) : (n.consume(l), u);
    }
    function c(l) {
      if (l === null)
        return !0;
      const f = i[l];
      let d = -1;
      if (f)
        for (; ++d < f.length; ) {
          const p = f[d];
          if (!p.previous || p.previous.call(r, r.previous))
            return !0;
        }
      return !1;
    }
  }
}
function vc(e) {
  return t;
  function t(n, r) {
    let i = -1, o;
    for (; ++i <= n.length; )
      o === void 0 ? n[i] && n[i][1].type === "data" && (o = i, i++) : (!n[i] || n[i][1].type !== "data") && (i !== o + 2 && (n[o][1].end = n[i - 1][1].end, n.splice(o + 2, i - o - 2), i = o + 2), o = void 0);
    return e ? e(n, r) : n;
  }
}
function qw(e, t) {
  const n = new kr();
  let r = 0;
  for (; ++r <= e.length; )
    if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
      const i = e[r - 1][1], o = t.sliceStream(i);
      let a = o.length, s = -1, u = 0, c;
      for (; a--; ) {
        const l = o[a];
        if (typeof l == "string") {
          for (s = l.length; l.charCodeAt(s - 1) === 32; )
            u++, s--;
          if (s)
            break;
          s = -1;
        } else if (l === -2)
          c = !0, u++;
        else if (l !== -1) {
          a++;
          break;
        }
      }
      if (t._contentTypeTextTrailing && r === e.length && (u = 0), u) {
        const l = {
          type: r === e.length || c || u < 2 ? "lineSuffix" : "hardBreakTrailing",
          start: {
            _bufferIndex: a ? s : i.start._bufferIndex + s,
            _index: i.start._index + a,
            line: i.end.line,
            column: i.end.column - u,
            offset: i.end.offset - u
          },
          end: {
            ...i.end
          }
        };
        i.end = {
          ...l.start
        }, i.start.offset === i.end.offset ? Object.assign(i, l) : n.add(r, 0, [["enter", l, t], ["exit", l, t]]);
      }
      r++;
    }
  return n.consume(e), e;
}
const Jw = {
  42: Me,
  43: Me,
  45: Me,
  48: Me,
  49: Me,
  50: Me,
  51: Me,
  52: Me,
  53: Me,
  54: Me,
  55: Me,
  56: Me,
  57: Me,
  62: cc
}, Ww = {
  91: ew
}, Hw = {
  [-2]: ni,
  [-1]: ni,
  32: ni
}, Kw = {
  35: aw,
  42: lr,
  45: [ls, lr],
  60: uw,
  61: ls,
  95: lr,
  96: ss,
  126: ss
}, Yw = {
  38: dc,
  92: fc
}, Gw = {
  [-5]: ri,
  [-4]: ri,
  [-3]: ri,
  33: Iw,
  38: dc,
  42: Zi,
  60: [Tk, hw],
  91: Cw,
  92: [iw, fc],
  93: So,
  95: Zi,
  96: Uk
}, Xw = {
  null: [Zi, Bw]
}, Qw = {
  null: [42, 95]
}, e0 = {
  null: []
}, t0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  attentionMarkers: Qw,
  contentInitial: Ww,
  disable: e0,
  document: Jw,
  flow: Kw,
  flowInitial: Hw,
  insideSpan: Xw,
  string: Yw,
  text: Gw
}, Symbol.toStringTag, { value: "Module" }));
function n0(e, t, n) {
  let r = {
    _bufferIndex: -1,
    _index: 0,
    line: n && n.line || 1,
    column: n && n.column || 1,
    offset: n && n.offset || 0
  };
  const i = {}, o = [];
  let a = [], s = [];
  const u = {
    attempt: E(I),
    check: E(y),
    consume: _,
    enter: w,
    exit: C,
    interrupt: E(y, {
      interrupt: !0
    })
  }, c = {
    code: null,
    containerState: {},
    defineSkip: m,
    events: [],
    now: h,
    parser: e,
    previous: null,
    sliceSerialize: d,
    sliceStream: p,
    write: f
  };
  let l = t.tokenize.call(c, u);
  return t.resolveAll && o.push(t), c;
  function f(M) {
    return a = Je(a, M), k(), a[a.length - 1] !== null ? [] : (R(t, 0), c.events = Pr(o, c.events, c), c.events);
  }
  function d(M, L) {
    return i0(p(M), L);
  }
  function p(M) {
    return r0(a, M);
  }
  function h() {
    const {
      _bufferIndex: M,
      _index: L,
      line: x,
      column: Z,
      offset: B
    } = r;
    return {
      _bufferIndex: M,
      _index: L,
      line: x,
      column: Z,
      offset: B
    };
  }
  function m(M) {
    i[M.line] = M.column, S();
  }
  function k() {
    for (; r._index < a.length; ) {
      const M = a[r._index];
      if (typeof M == "string") {
        const L = r._index;
        for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === L && r._bufferIndex < M.length; )
          g(M.charCodeAt(r._bufferIndex));
      } else
        g(M);
    }
  }
  function g(M) {
    l = l(M);
  }
  function _(M) {
    q(M) ? (r.line++, r.column = 1, r.offset += M === -3 ? 2 : 1, S()) : M !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === // Points w/ non-negative `_bufferIndex` reference
    // strings.
    /** @type {string} */
    a[r._index].length && (r._bufferIndex = -1, r._index++)), c.previous = M;
  }
  function w(M, L) {
    const x = L || {};
    return x.type = M, x.start = h(), c.events.push(["enter", x, c]), s.push(x), x;
  }
  function C(M) {
    const L = s.pop();
    return L.end = h(), c.events.push(["exit", L, c]), L;
  }
  function I(M, L) {
    R(M, L.from);
  }
  function y(M, L) {
    L.restore();
  }
  function E(M, L) {
    return x;
    function x(Z, B, Y) {
      let D, H, le, b;
      return Array.isArray(Z) ? (
        /* c8 ignore next 1 */
        Ze(Z)
      ) : "tokenize" in Z ? (
        // Looks like a construct.
        Ze([
          /** @type {Construct} */
          Z
        ])
      ) : ke(Z);
      function ke(ge) {
        return rt;
        function rt(Ke) {
          const mt = Ke !== null && ge[Ke], O = Ke !== null && ge.null, U = [
            // To do: add more extension tests.
            /* c8 ignore next 2 */
            ...Array.isArray(mt) ? mt : mt ? [mt] : [],
            ...Array.isArray(O) ? O : O ? [O] : []
          ];
          return Ze(U)(Ke);
        }
      }
      function Ze(ge) {
        return D = ge, H = 0, ge.length === 0 ? Y : v(ge[H]);
      }
      function v(ge) {
        return rt;
        function rt(Ke) {
          return b = F(), le = ge, ge.partial || (c.currentConstruct = ge), ge.name && c.parser.constructs.disable.null.includes(ge.name) ? nt() : ge.tokenize.call(
            // If we do have fields, create an object w/ `context` as its
            // prototype.
            // This allows a “live binding”, which is needed for `interrupt`.
            L ? Object.assign(Object.create(c), L) : c,
            u,
            Te,
            nt
          )(Ke);
        }
      }
      function Te(ge) {
        return M(le, b), B;
      }
      function nt(ge) {
        return b.restore(), ++H < D.length ? v(D[H]) : Y;
      }
    }
  }
  function R(M, L) {
    M.resolveAll && !o.includes(M) && o.push(M), M.resolve && Qe(c.events, L, c.events.length - L, M.resolve(c.events.slice(L), c)), M.resolveTo && (c.events = M.resolveTo(c.events, c));
  }
  function F() {
    const M = h(), L = c.previous, x = c.currentConstruct, Z = c.events.length, B = Array.from(s);
    return {
      from: Z,
      restore: Y
    };
    function Y() {
      r = M, c.previous = L, c.currentConstruct = x, c.events.length = Z, s = B, S();
    }
  }
  function S() {
    r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
  }
}
function r0(e, t) {
  const n = t.start._index, r = t.start._bufferIndex, i = t.end._index, o = t.end._bufferIndex;
  let a;
  if (n === i)
    a = [e[n].slice(r, o)];
  else {
    if (a = e.slice(n, i), r > -1) {
      const s = a[0];
      typeof s == "string" ? a[0] = s.slice(r) : a.shift();
    }
    o > 0 && a.push(e[i].slice(0, o));
  }
  return a;
}
function i0(e, t) {
  let n = -1;
  const r = [];
  let i;
  for (; ++n < e.length; ) {
    const o = e[n];
    let a;
    if (typeof o == "string")
      a = o;
    else
      switch (o) {
        case -5: {
          a = "\r";
          break;
        }
        case -4: {
          a = `
`;
          break;
        }
        case -3: {
          a = `\r
`;
          break;
        }
        case -2: {
          a = t ? " " : "	";
          break;
        }
        case -1: {
          if (!t && i)
            continue;
          a = " ";
          break;
        }
        default:
          a = String.fromCharCode(o);
      }
    i = o === -2, r.push(a);
  }
  return r.join("");
}
function o0(e) {
  const r = {
    constructs: (
      /** @type {FullNormalizedExtension} */
      ac([t0, ...(e || {}).extensions || []])
    ),
    content: i(_k),
    defined: [],
    document: i(Ik),
    flow: i(jw),
    lazy: {},
    string: i(Uw),
    text: i(Vw)
  };
  return r;
  function i(o) {
    return a;
    function a(s) {
      return n0(r, o, s);
    }
  }
}
function a0(e) {
  for (; !pc(e); )
    ;
  return e;
}
const us = /[\0\t\n\r]/g;
function s0() {
  let e = 1, t = "", n = !0, r;
  return i;
  function i(o, a, s) {
    o = t + (typeof o == "string" ? o.toString() : new TextDecoder(a || void 0).decode(o));
    const u = [];
    let c = 0;
    for (t = "", n && (o.charCodeAt(0) === 65279 && c++, n = void 0); c < o.length; ) {
      us.lastIndex = c;
      const l = us.exec(o), f = l && l.index !== void 0 ? l.index : o.length, d = o.charCodeAt(f);
      if (!l) {
        t = o.slice(c);
        break;
      }
      if (d === 10 && c === f && r)
        u.push(-3), r = void 0;
      else
        switch (r && (u.push(-5), r = void 0), c < f && (u.push(o.slice(c, f)), e += f - c), d) {
          case 0: {
            u.push(65533), e++;
            break;
          }
          case 9: {
            const p = Math.ceil(e / 4) * 4;
            for (u.push(-2); e++ < p; )
              u.push(-1);
            break;
          }
          case 10: {
            u.push(-4), e = 1;
            break;
          }
          default:
            r = !0, e = 1;
        }
      c = f + 1;
    }
    return s && (r && u.push(-5), t && u.push(t), u.push(null)), u;
  }
}
const l0 = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function u0(e) {
  return e.replace(l0, c0);
}
function c0(e, t, n) {
  if (t)
    return t;
  if (n.charCodeAt(0) === 35) {
    const i = n.charCodeAt(1), o = i === 120 || i === 88;
    return sc(n.slice(o ? 2 : 1), o ? 16 : 10);
  }
  return _o(n) || e;
}
const kc = {}.hasOwnProperty;
function f0(e, t, n) {
  return t && typeof t == "object" && (n = t, t = void 0), d0(n)(a0(o0(n).document().write(s0()(e, t, !0))));
}
function d0(e) {
  const t = {
    afterExit: [],
    beforeEnter: [],
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: a(Fo),
      autolinkProtocol: S,
      autolinkEmail: S,
      atxHeading: a(un),
      blockQuote: a(U),
      characterEscape: S,
      characterReference: S,
      codeFenced: a(Be),
      codeFencedFenceInfo: s,
      codeFencedFenceMeta: s,
      codeIndented: a(Be, s),
      codeText: a(zt, s),
      codeTextData: S,
      data: S,
      codeFlowValue: S,
      definition: a(Vn),
      definitionDestinationString: s,
      definitionLabelString: s,
      definitionTitleString: s,
      emphasis: a(ln),
      hardBreakEscape: a(Fr),
      hardBreakTrailing: a(Fr),
      htmlFlow: a(Lo, s),
      htmlFlowData: S,
      htmlText: a(Lo, s),
      htmlTextData: S,
      image: a(of),
      label: s,
      link: a(Fo),
      listItem: a(af),
      listItemValue: p,
      listOrdered: a(jo, d),
      listUnordered: a(jo),
      paragraph: a(sf),
      reference: Te,
      referenceString: s,
      resourceDestinationString: s,
      resourceTitleString: s,
      setextHeading: a(un),
      strong: a(lf),
      thematicBreak: a(cf)
    },
    exit: {
      atxHeading: c(),
      atxHeadingSequence: y,
      autolink: c(),
      autolinkEmail: O,
      autolinkProtocol: mt,
      blockQuote: c(),
      characterEscapeValue: M,
      characterReferenceMarkerHexadecimal: ge,
      characterReferenceMarkerNumeric: ge,
      characterReferenceValue: rt,
      characterReference: Ke,
      codeFenced: c(g),
      codeFencedFence: k,
      codeFencedFenceInfo: h,
      codeFencedFenceMeta: m,
      codeFlowValue: M,
      codeIndented: c(_),
      codeText: c(Y),
      codeTextData: M,
      data: M,
      definition: c(),
      definitionDestinationString: I,
      definitionLabelString: w,
      definitionTitleString: C,
      emphasis: c(),
      hardBreakEscape: c(x),
      hardBreakTrailing: c(x),
      htmlFlow: c(Z),
      htmlFlowData: M,
      htmlText: c(B),
      htmlTextData: M,
      image: c(H),
      label: b,
      labelText: le,
      lineEnding: L,
      link: c(D),
      listItem: c(),
      listOrdered: c(),
      listUnordered: c(),
      paragraph: c(),
      referenceString: nt,
      resourceDestinationString: ke,
      resourceTitleString: Ze,
      resource: v,
      setextHeading: c(F),
      setextHeadingLineSequence: R,
      setextHeadingText: E,
      strong: c(),
      thematicBreak: c()
    }
  };
  wc(t, (e || {}).mdastExtensions || []);
  const n = {};
  return r;
  function r(A) {
    let N = {
      type: "root",
      children: [],
      position: void 0
    };
    const W = {
      stack: [N],
      tokenStack: [],
      config: t,
      enter: u,
      exit: l,
      buffer: s,
      resume: f,
      data: n
    }, G = [], Oe = [];
    let ue = -1;
    for (; ++ue < A.length; )
      if (Oe.push(A[ue]), A[ue][1].type === "listOrdered" || A[ue][1].type === "listUnordered")
        if (A[ue][0] === "enter")
          G.push(Oe.length - 1);
        else {
          const Pe = G.pop();
          o(Oe, Pe);
        }
    for (A = Oe, ue = -1; ++ue < A.length; ) {
      const Pe = t[A[ue][0]];
      A[ue][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]), kc.call(Pe, A[ue][1].type) && Pe[A[ue][1].type].call({
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]), A[ue][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
        ...W,
        sliceSerialize: A[ue][2].sliceSerialize
      }, A[ue][1]);
    }
    if (W.tokenStack.length > 0) {
      const Pe = W.tokenStack[W.tokenStack.length - 1];
      (Pe[1] || cs).call(W, void 0, Pe[0]);
    }
    for (N.position = {
      start: yt(A.length > 0 ? A[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: yt(A.length > 0 ? A[A.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    }, ue = -1; ++ue < t.transforms.length; )
      N = t.transforms[ue](N) || N;
    return N;
  }
  function i(A, N, W) {
    let G = -1;
    for (; ++G < A.length; )
      A[G].call(N, W);
  }
  function o(A, N) {
    const W = A.length - 1;
    let G = N - 1, Oe = -1, ue = !1, Pe, it, cn, fn;
    const dn = [];
    for (; ++G <= W; ) {
      const Ne = A[G];
      switch (Ne[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote": {
          Ne[0] === "enter" ? Oe++ : Oe--, fn = void 0;
          break;
        }
        case "lineEndingBlank": {
          Ne[0] === "enter" && (Pe && !fn && !Oe && !cn && (cn = G), fn = void 0);
          break;
        }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace":
          break;
        default:
          fn = void 0;
      }
      if (!Oe && Ne[0] === "enter" && Ne[1].type === "listItemPrefix" || Oe === -1 && Ne[0] === "exit" && (Ne[1].type === "listUnordered" || Ne[1].type === "listOrdered")) {
        if (Pe) {
          let Bt = G;
          for (it = void 0; Bt--; ) {
            const ft = A[Bt];
            if (ft[1].type === "lineEnding" || ft[1].type === "lineEndingBlank") {
              if (ft[0] === "exit") continue;
              it && (A[it][1].type = "lineEndingBlank", ue = !0), ft[1].type = "lineEnding", it = Bt;
            } else if (!(ft[1].type === "linePrefix" || ft[1].type === "blockQuotePrefix" || ft[1].type === "blockQuotePrefixWhitespace" || ft[1].type === "blockQuoteMarker" || ft[1].type === "listItemIndent")) break;
          }
          cn && (!it || cn < it) && (Pe._spread = !0), Pe.end = Object.assign({}, it ? A[it][1].start : Ne[1].end), dn.push({
            at: it || G,
            event: ["exit", Pe, Ne[2]]
          });
        }
        if (Ne[1].type === "listItemPrefix") {
          const Bt = {
            type: "listItem",
            _spread: !1,
            start: Object.assign({}, Ne[1].start),
            // @ts-expect-error: we’ll add `end` in a second.
            end: void 0
          };
          Pe = Bt, dn.push({
            at: G,
            event: ["enter", Bt, Ne[2]]
          }), cn = void 0, fn = !0;
        }
      }
    }
    const Zo = A.splice(N);
    let jr = 0;
    for (G = -1; ++G < Zo.length; ) {
      for (; jr < dn.length && dn[jr].at === N + G; )
        A.push(dn[jr++].event);
      A.push(Zo[G]);
    }
    A[N][1]._spread = ue;
  }
  function a(A, N) {
    return W;
    function W(G) {
      u.call(this, A(G), G), N && N.call(this, G);
    }
  }
  function s() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function u(A, N, W) {
    this.stack[this.stack.length - 1].children.push(A), this.stack.push(A), this.tokenStack.push([N, W || void 0]), A.position = {
      start: yt(N.start),
      // @ts-expect-error: `end` will be patched later.
      end: void 0
    };
  }
  function c(A) {
    return N;
    function N(W) {
      A && A.call(this, W), l.call(this, W);
    }
  }
  function l(A, N) {
    const W = this.stack.pop(), G = this.tokenStack.pop();
    if (!G)
      throw new Error("Cannot close `" + A.type + "` (" + An({
        start: A.start,
        end: A.end
      }) + "): it’s not open");
    G[0].type !== A.type && (N ? N.call(this, A, G[0]) : (G[1] || cs).call(this, A, G[0])), W.position.end = yt(A.end);
  }
  function f() {
    return Or(this.stack.pop());
  }
  function d() {
    this.data.expectingFirstListItemValue = !0;
  }
  function p(A) {
    if (this.data.expectingFirstListItemValue) {
      const N = this.stack[this.stack.length - 2];
      N.start = Number.parseInt(this.sliceSerialize(A), 10), this.data.expectingFirstListItemValue = void 0;
    }
  }
  function h() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.lang = A;
  }
  function m() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.meta = A;
  }
  function k() {
    this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
  }
  function g() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.value = A.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
  }
  function _() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.value = A.replace(/(\r?\n|\r)$/g, "");
  }
  function w(A) {
    const N = this.resume(), W = this.stack[this.stack.length - 1];
    W.label = N, W.identifier = et(this.sliceSerialize(A)).toLowerCase();
  }
  function C() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.title = A;
  }
  function I() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.url = A;
  }
  function y(A) {
    const N = this.stack[this.stack.length - 1];
    if (!N.depth) {
      const W = this.sliceSerialize(A).length;
      N.depth = W;
    }
  }
  function E() {
    this.data.setextHeadingSlurpLineEnding = !0;
  }
  function R(A) {
    const N = this.stack[this.stack.length - 1];
    N.depth = this.sliceSerialize(A).codePointAt(0) === 61 ? 1 : 2;
  }
  function F() {
    this.data.setextHeadingSlurpLineEnding = void 0;
  }
  function S(A) {
    const W = this.stack[this.stack.length - 1].children;
    let G = W[W.length - 1];
    (!G || G.type !== "text") && (G = uf(), G.position = {
      start: yt(A.start),
      // @ts-expect-error: we’ll add `end` later.
      end: void 0
    }, W.push(G)), this.stack.push(G);
  }
  function M(A) {
    const N = this.stack.pop();
    N.value += this.sliceSerialize(A), N.position.end = yt(A.end);
  }
  function L(A) {
    const N = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const W = N.children[N.children.length - 1];
      W.position.end = yt(A.end), this.data.atHardBreak = void 0;
      return;
    }
    !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(N.type) && (S.call(this, A), M.call(this, A));
  }
  function x() {
    this.data.atHardBreak = !0;
  }
  function Z() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.value = A;
  }
  function B() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.value = A;
  }
  function Y() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.value = A;
  }
  function D() {
    const A = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const N = this.data.referenceType || "shortcut";
      A.type += "Reference", A.referenceType = N, delete A.url, delete A.title;
    } else
      delete A.identifier, delete A.label;
    this.data.referenceType = void 0;
  }
  function H() {
    const A = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const N = this.data.referenceType || "shortcut";
      A.type += "Reference", A.referenceType = N, delete A.url, delete A.title;
    } else
      delete A.identifier, delete A.label;
    this.data.referenceType = void 0;
  }
  function le(A) {
    const N = this.sliceSerialize(A), W = this.stack[this.stack.length - 2];
    W.label = u0(N), W.identifier = et(N).toLowerCase();
  }
  function b() {
    const A = this.stack[this.stack.length - 1], N = this.resume(), W = this.stack[this.stack.length - 1];
    if (this.data.inReference = !0, W.type === "link") {
      const G = A.children;
      W.children = G;
    } else
      W.alt = N;
  }
  function ke() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.url = A;
  }
  function Ze() {
    const A = this.resume(), N = this.stack[this.stack.length - 1];
    N.title = A;
  }
  function v() {
    this.data.inReference = void 0;
  }
  function Te() {
    this.data.referenceType = "collapsed";
  }
  function nt(A) {
    const N = this.resume(), W = this.stack[this.stack.length - 1];
    W.label = N, W.identifier = et(this.sliceSerialize(A)).toLowerCase(), this.data.referenceType = "full";
  }
  function ge(A) {
    this.data.characterReferenceType = A.type;
  }
  function rt(A) {
    const N = this.sliceSerialize(A), W = this.data.characterReferenceType;
    let G;
    W ? (G = sc(N, W === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : G = _o(N);
    const Oe = this.stack[this.stack.length - 1];
    Oe.value += G;
  }
  function Ke(A) {
    const N = this.stack.pop();
    N.position.end = yt(A.end);
  }
  function mt(A) {
    M.call(this, A);
    const N = this.stack[this.stack.length - 1];
    N.url = this.sliceSerialize(A);
  }
  function O(A) {
    M.call(this, A);
    const N = this.stack[this.stack.length - 1];
    N.url = "mailto:" + this.sliceSerialize(A);
  }
  function U() {
    return {
      type: "blockquote",
      children: [],
      position: void 0
    };
  }
  function Be() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: "",
      position: void 0
    };
  }
  function zt() {
    return {
      type: "inlineCode",
      value: "",
      position: void 0
    };
  }
  function Vn() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: "",
      position: void 0
    };
  }
  function ln() {
    return {
      type: "emphasis",
      children: [],
      position: void 0
    };
  }
  function un() {
    return {
      type: "heading",
      // @ts-expect-error `depth` will be set later.
      depth: 0,
      children: [],
      position: void 0
    };
  }
  function Fr() {
    return {
      type: "break",
      position: void 0
    };
  }
  function Lo() {
    return {
      type: "html",
      value: "",
      position: void 0
    };
  }
  function of() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null,
      position: void 0
    };
  }
  function Fo() {
    return {
      type: "link",
      title: null,
      url: "",
      children: [],
      position: void 0
    };
  }
  function jo(A) {
    return {
      type: "list",
      ordered: A.type === "listOrdered",
      start: null,
      spread: A._spread,
      children: [],
      position: void 0
    };
  }
  function af(A) {
    return {
      type: "listItem",
      spread: A._spread,
      checked: null,
      children: [],
      position: void 0
    };
  }
  function sf() {
    return {
      type: "paragraph",
      children: [],
      position: void 0
    };
  }
  function lf() {
    return {
      type: "strong",
      children: [],
      position: void 0
    };
  }
  function uf() {
    return {
      type: "text",
      value: "",
      position: void 0
    };
  }
  function cf() {
    return {
      type: "thematicBreak",
      position: void 0
    };
  }
}
function yt(e) {
  return {
    line: e.line,
    column: e.column,
    offset: e.offset
  };
}
function wc(e, t) {
  let n = -1;
  for (; ++n < t.length; ) {
    const r = t[n];
    Array.isArray(r) ? wc(e, r) : p0(e, r);
  }
}
function p0(e, t) {
  let n;
  for (n in t)
    if (kc.call(t, n))
      switch (n) {
        case "canContainEols": {
          const r = t[n];
          r && e[n].push(...r);
          break;
        }
        case "transforms": {
          const r = t[n];
          r && e[n].push(...r);
          break;
        }
        case "afterExit":
        case "beforeEnter": {
          const r = t[n];
          r && e[n].push(r);
          break;
        }
        case "enter":
        case "exit": {
          const r = t[n];
          r && Object.assign(e[n], r);
          break;
        }
      }
}
function cs(e, t) {
  throw e ? new Error("Cannot close `" + e.type + "` (" + An({
    start: e.start,
    end: e.end
  }) + "): a different token (`" + t.type + "`, " + An({
    start: t.start,
    end: t.end
  }) + ") is open") : new Error("Cannot close document, a token (`" + t.type + "`, " + An({
    start: t.start,
    end: t.end
  }) + ") is still open");
}
function h0(e) {
  const t = this;
  t.parser = n;
  function n(r) {
    return f0(r, {
      ...t.data("settings"),
      ...e,
      // Note: these options are not in the readme.
      // The goal is for them to be set by plugins on `data` instead of being
      // passed by users.
      extensions: t.data("micromarkExtensions") || [],
      mdastExtensions: t.data("fromMarkdownExtensions") || []
    });
  }
}
function m0(e, t) {
  const n = {
    type: "element",
    tagName: "blockquote",
    properties: {},
    children: e.wrap(e.all(t), !0)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function g0(e, t) {
  const n = { type: "element", tagName: "br", properties: {}, children: [] };
  return e.patch(t, n), [e.applyData(t, n), { type: "text", value: `
` }];
}
function y0(e, t) {
  const n = t.value ? t.value + `
` : "", r = {}, i = t.lang ? t.lang.split(/\s+/) : [];
  i.length > 0 && (r.className = ["language-" + i[0]]);
  let o = {
    type: "element",
    tagName: "code",
    properties: r,
    children: [{ type: "text", value: n }]
  };
  return t.meta && (o.data = { meta: t.meta }), e.patch(t, o), o = e.applyData(t, o), o = { type: "element", tagName: "pre", properties: {}, children: [o] }, e.patch(t, o), o;
}
function b0(e, t) {
  const n = {
    type: "element",
    tagName: "del",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function v0(e, t) {
  const n = {
    type: "element",
    tagName: "em",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function k0(e, t) {
  const n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", r = String(t.identifier).toUpperCase(), i = sn(r.toLowerCase()), o = e.footnoteOrder.indexOf(r);
  let a, s = e.footnoteCounts.get(r);
  s === void 0 ? (s = 0, e.footnoteOrder.push(r), a = e.footnoteOrder.length) : a = o + 1, s += 1, e.footnoteCounts.set(r, s);
  const u = {
    type: "element",
    tagName: "a",
    properties: {
      href: "#" + n + "fn-" + i,
      id: n + "fnref-" + i + (s > 1 ? "-" + s : ""),
      dataFootnoteRef: !0,
      ariaDescribedBy: ["footnote-label"]
    },
    children: [{ type: "text", value: String(a) }]
  };
  e.patch(t, u);
  const c = {
    type: "element",
    tagName: "sup",
    properties: {},
    children: [u]
  };
  return e.patch(t, c), e.applyData(t, c);
}
function w0(e, t) {
  const n = {
    type: "element",
    tagName: "h" + t.depth,
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function x0(e, t) {
  if (e.options.allowDangerousHtml) {
    const n = { type: "raw", value: t.value };
    return e.patch(t, n), e.applyData(t, n);
  }
}
function xc(e, t) {
  const n = t.referenceType;
  let r = "]";
  if (n === "collapsed" ? r += "[]" : n === "full" && (r += "[" + (t.label || t.identifier) + "]"), t.type === "imageReference")
    return [{ type: "text", value: "![" + t.alt + r }];
  const i = e.all(t), o = i[0];
  o && o.type === "text" ? o.value = "[" + o.value : i.unshift({ type: "text", value: "[" });
  const a = i[i.length - 1];
  return a && a.type === "text" ? a.value += r : i.push({ type: "text", value: r }), i;
}
function _0(e, t) {
  const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
  if (!r)
    return xc(e, t);
  const i = { src: sn(r.url || ""), alt: t.alt };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const o = { type: "element", tagName: "img", properties: i, children: [] };
  return e.patch(t, o), e.applyData(t, o);
}
function S0(e, t) {
  const n = { src: sn(t.url) };
  t.alt !== null && t.alt !== void 0 && (n.alt = t.alt), t.title !== null && t.title !== void 0 && (n.title = t.title);
  const r = { type: "element", tagName: "img", properties: n, children: [] };
  return e.patch(t, r), e.applyData(t, r);
}
function I0(e, t) {
  const n = { type: "text", value: t.value.replace(/\r?\n|\r/g, " ") };
  e.patch(t, n);
  const r = {
    type: "element",
    tagName: "code",
    properties: {},
    children: [n]
  };
  return e.patch(t, r), e.applyData(t, r);
}
function E0(e, t) {
  const n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
  if (!r)
    return xc(e, t);
  const i = { href: sn(r.url || "") };
  r.title !== null && r.title !== void 0 && (i.title = r.title);
  const o = {
    type: "element",
    tagName: "a",
    properties: i,
    children: e.all(t)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function C0(e, t) {
  const n = { href: sn(t.url) };
  t.title !== null && t.title !== void 0 && (n.title = t.title);
  const r = {
    type: "element",
    tagName: "a",
    properties: n,
    children: e.all(t)
  };
  return e.patch(t, r), e.applyData(t, r);
}
function A0(e, t, n) {
  const r = e.all(t), i = n ? z0(n) : _c(t), o = {}, a = [];
  if (typeof t.checked == "boolean") {
    const l = r[0];
    let f;
    l && l.type === "element" && l.tagName === "p" ? f = l : (f = { type: "element", tagName: "p", properties: {}, children: [] }, r.unshift(f)), f.children.length > 0 && f.children.unshift({ type: "text", value: " " }), f.children.unshift({
      type: "element",
      tagName: "input",
      properties: { type: "checkbox", checked: t.checked, disabled: !0 },
      children: []
    }), o.className = ["task-list-item"];
  }
  let s = -1;
  for (; ++s < r.length; ) {
    const l = r[s];
    (i || s !== 0 || l.type !== "element" || l.tagName !== "p") && a.push({ type: "text", value: `
` }), l.type === "element" && l.tagName === "p" && !i ? a.push(...l.children) : a.push(l);
  }
  const u = r[r.length - 1];
  u && (i || u.type !== "element" || u.tagName !== "p") && a.push({ type: "text", value: `
` });
  const c = { type: "element", tagName: "li", properties: o, children: a };
  return e.patch(t, c), e.applyData(t, c);
}
function z0(e) {
  let t = !1;
  if (e.type === "list") {
    t = e.spread || !1;
    const n = e.children;
    let r = -1;
    for (; !t && ++r < n.length; )
      t = _c(n[r]);
  }
  return t;
}
function _c(e) {
  const t = e.spread;
  return t ?? e.children.length > 1;
}
function T0(e, t) {
  const n = {}, r = e.all(t);
  let i = -1;
  for (typeof t.start == "number" && t.start !== 1 && (n.start = t.start); ++i < r.length; ) {
    const a = r[i];
    if (a.type === "element" && a.tagName === "li" && a.properties && Array.isArray(a.properties.className) && a.properties.className.includes("task-list-item")) {
      n.className = ["contains-task-list"];
      break;
    }
  }
  const o = {
    type: "element",
    tagName: t.ordered ? "ol" : "ul",
    properties: n,
    children: e.wrap(r, !0)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function O0(e, t) {
  const n = {
    type: "element",
    tagName: "p",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function P0(e, t) {
  const n = { type: "root", children: e.wrap(e.all(t)) };
  return e.patch(t, n), e.applyData(t, n);
}
function M0(e, t) {
  const n = {
    type: "element",
    tagName: "strong",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
function R0(e, t) {
  const n = e.all(t), r = n.shift(), i = [];
  if (r) {
    const a = {
      type: "element",
      tagName: "thead",
      properties: {},
      children: e.wrap([r], !0)
    };
    e.patch(t.children[0], a), i.push(a);
  }
  if (n.length > 0) {
    const a = {
      type: "element",
      tagName: "tbody",
      properties: {},
      children: e.wrap(n, !0)
    }, s = vo(t.children[1]), u = Qu(t.children[t.children.length - 1]);
    s && u && (a.position = { start: s, end: u }), i.push(a);
  }
  const o = {
    type: "element",
    tagName: "table",
    properties: {},
    children: e.wrap(i, !0)
  };
  return e.patch(t, o), e.applyData(t, o);
}
function $0(e, t, n) {
  const r = n ? n.children : void 0, o = (r ? r.indexOf(t) : 1) === 0 ? "th" : "td", a = n && n.type === "table" ? n.align : void 0, s = a ? a.length : t.children.length;
  let u = -1;
  const c = [];
  for (; ++u < s; ) {
    const f = t.children[u], d = {}, p = a ? a[u] : void 0;
    p && (d.align = p);
    let h = { type: "element", tagName: o, properties: d, children: [] };
    f && (h.children = e.all(f), e.patch(f, h), h = e.applyData(f, h)), c.push(h);
  }
  const l = {
    type: "element",
    tagName: "tr",
    properties: {},
    children: e.wrap(c, !0)
  };
  return e.patch(t, l), e.applyData(t, l);
}
function N0(e, t) {
  const n = {
    type: "element",
    tagName: "td",
    // Assume body cell.
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, n), e.applyData(t, n);
}
const fs = 9, ds = 32;
function D0(e) {
  const t = String(e), n = /\r?\n|\r/g;
  let r = n.exec(t), i = 0;
  const o = [];
  for (; r; )
    o.push(
      ps(t.slice(i, r.index), i > 0, !0),
      r[0]
    ), i = r.index + r[0].length, r = n.exec(t);
  return o.push(ps(t.slice(i), i > 0, !1)), o.join("");
}
function ps(e, t, n) {
  let r = 0, i = e.length;
  if (t) {
    let o = e.codePointAt(r);
    for (; o === fs || o === ds; )
      r++, o = e.codePointAt(r);
  }
  if (n) {
    let o = e.codePointAt(i - 1);
    for (; o === fs || o === ds; )
      i--, o = e.codePointAt(i - 1);
  }
  return i > r ? e.slice(r, i) : "";
}
function L0(e, t) {
  const n = { type: "text", value: D0(String(t.value)) };
  return e.patch(t, n), e.applyData(t, n);
}
function F0(e, t) {
  const n = {
    type: "element",
    tagName: "hr",
    properties: {},
    children: []
  };
  return e.patch(t, n), e.applyData(t, n);
}
const j0 = {
  blockquote: m0,
  break: g0,
  code: y0,
  delete: b0,
  emphasis: v0,
  footnoteReference: k0,
  heading: w0,
  html: x0,
  imageReference: _0,
  image: S0,
  inlineCode: I0,
  linkReference: E0,
  link: C0,
  listItem: A0,
  list: T0,
  paragraph: O0,
  // @ts-expect-error: root is different, but hard to type.
  root: P0,
  strong: M0,
  table: R0,
  tableCell: N0,
  tableRow: $0,
  text: L0,
  thematicBreak: F0,
  toml: Yn,
  yaml: Yn,
  definition: Yn,
  footnoteDefinition: Yn
};
function Yn() {
}
const Sc = -1, Mr = 0, Tn = 1, wr = 2, Io = 3, Eo = 4, Co = 5, Ao = 6, Ic = 7, Ec = 8, { defineProperty: Z0 } = Object, Cc = typeof self == "object" ? self : globalThis, hs = (e, t) => {
  switch (e) {
    case "Function":
    case "SharedWorker":
    case "Worker":
    case "eval":
    case "setInterval":
    case "setTimeout":
      throw new TypeError("unable to deserialize " + e);
  }
  return new Cc[e](t);
}, B0 = (e, t) => {
  const n = (i, o) => (e.set(o, i), i), r = (i) => {
    if (e.has(i))
      return e.get(i);
    const [o, a] = t[i];
    switch (o) {
      case Mr:
      case Sc:
        return n(a, i);
      case Tn: {
        const s = n([], i);
        for (const u of a)
          s.push(r(u));
        return s;
      }
      case wr: {
        const s = n({}, i);
        for (const [u, c] of a) {
          const l = r(u), f = r(c);
          l === "__proto__" ? Z0(s, l, {
            value: f,
            configurable: !0,
            enumerable: !0,
            writable: !0
          }) : s[l] = f;
        }
        return s;
      }
      case Io:
        return n(new Date(a), i);
      case Eo: {
        const { source: s, flags: u } = a;
        return n(new RegExp(s, u), i);
      }
      case Co: {
        const s = n(/* @__PURE__ */ new Map(), i);
        for (const [u, c] of a)
          s.set(r(u), r(c));
        return s;
      }
      case Ao: {
        const s = n(/* @__PURE__ */ new Set(), i);
        for (const u of a)
          s.add(r(u));
        return s;
      }
      case Ic: {
        const { name: s, message: u } = a;
        return n(
          typeof Cc[s] == "function" ? hs(s, u) : new Error(u),
          i
        );
      }
      case Ec:
        return n(BigInt(a), i);
      case "BigInt":
        return n(Object(BigInt(a)), i);
      case "ArrayBuffer":
        return n(new Uint8Array(a).buffer, a);
      case "DataView": {
        const { buffer: s } = new Uint8Array(a);
        return n(new DataView(s), a);
      }
      case "-0":
        return -0;
    }
    return n(hs(o, a), i);
  };
  return r;
}, ms = (e) => B0(/* @__PURE__ */ new Map(), e)(0), Pt = "", { toString: U0 } = {}, { keys: V0, is: q0 } = Object, yn = (e) => {
  const t = typeof e;
  if (t !== "object" || !e)
    return [Mr, t];
  const n = U0.call(e).slice(8, -1);
  switch (n) {
    case "Array":
      return [Tn, Pt];
    case "Object":
      return [wr, Pt];
    case "Date":
      return [Io, Pt];
    case "RegExp":
      return [Eo, Pt];
    case "Map":
      return [Co, Pt];
    case "Set":
      return [Ao, Pt];
    case "DataView":
      return [Tn, n];
  }
  return n.includes("Array") ? [Tn, n] : e instanceof Error ? [Ic, e.name || "Error"] : [wr, n];
}, Gn = ([e, t]) => e === Mr && (t === "function" || t === "symbol"), J0 = (e, t, n, r) => {
  const i = (a, s) => {
    const u = r.push(a) - 1;
    return n.set(s, u), u;
  }, o = (a) => {
    if (n.has(a))
      return n.get(a);
    let [s, u] = yn(a);
    switch (s) {
      case Mr: {
        let l = a;
        switch (u) {
          case "bigint":
            s = Ec, l = a.toString();
            break;
          case "number":
            if (!a && q0(a, -0))
              return r.push(["-0"]) - 1;
            break;
          case "function":
          case "symbol":
            if (e)
              throw new TypeError("unable to serialize " + u);
            l = null;
            break;
          case "undefined":
            return i([Sc], a);
        }
        return i([s, l], a);
      }
      case Tn: {
        if (u) {
          let d = a;
          return u === "DataView" ? d = new Uint8Array(a.buffer) : u === "ArrayBuffer" && (d = new Uint8Array(a)), i([u, [...d]], a);
        }
        const l = [], f = i([s, l], a);
        for (const d of a)
          l.push(o(d));
        return f;
      }
      case wr: {
        if (u)
          switch (u) {
            case "BigInt":
              return i([u, a.toString()], a);
            case "Boolean":
            case "Number":
            case "String":
              return i([u, a.valueOf()], a);
          }
        if (t && "toJSON" in a)
          return o(a.toJSON());
        const l = [], f = i([s, l], a);
        for (const d of V0(a))
          (e || !Gn(yn(a[d]))) && l.push([o(d), o(a[d])]);
        return f;
      }
      case Io:
        return i([s, isNaN(a.getTime()) ? Pt : a.toISOString()], a);
      case Eo: {
        const { source: l, flags: f } = a;
        return i([s, { source: l, flags: f }], a);
      }
      case Co: {
        const l = [], f = i([s, l], a);
        for (const [d, p] of a)
          (e || !(Gn(yn(d)) || Gn(yn(p)))) && l.push([o(d), o(p)]);
        return f;
      }
      case Ao: {
        const l = [], f = i([s, l], a);
        for (const d of a)
          (e || !Gn(yn(d))) && l.push(o(d));
        return f;
      }
    }
    const { message: c } = a;
    return i([s, { name: u, message: c }], a);
  };
  return o;
}, gs = (e, { json: t, lossy: n } = {}) => {
  const r = [];
  return J0(!(t || n), !!t, /* @__PURE__ */ new Map(), r)(e), r;
}, xr = typeof structuredClone == "function" ? (
  /* c8 ignore start */
  (e, t) => t && ("json" in t || "lossy" in t) ? ms(gs(e, t)) : structuredClone(e)
) : (e, t) => ms(gs(e, t));
function W0(e, t) {
  const n = [{ type: "text", value: "↩" }];
  return t > 1 && n.push({
    type: "element",
    tagName: "sup",
    properties: {},
    children: [{ type: "text", value: String(t) }]
  }), n;
}
function H0(e, t) {
  return "Back to reference " + (e + 1) + (t > 1 ? "-" + t : "");
}
function K0(e) {
  const t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", n = e.options.footnoteBackContent || W0, r = e.options.footnoteBackLabel || H0, i = e.options.footnoteLabel || "Footnotes", o = e.options.footnoteLabelTagName || "h2", a = e.options.footnoteLabelProperties || {
    className: ["sr-only"]
  }, s = [];
  let u = -1;
  for (; ++u < e.footnoteOrder.length; ) {
    const c = e.footnoteById.get(
      e.footnoteOrder[u]
    );
    if (!c)
      continue;
    const l = e.all(c), f = String(c.identifier).toUpperCase(), d = sn(f.toLowerCase());
    let p = 0;
    const h = [], m = e.footnoteCounts.get(f);
    for (; m !== void 0 && ++p <= m; ) {
      h.length > 0 && h.push({ type: "text", value: " " });
      let _ = typeof n == "string" ? n : n(u, p);
      typeof _ == "string" && (_ = { type: "text", value: _ }), h.push({
        type: "element",
        tagName: "a",
        properties: {
          href: "#" + t + "fnref-" + d + (p > 1 ? "-" + p : ""),
          dataFootnoteBackref: "",
          ariaLabel: typeof r == "string" ? r : r(u, p),
          className: ["data-footnote-backref"]
        },
        children: Array.isArray(_) ? _ : [_]
      });
    }
    const k = l[l.length - 1];
    if (k && k.type === "element" && k.tagName === "p") {
      const _ = k.children[k.children.length - 1];
      _ && _.type === "text" ? _.value += " " : k.children.push({ type: "text", value: " " }), k.children.push(...h);
    } else
      l.push(...h);
    const g = {
      type: "element",
      tagName: "li",
      properties: { id: t + "fn-" + d },
      children: e.wrap(l, !0)
    };
    e.patch(c, g), s.push(g);
  }
  if (s.length !== 0)
    return {
      type: "element",
      tagName: "section",
      properties: { dataFootnotes: !0, className: ["footnotes"] },
      children: [
        {
          type: "element",
          tagName: o,
          properties: {
            ...xr(a),
            id: "footnote-label"
          },
          children: [{ type: "text", value: i }]
        },
        { type: "text", value: `
` },
        {
          type: "element",
          tagName: "ol",
          properties: {},
          children: e.wrap(s, !0)
        },
        { type: "text", value: `
` }
      ]
    };
}
const Rr = (
  // Note: overloads in JSDoc can’t yet use different `@template`s.
  /**
   * @type {(
   *   (<Condition extends string>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & {type: Condition}) &
   *   (<Condition extends Props>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Condition) &
   *   (<Condition extends TestFunction>(test: Condition) => (node: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node & Predicate<Condition, Node>) &
   *   ((test?: null | undefined) => (node?: unknown, index?: number | null | undefined, parent?: Parent | null | undefined, context?: unknown) => node is Node) &
   *   ((test?: Test) => Check)
   * )}
   */
  /**
   * @param {Test} [test]
   * @returns {Check}
   */
  function(e) {
    if (e == null)
      return Q0;
    if (typeof e == "function")
      return $r(e);
    if (typeof e == "object")
      return Array.isArray(e) ? Y0(e) : (
        // Cast because `ReadonlyArray` goes into the above but `isArray`
        // narrows to `Array`.
        G0(
          /** @type {Props} */
          e
        )
      );
    if (typeof e == "string")
      return X0(e);
    throw new Error("Expected function, string, or object as test");
  }
);
function Y0(e) {
  const t = [];
  let n = -1;
  for (; ++n < e.length; )
    t[n] = Rr(e[n]);
  return $r(r);
  function r(...i) {
    let o = -1;
    for (; ++o < t.length; )
      if (t[o].apply(this, i)) return !0;
    return !1;
  }
}
function G0(e) {
  const t = (
    /** @type {Record<string, unknown>} */
    e
  );
  return $r(n);
  function n(r) {
    const i = (
      /** @type {Record<string, unknown>} */
      /** @type {unknown} */
      r
    );
    let o;
    for (o in e)
      if (i[o] !== t[o]) return !1;
    return !0;
  }
}
function X0(e) {
  return $r(t);
  function t(n) {
    return n && n.type === e;
  }
}
function $r(e) {
  return t;
  function t(n, r, i) {
    return !!(e1(n) && e.call(
      this,
      n,
      typeof r == "number" ? r : void 0,
      i || void 0
    ));
  }
}
function Q0() {
  return !0;
}
function e1(e) {
  return e !== null && typeof e == "object" && "type" in e;
}
const Ac = [], t1 = !0, On = !1, Vi = "skip";
function qi(e, t, n, r) {
  if (!e || typeof e != "object")
    throw new Error("Unexpected value `" + e + "` for `tree`, expected node");
  let i = !0, o, a, s, u;
  if (typeof n == "function" || n && typeof n == "object" ? (o = /** @type {Test} */
  t, a = n, r && (i = !1)) : (a = /** @type {Visitors | Visitor} */
  t, n && (i = !1)), typeof a == "function")
    s = a;
  else if (a && typeof a == "object") {
    if (!(a.enter === null || a.enter === void 0)) if (typeof a.enter == "function")
      s = a.enter;
    else
      throw new Error(
        "Unexpected value `" + a.enter + "` for `visitors.enter`, expected optional visitor"
      );
    if (typeof a.exit == "function")
      u = a.exit;
    else
      throw new Error(
        "Unexpected value `" + a.exit + "` for `visitors.exit`, expected visitor (pass a visitor directly if you only want an enter visitor)"
      );
  } else
    throw new Error(
      "Unexpected value `" + a + "` for `enter` or `visitors`, expected visitor or object with visitors"
    );
  const c = Rr(o), l = i ? 1 : -1;
  f(e, void 0, [])();
  function f(d, p, h) {
    const m = (
      /** @type {Record<string, unknown>} */
      d && typeof d == "object" ? d : {}
    );
    if (typeof m.type == "string") {
      const g = (
        // `hast`
        typeof m.tagName == "string" ? m.tagName : (
          // `xast`
          typeof m.name == "string" ? m.name : void 0
        )
      );
      Object.defineProperty(k, "name", {
        value: "node (" + (d.type + (g ? "<" + g + ">" : "")) + ")"
      });
    }
    return k;
    function k() {
      const g = !o || c(d, p, h[h.length - 1] || void 0);
      let _ = Ac;
      if (s && g && (_ = ys(s(d, h, p)), _[0] === On))
        return _;
      if ("children" in d && d.children) {
        const w = (
          /** @type {UnistParent} */
          d
        );
        if (w.children && _[0] !== Vi) {
          let C = (i ? -1 : w.children.length) + l;
          const I = [...h, w];
          for (; C > -1 && C < w.children.length; ) {
            const y = w.children[C], E = f(y, C, I)();
            if (E[0] === On)
              return E;
            C = typeof E[1] == "number" ? E[1] : C + l;
          }
        }
      }
      if (u && g) {
        const w = ys(u(d, h, p));
        if (w[0] === Vi)
          throw new Error(
            "Unexpected value `" + w[0] + "` from `exit`, expected `CONTINUE`, `EXIT`, index, or nothing"
          );
        if (w[0] === On || typeof w[1] == "number")
          return w;
      }
      return _;
    }
  }
}
function ys(e) {
  return Array.isArray(e) ? e : typeof e == "number" ? [t1, e] : e == null ? Ac : [e];
}
function Nr(e, t, n, r) {
  let i, o, a;
  o = /** @type {Visitor | Visitors} */
  t, a = n, typeof o == "function" ? qi(e, i, Ji(o), a) : qi(e, i, n1(o), a);
}
function n1(e) {
  return !e || typeof e != "object" ? e : {
    enter: typeof e.enter == "function" ? Ji(e.enter) : e.enter,
    exit: typeof e.exit == "function" ? Ji(e.exit) : e.exit
  };
}
function Ji(e) {
  return t;
  function t(n, r, i) {
    return e(n, i, r[r.length - 1]);
  }
}
const Wi = {}.hasOwnProperty, r1 = {};
function i1(e, t) {
  const n = t || r1, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), a = { ...j0, ...n.handlers }, s = {
    all: c,
    applyData: a1,
    definitionById: r,
    footnoteById: i,
    footnoteCounts: o,
    footnoteOrder: [],
    handlers: a,
    one: u,
    options: n,
    patch: o1,
    wrap: l1
  };
  return Nr(e, function(l) {
    if (l.type === "definition" || l.type === "footnoteDefinition") {
      const f = l.type === "definition" ? r : i, d = String(l.identifier).toUpperCase();
      f.has(d) || f.set(d, l);
    }
  }), s;
  function u(l, f) {
    const d = l.type, p = s.handlers[d];
    if (Wi.call(s.handlers, d) && p)
      return p(s, l, f);
    if (s.options.passThrough && s.options.passThrough.includes(d)) {
      if ("children" in l) {
        const { children: m, ...k } = l, g = xr(k);
        return g.children = s.all(l), g;
      }
      return xr(l);
    }
    return (s.options.unknownHandler || s1)(s, l, f);
  }
  function c(l) {
    const f = [];
    if ("children" in l) {
      const d = l.children;
      let p = -1;
      for (; ++p < d.length; ) {
        const h = s.one(d[p], l);
        if (h) {
          if (p && d[p - 1].type === "break" && (!Array.isArray(h) && h.type === "text" && (h.value = bs(h.value)), !Array.isArray(h) && h.type === "element")) {
            const m = h.children[0];
            m && m.type === "text" && (m.value = bs(m.value));
          }
          Array.isArray(h) ? f.push(...h) : f.push(h);
        }
      }
    }
    return f;
  }
}
function o1(e, t) {
  e.position && (t.position = Hv(e));
}
function a1(e, t) {
  let n = t;
  if (e && e.data) {
    const r = e.data.hName, i = e.data.hChildren, o = e.data.hProperties;
    if (typeof r == "string")
      if (n.type === "element")
        n.tagName = r;
      else {
        const a = "children" in n ? n.children : [n];
        n = { type: "element", tagName: r, properties: {}, children: a };
      }
    n.type === "element" && o && Object.assign(n.properties, xr(o)), "children" in n && n.children && i !== null && i !== void 0 && (n.children = i);
  }
  return n;
}
function s1(e, t) {
  const n = t.data || {}, r = "value" in t && !(Wi.call(n, "hProperties") || Wi.call(n, "hChildren")) ? { type: "text", value: t.value } : {
    type: "element",
    tagName: "div",
    properties: {},
    children: e.all(t)
  };
  return e.patch(t, r), e.applyData(t, r);
}
function l1(e, t) {
  const n = [];
  let r = -1;
  for (t && n.push({ type: "text", value: `
` }); ++r < e.length; )
    r && n.push({ type: "text", value: `
` }), n.push(e[r]);
  return t && e.length > 0 && n.push({ type: "text", value: `
` }), n;
}
function bs(e) {
  let t = 0, n = e.charCodeAt(t);
  for (; n === 9 || n === 32; )
    t++, n = e.charCodeAt(t);
  return e.slice(t);
}
function vs(e, t) {
  const n = i1(e, t), r = n.one(e, void 0), i = K0(n), o = Array.isArray(r) ? { type: "root", children: r } : r || { type: "root", children: [] };
  return i && o.children.push({ type: "text", value: `
` }, i), o;
}
function u1(e, t) {
  return e && "run" in e ? async function(n, r) {
    const i = (
      /** @type {HastRoot} */
      vs(n, { file: r, ...t })
    );
    await e.run(i, r);
  } : function(n, r) {
    return (
      /** @type {HastRoot} */
      vs(n, { file: r, ...e || t })
    );
  };
}
function ks(e) {
  if (e)
    throw e;
}
var ur = Object.prototype.hasOwnProperty, zc = Object.prototype.toString, ws = Object.defineProperty, xs = Object.getOwnPropertyDescriptor, _s = function(t) {
  return typeof Array.isArray == "function" ? Array.isArray(t) : zc.call(t) === "[object Array]";
}, Ss = function(t) {
  if (!t || zc.call(t) !== "[object Object]")
    return !1;
  var n = ur.call(t, "constructor"), r = t.constructor && t.constructor.prototype && ur.call(t.constructor.prototype, "isPrototypeOf");
  if (t.constructor && !n && !r)
    return !1;
  var i;
  for (i in t)
    ;
  return typeof i > "u" || ur.call(t, i);
}, Is = function(t, n) {
  ws && n.name === "__proto__" ? ws(t, n.name, {
    enumerable: !0,
    configurable: !0,
    value: n.newValue,
    writable: !0
  }) : t[n.name] = n.newValue;
}, Es = function(t, n) {
  if (n === "__proto__")
    if (ur.call(t, n)) {
      if (xs)
        return xs(t, n).value;
    } else return;
  return t[n];
}, c1 = function e() {
  var t, n, r, i, o, a, s = arguments[0], u = 1, c = arguments.length, l = !1;
  for (typeof s == "boolean" && (l = s, s = arguments[1] || {}, u = 2), (s == null || typeof s != "object" && typeof s != "function") && (s = {}); u < c; ++u)
    if (t = arguments[u], t != null)
      for (n in t)
        r = Es(s, n), i = Es(t, n), s !== i && (l && i && (Ss(i) || (o = _s(i))) ? (o ? (o = !1, a = r && _s(r) ? r : []) : a = r && Ss(r) ? r : {}, Is(s, { name: n, newValue: e(l, a, i) })) : typeof i < "u" && Is(s, { name: n, newValue: i }));
  return s;
};
const ii = /* @__PURE__ */ Cu(c1);
function Hi(e) {
  if (typeof e != "object" || e === null)
    return !1;
  const t = Object.getPrototypeOf(e);
  return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
function f1() {
  const e = [], t = { run: n, use: r };
  return t;
  function n(...i) {
    let o = -1;
    const a = i.pop();
    if (typeof a != "function")
      throw new TypeError("Expected function as last argument, not " + a);
    s(null, ...i);
    function s(u, ...c) {
      const l = e[++o];
      let f = -1;
      if (u) {
        a(u);
        return;
      }
      for (; ++f < i.length; )
        (c[f] === null || c[f] === void 0) && (c[f] = i[f]);
      i = c, l ? d1(l, s)(...c) : a(null, ...c);
    }
  }
  function r(i) {
    if (typeof i != "function")
      throw new TypeError(
        "Expected `middelware` to be a function, not " + i
      );
    return e.push(i), t;
  }
}
function d1(e, t) {
  let n;
  return r;
  function r(...a) {
    const s = e.length > a.length;
    let u;
    s && a.push(i);
    try {
      u = e.apply(this, a);
    } catch (c) {
      const l = (
        /** @type {Error} */
        c
      );
      if (s && n)
        throw l;
      return i(l);
    }
    s || (u && u.then && typeof u.then == "function" ? u.then(o, i) : u instanceof Error ? i(u) : o(u));
  }
  function i(a, ...s) {
    n || (n = !0, t(a, ...s));
  }
  function o(a) {
    i(null, a);
  }
}
const at = { basename: p1, dirname: h1, extname: m1, join: g1, sep: "/" };
function p1(e, t) {
  if (t !== void 0 && typeof t != "string")
    throw new TypeError('"ext" argument must be a string');
  Un(e);
  let n = 0, r = -1, i = e.length, o;
  if (t === void 0 || t.length === 0 || t.length > e.length) {
    for (; i--; )
      if (e.codePointAt(i) === 47) {
        if (o) {
          n = i + 1;
          break;
        }
      } else r < 0 && (o = !0, r = i + 1);
    return r < 0 ? "" : e.slice(n, r);
  }
  if (t === e)
    return "";
  let a = -1, s = t.length - 1;
  for (; i--; )
    if (e.codePointAt(i) === 47) {
      if (o) {
        n = i + 1;
        break;
      }
    } else
      a < 0 && (o = !0, a = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = a));
  return n === r ? r = a : r < 0 && (r = e.length), e.slice(n, r);
}
function h1(e) {
  if (Un(e), e.length === 0)
    return ".";
  let t = -1, n = e.length, r;
  for (; --n; )
    if (e.codePointAt(n) === 47) {
      if (r) {
        t = n;
        break;
      }
    } else r || (r = !0);
  return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function m1(e) {
  Un(e);
  let t = e.length, n = -1, r = 0, i = -1, o = 0, a;
  for (; t--; ) {
    const s = e.codePointAt(t);
    if (s === 47) {
      if (a) {
        r = t + 1;
        break;
      }
      continue;
    }
    n < 0 && (a = !0, n = t + 1), s === 46 ? i < 0 ? i = t : o !== 1 && (o = 1) : i > -1 && (o = -1);
  }
  return i < 0 || n < 0 || // We saw a non-dot character immediately before the dot.
  o === 0 || // The (right-most) trimmed path component is exactly `..`.
  o === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function g1(...e) {
  let t = -1, n;
  for (; ++t < e.length; )
    Un(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
  return n === void 0 ? "." : y1(n);
}
function y1(e) {
  Un(e);
  const t = e.codePointAt(0) === 47;
  let n = b1(e, !t);
  return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function b1(e, t) {
  let n = "", r = 0, i = -1, o = 0, a = -1, s, u;
  for (; ++a <= e.length; ) {
    if (a < e.length)
      s = e.codePointAt(a);
    else {
      if (s === 47)
        break;
      s = 47;
    }
    if (s === 47) {
      if (!(i === a - 1 || o === 1)) if (i !== a - 1 && o === 2) {
        if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
          if (n.length > 2) {
            if (u = n.lastIndexOf("/"), u !== n.length - 1) {
              u < 0 ? (n = "", r = 0) : (n = n.slice(0, u), r = n.length - 1 - n.lastIndexOf("/")), i = a, o = 0;
              continue;
            }
          } else if (n.length > 0) {
            n = "", r = 0, i = a, o = 0;
            continue;
          }
        }
        t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
      } else
        n.length > 0 ? n += "/" + e.slice(i + 1, a) : n = e.slice(i + 1, a), r = a - i - 1;
      i = a, o = 0;
    } else s === 46 && o > -1 ? o++ : o = -1;
  }
  return n;
}
function Un(e) {
  if (typeof e != "string")
    throw new TypeError(
      "Path must be a string. Received " + JSON.stringify(e)
    );
}
const v1 = { cwd: k1 };
function k1() {
  return "/";
}
function Ki(e) {
  return !!(e !== null && typeof e == "object" && "href" in e && e.href && "protocol" in e && e.protocol && // @ts-expect-error: indexing is fine.
  e.auth === void 0);
}
function w1(e) {
  if (typeof e == "string")
    e = new URL(e);
  else if (!Ki(e)) {
    const t = new TypeError(
      'The "path" argument must be of type string or an instance of URL. Received `' + e + "`"
    );
    throw t.code = "ERR_INVALID_ARG_TYPE", t;
  }
  if (e.protocol !== "file:") {
    const t = new TypeError("The URL must be of scheme file");
    throw t.code = "ERR_INVALID_URL_SCHEME", t;
  }
  return x1(e);
}
function x1(e) {
  if (e.hostname !== "") {
    const r = new TypeError(
      'File URL host must be "localhost" or empty on darwin'
    );
    throw r.code = "ERR_INVALID_FILE_URL_HOST", r;
  }
  const t = e.pathname;
  let n = -1;
  for (; ++n < t.length; )
    if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
      const r = t.codePointAt(n + 2);
      if (r === 70 || r === 102) {
        const i = new TypeError(
          "File URL path must not include encoded / characters"
        );
        throw i.code = "ERR_INVALID_FILE_URL_PATH", i;
      }
    }
  return decodeURIComponent(t);
}
const oi = (
  /** @type {const} */
  [
    "history",
    "path",
    "basename",
    "stem",
    "extname",
    "dirname"
  ]
);
class Tc {
  /**
   * Create a new virtual file.
   *
   * `options` is treated as:
   *
   * *   `string` or `Uint8Array` — `{value: options}`
   * *   `URL` — `{path: options}`
   * *   `VFile` — shallow copies its data over to the new file
   * *   `object` — all fields are shallow copied over to the new file
   *
   * Path related fields are set in the following order (least specific to
   * most specific): `history`, `path`, `basename`, `stem`, `extname`,
   * `dirname`.
   *
   * You cannot set `dirname` or `extname` without setting either `history`,
   * `path`, `basename`, or `stem` too.
   *
   * @param {Compatible | null | undefined} [value]
   *   File value.
   * @returns
   *   New instance.
   */
  constructor(t) {
    let n;
    t ? Ki(t) ? n = { path: t } : typeof t == "string" || _1(t) ? n = { value: t } : n = t : n = {}, this.cwd = "cwd" in n ? "" : v1.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
    let r = -1;
    for (; ++r < oi.length; ) {
      const o = oi[r];
      o in n && n[o] !== void 0 && n[o] !== null && (this[o] = o === "history" ? [...n[o]] : n[o]);
    }
    let i;
    for (i in n)
      oi.includes(i) || (this[i] = n[i]);
  }
  /**
   * Get the basename (including extname) (example: `'index.min.js'`).
   *
   * @returns {string | undefined}
   *   Basename.
   */
  get basename() {
    return typeof this.path == "string" ? at.basename(this.path) : void 0;
  }
  /**
   * Set basename (including extname) (`'index.min.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} basename
   *   Basename.
   * @returns {undefined}
   *   Nothing.
   */
  set basename(t) {
    si(t, "basename"), ai(t, "basename"), this.path = at.join(this.dirname || "", t);
  }
  /**
   * Get the parent path (example: `'~'`).
   *
   * @returns {string | undefined}
   *   Dirname.
   */
  get dirname() {
    return typeof this.path == "string" ? at.dirname(this.path) : void 0;
  }
  /**
   * Set the parent path (example: `'~'`).
   *
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} dirname
   *   Dirname.
   * @returns {undefined}
   *   Nothing.
   */
  set dirname(t) {
    Cs(this.basename, "dirname"), this.path = at.join(t || "", this.basename);
  }
  /**
   * Get the extname (including dot) (example: `'.js'`).
   *
   * @returns {string | undefined}
   *   Extname.
   */
  get extname() {
    return typeof this.path == "string" ? at.extname(this.path) : void 0;
  }
  /**
   * Set the extname (including dot) (example: `'.js'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be set if there’s no `path` yet.
   *
   * @param {string | undefined} extname
   *   Extname.
   * @returns {undefined}
   *   Nothing.
   */
  set extname(t) {
    if (ai(t, "extname"), Cs(this.dirname, "extname"), t) {
      if (t.codePointAt(0) !== 46)
        throw new Error("`extname` must start with `.`");
      if (t.includes(".", 1))
        throw new Error("`extname` cannot contain multiple dots");
    }
    this.path = at.join(this.dirname, this.stem + (t || ""));
  }
  /**
   * Get the full path (example: `'~/index.min.js'`).
   *
   * @returns {string}
   *   Path.
   */
  get path() {
    return this.history[this.history.length - 1];
  }
  /**
   * Set the full path (example: `'~/index.min.js'`).
   *
   * Cannot be nullified.
   * You can set a file URL (a `URL` object with a `file:` protocol) which will
   * be turned into a path with `url.fileURLToPath`.
   *
   * @param {URL | string} path
   *   Path.
   * @returns {undefined}
   *   Nothing.
   */
  set path(t) {
    Ki(t) && (t = w1(t)), si(t, "path"), this.path !== t && this.history.push(t);
  }
  /**
   * Get the stem (basename w/o extname) (example: `'index.min'`).
   *
   * @returns {string | undefined}
   *   Stem.
   */
  get stem() {
    return typeof this.path == "string" ? at.basename(this.path, this.extname) : void 0;
  }
  /**
   * Set the stem (basename w/o extname) (example: `'index.min'`).
   *
   * Cannot contain path separators (`'/'` on unix, macOS, and browsers, `'\'`
   * on windows).
   * Cannot be nullified (use `file.path = file.dirname` instead).
   *
   * @param {string} stem
   *   Stem.
   * @returns {undefined}
   *   Nothing.
   */
  set stem(t) {
    si(t, "stem"), ai(t, "stem"), this.path = at.join(this.dirname || "", t + (this.extname || ""));
  }
  // Normal prototypal methods.
  /**
   * Create a fatal message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `true` (error; file not usable)
   * and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {never}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {never}
   *   Never.
   * @throws {VFileMessage}
   *   Message.
   */
  fail(t, n, r) {
    const i = this.message(t, n, r);
    throw i.fatal = !0, i;
  }
  /**
   * Create an info message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `undefined` (info; change
   * likely not needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  info(t, n, r) {
    const i = this.message(t, n, r);
    return i.fatal = void 0, i;
  }
  /**
   * Create a message for `reason` associated with the file.
   *
   * The `fatal` field of the message is set to `false` (warning; change may be
   * needed) and the `file` field is set to the current file path.
   * The message is added to the `messages` field on `file`.
   *
   * > 🪦 **Note**: also has obsolete signatures.
   *
   * @overload
   * @param {string} reason
   * @param {MessageOptions | null | undefined} [options]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {string} reason
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Node | NodeLike | null | undefined} parent
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {Point | Position | null | undefined} place
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @overload
   * @param {Error | VFileMessage} cause
   * @param {string | null | undefined} [origin]
   * @returns {VFileMessage}
   *
   * @param {Error | VFileMessage | string} causeOrReason
   *   Reason for message, should use markdown.
   * @param {Node | NodeLike | MessageOptions | Point | Position | string | null | undefined} [optionsOrParentOrPlace]
   *   Configuration (optional).
   * @param {string | null | undefined} [origin]
   *   Place in code where the message originates (example:
   *   `'my-package:my-rule'` or `'my-rule'`).
   * @returns {VFileMessage}
   *   Message.
   */
  message(t, n, r) {
    const i = new Tr(
      // @ts-expect-error: the overloads are fine.
      t,
      n,
      r
    );
    return this.path && (i.name = this.path + ":" + i.name, i.file = this.path), i.fatal = !1, this.messages.push(i), i;
  }
  /**
   * Serialize the file.
   *
   * > **Note**: which encodings are supported depends on the engine.
   * > For info on Node.js, see:
   * > <https://nodejs.org/api/util.html#whatwg-supported-encodings>.
   *
   * @param {string | null | undefined} [encoding='utf8']
   *   Character encoding to understand `value` as when it’s a `Uint8Array`
   *   (default: `'utf-8'`).
   * @returns {string}
   *   Serialized file.
   */
  toString(t) {
    return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(t || void 0).decode(this.value);
  }
}
function ai(e, t) {
  if (e && e.includes(at.sep))
    throw new Error(
      "`" + t + "` cannot be a path: did not expect `" + at.sep + "`"
    );
}
function si(e, t) {
  if (!e)
    throw new Error("`" + t + "` cannot be empty");
}
function Cs(e, t) {
  if (!e)
    throw new Error("Setting `" + t + "` requires `path` to be set too");
}
function _1(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const S1 = (
  /**
   * @type {new <Parameters extends Array<unknown>, Result>(property: string | symbol) => (...parameters: Parameters) => Result}
   */
  /** @type {unknown} */
  /**
   * @this {Function}
   * @param {string | symbol} property
   * @returns {(...parameters: Array<unknown>) => unknown}
   */
  function(e) {
    const r = (
      /** @type {Record<string | symbol, Function>} */
      // Prototypes do exist.
      // type-coverage:ignore-next-line
      this.constructor.prototype
    ), i = r[e], o = function() {
      return i.apply(o, arguments);
    };
    return Object.setPrototypeOf(o, r), o;
  }
), I1 = {}.hasOwnProperty;
class zo extends S1 {
  /**
   * Create a processor.
   */
  constructor() {
    super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = f1();
  }
  /**
   * Copy a processor.
   *
   * @deprecated
   *   This is a private internal method and should not be used.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   New *unfrozen* processor ({@linkcode Processor}) that is
   *   configured to work the same as its ancestor.
   *   When the descendant processor is configured in the future it does not
   *   affect the ancestral processor.
   */
  copy() {
    const t = (
      /** @type {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>} */
      new zo()
    );
    let n = -1;
    for (; ++n < this.attachers.length; ) {
      const r = this.attachers[n];
      t.use(...r);
    }
    return t.data(ii(!0, {}, this.namespace)), t;
  }
  /**
   * Configure the processor with info available to all plugins.
   * Information is stored in an object.
   *
   * Typically, options can be given to a specific plugin, but sometimes it
   * makes sense to have information shared with several plugins.
   * For example, a list of HTML elements that are self-closing, which is
   * needed during all phases.
   *
   * > **Note**: setting information cannot occur on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * > **Note**: to register custom data in TypeScript, augment the
   * > {@linkcode Data} interface.
   *
   * @example
   *   This example show how to get and set info:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   const processor = unified().data('alpha', 'bravo')
   *
   *   processor.data('alpha') // => 'bravo'
   *
   *   processor.data() // => {alpha: 'bravo'}
   *
   *   processor.data({charlie: 'delta'})
   *
   *   processor.data() // => {charlie: 'delta'}
   *   ```
   *
   * @template {keyof Data} Key
   *
   * @overload
   * @returns {Data}
   *
   * @overload
   * @param {Data} dataset
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Key} key
   * @returns {Data[Key]}
   *
   * @overload
   * @param {Key} key
   * @param {Data[Key]} value
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @param {Data | Key} [key]
   *   Key to get or set, or entire dataset to set, or nothing to get the
   *   entire dataset (optional).
   * @param {Data[Key]} [value]
   *   Value to set (optional).
   * @returns {unknown}
   *   The current processor when setting, the value at `key` when getting, or
   *   the entire dataset when getting without key.
   */
  data(t, n) {
    return typeof t == "string" ? arguments.length === 2 ? (ci("data", this.frozen), this.namespace[t] = n, this) : I1.call(this.namespace, t) && this.namespace[t] || void 0 : t ? (ci("data", this.frozen), this.namespace = t, this) : this.namespace;
  }
  /**
   * Freeze a processor.
   *
   * Frozen processors are meant to be extended and not to be configured
   * directly.
   *
   * When a processor is frozen it cannot be unfrozen.
   * New processors working the same way can be created by calling the
   * processor.
   *
   * It’s possible to freeze processors explicitly by calling `.freeze()`.
   * Processors freeze automatically when `.parse()`, `.run()`, `.runSync()`,
   * `.stringify()`, `.process()`, or `.processSync()` are called.
   *
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   The current processor.
   */
  freeze() {
    if (this.frozen)
      return this;
    const t = (
      /** @type {Processor} */
      /** @type {unknown} */
      this
    );
    for (; ++this.freezeIndex < this.attachers.length; ) {
      const [n, ...r] = this.attachers[this.freezeIndex];
      if (r[0] === !1)
        continue;
      r[0] === !0 && (r[0] = void 0);
      const i = n.call(t, ...r);
      typeof i == "function" && this.transformers.use(i);
    }
    return this.frozen = !0, this.freezeIndex = Number.POSITIVE_INFINITY, this;
  }
  /**
   * Parse text to a syntax tree.
   *
   * > **Note**: `parse` freezes the processor if not already *frozen*.
   *
   * > **Note**: `parse` performs the parse phase, not the run phase or other
   * > phases.
   *
   * @param {Compatible | undefined} [file]
   *   file to parse (optional); typically `string` or `VFile`; any value
   *   accepted as `x` in `new VFile(x)`.
   * @returns {ParseTree extends undefined ? Node : ParseTree}
   *   Syntax tree representing `file`.
   */
  parse(t) {
    this.freeze();
    const n = Xn(t), r = this.parser || this.Parser;
    return li("parse", r), r(String(n), n);
  }
  /**
   * Process the given file as configured on the processor.
   *
   * > **Note**: `process` freezes the processor if not already *frozen*.
   *
   * > **Note**: `process` performs the parse, run, and stringify phases.
   *
   * @overload
   * @param {Compatible | undefined} file
   * @param {ProcessCallback<VFileWithOutput<CompileResult>>} done
   * @returns {undefined}
   *
   * @overload
   * @param {Compatible | undefined} [file]
   * @returns {Promise<VFileWithOutput<CompileResult>>}
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`]; any value accepted as
   *   `x` in `new VFile(x)`.
   * @param {ProcessCallback<VFileWithOutput<CompileResult>> | undefined} [done]
   *   Callback (optional).
   * @returns {Promise<VFile> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise a promise, rejected with a fatal error or resolved with the
   *   processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  process(t, n) {
    const r = this;
    return this.freeze(), li("process", this.parser || this.Parser), ui("process", this.compiler || this.Compiler), n ? i(void 0, n) : new Promise(i);
    function i(o, a) {
      const s = Xn(t), u = (
        /** @type {HeadTree extends undefined ? Node : HeadTree} */
        /** @type {unknown} */
        r.parse(s)
      );
      r.run(u, s, function(l, f, d) {
        if (l || !f || !d)
          return c(l);
        const p = (
          /** @type {CompileTree extends undefined ? Node : CompileTree} */
          /** @type {unknown} */
          f
        ), h = r.stringify(p, d);
        A1(h) ? d.value = h : d.result = h, c(
          l,
          /** @type {VFileWithOutput<CompileResult>} */
          d
        );
      });
      function c(l, f) {
        l || !f ? a(l) : o ? o(f) : n(void 0, f);
      }
    }
  }
  /**
   * Process the given file as configured on the processor.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `processSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `processSync` performs the parse, run, and stringify phases.
   *
   * @param {Compatible | undefined} [file]
   *   File (optional); typically `string` or `VFile`; any value accepted as
   *   `x` in `new VFile(x)`.
   * @returns {VFileWithOutput<CompileResult>}
   *   The processed file.
   *
   *   The parsed, transformed, and compiled value is available at
   *   `file.value` (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most
   *   > compilers return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  processSync(t) {
    let n = !1, r;
    return this.freeze(), li("processSync", this.parser || this.Parser), ui("processSync", this.compiler || this.Compiler), this.process(t, i), zs("processSync", "process", n), r;
    function i(o, a) {
      n = !0, ks(o), r = a;
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * > **Note**: `run` freezes the processor if not already *frozen*.
   *
   * > **Note**: `run` performs the run phase, not other phases.
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} file
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} done
   * @returns {undefined}
   *
   * @overload
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   * @param {Compatible | undefined} [file]
   * @returns {Promise<TailTree extends undefined ? Node : TailTree>}
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {(
   *   RunCallback<TailTree extends undefined ? Node : TailTree> |
   *   Compatible
   * )} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @param {RunCallback<TailTree extends undefined ? Node : TailTree>} [done]
   *   Callback (optional).
   * @returns {Promise<TailTree extends undefined ? Node : TailTree> | undefined}
   *   Nothing if `done` is given.
   *   Otherwise, a promise rejected with a fatal error or resolved with the
   *   transformed tree.
   */
  run(t, n, r) {
    As(t), this.freeze();
    const i = this.transformers;
    return !r && typeof n == "function" && (r = n, n = void 0), r ? o(void 0, r) : new Promise(o);
    function o(a, s) {
      const u = Xn(n);
      i.run(t, u, c);
      function c(l, f, d) {
        const p = (
          /** @type {TailTree extends undefined ? Node : TailTree} */
          f || t
        );
        l ? s(l) : a ? a(p) : r(void 0, p, d);
      }
    }
  }
  /**
   * Run *transformers* on a syntax tree.
   *
   * An error is thrown if asynchronous transforms are configured.
   *
   * > **Note**: `runSync` freezes the processor if not already *frozen*.
   *
   * > **Note**: `runSync` performs the run phase, not other phases.
   *
   * @param {HeadTree extends undefined ? Node : HeadTree} tree
   *   Tree to transform and inspect.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {TailTree extends undefined ? Node : TailTree}
   *   Transformed tree.
   */
  runSync(t, n) {
    let r = !1, i;
    return this.run(t, n, o), zs("runSync", "run", r), i;
    function o(a, s) {
      ks(a), i = s, r = !0;
    }
  }
  /**
   * Compile a syntax tree.
   *
   * > **Note**: `stringify` freezes the processor if not already *frozen*.
   *
   * > **Note**: `stringify` performs the stringify phase, not the run phase
   * > or other phases.
   *
   * @param {CompileTree extends undefined ? Node : CompileTree} tree
   *   Tree to compile.
   * @param {Compatible | undefined} [file]
   *   File associated with `node` (optional); any value accepted as `x` in
   *   `new VFile(x)`.
   * @returns {CompileResult extends undefined ? Value : CompileResult}
   *   Textual representation of the tree (see note).
   *
   *   > **Note**: unified typically compiles by serializing: most compilers
   *   > return `string` (or `Uint8Array`).
   *   > Some compilers, such as the one configured with
   *   > [`rehype-react`][rehype-react], return other values (in this case, a
   *   > React tree).
   *   > If you’re using a compiler that doesn’t serialize, expect different
   *   > result values.
   *   >
   *   > To register custom results in TypeScript, add them to
   *   > {@linkcode CompileResultMap}.
   *
   *   [rehype-react]: https://github.com/rehypejs/rehype-react
   */
  stringify(t, n) {
    this.freeze();
    const r = Xn(n), i = this.compiler || this.Compiler;
    return ui("stringify", i), As(t), i(t, r);
  }
  /**
   * Configure the processor to use a plugin, a list of usable values, or a
   * preset.
   *
   * If the processor is already using a plugin, the previous plugin
   * configuration is changed based on the options that are passed in.
   * In other words, the plugin is not added a second time.
   *
   * > **Note**: `use` cannot be called on *frozen* processors.
   * > Call the processor first to create a new unfrozen processor.
   *
   * @example
   *   There are many ways to pass plugins to `.use()`.
   *   This example gives an overview:
   *
   *   ```js
   *   import {unified} from 'unified'
   *
   *   unified()
   *     // Plugin with options:
   *     .use(pluginA, {x: true, y: true})
   *     // Passing the same plugin again merges configuration (to `{x: true, y: false, z: true}`):
   *     .use(pluginA, {y: false, z: true})
   *     // Plugins:
   *     .use([pluginB, pluginC])
   *     // Two plugins, the second with options:
   *     .use([pluginD, [pluginE, {}]])
   *     // Preset with plugins and settings:
   *     .use({plugins: [pluginF, [pluginG, {}]], settings: {position: false}})
   *     // Settings only:
   *     .use({settings: {position: false}})
   *   ```
   *
   * @template {Array<unknown>} [Parameters=[]]
   * @template {Node | string | undefined} [Input=undefined]
   * @template [Output=Input]
   *
   * @overload
   * @param {Preset | null | undefined} [preset]
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {PluggableList} list
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *
   * @overload
   * @param {Plugin<Parameters, Input, Output>} plugin
   * @param {...(Parameters | [boolean])} parameters
   * @returns {UsePlugin<ParseTree, HeadTree, TailTree, CompileTree, CompileResult, Input, Output>}
   *
   * @param {PluggableList | Plugin | Preset | null | undefined} value
   *   Usable value.
   * @param {...unknown} parameters
   *   Parameters, when a plugin is given as a usable value.
   * @returns {Processor<ParseTree, HeadTree, TailTree, CompileTree, CompileResult>}
   *   Current processor.
   */
  use(t, ...n) {
    const r = this.attachers, i = this.namespace;
    if (ci("use", this.frozen), t != null) if (typeof t == "function")
      u(t, n);
    else if (typeof t == "object")
      Array.isArray(t) ? s(t) : a(t);
    else
      throw new TypeError("Expected usable value, not `" + t + "`");
    return this;
    function o(c) {
      if (typeof c == "function")
        u(c, []);
      else if (typeof c == "object")
        if (Array.isArray(c)) {
          const [l, ...f] = (
            /** @type {PluginTuple<Array<unknown>>} */
            c
          );
          u(l, f);
        } else
          a(c);
      else
        throw new TypeError("Expected usable value, not `" + c + "`");
    }
    function a(c) {
      if (!("plugins" in c) && !("settings" in c))
        throw new Error(
          "Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither"
        );
      s(c.plugins), c.settings && (i.settings = ii(!0, i.settings, c.settings));
    }
    function s(c) {
      let l = -1;
      if (c != null) if (Array.isArray(c))
        for (; ++l < c.length; ) {
          const f = c[l];
          o(f);
        }
      else
        throw new TypeError("Expected a list of plugins, not `" + c + "`");
    }
    function u(c, l) {
      let f = -1, d = -1;
      for (; ++f < r.length; )
        if (r[f][0] === c) {
          d = f;
          break;
        }
      if (d === -1)
        r.push([c, ...l]);
      else if (l.length > 0) {
        let [p, ...h] = l;
        const m = r[d][1];
        Hi(m) && Hi(p) && (p = ii(!0, m, p)), r[d] = [c, p, ...h];
      }
    }
  }
}
const E1 = new zo().freeze();
function li(e, t) {
  if (typeof t != "function")
    throw new TypeError("Cannot `" + e + "` without `parser`");
}
function ui(e, t) {
  if (typeof t != "function")
    throw new TypeError("Cannot `" + e + "` without `compiler`");
}
function ci(e, t) {
  if (t)
    throw new Error(
      "Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`."
    );
}
function As(e) {
  if (!Hi(e) || typeof e.type != "string")
    throw new TypeError("Expected node, got `" + e + "`");
}
function zs(e, t, n) {
  if (!n)
    throw new Error(
      "`" + e + "` finished async. Use `" + t + "` instead"
    );
}
function Xn(e) {
  return C1(e) ? e : new Tc(e);
}
function C1(e) {
  return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function A1(e) {
  return typeof e == "string" || z1(e);
}
function z1(e) {
  return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
const T1 = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md", Ts = [], Os = { allowDangerousHtml: !0 }, O1 = /^(https?|ircs?|mailto|xmpp)$/i, P1 = [
  { from: "astPlugins", id: "remove-buggy-html-in-markdown-parser" },
  { from: "allowDangerousHtml", id: "remove-buggy-html-in-markdown-parser" },
  {
    from: "allowNode",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowElement"
  },
  {
    from: "allowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowedElements"
  },
  { from: "className", id: "remove-classname" },
  {
    from: "disallowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "disallowedElements"
  },
  { from: "escapeHtml", id: "remove-buggy-html-in-markdown-parser" },
  { from: "includeElementIndex", id: "#remove-includeelementindex" },
  {
    from: "includeNodeIndex",
    id: "change-includenodeindex-to-includeelementindex"
  },
  { from: "linkTarget", id: "remove-linktarget" },
  { from: "plugins", id: "change-plugins-to-remarkplugins", to: "remarkPlugins" },
  { from: "rawSourcePos", id: "#remove-rawsourcepos" },
  { from: "renderers", id: "change-renderers-to-components", to: "components" },
  { from: "source", id: "change-source-to-children", to: "children" },
  { from: "sourcePos", id: "#remove-sourcepos" },
  { from: "transformImageUri", id: "#add-urltransform", to: "urlTransform" },
  { from: "transformLinkUri", id: "#add-urltransform", to: "urlTransform" }
];
function M1(e) {
  const t = R1(e), n = $1(e);
  return N1(t.runSync(t.parse(n), n), e);
}
function R1(e) {
  const t = e.rehypePlugins || Ts, n = e.remarkPlugins || Ts, r = e.remarkRehypeOptions ? { ...e.remarkRehypeOptions, ...Os } : Os;
  return E1().use(h0).use(n).use(u1, r).use(t);
}
function $1(e) {
  const t = e.children || "", n = new Tc();
  return typeof t == "string" && (n.value = t), n;
}
function N1(e, t) {
  const n = t.allowedElements, r = t.allowElement, i = t.components, o = t.disallowedElements, a = t.skipHtml, s = t.unwrapDisallowed, u = t.urlTransform || D1;
  for (const l of P1)
    Object.hasOwn(t, l.from) && ("" + l.from + (l.to ? "use `" + l.to + "` instead" : "remove it") + T1 + l.id, void 0);
  return Nr(e, c), ek(e, {
    Fragment: Dn,
    components: i,
    ignoreInvalidStyle: !0,
    jsx: T,
    jsxs: ee,
    passKeys: !0,
    passNode: !0
  });
  function c(l, f, d) {
    if (l.type === "raw" && d && typeof f == "number")
      return a ? d.children.splice(f, 1) : d.children[f] = { type: "text", value: l.value }, f;
    if (l.type === "element") {
      let p;
      for (p in ti)
        if (Object.hasOwn(ti, p) && Object.hasOwn(l.properties, p)) {
          const h = l.properties[p], m = ti[p];
          (m === null || m.includes(l.tagName)) && (l.properties[p] = u(String(h || ""), p, l));
        }
    }
    if (l.type === "element") {
      let p = n ? !n.includes(l.tagName) : o ? o.includes(l.tagName) : !1;
      if (!p && r && typeof f == "number" && (p = !r(l, f, d)), p && d && typeof f == "number")
        return s && l.children ? d.children.splice(f, 1, ...l.children) : d.children.splice(f, 1), f;
    }
  }
}
function D1(e) {
  const t = e.indexOf(":"), n = e.indexOf("?"), r = e.indexOf("#"), i = e.indexOf("/");
  return (
    // If there is no protocol, it’s relative.
    t === -1 || // If the first colon is after a `?`, `#`, or `/`, it’s not a protocol.
    i !== -1 && t > i || n !== -1 && t > n || r !== -1 && t > r || // It is a protocol, it should be allowed.
    O1.test(e.slice(0, t)) ? e : ""
  );
}
function Ps(e, t) {
  const n = String(e);
  if (typeof t != "string")
    throw new TypeError("Expected character");
  let r = 0, i = n.indexOf(t);
  for (; i !== -1; )
    r++, i = n.indexOf(t, i + t.length);
  return r;
}
function L1(e) {
  if (typeof e != "string")
    throw new TypeError("Expected a string");
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
function F1(e, t, n) {
  const i = Rr((n || {}).ignore || []), o = j1(t);
  let a = -1;
  for (; ++a < o.length; )
    qi(e, s);
  function s(c, l, f) {
    if (c.type === "text" && typeof f == "number")
      return u(c, l, f);
    if (i(c, f, l[l.length - 1])) return Vi;
  }
  function u(c, l, f) {
    const d = l[l.length - 1], p = o[a][0], h = o[a][1];
    let m = 0, k = !1, g = [];
    p.lastIndex = 0;
    let _ = p.exec(c.value);
    for (; _; ) {
      const C = _.index, I = {
        index: _.index,
        input: _.input,
        stack: [...l, c]
      };
      let y = h(..._, I);
      if (typeof y == "string" && (y = y.length > 0 ? { type: "text", value: y } : void 0), y === !1)
        p.lastIndex = C + 1;
      else {
        if (m !== C && w({ type: "text", value: c.value.slice(m, C) }), Array.isArray(y))
          for (const E of y) w(E);
        else y && w(y);
        m = C + _[0].length, k = !0;
      }
      if (!p.global)
        break;
      _ = p.exec(c.value);
    }
    return k ? (m < c.value.length && w({ type: "text", value: c.value.slice(m) }), d.children.splice(f, 1, ...g)) : g = [c], f + g.length;
    function w(C) {
      const I = g[g.length - 1];
      I && I.type === "text" && C.type === "text" ? I.value += C.value : g.push(C);
    }
  }
}
function j1(e) {
  if (!Array.isArray(e))
    throw new TypeError("Expected find and replace tuple or list of tuples");
  const t = [], n = !e[0] || Array.isArray(e[0]) ? (
    /** @type {FindAndReplaceList} */
    e
  ) : [
    /** @type {FindAndReplaceTuple} */
    e
  ];
  let r = -1;
  for (; ++r < n.length; ) {
    const i = n[r];
    t.push([Z1(i[0]), B1(i[1])]);
  }
  return t;
}
function Z1(e) {
  return typeof e == "string" ? new RegExp(L1(e), "g") : e;
}
function B1(e) {
  return typeof e == "function" ? e : function() {
    return e;
  };
}
const fi = "phrasing", di = ["autolink", "link", "image", "label"];
function U1() {
  return {
    transforms: [Y1],
    enter: {
      literalAutolink: q1,
      literalAutolinkEmail: pi,
      literalAutolinkHttp: pi,
      literalAutolinkWww: pi
    },
    exit: {
      literalAutolink: K1,
      literalAutolinkEmail: H1,
      literalAutolinkHttp: J1,
      literalAutolinkWww: W1
    }
  };
}
function V1() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct: fi,
        notInConstruct: di
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct: fi,
        notInConstruct: di
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct: fi,
        notInConstruct: di
      }
    ]
  };
}
function q1(e) {
  this.enter(
    { type: "link", title: null, url: "", children: [], position: void 0 },
    e
  );
}
function pi(e) {
  this.config.enter.autolinkProtocol.call(this, e);
}
function J1(e) {
  this.config.exit.autolinkProtocol.call(this, e);
}
function W1(e) {
  this.config.exit.data.call(this, e);
  const t = this.stack[this.stack.length - 1];
  t.type, t.url = "http://" + this.sliceSerialize(e);
}
function H1(e) {
  this.config.exit.autolinkEmail.call(this, e);
}
function K1(e) {
  this.exit(e);
}
function Y1(e) {
  F1(
    e,
    [
      [
        new RegExp("(?<![\\da-z])(https?:\\/\\/|www(?=\\.))([\\w-]*\\.[\\w\\-.]*)([^\\t\\n\\r ]*)", "gi"),
        G1
      ],
      [
        new RegExp("(?<![\\w+\\-.@])xmpp:([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)(\\/(?:[\\w\\-/]|\\.(?=[\\dA-Za-z]))*)?", "g"),
        ex
      ],
      [new RegExp("(?<![\\w+\\-.@])mailto:([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)", "g"), Q1],
      [
        new RegExp("(?<![\\w+\\-.]|(?:^|[^\\d@A-Za-z])(?:mailto|xmpp):)([\\w+\\-.]+)@([\\w-]+(?:\\.[\\w-]+)+)", "g"),
        X1
      ]
    ],
    { ignore: ["link", "linkReference"] }
  );
}
function G1(e, t, n, r, i) {
  if (!rx(i))
    return !1;
  let o = "";
  if (/^w/i.test(t) && (n = t + n, t = "", o = "http://"), Zn(n.charCodeAt(0)) || !tx(n))
    return !1;
  const a = nx(n + r), s = {
    type: "link",
    title: null,
    url: o + t + a[0],
    children: [{ type: "text", value: t + a[0], position: void 0 }],
    position: void 0
  };
  return a[1] ? [s, { type: "text", value: a[1], position: void 0 }] : s;
}
function X1(e, t, n) {
  return /[\d\-_]$/.test(n) ? !1 : {
    type: "link",
    title: null,
    url: "mailto:" + t + "@" + n,
    children: [{ type: "text", value: t + "@" + n, position: void 0 }],
    position: void 0
  };
}
function Q1(e, t, n) {
  if (/[\d\-_]$/.test(n))
    return !1;
  const r = "mailto:" + t + "@" + n;
  return {
    type: "link",
    title: null,
    url: r,
    children: [{ type: "text", value: r, position: void 0 }],
    position: void 0
  };
}
function ex(e, t, n, r, i) {
  if (/[\d\-_]$/.test(n) || r && (!/[A-Za-z]$/.test(r) || i.input.charAt(i.index + e.length) === "@"))
    return !1;
  const o = "xmpp:" + t + "@" + n + (r || "");
  return {
    type: "link",
    title: null,
    url: o,
    children: [{ type: "text", value: o, position: void 0 }],
    position: void 0
  };
}
function tx(e) {
  const t = e.split(".");
  return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[\dA-Za-z]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[\dA-Za-z]/.test(t[t.length - 2])));
}
function nx(e) {
  let t = e.length;
  for (; t > 0; ) {
    const a = e.charCodeAt(t - 1);
    if (a === 33 || a === 34 || a === 38 || a === 39 || a === 41 || a === 44 || a === 46 || a === 58 || a === 59 || a === 60 || a === 62 || a === 63 || a === 93 || a === 125)
      t--;
    else
      break;
  }
  if (t === e.length)
    return [e, void 0];
  let n = e.slice(t);
  e = e.slice(0, t);
  let r = n.indexOf(")");
  const i = Ps(e, "(");
  let o = Ps(e, ")");
  for (; r !== -1 && i > o; )
    e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), o++;
  return [e, n];
}
function rx(e) {
  const t = e.input.charCodeAt(e.index - 1);
  return e.index === 0 || jt(t) || Zn(t);
}
Oc.peek = dx;
function ix() {
  this.buffer();
}
function ox(e) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, e);
}
function ax() {
  this.buffer();
}
function sx(e) {
  this.enter(
    { type: "footnoteDefinition", identifier: "", label: "", children: [] },
    e
  );
}
function lx(e) {
  const t = this.resume(), n = this.stack[this.stack.length - 1];
  n.type, n.identifier = et(
    this.sliceSerialize(e)
  ).toLowerCase(), n.label = t;
}
function ux(e) {
  this.exit(e);
}
function cx(e) {
  const t = this.resume(), n = this.stack[this.stack.length - 1];
  n.type, n.identifier = et(
    this.sliceSerialize(e)
  ).toLowerCase(), n.label = t;
}
function fx(e) {
  this.exit(e);
}
function dx() {
  return "[";
}
function Oc(e, t, n, r) {
  const i = n.createTracker(r);
  let o = i.move("[^");
  const a = n.enter("footnoteReference"), s = n.enter("reference");
  return o += i.move(
    n.safe(n.associationId(e), { after: "]", before: o })
  ), s(), a(), o += i.move("]"), o;
}
function px() {
  return {
    enter: {
      gfmFootnoteCallString: ix,
      gfmFootnoteCall: ox,
      gfmFootnoteDefinitionLabelString: ax,
      gfmFootnoteDefinition: sx
    },
    exit: {
      gfmFootnoteCallString: lx,
      gfmFootnoteCall: ux,
      gfmFootnoteDefinitionLabelString: cx,
      gfmFootnoteDefinition: fx
    }
  };
}
function hx(e) {
  let t = !1;
  return e && e.firstLineBlank && (t = !0), {
    handlers: { footnoteDefinition: n, footnoteReference: Oc },
    // This is on by default already.
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function n(r, i, o, a) {
    const s = o.createTracker(a);
    let u = s.move("[^");
    const c = o.enter("footnoteDefinition"), l = o.enter("label");
    return u += s.move(
      o.safe(o.associationId(r), { before: u, after: "]" })
    ), l(), u += s.move("]:"), r.children && r.children.length > 0 && (s.shift(4), u += s.move(
      (t ? `
` : " ") + o.indentLines(
        o.containerFlow(r, s.current()),
        t ? Pc : mx
      )
    )), c(), u;
  }
}
function mx(e, t, n) {
  return t === 0 ? e : Pc(e, t, n);
}
function Pc(e, t, n) {
  return (n ? "" : "    ") + e;
}
const gx = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
To.attention = wx;
To.peek = xx;
function yx() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: vx },
    exit: { strikethrough: kx }
  };
}
function bx() {
  return {
    handlers: { delete: To },
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: gx
      }
    ]
  };
}
function vx(e) {
  this.enter({ type: "delete", children: [], position: void 0 }, e);
}
function kx(e) {
  this.exit(e);
}
function To(e, t, n, r) {
  const i = n.createTracker(r), o = n.stack.includes("strikethrough") ? "~" : "~~", a = n.enter("strikethrough");
  let s = i.move(o);
  return s += n.containerPhrasing(e, {
    ...i.current(),
    before: s,
    after: "~"
  }), s += i.move(o), a(), s;
}
function wx() {
  return { construct: "strikethrough", markers: ["~"], sizes: [2, 1] };
}
function xx() {
  return "~";
}
function _x(e) {
  return e.length;
}
function Sx(e, t) {
  const n = t || {}, r = (n.align || []).concat(), i = n.stringLength || _x, o = [], a = [], s = [], u = [];
  let c = 0, l = -1;
  for (; ++l < e.length; ) {
    const m = [], k = [];
    let g = -1;
    for (e[l].length > c && (c = e[l].length); ++g < e[l].length; ) {
      const _ = Ix(e[l][g]);
      if (n.alignDelimiters !== !1) {
        const w = i(_);
        k[g] = w, (u[g] === void 0 || w > u[g]) && (u[g] = w);
      }
      m.push(_);
    }
    a[l] = m, s[l] = k;
  }
  let f = -1;
  if (typeof r == "object" && "length" in r)
    for (; ++f < c; )
      o[f] = Ms(r[f]);
  else {
    const m = Ms(r);
    for (; ++f < c; )
      o[f] = m;
  }
  f = -1;
  const d = [], p = [];
  for (; ++f < c; ) {
    const m = o[f];
    let k = "", g = "";
    m === 99 ? (k = ":", g = ":") : m === 108 ? k = ":" : m === 114 && (g = ":");
    let _ = n.alignDelimiters === !1 ? 1 : Math.max(
      1,
      u[f] - k.length - g.length
    );
    const w = k + "-".repeat(_) + g;
    n.alignDelimiters !== !1 && (_ = k.length + _ + g.length, _ > u[f] && (u[f] = _), p[f] = _), d[f] = w;
  }
  a.splice(1, 0, d), s.splice(1, 0, p), l = -1;
  const h = [];
  for (; ++l < a.length; ) {
    const m = a[l], k = s[l], g = n.fillRows === !1 ? Math.max(1, a[l === 1 ? 0 : l].length) : c;
    f = -1;
    const _ = [];
    for (; ++f < g; ) {
      const w = m[f] || "";
      let C = "", I = "";
      if (n.alignDelimiters !== !1) {
        const y = u[f] - (k[f] || 0), E = o[f];
        if (E === 114)
          C = " ".repeat(y);
        else if (E === 99) {
          const R = y / 2;
          y % 2 ? (C = " ".repeat(R + 0.5), I = " ".repeat(R - 0.5)) : (C = " ".repeat(R), I = C);
        } else
          I = " ".repeat(y);
      }
      n.delimiterStart !== !1 && !f && _.push("|"), n.padding !== !1 && // Don’t add the opening space if we’re not aligning and the cell is
      // empty: there will be a closing space.
      !(n.alignDelimiters === !1 && w === "") && (n.delimiterStart !== !1 || f) && _.push(" "), n.alignDelimiters !== !1 && _.push(C), _.push(w), n.alignDelimiters !== !1 && _.push(I), n.padding !== !1 && _.push(" "), (n.delimiterEnd !== !1 || f !== g - 1) && _.push("|");
    }
    h.push(
      n.delimiterEnd === !1 ? _.join("").replace(/ +$/, "") : _.join("")
    );
  }
  return h.join(`
`);
}
function Ix(e) {
  return e == null ? "" : String(e);
}
function Ms(e) {
  const t = typeof e == "string" ? e.codePointAt(0) : 0;
  return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
}
const Ex = (
  /** @type {(node?: unknown) => node is Exclude<PhrasingContent, Html>} */
  Rr([
    "break",
    "delete",
    "emphasis",
    // To do: next major: removed since footnotes were added to GFM.
    "footnote",
    "footnoteReference",
    "image",
    "imageReference",
    "inlineCode",
    // Enabled by `mdast-util-math`:
    "inlineMath",
    "link",
    "linkReference",
    // Enabled by `mdast-util-mdx`:
    "mdxJsxTextElement",
    // Enabled by `mdast-util-mdx`:
    "mdxTextExpression",
    "strong",
    "text",
    // Enabled by `mdast-util-directive`:
    "textDirective"
  ])
);
function Cx(e, t, n, r) {
  const i = n.enter("blockquote"), o = n.createTracker(r);
  o.move("> "), o.shift(2);
  const a = n.indentLines(
    n.containerFlow(e, o.current()),
    Ax
  );
  return i(), a;
}
function Ax(e, t, n) {
  return ">" + (n ? "" : " ") + e;
}
function zx(e, t) {
  return Rs(e, t.inConstruct, !0) && !Rs(e, t.notInConstruct, !1);
}
function Rs(e, t, n) {
  if (typeof t == "string" && (t = [t]), !t || t.length === 0)
    return n;
  let r = -1;
  for (; ++r < t.length; )
    if (e.includes(t[r]))
      return !0;
  return !1;
}
function $s(e, t, n, r) {
  let i = -1;
  for (; ++i < n.unsafe.length; ) {
    const o = n.unsafe[i];
    if (o.character === `
` && !o.before && !o.after && zx(n.stack, o))
      return /[\t ]/.test(r.before) ? "" : " ";
  }
  return `\\
`;
}
function Tx(e, t) {
  const n = String(e);
  let r = n.indexOf(t), i = r, o = 0, a = 0;
  if (typeof t != "string")
    throw new TypeError("Expected substring");
  for (; r !== -1; )
    r === i ? ++o > a && (a = o) : o = 1, i = r + t.length, r = n.indexOf(t, i);
  return a;
}
function Ox(e, t) {
  return !!(t.options.fences === !1 && e.value && // If there’s no info…
  !e.lang && // And there’s a non-whitespace character…
  /[^\n\r ]/.test(e.value) && // And the value doesn’t start or end in a blank…
  !/^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(e.value));
}
function Px(e) {
  const t = e.options.fence || "`";
  if (t !== "`" && t !== "~")
    throw new Error(
      "Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`"
    );
  return t;
}
function Mx(e, t, n, r) {
  const i = Px(n), o = e.value || "";
  if (Ox(e, n)) {
    const f = n.enter("codeIndented"), d = n.indentLines(o, Rx);
    return f(), d;
  }
  const a = n.createTracker(r), s = i.repeat(Math.max(Tx(o, i) + 1, 3)), u = n.enter("codeFenced"), c = i === "`" ? "GraveAccent" : "Tilde";
  let l = a.move(s);
  if (e.lang) {
    const f = n.enter(`codeFencedLang${c}`);
    l += a.move(
      n.safe(e.lang, {
        before: l,
        after: " ",
        encode: ["`"],
        ...a.current()
      })
    ), f();
  }
  if (e.lang && e.meta) {
    const f = n.enter(`codeFencedMeta${c}`);
    l += a.move(" "), l += a.move(
      n.safe(e.meta, {
        before: l,
        after: `
`,
        encode: ["`"],
        ...a.current()
      })
    ), f();
  }
  return l += a.move(`
`), o && (l += a.move(o + `
`)), l += a.move(s), u(), l;
}
function Rx(e, t, n) {
  return (n ? "" : "    ") + e;
}
function Oo(e) {
  const t = e.options.quote || '"';
  if (t !== '"' && t !== "'")
    throw new Error(
      "Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`"
    );
  return t;
}
function $x(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.enter("definition");
  let s = n.enter("label");
  const u = n.createTracker(r);
  let c = u.move("[");
  return c += u.move(
    n.safe(n.associationId(e), {
      before: c,
      after: "]",
      ...u.current()
    })
  ), c += u.move("]: "), s(), // If there’s no url, or…
  !e.url || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), c += u.move("<"), c += u.move(
    n.safe(e.url, { before: c, after: ">", ...u.current() })
  ), c += u.move(">")) : (s = n.enter("destinationRaw"), c += u.move(
    n.safe(e.url, {
      before: c,
      after: e.title ? " " : `
`,
      ...u.current()
    })
  )), s(), e.title && (s = n.enter(`title${o}`), c += u.move(" " + i), c += u.move(
    n.safe(e.title, {
      before: c,
      after: i,
      ...u.current()
    })
  ), c += u.move(i), s()), a(), c;
}
function Nx(e) {
  const t = e.options.emphasis || "*";
  if (t !== "*" && t !== "_")
    throw new Error(
      "Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`"
    );
  return t;
}
function _r(e) {
  const t = e.codePointAt(0);
  return t === void 0 ? "" : String.fromCodePoint(t);
}
function Yt(e) {
  const t = e.codePointAt(e.length - 2);
  return t !== void 0 && t > 65535 ? e.slice(-2) : e.slice(-1);
}
function Mc(e) {
  return "&#x" + e.toString(16).toUpperCase() + ";";
}
function Ns(e, t, n) {
  const r = Et(e), i = Et(t);
  return r === void 0 ? i === void 0 ? (
    // Letter inside:
    // we have to encode *both* letters for `_` as it is looser.
    // it already forms for `*` (and GFMs `~`).
    n === "_" ? { inside: !0, outside: !0 } : { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (letter, whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: encode outer (letter)
    { inside: !1, outside: !0 }
  ) : r === 1 ? i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode both (whitespace).
    { inside: !0, outside: !0 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === void 0 ? (
    // Letter inside: already forms.
    { inside: !1, outside: !1 }
  ) : i === 1 ? (
    // Whitespace inside: encode inner (whitespace).
    { inside: !0, outside: !1 }
  ) : (
    // Punctuation inside: already forms.
    { inside: !1, outside: !1 }
  );
}
function Dx(e) {
  if (e.charCodeAt(0) !== 60) return;
  const t = e.charCodeAt(1);
  if (t === 33) {
    const s = e.charCodeAt(2);
    return s === 45 ? 2 : s === 91 ? 5 : we(s) ? 4 : void 0;
  }
  if (t === 63) return 3;
  const n = t === 47, r = n ? 2 : 1;
  let i = r, o = e.charCodeAt(i);
  if (!we(o)) return;
  for (; o === 45 || xe(o); )
    o = e.charCodeAt(++i);
  const a = e.slice(r, i).toLowerCase();
  return !n && o !== 47 && Ui.includes(a) ? 1 : yc.includes(a) ? 6 : 7;
}
const Rc = /* @__PURE__ */ new Map([
  ["*", !1],
  ["_", !0]
]);
function Lx(e, t, n) {
  const r = /* @__PURE__ */ new Set();
  for (const o of e) {
    const a = n.get(o);
    if (a && o.attention && t.some((s) => s.attention === o.attention))
      for (const s of a.tokens)
        r.add(s.attention);
  }
  const i = [];
  for (const o of e)
    o.attention && r.delete(o.attention) && i.push(o.attention);
  return i.reverse(), i;
}
function $c(e, t, n) {
  const r = [], i = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map();
  let a = 0;
  for (; a < e.length; ) {
    if (!e[a].attention) {
      a++;
      continue;
    }
    const s = e[a].value.charAt(0), u = Rc.get(s);
    let c = a + 1;
    for (; c < e.length && e[c].attention && e[c].value.charAt(0) === s; )
      c++;
    const l = a ? e[a - 1].value : t, f = Et(l.charCodeAt(l.length - 1)), d = Et(
      (c < e.length ? e[c].value : n).charCodeAt(0)
    ), p = !d || d === 2 && !!f, h = !f || f === 2 && !!d, m = {
      tokens: e.slice(a, c),
      markers: [],
      start: 0,
      end: 0,
      // Underscores are strict, they cannot open or close inside words.
      open: u ? p && (!!f || !h) : p,
      close: u ? h && (!!d || !p) : h,
      // All builtins can split runs.
      split: u !== void 0
    };
    for (const k of m.tokens) {
      i.set(k, [...m.tokens]), o.set(k, m);
      let g = k.value.length;
      for (; g--; ) m.markers.push(k);
    }
    m.end = m.markers.length, r.push(m), a = c;
  }
  for (jx(r, i), a = -1; ++a < e.length; ) {
    const s = i.get(e[a]);
    if (s) return { attention: Lx(e, s, o), index: a };
  }
}
function Qn(e, t) {
  const n = e[t ? 0 : e.length - 1];
  if (!n || n.attention) return;
  const r = t ? _r(n.value) : Yt(n.value), i = Mc(
    /** @type {number} */
    r.codePointAt(0)
  );
  if (t)
    n.value = i + n.value.slice(r.length);
  else {
    let o = n.value.slice(0, n.value.length - r.length), a = 0;
    for (; o.charCodeAt(o.length - 1 - a) === 92; )
      a++;
    a % 2 && (o += "\\"), n.value = o + i;
  }
}
function Fx(e, t, n, r, i) {
  for (const o of n.attention) {
    const a = t.get(o) || o.sequences[0];
    for (const s of o.sequences) {
      if (s === a) continue;
      const u = new Map(t);
      u.set(o, s);
      const c = Dr(e, u, r, i), l = $c(c, r, i);
      if (!l || l.index > n.index)
        return { chosen: u, mistake: l, tokens: c };
    }
  }
}
function jx(e, t) {
  const n = /* @__PURE__ */ new Map();
  for (const r of e) {
    const i = r.tokens[0].value.charAt(0);
    let o = n.get(i);
    o || (o = [], n.set(i, o));
    let a = r.close ? o.length : 0;
    for (; a-- && r.start < r.end; ) {
      const s = o[a], u = s.end - s.start, c = r.end - r.start;
      if (r.split ? (
        // The rule of 3, on the sizes that are left.
        (s.close || r.open) && c % 3 && !((u + c) % 3)
      ) : (
        // Others pair whole runs of the same size.
        u !== s.markers.length || u !== c
      ))
        continue;
      const l = r.split ? u > 1 && c > 1 ? 2 : 1 : c, f = s.markers.slice(s.end - l, s.end), d = r.markers.slice(r.start, r.start + l), p = f[0], h = d[0];
      if (
        // Whole sequences:
        // the markers of a sequence are next to each other,
        // so if the first and last marker are of one sequence of that size,
        // all markers are exactly that sequence.
        p === f[l - 1] && p.value.length === l && h === d[l - 1] && h.value.length === l && // Of the same attention, so its opening and closing sequence.
        p.attention === h.attention
      )
        t.delete(p), t.delete(h);
      else {
        const m = [.../* @__PURE__ */ new Set([...f, ...d])];
        for (const k of m) {
          const g = t.get(k);
          g && g.push(...m);
        }
      }
      s.end -= l, r.start += l, s.start === s.end && o.splice(a, 1), a = o.length;
    }
    r.open && r.start < r.end && o.push(r);
  }
}
function Zx(e, t, n) {
  if (t.length === 0)
    throw new Error(
      "Cannot serialize `" + e + "` as attention without markers, expected one or more markers"
    );
  if (n.length === 0)
    throw new Error(
      "Cannot serialize `" + e + "` as attention without sizes, expected one or more sizes"
    );
  for (const i of n)
    if (!Number.isSafeInteger(i) || i < 1)
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as size, expected positive integer"
      );
  const r = [];
  for (const i of t) {
    if (i.length !== 1)
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected a single ascii character"
      );
    if (!lc(i.charCodeAt(0)))
      throw new Error(
        "Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected ascii punctuation"
      );
    for (const o of n)
      r.push(i.repeat(o));
  }
  return r;
}
function Bx(e, t, n) {
  const r = t.indexStack, i = e.children || [], o = [];
  let a = -1, s = n.before;
  r.push(-1);
  let u = t.createTracker(n);
  for (; ++a < i.length; ) {
    const c = i[a];
    let l;
    if (r[r.length - 1] = a, a + 1 < i.length) {
      let p = t.handle.handlers[i[a + 1].type];
      p && p.peek && (p = p.peek), l = p ? _r(
        p(i[a + 1], e, t, {
          before: "",
          after: "",
          ...u.current()
        })
      ) : "";
    } else
      l = n.after;
    const f = o[o.length - 1];
    typeof f == "string" && (s === "\r" || s === `
`) && c.type === "html" && Dx(c.value) !== 7 && (o[o.length - 1] = f.replace(/(\r?\n|\r)$/, " "), s = " ", u = t.createTracker(n), u.move(Lr(o, n.before, n.after)));
    const d = t.handle.handlers[c.type];
    if (d && d.attention) {
      const p = Po(
        /** @type {PhrasingParents} */
        c,
        d.attention,
        t,
        u
      );
      if (!p) continue;
      o.push(p), s = Yt(p.sequences[0]);
    } else {
      const p = t.handle(c, e, t, {
        ...u.current(),
        after: l,
        before: s
      });
      if (!p) continue;
      u.move(p), o.push(p), s = Yt(p);
    }
  }
  return r.pop(), o;
}
function Po(e, t, n, r) {
  const { construct: i, markers: o, sizes: a } = t(e, n), s = Zx(e.type, o, a), u = s[0], c = n.enter(i), l = n.createTracker(r.current());
  l.move(u);
  const f = Bx(e, n, {
    ...l.current(),
    before: u,
    after: u
  });
  if (c(), f.length !== 0)
    return r.move(u), r.move(Lr(f, u, u)), r.move(u), { children: f, sequences: s };
}
function Ds(e, t, n, r) {
  let i = Dr(e, t, n, r), o = $c(i, n, r);
  for (; o; ) {
    const a = Fx(e, t, o, n, r);
    if (!a) return;
    t = a.chosen, i = a.tokens, o = a.mistake;
  }
  return i;
}
function Nc(e, t, n, r) {
  let i = n, o = -1;
  for (; ++o < e.length; ) {
    const a = e[o];
    if (typeof a == "string") {
      i = "";
      continue;
    }
    const s = o === e.length - 1 ? r : "", u = a.sequences.find(function(c) {
      const l = c.charAt(0);
      return l !== i.charAt(0) && l !== s.charAt(0) || e.length === 1 && Rc.has(l) && c.length > n.length;
    }) || a.sequences[0];
    u !== a.sequences[0] && t.set(a, u), Nc(a.children, t, u, u), i = u;
  }
}
function Dr(e, t, n, r) {
  const i = [];
  let o, a = Yt(n), s = -1;
  for (; ++s < e.length; ) {
    const u = e[s];
    if (typeof u == "string") {
      const w = { value: u, attention: void 0 };
      o && o === _r(u) && Qn([w], !0), o = void 0, i.push(w), w.value && (a = Yt(w.value));
      continue;
    }
    const c = t.get(u) || u.sequences[0], l = c.charAt(0), f = e[s + 1], d = a, p = _r(
      f === void 0 ? r : typeof f == "string" ? f : t.get(f) || f.sequences[0]
    ), h = Dr(u.children, t, c, c), m = h[0].value, k = Ns(
      d.charCodeAt(d.length - 1),
      m.charCodeAt(0),
      l
    );
    k.inside && Qn(h, !0);
    const g = Yt(h[h.length - 1].value), _ = Ns(
      p.charCodeAt(0),
      g.charCodeAt(g.length - 1),
      l
    );
    _.inside && Qn(h, !1), k.outside && d !== `
` && d !== "\r" && Qn(i, !1), _.outside && (o = p), i.push({ value: c, attention: u }, ...h, {
      value: c,
      attention: u
    }), a = c.charAt(c.length - 1);
  }
  return i;
}
function Lr(e, t, n) {
  const r = /* @__PURE__ */ new Map();
  Nc(e, r, t, n);
  const i = (
    // Start from guesses (based on the preferred sequences).
    (r.size > 0 ? Ds(e, r, t, n) : void 0) || // If stuck, start from the preferred sequences instead.
    Ds(e, /* @__PURE__ */ new Map(), t, n) || // If stuck again, use the preferred sequences as they are.
    Dr(e, /* @__PURE__ */ new Map(), t, n)
  );
  let o = "";
  for (const a of i) o += a.value;
  return o;
}
Mo.attention = Dc;
Mo.peek = Ux;
function Mo(e, t, n, r) {
  const i = n.enter("phrasing"), o = Po(e, Dc, n, n.createTracker(r)), a = o ? Lr([o], r.before, r.after) : "";
  return i(), a;
}
function Dc(e, t) {
  return {
    construct: "emphasis",
    markers: Nx(t) === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [1]
  };
}
function Ux(e, t, n) {
  return n.options.emphasis || "*";
}
function Vx(e, t) {
  let n = !1;
  return Nr(e, function(r) {
    if ("value" in r && /\r?\n|\r/.test(r.value) || r.type === "break")
      return n = !0, On;
  }), !!((!e.depth || e.depth < 3) && Or(e) && (t.options.setext || n));
}
function qx(e, t, n, r) {
  const i = Math.max(Math.min(6, e.depth || 1), 1), o = n.createTracker(r);
  if (Vx(e, n)) {
    const f = n.enter("headingSetext"), d = n.enter("phrasing"), p = n.containerPhrasing(e, {
      ...o.current(),
      before: `
`,
      after: `
`
    });
    return d(), f(), p + `
` + (i === 1 ? "=" : "-").repeat(
      // The whole size…
      p.length - // Minus the position of the character after the last EOL (or
      // 0 if there is none)…
      (Math.max(p.lastIndexOf("\r"), p.lastIndexOf(`
`)) + 1)
    );
  }
  const a = "#".repeat(i), s = n.enter("headingAtx"), u = n.enter("phrasing");
  o.move(a + " ");
  let c = n.containerPhrasing(e, {
    before: "# ",
    after: `
`,
    ...o.current()
  });
  const l = c.charCodeAt(0);
  return (l === 9 || l === 32) && (c = Mc(l) + c.slice(1)), c = c ? a + " " + c : a, n.options.closeAtx && (c += " " + a), u(), s(), c;
}
Lc.peek = Jx;
function Lc(e) {
  return e.value || "";
}
function Jx() {
  return "<";
}
Fc.peek = Wx;
function Fc(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.enter("image");
  let s = n.enter("label");
  const u = n.createTracker(r);
  let c = u.move("![");
  return c += u.move(
    n.safe(e.alt, { before: c, after: "]", ...u.current() })
  ), c += u.move("]("), s(), // If there’s no url but there is a title…
  !e.url && e.title || // If there are control characters or whitespace.
  /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), c += u.move("<"), c += u.move(
    n.safe(e.url, { before: c, after: ">", ...u.current() })
  ), c += u.move(">")) : (s = n.enter("destinationRaw"), c += u.move(
    n.safe(e.url, {
      before: c,
      after: e.title ? " " : ")",
      ...u.current()
    })
  )), s(), e.title && (s = n.enter(`title${o}`), c += u.move(" " + i), c += u.move(
    n.safe(e.title, {
      before: c,
      after: i,
      ...u.current()
    })
  ), c += u.move(i), s()), c += u.move(")"), a(), c;
}
function Wx() {
  return "!";
}
jc.peek = Hx;
function jc(e, t, n, r) {
  const i = e.referenceType, o = n.enter("imageReference");
  let a = n.enter("label");
  const s = n.createTracker(r);
  let u = s.move("![");
  const c = n.safe(e.alt, {
    before: u,
    after: "]",
    ...s.current()
  });
  u += s.move(c + "]["), a();
  const l = n.stack;
  n.stack = l.filter(function(d) {
    return d !== "phrasing";
  }), a = n.enter("reference");
  const f = n.safe(n.associationId(e), {
    before: u,
    after: "]",
    ...s.current()
  });
  return a(), n.stack = l, o(), i === "full" || !c || c !== f ? u += s.move(f + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += s.move("]"), u;
}
function Hx() {
  return "!";
}
Zc.peek = Kx;
function Zc(e, t, n) {
  let r = e.value || "", i = "`", o = -1;
  for (; new RegExp("(^|[^`])" + i + "([^`]|$)").test(r); )
    i += "`";
  for (/[^\n\r ]/.test(r) && (/^[\n\r ]/.test(r) && /[\n\r ]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++o < n.unsafe.length; ) {
    const a = n.unsafe[o], s = n.compilePattern(a);
    if (!a.atBreak) continue;
    let u;
    for (; u = s.exec(r); ) {
      let c = u.index;
      r.charCodeAt(c) === 10 && r.charCodeAt(c - 1) === 13 && c--, r = r.slice(0, c) + " " + r.slice(u.index + 1);
    }
  }
  return i + r + i;
}
function Kx() {
  return "`";
}
function Bc(e, t) {
  const n = Or(e);
  return !!(!t.options.resourceLink && // If there’s a url…
  e.url && // And there’s no title…
  !e.title && // And the content of `node` is a single text node…
  e.children && e.children.length === 1 && e.children[0].type === "text" && // And if the url is the same as the content…
  (n === e.url || "mailto:" + n === e.url) && // And that starts w/ a protocol…
  /^[a-z][+\-.a-z]+:/i.test(e.url) && // And that doesn’t contain ASCII control codes (character escapes and
  // references don’t work), space, or angle brackets…
  !/[\0- <>\u007F]/.test(e.url));
}
Uc.peek = Yx;
function Uc(e, t, n, r) {
  const i = Oo(n), o = i === '"' ? "Quote" : "Apostrophe", a = n.createTracker(r);
  if (Bc(e, n)) {
    const h = n.stack;
    n.stack = h.filter(function(g) {
      return g !== "phrasing";
    });
    const m = n.enter("autolink");
    let k = a.move("<");
    return k += a.move(
      n.containerPhrasing(e, {
        before: k,
        after: ">",
        ...a.current()
      })
    ), k += a.move(">"), m(), n.stack = h, k;
  }
  const s = n.enter("link");
  let u = n.enter("label"), c = a.move("[");
  const l = n.containerPhrasing(e, {
    before: c,
    after: "](",
    ...a.current()
  });
  c += a.move(l), u(), c += a.move("](");
  const f = /[\0- \u007F]/.test(e.url), d = r.before.charAt(r.before.length - 1);
  let p = e.title || void 0;
  if (!p && !f && (d === `
` || d === "\r")) {
    let h = 0;
    for (; h < l.length && l.charCodeAt(h) !== 93; )
      h += l.charCodeAt(h) === 92 ? 2 : 1;
    l.charCodeAt(h + 1) === 58 && (p = "");
  }
  return /* If there’s no url but there is a title… */ !e.url && typeof p == "string" || // If there are control characters or whitespace.
  f ? (u = n.enter("destinationLiteral"), c += a.move("<"), c += a.move(
    n.safe(e.url, { before: c, after: ">", ...a.current() })
  ), c += a.move(">")) : (u = n.enter("destinationRaw"), c += a.move(
    n.safe(e.url, {
      before: c,
      after: typeof p == "string" ? " " : ")",
      ...a.current()
    })
  )), u(), typeof p == "string" && (u = n.enter(`title${o}`), c += a.move(" " + i), c += a.move(
    n.safe(p, {
      before: c,
      after: i,
      ...a.current()
    })
  ), c += a.move(i), u()), c += a.move(")"), s(), c;
}
function Yx(e, t, n) {
  return Bc(e, n) ? "<" : "[";
}
Vc.peek = Gx;
function Vc(e, t, n, r) {
  const i = e.referenceType, o = n.enter("linkReference");
  let a = n.enter("label");
  const s = n.createTracker(r);
  let u = s.move("[");
  const c = n.containerPhrasing(e, {
    before: u,
    after: "]",
    ...s.current()
  });
  u += s.move(c + "]["), a();
  const l = n.stack;
  n.stack = l.filter(function(d) {
    return d !== "phrasing";
  }), a = n.enter("reference");
  const f = n.safe(n.associationId(e), {
    before: u,
    after: "]",
    ...s.current()
  });
  return a(), n.stack = l, o(), i === "full" || !c || c !== f ? u += s.move(f + "]") : i === "shortcut" ? u = u.slice(0, -1) : u += s.move("]"), u;
}
function Gx() {
  return "[";
}
function Ro(e) {
  const t = e.options.bullet || "*";
  if (t !== "*" && t !== "+" && t !== "-")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`"
    );
  return t;
}
function Xx(e) {
  const t = Ro(e), n = e.options.bulletOther;
  if (!n)
    return t === "*" ? "-" : "*";
  if (n !== "*" && n !== "+" && n !== "-")
    throw new Error(
      "Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`"
    );
  if (n === t)
    throw new Error(
      "Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different"
    );
  return n;
}
function Qx(e) {
  const t = e.options.bulletOrdered || ".";
  if (t !== "." && t !== ")")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`"
    );
  return t;
}
function qc(e) {
  const t = e.options.rule || "*";
  if (t !== "*" && t !== "-" && t !== "_")
    throw new Error(
      "Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`"
    );
  return t;
}
function e_(e, t, n, r) {
  const i = n.enter("list"), o = n.bulletCurrent;
  let a = e.ordered ? Qx(n) : Ro(n);
  const s = e.ordered ? a === "." ? ")" : "." : Xx(n);
  let u = t && n.bulletLastUsed ? a === n.bulletLastUsed : !1;
  if (!e.ordered) {
    const l = e.children ? e.children[0] : void 0;
    if (
      // Bullet could be used as a thematic break marker:
      (a === "*" || a === "-") && // Empty first list item:
      l && (!l.children || !l.children[0]) && // Directly in two other list items:
      n.stack[n.stack.length - 1] === "list" && n.stack[n.stack.length - 2] === "listItem" && n.stack[n.stack.length - 3] === "list" && n.stack[n.stack.length - 4] === "listItem" && // That are each the first child.
      n.indexStack[n.indexStack.length - 1] === 0 && n.indexStack[n.indexStack.length - 2] === 0 && n.indexStack[n.indexStack.length - 3] === 0 && (u = !0), qc(n) === a && l
    ) {
      let f = -1;
      for (; ++f < e.children.length; ) {
        const d = e.children[f];
        if (d && d.type === "listItem" && d.children && d.children[0] && d.children[0].type === "thematicBreak") {
          u = !0;
          break;
        }
      }
    }
  }
  u && (a = s), n.bulletCurrent = a;
  const c = n.containerFlow(e, r);
  return n.bulletLastUsed = a, n.bulletCurrent = o, i(), c;
}
function t_(e) {
  const t = e.options.listItemIndent || "one";
  if (t !== "tab" && t !== "one" && t !== "mixed")
    throw new Error(
      "Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`"
    );
  return t;
}
function n_(e, t, n, r) {
  const i = t_(n);
  let o = n.bulletCurrent || Ro(n);
  t && t.type === "list" && t.ordered && (o = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === !1 ? 0 : t.children.indexOf(e)) + o);
  let a = o.length + 1;
  (i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (a = Math.ceil(a / 4) * 4);
  const s = n.createTracker(r);
  s.move(o + " ".repeat(a - o.length)), s.shift(a);
  const u = n.enter("listItem"), c = n.indentLines(
    n.containerFlow(e, s.current()),
    l
  );
  return u(), c;
  function l(f, d, p) {
    return d ? (p ? "" : " ".repeat(a)) + f : (p ? o : o + " ".repeat(a - o.length)) + f;
  }
}
function r_(e, t, n, r) {
  const i = n.enter("paragraph"), o = n.enter("phrasing"), a = n.containerPhrasing(e, r);
  return o(), i(), a;
}
function i_(e, t, n, r) {
  if (!e.children.some(function(s) {
    return Ex(s);
  })) return n.containerFlow(e, r);
  const o = n.enter("phrasing"), a = n.containerPhrasing(e, r);
  return o(), a;
}
function o_(e) {
  const t = e.options.strong || "*";
  if (t !== "*" && t !== "_")
    throw new Error(
      "Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`"
    );
  return t;
}
$o.attention = Jc;
$o.peek = a_;
function $o(e, t, n, r) {
  const i = n.enter("phrasing"), o = Po(e, Jc, n, n.createTracker(r)), a = o ? Lr([o], r.before, r.after) : "";
  return i(), a;
}
function Jc(e, t) {
  return {
    construct: "strong",
    markers: o_(t) === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [2]
  };
}
function a_(e, t, n) {
  return n.options.strong || "*";
}
function s_(e, t, n, r) {
  const i = t ? t.children : [], o = n.indexStack[n.indexStack.length - 1];
  return n.safe(e.value, {
    ...r,
    afterNode: i[o + 1],
    beforeNode: i[o - 1]
  });
}
function l_(e) {
  const t = e.options.ruleRepetition || 3;
  if (t < 3)
    throw new Error(
      "Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more"
    );
  return t;
}
function u_(e, t, n) {
  const r = (qc(n) + (n.options.ruleSpaces ? " " : "")).repeat(l_(n));
  return n.options.ruleSpaces ? r.slice(0, -1) : r;
}
const Yi = {
  blockquote: Cx,
  break: $s,
  code: Mx,
  definition: $x,
  emphasis: Mo,
  hardBreak: $s,
  heading: qx,
  html: Lc,
  image: Fc,
  imageReference: jc,
  inlineCode: Zc,
  link: Uc,
  linkReference: Vc,
  list: e_,
  listItem: n_,
  paragraph: r_,
  root: i_,
  strong: $o,
  text: s_,
  thematicBreak: u_
};
function c_() {
  return {
    enter: {
      table: f_,
      tableData: Ls,
      tableHeader: Ls,
      tableRow: p_
    },
    exit: {
      codeText: h_,
      table: d_,
      tableData: hi,
      tableHeader: hi,
      tableRow: hi
    }
  };
}
function f_(e) {
  const t = e._align;
  this.enter(
    {
      type: "table",
      align: t.map(function(n) {
        return n === "none" ? null : n;
      }),
      children: [],
      position: void 0
    },
    e
  ), this.data.inTable = !0;
}
function d_(e) {
  this.exit(e), this.data.inTable = void 0;
}
function p_(e) {
  this.enter({ type: "tableRow", children: [], position: void 0 }, e);
}
function hi(e) {
  this.exit(e);
}
function Ls(e) {
  this.enter({ type: "tableCell", children: [], position: void 0 }, e);
}
function h_(e) {
  let t = this.resume();
  this.data.inTable && (t = t.replace(/\\([\\|])/g, m_));
  const n = this.stack[this.stack.length - 1];
  n.type, n.value = t, this.exit(e);
}
function m_(e, t) {
  return t === "|" ? t : e;
}
function g_(e) {
  const t = e || {}, {
    tableCellPadding: n,
    tablePipeAlign: r,
    stringLength: i
  } = t, o = n ? " " : "|";
  return {
    handlers: {
      inlineCode: d,
      table: a,
      tableCell: u,
      tableRow: s
    },
    join: [y_],
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      // A pipe, when followed by a tab or space (padding), or a dash or colon
      // (unpadded delimiter row), could result in a table.
      { atBreak: !0, character: "|", after: "[	 :-]" },
      // A pipe in a cell must be encoded.
      { character: "|", inConstruct: "tableCell" },
      // A colon must be followed by a dash, in which case it could start a
      // delimiter row.
      { atBreak: !0, character: ":", after: "-" },
      // A delimiter row can also start with a dash, when followed by more
      // dashes, a colon, or a pipe.
      // This is a stricter version than the built in check for lists, thematic
      // breaks, and setex heading underlines though:
      // <https://github.com/syntax-tree/mdast-util-to-markdown/blob/51a2038/lib/unsafe.js#L57>
      { atBreak: !0, character: "-", after: "[:|-]" }
    ]
  };
  function a(p, h, m, k) {
    const g = l(p, m, k), _ = g[0];
    if (_) {
      let w = p.align ? p.align.length : 0, C = -1;
      if (!w)
        for (; ++C < g.length; )
          g[C].length > w && (w = g[C].length);
      for (; _.length < w; ) _.push("");
    }
    return c(g, p.align);
  }
  function s(p, h, m, k) {
    const g = f(p, m, k), _ = c([g]);
    return _.slice(0, _.indexOf(`
`));
  }
  function u(p, h, m, k) {
    const g = m.enter("tableCell"), _ = m.enter("phrasing"), w = m.containerPhrasing(p, {
      ...k,
      before: o,
      after: o
    });
    return _(), g(), w;
  }
  function c(p, h) {
    return Sx(p, {
      align: h,
      alignDelimiters: r,
      fillRows: !1,
      padding: n,
      stringLength: i
    });
  }
  function l(p, h, m) {
    const { children: k } = p;
    let g = -1;
    const _ = [], w = h.enter("table");
    for (; ++g < k.length; )
      _[g] = f(k[g], h, m);
    return w(), _;
  }
  function f(p, h, m) {
    const { children: k } = p;
    let g = -1;
    const _ = [], w = h.enter("tableRow");
    for (; ++g < k.length; )
      _[g] = u(k[g], p, h, m);
    return w(), _;
  }
  function d(p, h, m) {
    const k = Yi.inlineCode(p, h, m);
    if (!m.stack.includes("tableCell")) return k;
    const g = [];
    let _ = 0, w = k.indexOf("|");
    for (; w !== -1; ) {
      let C = w;
      for (; C > _ && k.charCodeAt(C - 1) === 92; )
        C--;
      g.push(k.slice(_, w)), (w - C) % 2 === 0 && g.push("\\"), _ = w, w = k.indexOf("|", w + 1);
    }
    return g.push(k.slice(_)), g.join("");
  }
}
function y_(e, t, n, r) {
  if (e.type === "table" && n.type === "listItem" && n.spread === !1 && (t.type === "definition" || t.type === "heading" && b_(t, r) || t.type === "paragraph" || t.type === "table"))
    return 1;
}
function b_(e, t) {
  let n = !1;
  return Nr(e, function(r) {
    if (r.type === "break" || "value" in r && /\r?\n|\r/.test(r.value))
      return n = !0, On;
  }), !!((!e.depth || e.depth < 3) && Or(e) && (t.options.setext || n));
}
function v_() {
  return {
    exit: {
      taskListCheckValueChecked: Fs,
      taskListCheckValueUnchecked: Fs,
      paragraph: w_
    }
  };
}
function k_() {
  return {
    handlers: { paragraph: x_ },
    join: [__]
  };
}
function Fs(e) {
  const t = this.stack[this.stack.length - 2];
  t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function w_(e) {
  const t = this.stack[this.stack.length - 2];
  if (t && t.type === "listItem" && typeof t.checked == "boolean") {
    const n = this.stack[this.stack.length - 1];
    n.type;
    const r = n.children[0];
    if (r && r.type === "text") {
      const i = t.children;
      let o = -1, a;
      for (; ++o < i.length; ) {
        const s = i[o];
        if (s.type === "paragraph") {
          a = s;
          break;
        }
      }
      a === n && (r.value = r.value.slice(1), r.value.length === 0 ? n.children.shift() : n.position && r.position && typeof r.position.start.offset == "number" && (r.position.start.column++, r.position.start.offset++, n.position.start = { ...r.position.start }));
    }
  }
  this.exit(e);
}
function x_(e, t, n, r) {
  if (!t || t.type !== "listItem" || Wc(t) !== e)
    return Yi.paragraph(e, t, n, r);
  const i = "[" + (t.checked ? "x" : " ") + "] ", o = n.createTracker(r);
  o.move(i);
  const a = Yi.paragraph(
    e.children.length > 0 ? e : { type: "paragraph", children: [{ type: "text", value: " " }] },
    t,
    n,
    { ...r, ...o.current() }
  );
  return i + a;
}
function __(e, t, n) {
  if (!(e.type === "definition" && n.type === "listItem"))
    return;
  const r = Wc(n);
  if (r && n.children.indexOf(e) < n.children.indexOf(r))
    return 0;
}
function Wc(e) {
  if (typeof e.checked == "boolean")
    for (const t of e.children) {
      if (t.type === "paragraph")
        return t;
      if (t.type !== "definition")
        return;
    }
}
function S_() {
  return [
    U1(),
    px(),
    yx(),
    c_(),
    v_()
  ];
}
function I_(e) {
  return {
    extensions: [
      V1(),
      hx(e),
      bx(),
      g_(e),
      k_()
    ]
  };
}
const E_ = {
  tokenize: P_,
  partial: !0
}, Hc = {
  tokenize: M_,
  partial: !0
}, Kc = {
  tokenize: R_,
  partial: !0
}, Yc = {
  tokenize: $_,
  partial: !0
}, C_ = {
  tokenize: N_,
  partial: !0
}, Gc = {
  name: "wwwAutolink",
  tokenize: T_,
  previous: Qc
}, Xc = {
  name: "protocolAutolink",
  tokenize: O_,
  previous: ef
}, ht = {
  name: "emailAutolink",
  tokenize: z_,
  previous: tf
}, ct = {};
function A_() {
  return {
    text: ct
  };
}
let Ot = 48;
for (; Ot < 123; )
  ct[Ot] = ht, Ot++, Ot === 58 ? Ot = 65 : Ot === 91 && (Ot = 97);
ct[43] = ht;
ct[45] = ht;
ct[46] = ht;
ct[95] = ht;
ct[72] = [ht, Xc];
ct[104] = [ht, Xc];
ct[87] = [ht, Gc];
ct[119] = [ht, Gc];
function z_(e, t, n) {
  const r = this;
  let i, o;
  return a;
  function a(f) {
    return !Gi(f) || !tf.call(r, r.previous) || No(r.events) ? n(f) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), s(f));
  }
  function s(f) {
    return Gi(f) ? (e.consume(f), s) : f === 64 ? (e.consume(f), u) : n(f);
  }
  function u(f) {
    return f === 46 ? e.check(C_, l, c)(f) : f === 45 || f === 95 || xe(f) ? (o = !0, e.consume(f), u) : l(f);
  }
  function c(f) {
    return e.consume(f), i = !0, u;
  }
  function l(f) {
    return o && i && we(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(f)) : n(f);
  }
}
function T_(e, t, n) {
  const r = this;
  return i;
  function i(a) {
    return a !== 87 && a !== 119 || !Qc.call(r, r.previous) || No(r.events) ? n(a) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(E_, e.attempt(Hc, e.attempt(Kc, o), n), n)(a));
  }
  function o(a) {
    return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(a);
  }
}
function O_(e, t, n) {
  const r = this;
  let i = "", o = !1;
  return a;
  function a(f) {
    return (f === 72 || f === 104) && ef.call(r, r.previous) && !No(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(f), e.consume(f), s) : n(f);
  }
  function s(f) {
    if (we(f) && i.length < 5)
      return i += String.fromCodePoint(f), e.consume(f), s;
    if (f === 58) {
      const d = i.toLowerCase();
      if (d === "http" || d === "https")
        return e.consume(f), u;
    }
    return n(f);
  }
  function u(f) {
    return f === 47 ? (e.consume(f), o ? c : (o = !0, u)) : n(f);
  }
  function c(f) {
    return f === null || vr(f) || ae(f) || jt(f) || Zn(f) ? n(f) : e.attempt(Hc, e.attempt(Kc, l), n)(f);
  }
  function l(f) {
    return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(f);
  }
}
function P_(e, t, n) {
  let r = 0;
  return i;
  function i(a) {
    return (a === 87 || a === 119) && r < 3 ? (r++, e.consume(a), i) : a === 46 && r === 3 ? (e.consume(a), o) : n(a);
  }
  function o(a) {
    return a === null ? n(a) : t(a);
  }
}
function M_(e, t, n) {
  let r, i, o;
  return a;
  function a(c) {
    return c === 46 || c === 95 ? e.check(Yc, u, s)(c) : c === null || ae(c) || jt(c) || c !== 45 && Zn(c) ? u(c) : (o = !0, e.consume(c), a);
  }
  function s(c) {
    return c === 95 ? r = !0 : (i = r, r = void 0), e.consume(c), a;
  }
  function u(c) {
    return i || r || !o ? n(c) : t(c);
  }
}
function R_(e, t) {
  let n = 0, r = 0;
  return i;
  function i(a) {
    return a === 40 ? (n++, e.consume(a), i) : a === 41 && r < n ? o(a) : a === 33 || a === 34 || a === 38 || a === 39 || a === 41 || a === 42 || a === 44 || a === 46 || a === 58 || a === 59 || a === 60 || a === 63 || a === 93 || a === 95 || a === 126 ? e.check(Yc, t, o)(a) : a === null || ae(a) || jt(a) ? t(a) : (e.consume(a), i);
  }
  function o(a) {
    return a === 41 && r++, e.consume(a), i;
  }
}
function $_(e, t, n) {
  return r;
  function r(s) {
    return s === 33 || s === 34 || s === 39 || s === 41 || s === 42 || s === 44 || s === 46 || s === 58 || s === 59 || s === 63 || s === 95 || s === 126 ? (e.consume(s), r) : s === 38 ? (e.consume(s), o) : s === 93 ? (e.consume(s), i) : (
      // `<` is an end.
      s === 60 || // So is whitespace.
      s === null || ae(s) || jt(s) ? t(s) : n(s)
    );
  }
  function i(s) {
    return s === null || s === 40 || s === 91 || ae(s) || jt(s) ? t(s) : r(s);
  }
  function o(s) {
    return we(s) ? a(s) : n(s);
  }
  function a(s) {
    return s === 59 ? (e.consume(s), r) : we(s) ? (e.consume(s), a) : n(s);
  }
}
function N_(e, t, n) {
  return r;
  function r(o) {
    return e.consume(o), i;
  }
  function i(o) {
    return xe(o) ? n(o) : t(o);
  }
}
function Qc(e) {
  return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || ae(e);
}
function ef(e) {
  return !we(e);
}
function tf(e) {
  return !(e === 47 || Gi(e));
}
function Gi(e) {
  return e === 43 || e === 45 || e === 46 || e === 95 || xe(e);
}
function No(e) {
  let t = e.length, n = !1;
  for (; t--; ) {
    const r = e[t][1];
    if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
      n = !0;
      break;
    }
    if (r._gfmAutolinkLiteralWalkedInto) {
      n = !1;
      break;
    }
  }
  return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
const D_ = {
  tokenize: q_,
  partial: !0
};
function L_() {
  return {
    document: {
      91: {
        name: "gfmFootnoteDefinition",
        tokenize: B_,
        continuation: {
          tokenize: U_
        },
        exit: V_
      }
    },
    text: {
      91: {
        name: "gfmFootnoteCall",
        tokenize: Z_
      },
      93: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: F_,
        resolveTo: j_
      }
    }
  };
}
function F_(e, t, n) {
  const r = this;
  let i = r.events.length;
  const o = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let a;
  for (; i--; ) {
    const u = r.events[i][1];
    if (u.type === "labelImage") {
      a = u;
      break;
    }
    if (u.type === "gfmFootnoteCall" || u.type === "labelLink" || u.type === "label" || u.type === "image" || u.type === "link")
      break;
  }
  return s;
  function s(u) {
    if (!a || !a._balanced)
      return n(u);
    const c = et(r.sliceSerialize({
      start: a.end,
      end: r.now()
    }));
    return c.codePointAt(0) !== 94 || !o.includes(c.slice(1)) ? n(u) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(u), e.exit("gfmFootnoteCallLabelMarker"), t(u));
  }
}
function j_(e, t) {
  let n = e.length;
  for (; n--; )
    if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
      e[n][1];
      break;
    }
  e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
  const r = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, e[n + 3][1].start),
    end: Object.assign({}, e[e.length - 1][1].end)
  }, i = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, e[n + 3][1].end),
    end: Object.assign({}, e[n + 3][1].end)
  };
  i.end.column++, i.end.offset++, i.end._bufferIndex++;
  const o = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, i.end),
    end: Object.assign({}, e[e.length - 1][1].start)
  }, a = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, o.start),
    end: Object.assign({}, o.end)
  }, s = [
    // Take the `labelImageMarker` (now `data`, the `!`)
    e[n + 1],
    e[n + 2],
    ["enter", r, t],
    // The `[`
    e[n + 3],
    e[n + 4],
    // The `^`.
    ["enter", i, t],
    ["exit", i, t],
    // Everything in between.
    ["enter", o, t],
    ["enter", a, t],
    ["exit", a, t],
    ["exit", o, t],
    // The ending (`]`, properly parsed and labelled).
    e[e.length - 2],
    e[e.length - 1],
    ["exit", r, t]
  ];
  return e.splice(n, e.length - n + 1, ...s), e;
}
function Z_(e, t, n) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let o = 0, a;
  return s;
  function s(f) {
    return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(f), e.exit("gfmFootnoteCallLabelMarker"), u;
  }
  function u(f) {
    return f !== 94 ? n(f) : (e.enter("gfmFootnoteCallMarker"), e.consume(f), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", c);
  }
  function c(f) {
    if (
      // Too long.
      o > 999 || // Closing brace with nothing.
      f === 93 && !a || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      f === null || f === 91 || ae(f)
    )
      return n(f);
    if (f === 93) {
      e.exit("chunkString");
      const d = e.exit("gfmFootnoteCallString");
      return i.includes(et(r.sliceSerialize(d))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(f), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(f);
    }
    return ae(f) || (a = !0), o++, e.consume(f), f === 92 ? l : c;
  }
  function l(f) {
    return f === 91 || f === 92 || f === 93 ? (e.consume(f), o++, c) : c(f);
  }
}
function B_(e, t, n) {
  const r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []);
  let o, a = 0, s;
  return u;
  function u(h) {
    return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionLabelMarker"), c;
  }
  function c(h) {
    return h === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", l) : n(h);
  }
  function l(h) {
    if (
      // Too long.
      a > 999 || // Closing brace with nothing.
      h === 93 && !s || // Space or tab is not supported by GFM for some reason.
      // `\n` and `[` not being supported makes sense.
      h === null || h === 91 || ae(h)
    )
      return n(h);
    if (h === 93) {
      e.exit("chunkString");
      const m = e.exit("gfmFootnoteDefinitionLabelString");
      return o = et(r.sliceSerialize(m)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(h), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), d;
    }
    return ae(h) || (s = !0), a++, e.consume(h), h === 92 ? f : l;
  }
  function f(h) {
    return h === 91 || h === 92 || h === 93 ? (e.consume(h), a++, l) : l(h);
  }
  function d(h) {
    return h === 58 ? (e.enter("definitionMarker"), e.consume(h), e.exit("definitionMarker"), i.includes(o) || i.push(o), ne(e, p, "gfmFootnoteDefinitionWhitespace")) : n(h);
  }
  function p(h) {
    return t(h);
  }
}
function U_(e, t, n) {
  return e.check(Bn, t, e.attempt(D_, t, n));
}
function V_(e) {
  e.exit("gfmFootnoteDefinition");
}
function q_(e, t, n) {
  const r = this;
  return ne(e, i, "gfmFootnoteDefinitionIndent", 5);
  function i(o) {
    const a = r.events[r.events.length - 1];
    return a && a[1].type === "gfmFootnoteDefinitionIndent" && a[2].sliceSerialize(a[1], !0).length === 4 ? t(o) : n(o);
  }
}
function J_(e) {
  let n = (e || {}).singleTilde;
  const r = {
    name: "strikethrough",
    tokenize: o,
    resolveAll: i
  };
  return n == null && (n = !0), {
    text: {
      126: r
    },
    insideSpan: {
      null: [r]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function i(a, s) {
    let u = -1;
    for (; ++u < a.length; )
      if (a[u][0] === "enter" && a[u][1].type === "strikethroughSequenceTemporary" && a[u][1]._close) {
        let c = u;
        for (; c--; )
          if (a[c][0] === "exit" && a[c][1].type === "strikethroughSequenceTemporary" && a[c][1]._open && // If the sizes are the same:
          a[u][1].end.offset - a[u][1].start.offset === a[c][1].end.offset - a[c][1].start.offset) {
            a[u][1].type = "strikethroughSequence", a[c][1].type = "strikethroughSequence";
            const l = {
              type: "strikethrough",
              start: Object.assign({}, a[c][1].start),
              end: Object.assign({}, a[u][1].end)
            }, f = {
              type: "strikethroughText",
              start: Object.assign({}, a[c][1].end),
              end: Object.assign({}, a[u][1].start)
            }, d = [["enter", l, s], ["enter", a[c][1], s], ["exit", a[c][1], s], ["enter", f, s]], p = s.parser.constructs.insideSpan.null;
            p && Qe(d, d.length, 0, Pr(p, a.slice(c + 1, u), s)), Qe(d, d.length, 0, [["exit", f, s], ["enter", a[u][1], s], ["exit", a[u][1], s], ["exit", l, s]]), Qe(a, c - 1, u - c + 3, d), u = c + d.length - 2;
            break;
          }
      }
    for (u = -1; ++u < a.length; )
      a[u][1].type === "strikethroughSequenceTemporary" && (a[u][1].type = "data");
    return a;
  }
  function o(a, s, u) {
    const c = this.previous, l = this.events;
    let f = 0;
    return d;
    function d(h) {
      return c === 126 && l[l.length - 1][1].type !== "characterEscape" ? u(h) : (a.enter("strikethroughSequenceTemporary"), p(h));
    }
    function p(h) {
      const m = Et(c);
      if (h === 126)
        return f > 1 ? u(h) : (a.consume(h), f++, p);
      if (f < 2 && !n) return u(h);
      const k = a.exit("strikethroughSequenceTemporary"), g = Et(h);
      return k._open = !g || g === 2 && !!m, k._close = !m || m === 2 && !!g, s(h);
    }
  }
}
class W_ {
  /**
   * Create a new edit map.
   */
  constructor() {
    this.map = [], this.index = /* @__PURE__ */ new Map();
  }
  /**
   * Create an edit: a remove and/or add at a certain place.
   *
   * @param {number} index
   *   Index at which to apply the edit.
   * @param {number} remove
   *   Count of items to remove at the index.
   * @param {Array<Event>} add
   *   Items to add at the index.
   * @returns {undefined}
   *   Nothing.
   */
  add(t, n, r) {
    H_(this, t, n, r);
  }
  // To do: add this when moving to `micromark`.
  // /**
  //  * Create an edit: but insert `add` before existing additions.
  //  *
  //  * @param {number} index
  //  * @param {number} remove
  //  * @param {Array<Event>} add
  //  * @returns {undefined}
  //  */
  // addBefore(index, remove, add) {
  //   addImplementation(this, index, remove, add, true)
  // }
  /**
   * Done, change the events.
   *
   * @param {Array<Event>} events
   *   List of events to apply the edits to.
   * @returns {undefined}
   *   Nothing.
   */
  consume(t) {
    if (this.map.sort(function(o, a) {
      return o[0] - a[0];
    }), this.map.length === 0)
      return;
    let n = this.map.length;
    const r = [];
    for (; n > 0; )
      n -= 1, r.push(t.slice(this.map[n][0] + this.map[n][1]), this.map[n][2]), t.length = this.map[n][0];
    r.push(t.slice()), t.length = 0;
    let i = r.pop();
    for (; i; ) {
      for (const o of i)
        t.push(o);
      i = r.pop();
    }
    this.map.length = 0, this.index.clear();
  }
}
function H_(e, t, n, r) {
  if (n === 0 && r.length === 0)
    return;
  const i = e.index.get(t);
  if (i) {
    i[1] += n, i[2].push(...r);
    return;
  }
  const o = [t, n, r];
  e.map.push(o), e.index.set(t, o);
}
function K_(e, t) {
  let n = !1;
  const r = [];
  for (; t < e.length; ) {
    const i = e[t];
    if (n) {
      if (i[0] === "enter")
        i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
      else if (i[1].type === "tableContent") {
        if (e[t - 1][1].type === "tableDelimiterMarker") {
          const o = r.length - 1;
          r[o] = r[o] === "left" ? "center" : "right";
        }
      } else if (i[1].type === "tableDelimiterRow")
        break;
    } else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = !0);
    t += 1;
  }
  return r;
}
function Y_() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: G_,
        resolveAll: X_
      }
    }
  };
}
function G_(e, t, n) {
  const r = this;
  let i = 0, o = 0, a;
  return s;
  function s(S) {
    let M = r.events.length - 1;
    for (; M > -1; ) {
      const {
        type: Z
      } = r.events[M][1];
      if (Z === "lineEnding" || // Note: markdown-rs uses `whitespace` instead of `linePrefix`
      Z === "linePrefix")
        M--;
      else
        break;
    }
    const L = M > -1 ? r.events[M][1].type : null, x = L === "tableHead" || L === "tableRow" ? y : u;
    return x === y && r.parser.lazy[r.now().line] ? n(S) : x(S);
  }
  function u(S) {
    return e.enter("tableHead"), e.enter("tableRow"), c(S);
  }
  function c(S) {
    return S === 124 || (a = !0, o += 1), l(S);
  }
  function l(S) {
    return S === null ? n(S) : q(S) ? o > 1 ? (o = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(S), e.exit("lineEnding"), p) : n(S) : X(S) ? ne(e, l, "whitespace")(S) : (o += 1, a && (a = !1, i += 1), S === 124 ? (e.enter("tableCellDivider"), e.consume(S), e.exit("tableCellDivider"), a = !0, l) : (e.enter("data"), f(S)));
  }
  function f(S) {
    return S === null || S === 124 || ae(S) ? (e.exit("data"), l(S)) : (e.consume(S), S === 92 ? d : f);
  }
  function d(S) {
    return S === 92 || S === 124 ? (e.consume(S), f) : f(S);
  }
  function p(S) {
    return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(S) : (e.enter("tableDelimiterRow"), a = !1, X(S) ? ne(e, h, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(S) : h(S));
  }
  function h(S) {
    return S === 45 || S === 58 ? k(S) : S === 124 ? (a = !0, e.enter("tableCellDivider"), e.consume(S), e.exit("tableCellDivider"), m) : I(S);
  }
  function m(S) {
    return X(S) ? ne(e, k, "whitespace")(S) : k(S);
  }
  function k(S) {
    return S === 58 ? (o += 1, a = !0, e.enter("tableDelimiterMarker"), e.consume(S), e.exit("tableDelimiterMarker"), g) : S === 45 ? (o += 1, g(S)) : S === null || q(S) ? C(S) : I(S);
  }
  function g(S) {
    return S === 45 ? (e.enter("tableDelimiterFiller"), _(S)) : I(S);
  }
  function _(S) {
    return S === 45 ? (e.consume(S), _) : S === 58 ? (a = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(S), e.exit("tableDelimiterMarker"), w) : (e.exit("tableDelimiterFiller"), w(S));
  }
  function w(S) {
    return X(S) ? ne(e, C, "whitespace")(S) : C(S);
  }
  function C(S) {
    return S === 124 ? h(S) : S === null || q(S) ? !a || i !== o ? I(S) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(S)) : I(S);
  }
  function I(S) {
    return n(S);
  }
  function y(S) {
    return e.enter("tableRow"), E(S);
  }
  function E(S) {
    return S === 124 ? (e.enter("tableCellDivider"), e.consume(S), e.exit("tableCellDivider"), E) : S === null || q(S) ? (e.exit("tableRow"), t(S)) : X(S) ? ne(e, E, "whitespace")(S) : (e.enter("data"), R(S));
  }
  function R(S) {
    return S === null || S === 124 || ae(S) ? (e.exit("data"), E(S)) : (e.consume(S), S === 92 ? F : R);
  }
  function F(S) {
    return S === 92 || S === 124 ? (e.consume(S), R) : R(S);
  }
}
function X_(e, t) {
  let n = -1, r = !0, i = 0, o = [0, 0, 0, 0], a = [0, 0, 0, 0], s = !1, u = 0, c, l, f;
  const d = new W_();
  for (; ++n < e.length; ) {
    const p = e[n], h = p[1];
    p[0] === "enter" ? h.type === "tableHead" ? (s = !1, u !== 0 && (js(d, t, u, c, l), l = void 0, u = 0), c = {
      type: "table",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, d.add(n, 0, [["enter", c, t]])) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (r = !0, f = void 0, o = [0, 0, 0, 0], a = [0, n + 1, 0, 0], s && (s = !1, l = {
      type: "tableBody",
      start: Object.assign({}, h.start),
      // Note: correct end is set later.
      end: Object.assign({}, h.end)
    }, d.add(n, 0, [["enter", l, t]])), i = h.type === "tableDelimiterRow" ? 2 : l ? 3 : 1) : i && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") ? (r = !1, a[2] === 0 && (o[1] !== 0 && (a[0] = a[1], f = er(d, t, o, i, void 0, f), o = [0, 0, 0, 0]), a[2] = n)) : h.type === "tableCellDivider" && (r ? r = !1 : (o[1] !== 0 && (a[0] = a[1], f = er(d, t, o, i, void 0, f)), o = a, a = [o[1], n, 0, 0])) : h.type === "tableHead" ? (s = !0, u = n) : h.type === "tableRow" || h.type === "tableDelimiterRow" ? (u = n, o[1] !== 0 ? (a[0] = a[1], f = er(d, t, o, i, n, f)) : a[1] !== 0 && (f = er(d, t, a, i, n, f)), i = 0) : i && (h.type === "data" || h.type === "tableDelimiterMarker" || h.type === "tableDelimiterFiller") && (a[3] = n);
  }
  for (u !== 0 && js(d, t, u, c, l), d.consume(t.events), n = -1; ++n < t.events.length; ) {
    const p = t.events[n];
    p[0] === "enter" && p[1].type === "table" && (p[1]._align = K_(t.events, n));
  }
  return e;
}
function er(e, t, n, r, i, o) {
  const a = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData", s = "tableContent";
  n[0] !== 0 && (o.end = Object.assign({}, Ht(t.events, n[0])), e.add(n[0], 0, [["exit", o, t]]));
  const u = Ht(t.events, n[1]);
  if (o = {
    type: a,
    start: Object.assign({}, u),
    // Note: correct end is set later.
    end: Object.assign({}, u)
  }, e.add(n[1], 0, [["enter", o, t]]), n[2] !== 0) {
    const c = Ht(t.events, n[2]), l = Ht(t.events, n[3]), f = {
      type: s,
      start: Object.assign({}, c),
      end: Object.assign({}, l)
    };
    if (e.add(n[2], 0, [["enter", f, t]]), r !== 2) {
      const d = t.events[n[2]], p = t.events[n[3]];
      if (d[1].end = Object.assign({}, p[1].end), d[1].type = "chunkText", d[1].contentType = "text", n[3] > n[2] + 1) {
        const h = n[2] + 1, m = n[3] - n[2] - 1;
        e.add(h, m, []);
      }
    }
    e.add(n[3] + 1, 0, [["exit", f, t]]);
  }
  return i !== void 0 && (o.end = Object.assign({}, Ht(t.events, i)), e.add(i, 0, [["exit", o, t]]), o = void 0), o;
}
function js(e, t, n, r, i) {
  const o = [], a = Ht(t.events, n);
  i && (i.end = Object.assign({}, a), o.push(["exit", i, t])), r.end = Object.assign({}, a), o.push(["exit", r, t]), e.add(n + 1, 0, o);
}
function Ht(e, t) {
  const n = e[t], r = n[0] === "enter" ? "start" : "end";
  return n[1][r];
}
const Q_ = {
  name: "tasklistCheck",
  tokenize: tS
};
function eS() {
  return {
    text: {
      91: Q_
    }
  };
}
function tS(e, t, n) {
  const r = this;
  return i;
  function i(u) {
    return (
      // Exit if there’s stuff before.
      r.previous !== null || // Exit if not in the first content that is the first child of a list
      // item.
      !r._gfmTasklistFirstContentOfListItem ? n(u) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), o)
    );
  }
  function o(u) {
    return ae(u) ? (e.enter("taskListCheckValueUnchecked"), e.consume(u), e.exit("taskListCheckValueUnchecked"), a) : u === 88 || u === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(u), e.exit("taskListCheckValueChecked"), a) : n(u);
  }
  function a(u) {
    return u === 93 ? (e.enter("taskListCheckMarker"), e.consume(u), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), s) : n(u);
  }
  function s(u) {
    return q(u) ? t(u) : X(u) ? e.check({
      tokenize: nS
    }, t, n)(u) : n(u);
  }
}
function nS(e, t, n) {
  return ne(e, r, "whitespace");
  function r(i) {
    return i === null ? n(i) : t(i);
  }
}
function rS(e) {
  return ac([
    A_(),
    L_(),
    J_(e),
    Y_(),
    eS()
  ]);
}
const iS = {};
function oS(e) {
  const t = (
    /** @type {Processor<Root>} */
    this
  ), n = e || iS, r = t.data(), i = r.micromarkExtensions || (r.micromarkExtensions = []), o = r.fromMarkdownExtensions || (r.fromMarkdownExtensions = []), a = r.toMarkdownExtensions || (r.toMarkdownExtensions = []);
  i.push(rS(n)), o.push(S_()), a.push(I_(n));
}
const aS = {
  fontSize: 13,
  lineHeight: 1.6,
  wordBreak: "break-word"
}, sS = {
  padding: "1px 4px",
  borderRadius: 4,
  background: "rgba(128,128,128,0.15)",
  fontSize: 12,
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace"
}, lS = {
  margin: "8px 0",
  padding: 10,
  borderRadius: 8,
  background: "rgba(128,128,128,0.12)",
  overflowX: "auto"
}, uS = {
  borderCollapse: "collapse",
  margin: "8px 0",
  fontSize: 12
}, Zs = {
  border: "1px solid var(--border-color, #d2d2d7)",
  padding: "4px 8px"
};
function cS({ content: e }) {
  return /* @__PURE__ */ T("div", { style: aS, children: /* @__PURE__ */ T(
    M1,
    {
      remarkPlugins: [oS],
      components: {
        p: ({ children: t }) => /* @__PURE__ */ T("p", { style: { margin: "0 0 8px" }, children: t }),
        // 无 language- 标记的视为行内 code（轻量渲染的已知限制，块级统一带标记）
        code: ({ className: t, children: n }) => t != null && t.includes("language-") ? /* @__PURE__ */ T("code", { style: { fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }, children: n }) : /* @__PURE__ */ T("code", { style: sS, children: n }),
        pre: ({ children: t }) => /* @__PURE__ */ T("pre", { style: lS, children: t }),
        ul: ({ children: t }) => /* @__PURE__ */ T("ul", { style: { margin: "4px 0 8px", paddingLeft: 20 }, children: t }),
        ol: ({ children: t }) => /* @__PURE__ */ T("ol", { style: { margin: "4px 0 8px", paddingLeft: 20 }, children: t }),
        a: ({ children: t, href: n }) => /* @__PURE__ */ T("a", { href: n, style: { color: "var(--theme-color, #0a84ff)" }, target: "_blank", rel: "noreferrer", children: t }),
        table: ({ children: t }) => /* @__PURE__ */ T("table", { style: uS, children: t }),
        th: ({ children: t }) => /* @__PURE__ */ T("th", { style: Zs, children: t }),
        td: ({ children: t }) => /* @__PURE__ */ T("td", { style: Zs, children: t }),
        blockquote: ({ children: t }) => /* @__PURE__ */ T(
          "blockquote",
          {
            style: {
              margin: "8px 0",
              padding: "2px 10px",
              borderLeft: "3px solid var(--border-color, #d2d2d7)",
              color: "var(--text-secondary, #6e6e73)"
            },
            children: t
          }
        )
      },
      children: e
    }
  ) });
}
function fS(e) {
  return e.parts.filter((t) => t.type === "text").map((t) => t.text).join(`
`);
}
const dS = { display: "flex", gap: 8, marginTop: 12, alignItems: "flex-start" }, pS = {
  width: 26,
  height: 26,
  borderRadius: "50%",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  fontSize: 10
}, bn = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 2,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex",
  alignItems: "center",
  gap: 2,
  fontSize: 11
};
function hS({ message: e, meta: t, streaming: n, actions: r, canUndo: i }) {
  var d;
  const o = e.role === "user", a = fS(e), s = (d = e.metadata) == null ? void 0 : d.displayText, [u, c] = ve(!1), l = Ve(void 0);
  qe(() => () => clearTimeout(l.current), []);
  const f = async () => {
    await navigator.clipboard.writeText(a), c(!0), clearTimeout(l.current), l.current = setTimeout(() => c(!1), 2e3);
  };
  return /* @__PURE__ */ ee("div", { style: { ...dS, flexDirection: o ? "row-reverse" : "row" }, children: [
    /* @__PURE__ */ T(
      "div",
      {
        style: {
          ...pS,
          background: o ? "var(--theme-color, #0a84ff)" : "rgba(128,128,128,0.2)",
          color: o ? "#fff" : "var(--text-secondary, #6e6e73)"
        },
        children: o ? "我" : /* @__PURE__ */ T(gi, { size: 13 })
      }
    ),
    /* @__PURE__ */ ee(
      "div",
      {
        style: {
          padding: "8px 10px",
          borderRadius: 10,
          maxWidth: "85%",
          overflow: "hidden",
          background: o ? "var(--theme-color, #0a84ff)" : "var(--bg-primary, #f5f5f7)",
          color: o ? "#fff" : "var(--text-primary, #1d1d1f)"
        },
        children: [
          o ? /* @__PURE__ */ T("p", { style: { margin: 0, fontSize: 13, whiteSpace: "pre-wrap", wordBreak: "break-word" }, children: s ?? a }) : /* @__PURE__ */ T("div", { style: { minHeight: 18 }, children: a === "" && n ? /* @__PURE__ */ T(gS, {}) : /* @__PURE__ */ ee(Dn, { children: [
            /* @__PURE__ */ T(cS, { content: a }),
            ((t == null ? void 0 : t.stopped) || ((t == null ? void 0 : t.omitted) ?? 0) > 0) && /* @__PURE__ */ T(mS, { meta: t })
          ] }) }),
          !o && a !== "" && /* @__PURE__ */ ee("div", { style: { display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 4 }, children: [
            i && (r == null ? void 0 : r.undoApply) && /* @__PURE__ */ T(
              "button",
              {
                type: "button",
                onClick: () => {
                  var p;
                  return (p = r.undoApply) == null ? void 0 : p.call(r, a);
                },
                title: "撤销本次就地应用",
                style: bn,
                children: /* @__PURE__ */ T("span", { children: "撤销应用" })
              }
            ),
            (r == null ? void 0 : r.insertAtCursor) && /* @__PURE__ */ ee("button", { type: "button", onClick: () => r.insertAtCursor(a), title: "插入到光标位置", style: bn, children: [
              /* @__PURE__ */ T(_f, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "插入" })
            ] }),
            (r == null ? void 0 : r.replaceContent) && /* @__PURE__ */ ee("button", { type: "button", onClick: () => r.replaceContent(a), title: "替换整个文档内容", style: bn, children: [
              /* @__PURE__ */ T(Cf, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "替换全文" })
            ] }),
            (r == null ? void 0 : r.saveAsNewFile) && /* @__PURE__ */ ee("button", { type: "button", onClick: () => r.saveAsNewFile(a), title: "另存为新文件", style: bn, children: [
              /* @__PURE__ */ T(Sf, { size: 12 }),
              /* @__PURE__ */ T("span", { children: "另存" })
            ] }),
            /* @__PURE__ */ T("button", { type: "button", onClick: f, title: "复制内容", style: bn, children: u ? /* @__PURE__ */ T(kf, { size: 12 }) : /* @__PURE__ */ T(xf, { size: 12 }) })
          ] })
        ]
      }
    )
  ] });
}
function mS({ meta: e }) {
  const t = [];
  return e != null && e.stopped && t.push("已停止生成"), ((e == null ? void 0 : e.omitted) ?? 0) > 0 && t.push(`上下文超限，已省略 ${e == null ? void 0 : e.omitted} 条早期消息`), /* @__PURE__ */ T("div", { style: { marginTop: 6, fontSize: 11, color: "var(--text-secondary, #6e6e73)", fontStyle: "italic" }, children: t.join("；") });
}
function gS() {
  const e = {
    width: 5,
    height: 5,
    borderRadius: "50%",
    background: "var(--text-secondary, #6e6e73)",
    display: "inline-block",
    marginRight: 3
  };
  return /* @__PURE__ */ ee("div", { style: { padding: "4px 0" }, children: [
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite" } }),
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite 0.2s" } }),
    /* @__PURE__ */ T("span", { style: { ...e, animation: "ai-blink 1.2s infinite 0.4s" } })
  ] });
}
const nf = [
  { value: "openai-compatible", label: "OpenAI 兼容" },
  { value: "anthropic", label: "Anthropic" },
  { value: "google", label: "Google" }
], yS = () => ({
  name: "",
  provider: "openai-compatible",
  modelId: "",
  baseUrl: "",
  contextWindow: 128e3,
  apiKey: ""
});
function bS({ services: e, models: t, onSave: n, onDelete: r, onSetDefault: i, onClose: o }) {
  const [a, s] = ve(null), [u, c] = ve(""), [l, f] = ve(!1), [d, p] = ve(null), [h, m] = ve(!1);
  qe(() => {
    let w = !1;
    return e.invokeBackend("getSetting", { key: $i }).then(({ value: C }) => {
      w || m(C === "true");
    }).catch(() => {
    }), () => {
      w = !0;
    };
  }, [e]);
  const k = () => {
    const w = !h;
    m(w), e.invokeBackend("setSetting", { key: $i, value: String(w) }).catch(() => m(!w));
  }, g = async () => {
    if (a) {
      if (!a.modelId.trim()) {
        c("请填写模型 ID");
        return;
      }
      f(!0), c("");
      try {
        await n(a), s(null);
      } catch (w) {
        c(w instanceof Error ? w.message : String(w));
      } finally {
        f(!1);
      }
    }
  }, _ = async (w) => {
    if (d !== w) {
      p(w);
      return;
    }
    p(null);
    try {
      await r(w);
    } catch (C) {
      c(C instanceof Error ? C.message : String(C));
    }
  };
  return qe(() => {
    const w = (C) => {
      C.key === "Escape" && (a ? s(null) : o());
    };
    return window.addEventListener("keydown", w), () => window.removeEventListener("keydown", w);
  }, [a, o]), /* @__PURE__ */ T(wS, { children: /* @__PURE__ */ ee("div", { style: xS, children: [
    /* @__PURE__ */ ee("div", { style: _S, children: [
      /* @__PURE__ */ T("strong", { style: { fontSize: 14 }, children: "模型设置" }),
      /* @__PURE__ */ T("button", { type: "button", onClick: o, style: tr, title: "关闭", children: /* @__PURE__ */ T(yi, { size: 14 }) })
    ] }),
    a === null ? /* @__PURE__ */ ee(Dn, { children: [
      t.length === 0 && /* @__PURE__ */ T("p", { style: { fontSize: 12, color: "var(--text-secondary, #6e6e73)", margin: "12px 0" }, children: "还没有模型，点击下方按钮添加。" }),
      t.map((w) => /* @__PURE__ */ ee("div", { style: SS, children: [
        /* @__PURE__ */ ee("div", { style: { flex: 1, minWidth: 0 }, children: [
          /* @__PURE__ */ ee("div", { style: { fontSize: 13, fontWeight: 500, display: "flex", alignItems: "center", gap: 6 }, children: [
            /* @__PURE__ */ T("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: w.name || w.modelId }),
            w.isDefault && /* @__PURE__ */ T(MS, { children: "默认" })
          ] }),
          /* @__PURE__ */ ee("div", { style: { fontSize: 11, color: "var(--text-secondary, #6e6e73)" }, children: [
            kS(w.provider),
            " · ",
            w.modelId
          ] })
        ] }),
        /* @__PURE__ */ T("button", { type: "button", onClick: () => void i(w.id), style: tr, title: "设为默认", children: /* @__PURE__ */ T(Of, { size: 13, fill: w.isDefault ? "currentColor" : "none" }) }),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => s({
              id: w.id,
              name: w.name ?? "",
              provider: w.provider,
              modelId: w.modelId,
              baseUrl: w.baseUrl,
              contextWindow: w.contextWindow,
              apiKey: ""
            }),
            style: tr,
            title: "编辑",
            children: /* @__PURE__ */ T(Ks, { size: 13 })
          }
        ),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => void _(w.id),
            style: { ...tr, color: d === w.id ? "#e5484d" : void 0 },
            title: d === w.id ? "再点一次确认删除" : "删除",
            children: /* @__PURE__ */ T(Ys, { size: 13 })
          }
        )
      ] }, w.id)),
      /* @__PURE__ */ ee("button", { type: "button", onClick: () => s(yS()), style: Do, children: [
        /* @__PURE__ */ T(Ef, { size: 13 }),
        " 添加模型"
      ] }),
      /* @__PURE__ */ ee("div", { style: AS, children: [
        /* @__PURE__ */ T("div", { style: zS, children: "对话行为" }),
        /* @__PURE__ */ ee("label", { style: TS, children: [
          /* @__PURE__ */ T("input", { type: "checkbox", checked: h, onChange: k }),
          /* @__PURE__ */ T("span", { children: "生成完成后应用到文档（替换选中内容）" })
        ] }),
        /* @__PURE__ */ T("p", { style: OS, children: "开启后，编辑器右键 AI 动作的结果会自动替换文档中选中的内容" })
      ] })
    ] }) : /* @__PURE__ */ T(vS, { form: a, setForm: s, onSave: g, busy: l }),
    u !== "" && /* @__PURE__ */ T("p", { style: CS, children: u })
  ] }) });
}
function vS({
  form: e,
  setForm: t,
  onSave: n,
  busy: r
}) {
  const i = (o, a, s) => /* @__PURE__ */ ee("label", { style: { display: "block", marginBottom: 10 }, children: [
    /* @__PURE__ */ T("span", { style: IS, children: o }),
    a,
    s && /* @__PURE__ */ T("span", { style: ES, children: s })
  ] });
  return /* @__PURE__ */ ee("div", { children: [
    i(
      "名称",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.name,
          placeholder: "选填，默认显示模型 ID",
          onChange: (o) => t({ ...e, name: o.target.value })
        }
      )
    ),
    i(
      "提供商",
      /* @__PURE__ */ T("select", { style: qt, value: e.provider, onChange: (o) => t({ ...e, provider: o.target.value }), children: nf.map((o) => /* @__PURE__ */ T("option", { value: o.value, children: o.label }, o.value)) })
    ),
    i(
      "模型 ID",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.modelId,
          placeholder: "如 gpt-4o / claude-sonnet-4-5",
          onChange: (o) => t({ ...e, modelId: o.target.value })
        }
      )
    ),
    i(
      "Base URL",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          value: e.baseUrl,
          placeholder: "留空使用官方默认地址",
          onChange: (o) => t({ ...e, baseUrl: o.target.value })
        }
      )
    ),
    i(
      "上下文窗口",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          type: "number",
          value: e.contextWindow,
          min: 0,
          onChange: (o) => t({ ...e, contextWindow: Number(o.target.value) || 0 })
        }
      ),
      "token 数，0 表示使用默认 128k"
    ),
    i(
      "API Key",
      /* @__PURE__ */ T(
        "input",
        {
          style: qt,
          type: "password",
          value: e.apiKey ?? "",
          placeholder: e.id ? "留空表示不修改" : "必填",
          onChange: (o) => t({ ...e, apiKey: o.target.value })
        }
      ),
      "加密存储在系统安全区，不写入数据库"
    ),
    /* @__PURE__ */ ee("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" }, children: [
      /* @__PURE__ */ T("button", { type: "button", onClick: () => t(null), style: PS, disabled: r, children: "取消" }),
      /* @__PURE__ */ T("button", { type: "button", onClick: n, style: Do, disabled: r, children: "保存" })
    ] })
  ] });
}
function kS(e) {
  var t;
  return ((t = nf.find((n) => n.value === e)) == null ? void 0 : t.label) ?? e;
}
function wS({ children: e }) {
  return /* @__PURE__ */ ee(Dn, { children: [
    /* @__PURE__ */ T("style", { children: `
        @keyframes swallow-ai-ms-fade-in { from { opacity: 0 } to { opacity: 1 } }
        @keyframes swallow-ai-ms-zoom-in { from { opacity: 0; transform: scale(0.95) } to { opacity: 1; transform: scale(1) } }
      ` }),
    /* @__PURE__ */ T(
      "div",
      {
        style: {
          position: "absolute",
          inset: 0,
          zIndex: 30,
          // 对齐宿主 Dialog 遮罩（bg-black/80）
          background: "rgba(0,0,0,0.8)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 12,
          animation: "swallow-ai-ms-fade-in 0.15s ease-out"
        },
        children: e
      }
    )
  ] });
}
const xS = {
  // 对齐宿主 Dialog：白底卡片 + 边框 + zoom/fade 进场
  background: "var(--bg-secondary, #fff)",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 12,
  padding: 14,
  width: "100%",
  maxHeight: "100%",
  overflowY: "auto",
  boxShadow: "0 8px 30px rgba(0,0,0,0.18)",
  animation: "swallow-ai-ms-zoom-in 0.2s ease-out"
}, _S = { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }, SS = { display: "flex", alignItems: "center", gap: 4, padding: "6px 0", borderBottom: "1px solid var(--border-color, #e5e5e5)" }, IS = { display: "block", fontSize: 11, color: "var(--text-secondary, #6e6e73)", marginBottom: 3 }, ES = { display: "block", fontSize: 10, color: "var(--text-secondary, #6e6e73)", marginTop: 2 }, CS = { color: "#e5484d", fontSize: 12, margin: "8px 0 0" }, AS = {
  marginTop: 14,
  paddingTop: 12,
  borderTop: "1px solid var(--border-color, #e5e5e5)"
}, zS = { fontSize: 12, fontWeight: 500, marginBottom: 6 }, TS = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  fontSize: 12,
  cursor: "pointer"
}, OS = {
  fontSize: 11,
  color: "var(--text-secondary, #6e6e73)",
  margin: "6px 0 0"
}, qt = {
  width: "100%",
  padding: "6px 8px",
  fontSize: 12,
  borderRadius: 6,
  border: "1px solid var(--border-color, #e5e5e5)",
  // 对齐宿主 Input（bg-transparent）：白卡片上透明底描边
  background: "transparent",
  color: "var(--text-primary, #1d1d1f)",
  boxSizing: "border-box"
}, tr = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 4,
  borderRadius: 6,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex"
}, Do = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  border: "none",
  borderRadius: 6,
  padding: "6px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff"
}, PS = {
  ...Do,
  // 白卡片上的次按钮用宿主外壳灰，避免白底不可见
  background: "var(--bg-primary, #f5f5f7)",
  color: "var(--text-primary, #1d1d1f)"
};
function MS({ children: e }) {
  return /* @__PURE__ */ T(
    "span",
    {
      style: {
        fontSize: 10,
        padding: "1px 5px",
        borderRadius: 4,
        // 主题色淡底（color-mix 从 --theme-color 派生，不再硬编码蓝色）
        background: "color-mix(in srgb, var(--theme-color, #0a84ff) 12%, transparent)",
        color: "var(--theme-color, #0a84ff)",
        flexShrink: 0
      },
      children: e
    }
  );
}
const RS = [
  { key: "continue_writing", label: "续写", iconName: "Edit3" },
  { key: "polish", label: "润色", iconName: "Star" },
  { key: "correct", label: "纠错", iconName: "Check" },
  { key: "outline", label: "提纲", iconName: "FileText" },
  { key: "summary", label: "摘要", iconName: "Copy" },
  { key: "format", label: "格式整理", iconName: "Code" },
  { key: "complete", label: "补全", iconName: "FilePlus" },
  { key: "rewrite", label: "改写", iconName: "RefreshCw" },
  { key: "explain", label: "解释", iconName: "Eye" }
], rf = "com.swallownote.ai";
async function $S(e) {
  const t = e.path ?? "";
  if (!t || e.isDirectory) return null;
  const n = await Ws.read(t);
  return {
    type: "file-attach",
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    path: t,
    name: t.split("/").pop() ?? t,
    content: n
  };
}
function NS(e, t) {
  return `请基于以下文件内容回答我的问题（${e}）：

${t}

`;
}
async function DS(e, t, n) {
  const r = await kt.getSelection(), i = (r == null ? void 0 : r.text) ?? n.selection ?? "", o = i.length > 0, a = o ? i : await kt.getActiveContent() ?? "";
  return {
    type: "role-action",
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    roleKey: e,
    roleName: t,
    hasSelection: o,
    content: a,
    lineRange: (r == null ? void 0 : r.lineRange) ?? void 0,
    filePath: n.path ?? ""
  };
}
function LS() {
  for (const e of RS)
    qs(rf, {
      id: `ai-role-${e.key}`,
      label: e.label,
      iconName: e.iconName,
      locations: ["editor"],
      onClick: (t) => {
        DS(e.key, e.label, t).then((n) => {
          Js(n);
        });
      }
    });
}
function FS() {
  qs(rf, {
    id: "ai-add-file-to-chat",
    label: "添加到 AI 对话",
    iconName: "FileText",
    locations: ["fileTree"],
    when: (e) => e.isDirectory !== !0,
    onClick: async (e) => {
      try {
        const t = await $S(e);
        t && Js(t);
      } catch (t) {
        console.warn("[ai] 添加到 AI 对话失败：", t);
      }
    }
  });
}
function jS({ services: e, pendingRequest: t }) {
  const n = yv(e), r = bv(e), i = vv(e), [o, a] = ve(""), [s, u] = ve(!1), [c, l] = ve(!1), [f, d] = ve(null), [p, h] = ve(""), [m, k] = ve(null), g = Ve(null), [_, w] = ve(null), C = Ve(void 0), I = ye((O, U) => {
    clearTimeout(C.current), w({ text: O, tone: U }), C.current = setTimeout(() => w(null), 3e3);
  }, []);
  qe(() => () => clearTimeout(C.current), []);
  const y = Ve(!1);
  qe(() => {
    y.current || (y.current = !0, (async () => {
      const O = await e.invokeBackend("importLegacyData");
      if (!(O != null && O.imported)) return;
      const U = O.counts;
      I(
        `已导入历史数据：消息 ${(U == null ? void 0 : U.messages) ?? 0} 条 · 角色 ${(U == null ? void 0 : U.rolePrompts) ?? 0} 个 · 模型 ${(U == null ? void 0 : U.models) ?? 0} 个`
      ), await Promise.all([r.refresh(), n.refresh()]), await e.invokeBackend("finalizeLegacyImport");
    })().catch(() => {
    }));
  }, []);
  const E = Ve(null), R = Ve(null), [F, S] = ve(null), M = Gt(
    () => new hv({
      invokeBackend: e.invokeBackend,
      invokeBackendStream: e.invokeBackendStream,
      getModelId: () => n.activeModelIdRef.current,
      getApiKey: (O) => e.secureStorage.get(`model:${O}`)
    }),
    [e, n.activeModelIdRef]
  ), L = ye(
    (O) => {
      const U = g.current;
      if (!U || O.isError) return;
      const Be = O.message.metadata ?? {}, zt = E.current;
      E.current = null, (async () => {
        const Vn = qu(O.message), ln = { stopped: Be.stopped, omitted: Be.omitted };
        if (zt && zt.selectionOriginal !== "" && await US(e)) {
          const un = await kt.getSelection().catch(() => null);
          un && un.text === zt.selectionOriginal && await kt.replaceSelection(Vn).catch(() => !1) ? (ln.applied = !0, ln.selectionOriginal = zt.selectionOriginal, S({ id: O.message.id, selectionOriginal: zt.selectionOriginal }), I("已应用到文档")) : I("请先选中要修改的内容", "error");
        }
        await i.appendAssistant(U, Vn, ln), r.refresh();
      })().catch(() => {
      });
    },
    [i, r, e, I]
  ), { messages: x, sendMessage: Z, status: B, stop: Y, error: D, setMessages: H, regenerate: le, clearError: b } = dv({
    transport: M,
    onFinish: L
  }), ke = B === "submitted" || B === "streaming";
  qe(() => {
    let O = !1;
    if (r.activeId === null) {
      H([]);
      return;
    }
    return i.loadMessages(r.activeId).then((U) => {
      O || H(U);
    }).catch(() => {
    }), () => {
      O = !0;
    };
  }, [r.activeId, i, H]);
  const Ze = Ve(null);
  qe(() => {
    const O = Ze.current;
    O && (O.scrollTop = O.scrollHeight);
  }, [x]), qe(() => {
    const O = t;
    if (!(!O || typeof O != "object" || O.type !== "role-action") && R.current !== O.id) {
      if (R.current = O.id, !n.activeModelIdRef.current) {
        I("请先在设置中添加模型，再使用角色动作", "error");
        return;
      }
      (async () => {
        Y();
        let U = r.activeId;
        if (!U)
          try {
            U = await r.create();
          } catch {
            I("创建会话失败", "error");
            return;
          }
        g.current = U;
        const Be = BS(O);
        try {
          await i.appendUser(U, O.content, { roleKey: O.roleKey, displayText: Be });
        } catch {
          I("消息落库失败", "error");
          return;
        }
        r.refresh(), E.current = { selectionOriginal: O.hasSelection ? O.content : "" }, Z(
          { text: O.content, metadata: { displayText: Be, roleKey: O.roleKey } },
          { body: { roleKey: O.roleKey } }
        );
      })();
    }
  }, [t, n, r, i, Z, Y, I]), qe(() => {
    const O = t;
    if (!O || typeof O != "object" || O.type !== "file-attach" || R.current === O.id) return;
    R.current = O.id;
    const U = NS(O.path, O.content);
    a((Be) => Be ? `${Be}

${U}` : U);
  }, [t]);
  const v = Gt(
    () => ({
      insertAtCursor: (O) => {
        kt.insertAtCursor(O).then((U) => I(U ? "已插入到光标位置" : "插入失败：编辑器不可用", U ? void 0 : "error")).catch(() => I("插入失败", "error"));
      },
      replaceContent: (O) => {
        kt.replaceContent(O).then(() => I("已替换全文")).catch(() => I("替换失败", "error"));
      },
      saveAsNewFile: (O) => {
        const U = `ai-notes/${VS()}.md`;
        Ws.createNote(U, O).then(() => I(`已另存为 ${U}`)).catch(() => I("另存失败", "error"));
      },
      undoApply: (O) => {
        F && (async () => {
          const U = await kt.getSelection().catch(() => null);
          if (!U) {
            I("请先选中要撤销的内容", "error");
            return;
          }
          if (U.text !== O) {
            I("文档已变动，无法自动撤销", "error");
            return;
          }
          await kt.replaceSelection(F.selectionOriginal).catch(() => !1) ? (S(null), I("已撤销本次应用")) : I("文档已变动，无法自动撤销", "error");
        })();
      }
    }),
    [F, I]
  ), Te = async () => {
    const O = o.trim();
    if (!O || !n.activeModelId || ke) return;
    b(), E.current = null;
    let U = r.activeId;
    U || (U = await r.create()), g.current = U;
    try {
      await i.appendUser(U, O), r.refresh();
    } catch {
      return;
    }
    a(""), Z({ text: O });
  }, nt = () => {
    ke && Y();
  }, ge = r.sessions.find((O) => O.id === r.activeId) ?? null, rt = r.loaded && n.models.length === 0, Ke = async () => {
    f && p.trim() && await r.rename(f, p.trim()).catch(() => {
    }), d(null);
  }, mt = async (O) => {
    if (m !== O) {
      k(O);
      return;
    }
    k(null), nt(), await r.remove(O).catch(() => {
    });
  };
  return /* @__PURE__ */ ee("div", { style: qS, children: [
    /* @__PURE__ */ T("style", { children: "@keyframes ai-blink{0%,100%{opacity:.2}50%{opacity:1}}" }),
    /* @__PURE__ */ ee("div", { style: JS, children: [
      /* @__PURE__ */ ee(
        "button",
        {
          type: "button",
          onClick: () => {
            l((O) => !O), k(null);
          },
          style: WS,
          title: "会话列表",
          children: [
            /* @__PURE__ */ T("span", { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 130 }, children: (ge == null ? void 0 : ge.title) ?? "新对话" }),
            /* @__PURE__ */ T(wf, { size: 12 })
          ]
        }
      ),
      /* @__PURE__ */ T("span", { style: { flex: 1 } }),
      /* @__PURE__ */ ee(
        "select",
        {
          value: n.activeModelId ?? "",
          onChange: (O) => n.setActiveModel(O.target.value),
          style: HS,
          title: "选择模型",
          children: [
            n.models.length === 0 && /* @__PURE__ */ T("option", { value: "", children: "未配置模型" }),
            n.models.map((O) => /* @__PURE__ */ T("option", { value: O.id, children: O.name || O.modelId }, O.id))
          ]
        }
      ),
      /* @__PURE__ */ T("button", { type: "button", onClick: () => u(!0), style: vn, title: "模型设置", children: /* @__PURE__ */ T(Af, { size: 13 }) })
    ] }),
    _ && /* @__PURE__ */ T(
      "div",
      {
        style: {
          ...nI,
          ..._.tone === "error" ? { background: "rgba(229,72,77,0.1)", color: "#e5484d" } : {}
        },
        children: _.text
      }
    ),
    c && /* @__PURE__ */ T(ZS, { onClose: () => l(!1), children: /* @__PURE__ */ ee("div", { style: oI, onClick: (O) => O.stopPropagation(), children: [
      /* @__PURE__ */ ee("div", { style: aI, children: [
        /* @__PURE__ */ T("strong", { style: { fontSize: 13 }, children: "会话" }),
        /* @__PURE__ */ T("button", { type: "button", onClick: () => l(!1), style: vn, title: "关闭", children: /* @__PURE__ */ T(yi, { size: 13 }) })
      ] }),
      /* @__PURE__ */ ee("div", { style: { overflowY: "auto", flex: 1 }, children: [
        r.sessions.length === 0 && /* @__PURE__ */ T("p", { style: { fontSize: 12, color: "var(--text-secondary, #6e6e73)", margin: "8px 0" }, children: "暂无会话" }),
        r.sessions.map((O) => /* @__PURE__ */ T(
          "div",
          {
            style: {
              ...sI,
              background: O.id === r.activeId ? "rgba(10,132,255,0.08)" : "transparent"
            },
            children: f === O.id ? /* @__PURE__ */ T(
              "input",
              {
                autoFocus: !0,
                style: uI,
                value: p,
                onChange: (U) => h(U.target.value),
                onBlur: () => void Ke(),
                onKeyDown: (U) => {
                  U.key === "Enter" && Ke(), U.key === "Escape" && d(null);
                }
              }
            ) : /* @__PURE__ */ ee(Dn, { children: [
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  style: lI,
                  onClick: () => {
                    nt(), r.activate(O.id), l(!1);
                  },
                  children: O.title
                }
              ),
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    d(O.id), h(O.title);
                  },
                  style: vn,
                  title: "重命名",
                  children: /* @__PURE__ */ T(Ks, { size: 12 })
                }
              ),
              /* @__PURE__ */ T(
                "button",
                {
                  type: "button",
                  onClick: () => void mt(O.id),
                  style: { ...vn, color: m === O.id ? "#e5484d" : void 0 },
                  title: m === O.id ? "再点一次确认删除" : "删除",
                  children: /* @__PURE__ */ T(Ys, { size: 12 })
                }
              )
            ] })
          },
          O.id
        ))
      ] }),
      /* @__PURE__ */ ee(
        "button",
        {
          type: "button",
          style: Us,
          onClick: () => {
            nt(), r.create().then(() => l(!1)).catch(() => {
            });
          },
          children: [
            /* @__PURE__ */ T(If, { size: 13 }),
            " 新建对话"
          ]
        }
      )
    ] }) }),
    s && /* @__PURE__ */ T(
      bS,
      {
        services: e,
        models: n.models,
        onSave: n.saveModel,
        onDelete: n.deleteModel,
        onSetDefault: n.setDefaultModel,
        onClose: () => u(!1)
      }
    ),
    /* @__PURE__ */ T("div", { ref: Ze, style: KS, children: rt ? /* @__PURE__ */ T(
      Bs,
      {
        icon: /* @__PURE__ */ T(gi, { size: 26 }),
        text: "先添加一个模型开始对话",
        action: /* @__PURE__ */ T("button", { type: "button", style: Us, onClick: () => u(!0), children: "添加模型" })
      }
    ) : x.length === 0 && !ke ? /* @__PURE__ */ T(Bs, { icon: /* @__PURE__ */ T(gi, { size: 26 }), text: "有什么可以帮你？" }) : x.map((O) => /* @__PURE__ */ T(
      hS,
      {
        message: O,
        meta: O.metadata ?? void 0,
        streaming: ke,
        actions: v,
        canUndo: (F == null ? void 0 : F.id) === O.id
      },
      O.id
    )) }),
    D && /* @__PURE__ */ ee("div", { style: tI, children: [
      /* @__PURE__ */ T("span", { style: { flex: 1, overflow: "hidden", textOverflow: "ellipsis" }, children: D.message }),
      /* @__PURE__ */ T("button", { type: "button", style: rI, onClick: () => void le(), children: "重试" }),
      /* @__PURE__ */ T("button", { type: "button", style: vn, onClick: () => b(), title: "关闭", children: /* @__PURE__ */ T(yi, { size: 12 }) })
    ] }),
    /* @__PURE__ */ ee("div", { style: YS, children: [
      /* @__PURE__ */ T(
        "textarea",
        {
          style: GS,
          placeholder: rt ? "请先添加模型" : "输入消息，Enter 发送，Shift+Enter 换行",
          value: o,
          disabled: rt,
          onChange: (O) => {
            a(O.target.value);
            const U = O.target;
            U.style.height = "auto", U.style.height = Math.min(Math.max(U.scrollHeight, 50), 160) + "px";
          },
          onKeyDown: (O) => {
            O.key === "Enter" && !O.shiftKey && (O.preventDefault(), Te());
          }
        }
      ),
      /* @__PURE__ */ ee("div", { style: XS, children: [
        /* @__PURE__ */ T("span", { style: { fontSize: 11, color: "var(--text-secondary, #6e6e73)" }, children: n.activeModelId ? "" : "未配置模型" }),
        /* @__PURE__ */ T("span", { style: { flex: 1 } }),
        ke && /* @__PURE__ */ T("button", { type: "button", onClick: () => Y(), style: eI, title: "停止生成", children: /* @__PURE__ */ T(Tf, { size: 11 }) }),
        /* @__PURE__ */ T(
          "button",
          {
            type: "button",
            onClick: () => void Te(),
            disabled: rt || !o.trim() || ke,
            style: QS,
            title: "发送",
            children: "发送"
          }
        )
      ] })
    ] })
  ] });
}
function ZS({ children: e, onClose: t }) {
  return /* @__PURE__ */ T("div", { style: iI, onClick: t, children: e });
}
function Bs({ icon: e, text: t, action: n }) {
  return /* @__PURE__ */ ee(
    "div",
    {
      style: {
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        color: "var(--text-secondary, #6e6e73)",
        fontSize: 13
      },
      children: [
        e,
        /* @__PURE__ */ T("span", { children: t }),
        n
      ]
    }
  );
}
function BS(e) {
  const t = e.filePath.split(/[\\/]/).pop() ?? e.filePath, n = e.lineRange ? ` (L${e.lineRange[0]}-${e.lineRange[1]})` : e.hasSelection ? "" : "（全文）";
  return `[${e.roleName}] ${t}${n}`;
}
async function US(e) {
  try {
    const { value: t } = await e.invokeBackend("getSetting", {
      key: $i
    });
    return t === "true";
  } catch {
    return !1;
  }
}
function VS() {
  const e = /* @__PURE__ */ new Date(), t = (n) => String(n).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}-${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`;
}
const qS = {
  position: "relative",
  display: "flex",
  flexDirection: "column",
  height: "100%",
  // 对齐宿主面板容器背景 token（App.tsx 右侧面板同款），亮暗色及自定义主题均跟随
  background: "var(--bg-secondary-gradient, var(--bg-secondary, #fff))",
  color: "var(--text-primary, #1d1d1f)",
  overflow: "hidden"
}, JS = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  padding: "6px 10px",
  borderBottom: "1px solid var(--border-color, #e5e5ea)",
  flexShrink: 0
}, WS = {
  display: "inline-flex",
  alignItems: "center",
  gap: 4,
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: "4px 6px",
  borderRadius: 6,
  fontSize: 12,
  color: "var(--text-primary, #1d1d1f)",
  maxWidth: 170
}, HS = {
  fontSize: 12,
  padding: "3px 4px",
  borderRadius: 6,
  border: "none",
  background: "transparent",
  color: "var(--text-secondary, #6e6e73)",
  maxWidth: 150,
  cursor: "pointer",
  outline: "none"
}, vn = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: 4,
  borderRadius: 6,
  color: "var(--text-secondary, #6e6e73)",
  display: "inline-flex",
  alignItems: "center",
  flexShrink: 0
}, KS = {
  flex: 1,
  overflowY: "auto",
  padding: "4px 12px 12px"
}, YS = {
  flexShrink: 0,
  margin: "0 10px 10px",
  border: "1px solid var(--border-color, #d2d2d7)",
  borderRadius: 10,
  // 面板底色改为白后，输入区用宿主外壳灰（--bg-primary）保持层次对比
  background: "var(--bg-primary, #f5f5f7)"
}, GS = {
  width: "100%",
  border: "none",
  outline: "none",
  resize: "none",
  background: "transparent",
  color: "var(--text-primary, #1d1d1f)",
  fontSize: 13,
  lineHeight: 1.5,
  padding: "8px 10px 2px",
  minHeight: 50,
  maxHeight: 160,
  boxSizing: "border-box",
  fontFamily: "inherit"
}, XS = { display: "flex", alignItems: "center", gap: 6, padding: "2px 8px 8px" }, QS = {
  border: "none",
  borderRadius: 6,
  padding: "5px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff"
}, eI = {
  border: "none",
  borderRadius: 6,
  padding: 5,
  cursor: "pointer",
  background: "#e5484d",
  color: "#fff",
  display: "inline-flex"
}, tI = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  margin: "0 10px 8px",
  padding: "6px 10px",
  borderRadius: 8,
  background: "rgba(229,72,77,0.1)",
  color: "#e5484d",
  fontSize: 12,
  flexShrink: 0
}, nI = {
  margin: "6px 10px 0",
  padding: "5px 10px",
  borderRadius: 8,
  background: "rgba(10,132,255,0.08)",
  color: "var(--theme-color, #0a84ff)",
  fontSize: 12,
  flexShrink: 0
}, rI = {
  border: "none",
  borderRadius: 5,
  padding: "2px 8px",
  fontSize: 11,
  cursor: "pointer",
  background: "rgba(229,72,77,0.15)",
  color: "#e5484d",
  flexShrink: 0
}, iI = {
  position: "absolute",
  inset: 0,
  zIndex: 30,
  background: "rgba(0,0,0,0.2)",
  display: "flex",
  alignItems: "flex-start",
  justifyContent: "flex-start",
  padding: "40px 10px 10px"
}, oI = {
  background: "var(--bg-primary, #fff)",
  borderRadius: 10,
  padding: 10,
  width: "100%",
  maxHeight: "70%",
  display: "flex",
  flexDirection: "column",
  gap: 6,
  boxShadow: "0 8px 30px rgba(0,0,0,0.18)"
}, aI = { display: "flex", alignItems: "center", justifyContent: "space-between" }, sI = {
  display: "flex",
  alignItems: "center",
  gap: 2,
  borderRadius: 6,
  padding: "2px 2px 2px 6px"
}, lI = {
  flex: 1,
  textAlign: "left",
  border: "none",
  background: "transparent",
  cursor: "pointer",
  padding: "6px 4px",
  fontSize: 12,
  color: "var(--text-primary, #1d1d1f)",
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap"
}, uI = {
  flex: 1,
  fontSize: 12,
  padding: "5px 6px",
  borderRadius: 5,
  border: "1px solid var(--theme-color, #0a84ff)",
  outline: "none",
  background: "var(--bg-primary, #fff)",
  color: "var(--text-primary, #1d1d1f)",
  minWidth: 0
}, Us = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 4,
  border: "none",
  borderRadius: 6,
  padding: "6px 12px",
  fontSize: 12,
  cursor: "pointer",
  background: "var(--theme-color, #0a84ff)",
  color: "#fff",
  flexShrink: 0
}, cI = "com.swallownote.ai", fI = "AI 助手", dI = "与 AI 对话并操作笔记：智能问答、内容生成、笔记整理。", pI = "0.1.5", hI = 1, mI = "SwallowNote", gI = "2026-11-12T08:18:59Z", yI = "titleBar", bI = "rightPanel", vI = 40, kI = !0, wI = !0, xI = "0.1.0", _I = "src/index.tsx", SI = [
  "storage",
  "events",
  "backend",
  "editor-write",
  "files",
  "context-menu",
  "secure-storage"
], II = {
  id: cI,
  name: fI,
  description: dI,
  version: pI,
  manifestVersion: hI,
  author: mI,
  publishedAt: gI,
  iconPosition: yI,
  contentPosition: bI,
  order: vI,
  enabled: kI,
  hasBackend: wI,
  minHostVersion: xI,
  entry: _I,
  permissions: SI
};
function EI({ size: e = 16 }) {
  return /* @__PURE__ */ T(zf, { size: e });
}
function CI(e) {
  const t = Gt(
    () => ({
      // SDK 的 invokeBackend 非泛型，这里转发为 hooks 需要的泛型签名
      invokeBackend: (n, r) => e.invokeBackend(n, r),
      invokeBackendStream: e.invokeBackendStream,
      secureStorage: e.secureStorage
    }),
    [e.invokeBackend, e.invokeBackendStream, e.secureStorage]
  );
  return /* @__PURE__ */ T(jS, { services: t, pendingRequest: e.pendingRequest });
}
const MI = ff(II, {
  icon: EI,
  panel: CI,
  // onLoad hook（flat 结构，不是嵌套在 hooks 里）：
  // 即使为空也触发 runPluginLifecycleHook 执行 setHost，
  // 使 SDK 的 openEditorTab 等 API 能转发到宿主实现
  onLoad: () => {
    LS(), FS();
  }
});
export {
  MI as default,
  TI as setHost
};
