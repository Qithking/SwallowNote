// @swallow-manifest {"id":"com.swallownote.secret-disk","name":"密盘","description":"加密的私有笔记空间，所有数据以 markdown 存储于严格加密的 SQLite 数据库（.swl）。","version":"0.1.8","author":"SwallowNote","published_at":"2026-11-12T08:19:34Z","icon_position":"sidebar","content_position":"leftPanel","order":60,"enabled":true,"has_backend":true}
import * as c from "react";
import { forwardRef as tt, createElement as Et, useState as M, useRef as $, useCallback as V, useEffect as J } from "react";
import { jsx as s, Fragment as Ke, jsxs as x } from "react/jsx-runtime";
import * as en from "react-dom";
function qn(e, t) {
  return { ...e, ...t };
}
function Yn(e) {
  const t = (o) => `swallow-plugin:${e}:${o}`, n = /* @__PURE__ */ new Map();
  if (typeof localStorage < "u")
    for (let o = 0; o < localStorage.length; o++) {
      const i = localStorage.key(o);
      if (i && i.startsWith(`swallow-plugin:${e}:`))
        try {
          n.set(i.slice(`swallow-plugin:${e}:`.length), JSON.parse(localStorage.getItem(i)));
        } catch {
        }
    }
  const r = (o) => {
    if (typeof localStorage > "u")
      return;
    const i = t(o);
    n.has(o) ? localStorage.setItem(i, JSON.stringify(n.get(o))) : localStorage.removeItem(i);
  };
  return {
    async get(o) {
      return n.has(o) ? n.get(o) : null;
    },
    async set(o, i) {
      n.set(o, i), r(o);
    },
    async delete(o) {
      n.delete(o), r(o);
    },
    async clear() {
      for (const o of Array.from(n.keys()))
        n.delete(o), r(o);
    },
    async keys() {
      return Array.from(n.keys()).sort();
    },
    async entries() {
      const o = [];
      for (const [i, l] of n)
        try {
          o.push({ key: i, size: JSON.stringify(l).length });
        } catch {
          o.push({ key: i, size: 0 });
        }
      return o.sort((i, l) => l.size - i.size);
    }
  };
}
const lt = /* @__PURE__ */ new Map();
function Zn(e, t) {
  if (e.size > t) {
    const n = e.keys().next().value;
    n !== void 0 && e.delete(n);
  }
}
function Xn(e) {
  var r, o;
  const t = (o = (r = Te()).getPluginStorage) == null ? void 0 : o.call(r, e);
  if (t)
    return t;
  let n = lt.get(e);
  return n || (n = Yn(e), lt.set(e, n), Zn(lt, 50)), n;
}
class Gn {
  constructor() {
    this.target = new EventTarget(), this.wrapperMap = /* @__PURE__ */ new Map();
  }
  on(t, n) {
    const r = (i) => n(i.detail);
    this.target.addEventListener(t, r);
    let o = this.wrapperMap.get(n);
    return o || (o = /* @__PURE__ */ new Map(), this.wrapperMap.set(n, o)), o.set(t, r), () => {
      this.target.removeEventListener(t, r), o.delete(t), o.size === 0 && this.wrapperMap.delete(n);
    };
  }
  off(t, n) {
    const r = this.wrapperMap.get(n), o = r == null ? void 0 : r.get(t);
    o && (this.target.removeEventListener(t, o), r.delete(t), r.size === 0 && this.wrapperMap.delete(n));
  }
  removeAllListenersForPlugin(t) {
  }
  emit(t, n) {
    this.target.dispatchEvent(new CustomEvent(t, { detail: n }));
  }
}
const It = new Gn();
It.emit.bind(It);
function Jn(e, t) {
  const n = Te().openEditorTab;
  n ? n(e, t) : console.warn(`[plugin-sdk] openEditorTab called for plugin "${e}" but no host override is installed. This is expected in standalone preview mode (npm run dev); in host mode the host installs the override via setHost().`);
}
function Qn(e, t) {
  const n = Te().closeEditorTab;
  n ? n(e, t) : console.warn(`[plugin-sdk] closeEditorTab called for plugin "${e}" tab "${t}" but no host override is installed. This is expected in standalone preview mode (npm run dev); in host mode the host installs the override via setHost().`);
}
function Ot(e) {
  const t = Te().closePluginTabs;
  t ? t(e) : console.warn(`[plugin-sdk] closePluginTabs called for plugin "${e}" but no host override is installed. This is expected in standalone preview mode (npm run dev); in host mode the host installs the override via setHost().`);
}
const we = [];
let er = 0;
function Te() {
  const e = we[we.length - 1];
  return e ? e.overrides : tr;
}
const tr = Object.freeze({});
function qi(e, t) {
  const n = er++, r = { ...Te(), ...e };
  return we.push({ overrides: r, token: n, pluginId: t }), () => {
    for (let o = we.length - 1; o >= 0; o--)
      if (we[o].token === n) {
        we.splice(o, 1);
        return;
      }
  };
}
const nr = "com.swallownote.secret-disk", rr = "密盘", or = "加密的私有笔记空间，所有数据以 markdown 存储于严格加密的 SQLite 数据库（.swl）。", ir = "0.1.8", ar = 1, sr = "SwallowNote", cr = "2026-11-12T08:19:34Z", lr = "sidebar", ur = "leftPanel", dr = 60, fr = !0, pr = !0, hr = "src/index.tsx", vr = [
  "storage",
  "events",
  "backend"
], yr = {
  id: nr,
  name: rr,
  description: or,
  version: ir,
  manifestVersion: ar,
  author: sr,
  publishedAt: cr,
  iconPosition: lr,
  contentPosition: ur,
  order: dr,
  enabled: fr,
  hasBackend: pr,
  entry: hr,
  permissions: vr
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const gr = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), tn = (...e) => e.filter((t, n, r) => !!t && t.trim() !== "" && r.indexOf(t) === n).join(" ").trim();
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var mr = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const br = tt(
  ({
    color: e = "currentColor",
    size: t = 24,
    strokeWidth: n = 2,
    absoluteStrokeWidth: r,
    className: o = "",
    children: i,
    iconNode: l,
    ...a
  }, d) => Et(
    "svg",
    {
      ref: d,
      ...mr,
      width: t,
      height: t,
      stroke: e,
      strokeWidth: r ? Number(n) * 24 / Number(t) : n,
      className: tn("lucide", o),
      ...a
    },
    [
      ...l.map(([v, h]) => Et(v, h)),
      ...Array.isArray(i) ? i : [i]
    ]
  )
);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const B = (e, t) => {
  const n = tt(
    ({ className: r, ...o }, i) => Et(br, {
      ref: i,
      iconNode: t,
      className: tn(`lucide-${gr(e)}`, r),
      ...o
    })
  );
  return n.displayName = `${e}`, n;
};
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const wr = B("ChevronRight", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Sr = B("ClipboardCopy", [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2", key: "4jdomd" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v4", key: "3hqy98" }],
  ["path", { d: "M21 14H11", key: "1bme5i" }],
  ["path", { d: "m15 10-4 4 4 4", key: "5dvupr" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Er = B("Database", [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Cr = B("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const nn = B("EyeOff", [
  [
    "path",
    {
      d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
      key: "ct8e1f"
    }
  ],
  ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
  [
    "path",
    {
      d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
      key: "13bj9a"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const rn = B("Eye", [
  [
    "path",
    {
      d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
      key: "1nclc0"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const kr = B("FilePlus", [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M9 15h6", key: "cctwl0" }],
  ["path", { d: "M12 18v-6", key: "17g6i2" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Xe = B("FileText", [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const xr = B("FolderOpen", [
  [
    "path",
    {
      d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
      key: "usdka0"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Rr = B("FolderPlus", [
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "M9 13h6", key: "1uhe8q" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ge = B("Folder", [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const on = B("KeyRound", [
  [
    "path",
    {
      d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
      key: "1s6t7t"
    }
  ],
  ["circle", { cx: "16.5", cy: "7.5", r: ".5", fill: "currentColor", key: "w0ekpg" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Me = B("Lock", [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Pr = B("PenLine", [
  ["path", { d: "M12 20h9", key: "t2du7b" }],
  [
    "path",
    {
      d: "M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",
      key: "1ykcvy"
    }
  ]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Dr = B("RefreshCw", [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ir = B("Settings", [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Or = B("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);
/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Mr = B("Upload", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "17 8 12 3 7 8", key: "t8dd8p" }],
  ["line", { x1: "12", x2: "12", y1: "3", y2: "15", key: "widbto" }]
]);
function Tr({ size: e = 20 }) {
  return /* @__PURE__ */ s(Me, { size: e, strokeWidth: 1.8 });
}
function ie(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function(o) {
    if (e == null || e(o), n === !1 || !o.defaultPrevented)
      return t == null ? void 0 : t(o);
  };
}
function Mt(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
function Lr(...e) {
  return (t) => {
    let n = !1;
    const r = e.map((o) => {
      const i = Mt(o, t);
      return !n && typeof i == "function" && (n = !0), i;
    });
    if (n)
      return () => {
        for (let o = 0; o < r.length; o++) {
          const i = r[o];
          typeof i == "function" ? i() : Mt(e[o], null);
        }
      };
  };
}
function de(...e) {
  return c.useCallback(Lr(...e), e);
}
function Ar(e, t = []) {
  let n = [];
  function r(i, l) {
    const a = c.createContext(l);
    a.displayName = i + "Context";
    const d = n.length;
    n = [...n, l];
    const v = (f) => {
      var C;
      const { scope: y, children: g, ...b } = f, u = ((C = y == null ? void 0 : y[e]) == null ? void 0 : C[d]) || a, m = c.useMemo(() => b, Object.values(b));
      return /* @__PURE__ */ s(u.Provider, { value: m, children: g });
    };
    v.displayName = i + "Provider";
    function h(f, y) {
      var u;
      const g = ((u = y == null ? void 0 : y[e]) == null ? void 0 : u[d]) || a, b = c.useContext(g);
      if (b) return b;
      if (l !== void 0) return l;
      throw new Error(`\`${f}\` must be used within \`${i}\``);
    }
    return [v, h];
  }
  const o = () => {
    const i = n.map((l) => c.createContext(l));
    return function(a) {
      const d = (a == null ? void 0 : a[e]) || i;
      return c.useMemo(
        () => ({ [`__scope${e}`]: { ...a, [e]: d } }),
        [a, d]
      );
    };
  };
  return o.scopeName = e, [r, Nr(o, ...t)];
}
function Nr(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = () => {
    const r = e.map((o) => ({
      useScope: o(),
      scopeName: o.scopeName
    }));
    return function(i) {
      const l = r.reduce((a, { useScope: d, scopeName: v }) => {
        const f = d(i)[`__scope${v}`];
        return { ...a, ...f };
      }, {});
      return c.useMemo(() => ({ [`__scope${t.scopeName}`]: l }), [l]);
    };
  };
  return n.scopeName = t.scopeName, n;
}
var Ee = globalThis != null && globalThis.document ? c.useLayoutEffect : () => {
}, _r = c[" useId ".trim().toString()] || (() => {
}), zr = 0;
function ut(e) {
  const [t, n] = c.useState(_r());
  return Ee(() => {
    n((r) => r ?? String(zr++));
  }, [e]), e || (t ? `radix-${t}` : "");
}
var Tt = c[" useEffectEvent ".trim().toString()], Lt = c[" useInsertionEffect ".trim().toString()];
function Fr(e) {
  if (typeof Tt == "function")
    return Tt(e);
  const t = c.useRef(() => {
    throw new Error("Cannot call an event handler while rendering.");
  });
  return typeof Lt == "function" ? Lt(() => {
    t.current = e;
  }) : Ee(() => {
    t.current = e;
  }), c.useMemo(() => (...n) => {
    var r;
    return (r = t.current) == null ? void 0 : r.call(t, ...n);
  }, []);
}
var Wr = c[" useInsertionEffect ".trim().toString()] || Ee;
function Br({
  prop: e,
  defaultProp: t,
  onChange: n = () => {
  },
  caller: r
}) {
  const [o, i, l] = $r({
    defaultProp: t,
    onChange: n
  }), a = e !== void 0, d = a ? e : o;
  {
    const h = c.useRef(e !== void 0);
    c.useEffect(() => {
      const f = h.current;
      f !== a && console.warn(
        `${r} is changing from ${f ? "controlled" : "uncontrolled"} to ${a ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
      ), h.current = a;
    }, [a, r]);
  }
  const v = c.useCallback(
    (h) => {
      var f;
      if (a) {
        const y = Ur(h) ? h(e) : h;
        y !== e && ((f = l.current) == null || f.call(l, y));
      } else
        i(h);
    },
    [a, e, i, l]
  );
  return [d, v];
}
function $r({
  defaultProp: e,
  onChange: t
}) {
  const [n, r] = c.useState(e), o = c.useRef(n), i = c.useRef(t);
  return Wr(() => {
    i.current = t;
  }, [t]), c.useEffect(() => {
    var l;
    o.current !== n && ((l = i.current) == null || l.call(i, n), o.current = n);
  }, [n, o]), [n, r, i];
}
function Ur(e) {
  return typeof e == "function";
}
// @__NO_SIDE_EFFECTS__
function an(e) {
  const t = c.forwardRef((n, r) => {
    let { children: o, ...i } = n, l = null, a = !1;
    const d = [];
    At(o) && typeof Fe == "function" && (o = Fe(o._payload)), c.Children.forEach(o, (y) => {
      var g;
      if (qr(y)) {
        a = !0;
        const b = y;
        let u = "child" in b.props ? b.props.child : b.props.children;
        At(u) && typeof Fe == "function" && (u = Fe(u._payload)), l = Vr(b, u), d.push((g = l == null ? void 0 : l.props) == null ? void 0 : g.children);
      } else
        d.push(y);
    }), l ? l = c.cloneElement(l, void 0, d) : (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !a && c.Children.count(o) === 1 && c.isValidElement(o) && (l = o)
    );
    const v = l ? Kr(l) : void 0, h = de(r, v);
    if (!l) {
      if (o || o === 0)
        throw new Error(
          a ? Gr(e) : Xr(e)
        );
      return o;
    }
    const f = jr(i, l.props ?? {});
    return l.type !== c.Fragment && (f.ref = r ? h : v), c.cloneElement(l, f);
  });
  return t.displayName = `${e}.Slot`, t;
}
var Hr = Symbol.for("radix.slottable"), Vr = (e, t) => {
  if ("child" in e.props) {
    const n = e.props.child;
    return c.isValidElement(n) ? c.cloneElement(n, void 0, e.props.children(n.props.children)) : null;
  }
  return c.isValidElement(t) ? t : null;
};
function jr(e, t) {
  const n = { ...t };
  for (const r in t) {
    const o = e[r], i = t[r];
    /^on[A-Z]/.test(r) ? o && i ? n[r] = (...a) => {
      const d = i(...a);
      return o(...a), d;
    } : o && (n[r] = o) : r === "style" ? n[r] = { ...o, ...i } : r === "className" && (n[r] = [o, i].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
function Kr(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
function qr(e) {
  return c.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Hr;
}
var Yr = Symbol.for("react.lazy");
function At(e) {
  return e != null && typeof e == "object" && "$$typeof" in e && e.$$typeof === Yr && "_payload" in e && Zr(e._payload);
}
function Zr(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
var Xr = (e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, Gr = (e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, Fe = c[" use ".trim().toString()], Jr = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], ee = Jr.reduce((e, t) => {
  const n = /* @__PURE__ */ an(`Primitive.${t}`), r = c.forwardRef((o, i) => {
    const { asChild: l, ...a } = o, d = l ? n : t;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ s(d, { ...a, ref: i });
  });
  return r.displayName = `Primitive.${t}`, { ...e, [t]: r };
}, {});
function Qr(e, t) {
  e && en.flushSync(() => e.dispatchEvent(t));
}
function Je(e) {
  const t = c.useRef(e);
  return c.useEffect(() => {
    t.current = e;
  }), c.useMemo(() => (...n) => {
    var r;
    return (r = t.current) == null ? void 0 : r.call(t, ...n);
  }, []);
}
var eo = "DismissableLayer", Ct = "dismissableLayer.update", to = "dismissableLayer.pointerDownOutside", no = "dismissableLayer.focusOutside", Nt, Rt = c.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set(),
  // Outside elements that belong to a layer's own dismiss affordance (eg, a
  // dialog overlay). Pressing them should dismiss the layer regardless of
  // whether or not they stop propagation.
  //
  // See https://github.com/radix-ui/primitives/issues/3346
  dismissableSurfaces: /* @__PURE__ */ new Set()
}), sn = c.forwardRef(
  (e, t) => {
    const {
      disableOutsidePointerEvents: n = !1,
      deferPointerDownOutside: r = !1,
      onEscapeKeyDown: o,
      onPointerDownOutside: i,
      onFocusOutside: l,
      onInteractOutside: a,
      onDismiss: d,
      ...v
    } = e, h = c.useContext(Rt), [f, y] = c.useState(null), g = (f == null ? void 0 : f.ownerDocument) ?? (globalThis == null ? void 0 : globalThis.document), [, b] = c.useState({}), u = de(t, y), m = Array.from(h.layers), [C] = [...h.layersWithOutsidePointerEventsDisabled].slice(-1), E = m.indexOf(C), k = f ? m.indexOf(f) : -1, S = h.layersWithOutsidePointerEventsDisabled.size > 0, P = k >= E, F = c.useRef(!1), W = ao(
      (I) => {
        const A = I.target;
        if (!(A instanceof Node))
          return;
        const j = [...h.branches].some(
          (O) => O.contains(A)
        );
        !P || j || (i == null || i(I), a == null || a(I), I.defaultPrevented || d == null || d());
      },
      {
        ownerDocument: g,
        deferPointerDownOutside: r,
        isDeferredPointerDownOutsideRef: F,
        dismissableSurfaces: h.dismissableSurfaces
      }
    ), H = so((I) => {
      if (r && F.current)
        return;
      const A = I.target;
      [...h.branches].some((O) => O.contains(A)) || (l == null || l(I), a == null || a(I), I.defaultPrevented || d == null || d());
    }, g), N = f ? k === m.length - 1 : !1, K = Fr((I) => {
      I.key === "Escape" && (o == null || o(I), !I.defaultPrevented && d && (I.preventDefault(), d()));
    });
    return c.useEffect(() => {
      if (N)
        return g.addEventListener("keydown", K, { capture: !0 }), () => g.removeEventListener("keydown", K, { capture: !0 });
    }, [g, N]), c.useEffect(() => {
      if (f)
        return n && (h.layersWithOutsidePointerEventsDisabled.size === 0 && (Nt = g.body.style.pointerEvents, g.body.style.pointerEvents = "none"), h.layersWithOutsidePointerEventsDisabled.add(f)), h.layers.add(f), _t(), () => {
          n && (h.layersWithOutsidePointerEventsDisabled.delete(f), h.layersWithOutsidePointerEventsDisabled.size === 0 && (g.body.style.pointerEvents = Nt));
        };
    }, [f, g, n, h]), c.useEffect(() => () => {
      f && (h.layers.delete(f), h.layersWithOutsidePointerEventsDisabled.delete(f), _t());
    }, [f, h]), c.useEffect(() => {
      const I = () => b({});
      return document.addEventListener(Ct, I), () => document.removeEventListener(Ct, I);
    }, []), /* @__PURE__ */ s(
      ee.div,
      {
        ...v,
        ref: u,
        style: {
          pointerEvents: S ? P ? "auto" : "none" : void 0,
          ...e.style
        },
        onFocusCapture: ie(e.onFocusCapture, H.onFocusCapture),
        onBlurCapture: ie(e.onBlurCapture, H.onBlurCapture),
        onPointerDownCapture: ie(
          e.onPointerDownCapture,
          W.onPointerDownCapture
        )
      }
    );
  }
);
sn.displayName = eo;
var ro = "DismissableLayerBranch", oo = c.forwardRef((e, t) => {
  const n = c.useContext(Rt), r = c.useRef(null), o = de(t, r);
  return c.useEffect(() => {
    const i = r.current;
    if (i)
      return n.branches.add(i), () => {
        n.branches.delete(i);
      };
  }, [n.branches]), /* @__PURE__ */ s(ee.div, { ...e, ref: o });
});
oo.displayName = ro;
function io() {
  const e = c.useContext(Rt), [t, n] = c.useState(null);
  return c.useEffect(() => {
    if (t)
      return e.dismissableSurfaces.add(t), () => {
        e.dismissableSurfaces.delete(t);
      };
  }, [t, e.dismissableSurfaces]), n;
}
function ao(e, t) {
  const {
    ownerDocument: n = globalThis == null ? void 0 : globalThis.document,
    deferPointerDownOutside: r = !1,
    isDeferredPointerDownOutsideRef: o,
    dismissableSurfaces: i
  } = t, l = Je(e), a = c.useRef(!1), d = c.useRef(!1), v = c.useRef(/* @__PURE__ */ new Map()), h = c.useRef(() => {
  });
  return c.useEffect(() => {
    function f() {
      d.current = !1, o.current = !1, v.current.clear();
    }
    function y() {
      return Array.from(v.current.values()).some(Boolean);
    }
    function g(E) {
      if (!d.current)
        return;
      const k = E.target;
      k instanceof Node && [...i].some((P) => P.contains(k)) || v.current.set(E.type, !0), E.type === "click" && window.setTimeout(() => {
        d.current && h.current();
      }, 0);
    }
    function b(E) {
      d.current && v.current.set(E.type, !1);
    }
    const u = (E) => {
      if (E.target && !a.current) {
        let k = function() {
          n.removeEventListener("click", h.current);
          const P = y();
          f(), P || cn(
            to,
            l,
            S,
            { discrete: !0 }
          );
        };
        const S = { originalEvent: E };
        d.current = !0, o.current = r && E.button === 0, v.current.clear(), !r || E.button !== 0 ? k() : (n.removeEventListener("click", h.current), h.current = k, n.addEventListener("click", h.current, { once: !0 }));
      } else
        n.removeEventListener("click", h.current), f();
      a.current = !1;
    }, m = [
      "pointerup",
      "mousedown",
      "mouseup",
      "touchstart",
      "touchend",
      "click"
    ];
    for (const E of m)
      n.addEventListener(E, g, !0), n.addEventListener(E, b);
    const C = window.setTimeout(() => {
      n.addEventListener("pointerdown", u);
    }, 0);
    return () => {
      window.clearTimeout(C), n.removeEventListener("pointerdown", u), n.removeEventListener("click", h.current);
      for (const E of m)
        n.removeEventListener(E, g, !0), n.removeEventListener(E, b);
    };
  }, [
    n,
    l,
    r,
    o,
    i
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => a.current = !0
  };
}
function so(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Je(e), r = c.useRef(!1);
  return c.useEffect(() => {
    const o = (i) => {
      i.target && !r.current && cn(no, n, { originalEvent: i }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", o), () => t.removeEventListener("focusin", o);
  }, [t, n]), {
    onFocusCapture: () => r.current = !0,
    onBlurCapture: () => r.current = !1
  };
}
function _t() {
  const e = new CustomEvent(Ct);
  document.dispatchEvent(e);
}
function cn(e, t, n, { discrete: r }) {
  const o = n.originalEvent.target, i = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
  t && o.addEventListener(e, t, { once: !0 }), r ? Qr(o, i) : o.dispatchEvent(i);
}
var dt = "focusScope.autoFocusOnMount", ft = "focusScope.autoFocusOnUnmount", zt = { bubbles: !1, cancelable: !0 }, co = "FocusScope", ln = c.forwardRef((e, t) => {
  const {
    loop: n = !1,
    trapped: r = !1,
    onMountAutoFocus: o,
    onUnmountAutoFocus: i,
    ...l
  } = e, [a, d] = c.useState(null), v = Je(o), h = Je(i), f = c.useRef(null), y = de(t, d), g = c.useRef({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  c.useEffect(() => {
    if (r) {
      let u = function(k) {
        if (g.paused || !a) return;
        const S = k.target;
        a.contains(S) ? f.current = S : oe(f.current, { select: !0 });
      }, m = function(k) {
        if (g.paused || !a) return;
        const S = k.relatedTarget;
        S !== null && (a.contains(S) || oe(f.current, { select: !0 }));
      }, C = function(k) {
        if (document.activeElement === document.body)
          for (const P of k)
            P.removedNodes.length > 0 && oe(a);
      };
      document.addEventListener("focusin", u), document.addEventListener("focusout", m);
      const E = new MutationObserver(C);
      return a && E.observe(a, { childList: !0, subtree: !0 }), () => {
        document.removeEventListener("focusin", u), document.removeEventListener("focusout", m), E.disconnect();
      };
    }
  }, [r, a, g.paused]), c.useEffect(() => {
    if (a) {
      Wt.add(g);
      const u = document.activeElement;
      if (!a.contains(u)) {
        const C = new CustomEvent(dt, zt);
        a.addEventListener(dt, v), a.dispatchEvent(C), C.defaultPrevented || (lo(vo(un(a)), { select: !0 }), document.activeElement === u && oe(a));
      }
      return () => {
        a.removeEventListener(dt, v), setTimeout(() => {
          const C = new CustomEvent(ft, zt);
          a.addEventListener(ft, h), a.dispatchEvent(C), C.defaultPrevented || oe(u ?? document.body, { select: !0 }), a.removeEventListener(ft, h), Wt.remove(g);
        }, 0);
      };
    }
  }, [a, v, h, g]);
  const b = c.useCallback(
    (u) => {
      if (!n && !r || g.paused) return;
      const m = u.key === "Tab" && !u.altKey && !u.ctrlKey && !u.metaKey, C = document.activeElement;
      if (m && C) {
        const E = u.currentTarget, [k, S] = uo(E);
        k && S ? !u.shiftKey && C === S ? (u.preventDefault(), n && oe(k, { select: !0 })) : u.shiftKey && C === k && (u.preventDefault(), n && oe(S, { select: !0 })) : C === E && u.preventDefault();
      }
    },
    [n, r, g.paused]
  );
  return /* @__PURE__ */ s(ee.div, { tabIndex: -1, ...l, ref: y, onKeyDown: b });
});
ln.displayName = co;
function lo(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const r of e)
    if (oe(r, { select: t }), document.activeElement !== n) return;
}
function uo(e) {
  const t = un(e), n = Ft(t, e), r = Ft(t.reverse(), e);
  return [n, r];
}
function un(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (r) => {
      const o = r.tagName === "INPUT" && r.type === "hidden";
      return r.disabled || r.hidden || o ? NodeFilter.FILTER_SKIP : r.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; n.nextNode(); ) t.push(n.currentNode);
  return t;
}
function Ft(e, t) {
  for (const n of e)
    if (!fo(n, { upTo: t })) return n;
}
function fo(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function po(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function oe(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== n && po(e) && t && e.select();
  }
}
var Wt = ho();
function ho() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && (n == null || n.pause()), e = Bt(e, t), e.unshift(t);
    },
    remove(t) {
      var n;
      e = Bt(e, t), (n = e[0]) == null || n.resume();
    }
  };
}
function Bt(e, t) {
  const n = [...e], r = n.indexOf(t);
  return r !== -1 && n.splice(r, 1), n;
}
function vo(e) {
  return e.filter((t) => t.tagName !== "A");
}
var yo = "Portal", dn = c.forwardRef((e, t) => {
  var a;
  const { container: n, ...r } = e, [o, i] = c.useState(!1);
  Ee(() => i(!0), []);
  const l = n || o && ((a = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : a.body);
  return l ? en.createPortal(/* @__PURE__ */ s(ee.div, { ...r, ref: t }), l) : null;
});
dn.displayName = yo;
function go(e, t) {
  return c.useReducer((n, r) => t[n][r] ?? n, e);
}
var nt = (e) => {
  const { present: t, children: n } = e, r = mo(t), o = typeof n == "function" ? n({ present: r.isPresent }) : c.Children.only(n), i = bo(r.ref, wo(o));
  return typeof n == "function" || r.isPresent ? c.cloneElement(o, { ref: i }) : null;
};
nt.displayName = "Presence";
function mo(e) {
  const [t, n] = c.useState(), r = c.useRef(null), o = c.useRef(e), i = c.useRef("none"), l = e ? "mounted" : "unmounted", [a, d] = go(l, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return c.useEffect(() => {
    const v = We(r.current);
    i.current = a === "mounted" ? v : "none";
  }, [a]), Ee(() => {
    const v = r.current, h = o.current;
    if (h !== e) {
      const y = i.current, g = We(v);
      e ? d("MOUNT") : g === "none" || (v == null ? void 0 : v.display) === "none" ? d("UNMOUNT") : d(h && y !== g ? "ANIMATION_OUT" : "UNMOUNT"), o.current = e;
    }
  }, [e, d]), Ee(() => {
    if (t) {
      let v;
      const h = t.ownerDocument.defaultView ?? window, f = (g) => {
        const u = We(r.current).includes(CSS.escape(g.animationName));
        if (g.target === t && u && (d("ANIMATION_END"), !o.current)) {
          const m = t.style.animationFillMode;
          t.style.animationFillMode = "forwards", v = h.setTimeout(() => {
            t.style.animationFillMode === "forwards" && (t.style.animationFillMode = m);
          });
        }
      }, y = (g) => {
        g.target === t && (i.current = We(r.current));
      };
      return t.addEventListener("animationstart", y), t.addEventListener("animationcancel", f), t.addEventListener("animationend", f), () => {
        h.clearTimeout(v), t.removeEventListener("animationstart", y), t.removeEventListener("animationcancel", f), t.removeEventListener("animationend", f);
      };
    } else
      d("ANIMATION_END");
  }, [t, d]), {
    isPresent: ["mounted", "unmountSuspended"].includes(a),
    ref: c.useCallback((v) => {
      r.current = v ? getComputedStyle(v) : null, n(v);
    }, [])
  };
}
function $t(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
function bo(...e) {
  const t = c.useRef(e);
  return t.current = e, c.useCallback((n) => {
    const r = t.current;
    let o = !1;
    const i = r.map((l) => {
      const a = $t(l, n);
      return !o && typeof a == "function" && (o = !0), a;
    });
    if (o)
      return () => {
        for (let l = 0; l < i.length; l++) {
          const a = i[l];
          typeof a == "function" ? a() : $t(r[l], null);
        }
      };
  }, []);
}
function We(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function wo(e) {
  var r, o;
  let t = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = (o = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : o.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
var Be = 0, G = null;
function So() {
  c.useEffect(() => {
    G || (G = { start: Ut(), end: Ut() });
    const { start: e, end: t } = G;
    return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), Be++, () => {
      Be === 1 && (G == null || G.start.remove(), G == null || G.end.remove(), G = null), Be = Math.max(0, Be - 1);
    };
  }, []);
}
function Ut() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
var Q = function() {
  return Q = Object.assign || function(t) {
    for (var n, r = 1, o = arguments.length; r < o; r++) {
      n = arguments[r];
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
    }
    return t;
  }, Q.apply(this, arguments);
};
function fn(e, t) {
  var n = {};
  for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++)
      t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
  return n;
}
function Eo(e, t, n) {
  if (n || arguments.length === 2) for (var r = 0, o = t.length, i; r < o; r++)
    (i || !(r in t)) && (i || (i = Array.prototype.slice.call(t, 0, r)), i[r] = t[r]);
  return e.concat(i || Array.prototype.slice.call(t));
}
var qe = "right-scroll-bar-position", Ye = "width-before-scroll-bar", Co = "with-scroll-bars-hidden", ko = "--removed-body-scroll-bar-size";
function pt(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function xo(e, t) {
  var n = M(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(r) {
          var o = n.value;
          o !== r && (n.value = r, n.callback(r, o));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
var Ro = typeof window < "u" ? c.useLayoutEffect : c.useEffect, Ht = /* @__PURE__ */ new WeakMap();
function Po(e, t) {
  var n = xo(null, function(r) {
    return e.forEach(function(o) {
      return pt(o, r);
    });
  });
  return Ro(function() {
    var r = Ht.get(n);
    if (r) {
      var o = new Set(r), i = new Set(e), l = n.current;
      o.forEach(function(a) {
        i.has(a) || pt(a, null);
      }), i.forEach(function(a) {
        o.has(a) || pt(a, l);
      });
    }
    Ht.set(n, e);
  }, [e]), n;
}
function Do(e) {
  return e;
}
function Io(e, t) {
  t === void 0 && (t = Do);
  var n = [], r = !1, o = {
    read: function() {
      if (r)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(i) {
      var l = t(i, r);
      return n.push(l), function() {
        n = n.filter(function(a) {
          return a !== l;
        });
      };
    },
    assignSyncMedium: function(i) {
      for (r = !0; n.length; ) {
        var l = n;
        n = [], l.forEach(i);
      }
      n = {
        push: function(a) {
          return i(a);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(i) {
      r = !0;
      var l = [];
      if (n.length) {
        var a = n;
        n = [], a.forEach(i), l = n;
      }
      var d = function() {
        var h = l;
        l = [], h.forEach(i);
      }, v = function() {
        return Promise.resolve().then(d);
      };
      v(), n = {
        push: function(h) {
          l.push(h), v();
        },
        filter: function(h) {
          return l = l.filter(h), n;
        }
      };
    }
  };
  return o;
}
function Oo(e) {
  e === void 0 && (e = {});
  var t = Io(null);
  return t.options = Q({ async: !0, ssr: !1 }, e), t;
}
var pn = function(e) {
  var t = e.sideCar, n = fn(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var r = t.read();
  if (!r)
    throw new Error("Sidecar medium not found");
  return c.createElement(r, Q({}, n));
};
pn.isSideCarExport = !0;
function Mo(e, t) {
  return e.useMedium(t), pn;
}
var hn = Oo(), ht = function() {
}, rt = c.forwardRef(function(e, t) {
  var n = c.useRef(null), r = c.useState({
    onScrollCapture: ht,
    onWheelCapture: ht,
    onTouchMoveCapture: ht
  }), o = r[0], i = r[1], l = e.forwardProps, a = e.children, d = e.className, v = e.removeScrollBar, h = e.enabled, f = e.shards, y = e.sideCar, g = e.noRelative, b = e.noIsolation, u = e.inert, m = e.allowPinchZoom, C = e.as, E = C === void 0 ? "div" : C, k = e.gapMode, S = fn(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), P = y, F = Po([n, t]), W = Q(Q({}, S), o);
  return c.createElement(
    c.Fragment,
    null,
    h && c.createElement(P, { sideCar: hn, removeScrollBar: v, shards: f, noRelative: g, noIsolation: b, inert: u, setCallbacks: i, allowPinchZoom: !!m, lockRef: n, gapMode: k }),
    l ? c.cloneElement(c.Children.only(a), Q(Q({}, W), { ref: F })) : c.createElement(E, Q({}, W, { className: d, ref: F }), a)
  );
});
rt.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
rt.classNames = {
  fullWidth: Ye,
  zeroRight: qe
};
var To = function() {
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function Lo() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = To();
  return t && e.setAttribute("nonce", t), e;
}
function Ao(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function No(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var _o = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = Lo()) && (Ao(t, n), No(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, zo = function() {
  var e = _o();
  return function(t, n) {
    c.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, vn = function() {
  var e = zo(), t = function(n) {
    var r = n.styles, o = n.dynamic;
    return e(r, o), null;
  };
  return t;
}, Fo = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, vt = function(e) {
  return parseInt(e || "", 10) || 0;
}, Wo = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], o = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [vt(n), vt(r), vt(o)];
}, Bo = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return Fo;
  var t = Wo(e), n = document.documentElement.clientWidth, r = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, r - n + t[2] - t[0])
  };
}, $o = vn(), Se = "data-scroll-locked", Uo = function(e, t, n, r) {
  var o = e.left, i = e.top, l = e.right, a = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(Co, ` {
   overflow: hidden `).concat(r, `;
   padding-right: `).concat(a, "px ").concat(r, `;
  }
  body[`).concat(Se, `] {
    overflow: hidden `).concat(r, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(r, ";"),
    n === "margin" && `
    padding-left: `.concat(o, `px;
    padding-top: `).concat(i, `px;
    padding-right: `).concat(l, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(a, "px ").concat(r, `;
    `),
    n === "padding" && "padding-right: ".concat(a, "px ").concat(r, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(qe, ` {
    right: `).concat(a, "px ").concat(r, `;
  }
  
  .`).concat(Ye, ` {
    margin-right: `).concat(a, "px ").concat(r, `;
  }
  
  .`).concat(qe, " .").concat(qe, ` {
    right: 0 `).concat(r, `;
  }
  
  .`).concat(Ye, " .").concat(Ye, ` {
    margin-right: 0 `).concat(r, `;
  }
  
  body[`).concat(Se, `] {
    `).concat(ko, ": ").concat(a, `px;
  }
`);
}, Vt = function() {
  var e = parseInt(document.body.getAttribute(Se) || "0", 10);
  return isFinite(e) ? e : 0;
}, Ho = function() {
  c.useEffect(function() {
    return document.body.setAttribute(Se, (Vt() + 1).toString()), function() {
      var e = Vt() - 1;
      e <= 0 ? document.body.removeAttribute(Se) : document.body.setAttribute(Se, e.toString());
    };
  }, []);
}, Vo = function(e) {
  var t = e.noRelative, n = e.noImportant, r = e.gapMode, o = r === void 0 ? "margin" : r;
  Ho();
  var i = c.useMemo(function() {
    return Bo(o);
  }, [o]);
  return c.createElement($o, { styles: Uo(i, !t, o, n ? "" : "!important") });
}, kt = !1;
if (typeof window < "u")
  try {
    var $e = Object.defineProperty({}, "passive", {
      get: function() {
        return kt = !0, !0;
      }
    });
    window.addEventListener("test", $e, $e), window.removeEventListener("test", $e, $e);
  } catch {
    kt = !1;
  }
var ge = kt ? { passive: !1 } : !1, jo = function(e) {
  return e.tagName === "TEXTAREA";
}, yn = function(e, t) {
  if (!(e instanceof Element))
    return !1;
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !jo(e) && n[t] === "visible")
  );
}, Ko = function(e) {
  return yn(e, "overflowY");
}, qo = function(e) {
  return yn(e, "overflowX");
}, jt = function(e, t) {
  var n = t.ownerDocument, r = t;
  do {
    typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host);
    var o = gn(e, r);
    if (o) {
      var i = mn(e, r), l = i[1], a = i[2];
      if (l > a)
        return !0;
    }
    r = r.parentNode;
  } while (r && r !== n.body);
  return !1;
}, Yo = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, r = e.clientHeight;
  return [
    t,
    n,
    r
  ];
}, Zo = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, r = e.clientWidth;
  return [
    t,
    n,
    r
  ];
}, gn = function(e, t) {
  return e === "v" ? Ko(t) : qo(t);
}, mn = function(e, t) {
  return e === "v" ? Yo(t) : Zo(t);
}, Xo = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Go = function(e, t, n, r, o) {
  var i = Xo(e, window.getComputedStyle(t).direction), l = i * r, a = n.target, d = t.contains(a), v = !1, h = l > 0, f = 0, y = 0;
  do {
    if (!a)
      break;
    var g = mn(e, a), b = g[0], u = g[1], m = g[2], C = u - m - i * b;
    (b || C) && gn(e, a) && (f += C, y += b);
    var E = a.parentNode;
    a = E && E.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? E.host : E;
  } while (
    // portaled content
    !d && a !== document.body || // self content
    d && (t.contains(a) || t === a)
  );
  return (h && Math.abs(f) < 1 || !h && Math.abs(y) < 1) && (v = !0), v;
}, Ue = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, Kt = function(e) {
  return [e.deltaX, e.deltaY];
}, qt = function(e) {
  return e && "current" in e ? e.current : e;
}, Jo = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Qo = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, ei = 0, me = [];
function ti(e) {
  var t = c.useRef([]), n = c.useRef([0, 0]), r = c.useRef(), o = c.useState(ei++)[0], i = c.useState(vn)[0], l = c.useRef(e);
  c.useEffect(function() {
    l.current = e;
  }, [e]), c.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(o));
      var u = Eo([e.lockRef.current], (e.shards || []).map(qt), !0).filter(Boolean);
      return u.forEach(function(m) {
        return m.classList.add("allow-interactivity-".concat(o));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(o)), u.forEach(function(m) {
          return m.classList.remove("allow-interactivity-".concat(o));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var a = c.useCallback(function(u, m) {
    if ("touches" in u && u.touches.length === 2 || u.type === "wheel" && u.ctrlKey)
      return !l.current.allowPinchZoom;
    var C = Ue(u), E = n.current, k = "deltaX" in u ? u.deltaX : E[0] - C[0], S = "deltaY" in u ? u.deltaY : E[1] - C[1], P, F = u.target, W = Math.abs(k) > Math.abs(S) ? "h" : "v";
    if ("touches" in u && W === "h" && F.type === "range")
      return !1;
    var H = window.getSelection(), N = H && H.anchorNode, K = N ? N === F || N.contains(F) : !1;
    if (K)
      return !1;
    var I = jt(W, F);
    if (!I)
      return !0;
    if (I ? P = W : (P = W === "v" ? "h" : "v", I = jt(W, F)), !I)
      return !1;
    if (!r.current && "changedTouches" in u && (k || S) && (r.current = P), !P)
      return !0;
    var A = r.current || P;
    return Go(A, m, u, A === "h" ? k : S);
  }, []), d = c.useCallback(function(u) {
    var m = u;
    if (!(!me.length || me[me.length - 1] !== i)) {
      var C = "deltaY" in m ? Kt(m) : Ue(m), E = t.current.filter(function(P) {
        return P.name === m.type && (P.target === m.target || m.target === P.shadowParent) && Jo(P.delta, C);
      })[0];
      if (E && E.should) {
        m.cancelable && m.preventDefault();
        return;
      }
      if (!E) {
        var k = (l.current.shards || []).map(qt).filter(Boolean).filter(function(P) {
          return P.contains(m.target);
        }), S = k.length > 0 ? a(m, k[0]) : !l.current.noIsolation;
        S && m.cancelable && m.preventDefault();
      }
    }
  }, []), v = c.useCallback(function(u, m, C, E) {
    var k = { name: u, delta: m, target: C, should: E, shadowParent: ni(C) };
    t.current.push(k), setTimeout(function() {
      t.current = t.current.filter(function(S) {
        return S !== k;
      });
    }, 1);
  }, []), h = c.useCallback(function(u) {
    n.current = Ue(u), r.current = void 0;
  }, []), f = c.useCallback(function(u) {
    v(u.type, Kt(u), u.target, a(u, e.lockRef.current));
  }, []), y = c.useCallback(function(u) {
    v(u.type, Ue(u), u.target, a(u, e.lockRef.current));
  }, []);
  c.useEffect(function() {
    return me.push(i), e.setCallbacks({
      onScrollCapture: f,
      onWheelCapture: f,
      onTouchMoveCapture: y
    }), document.addEventListener("wheel", d, ge), document.addEventListener("touchmove", d, ge), document.addEventListener("touchstart", h, ge), function() {
      me = me.filter(function(u) {
        return u !== i;
      }), document.removeEventListener("wheel", d, ge), document.removeEventListener("touchmove", d, ge), document.removeEventListener("touchstart", h, ge);
    };
  }, []);
  var g = e.removeScrollBar, b = e.inert;
  return c.createElement(
    c.Fragment,
    null,
    b ? c.createElement(i, { styles: Qo(o) }) : null,
    g ? c.createElement(Vo, { noRelative: e.noRelative, gapMode: e.gapMode }) : null
  );
}
function ni(e) {
  for (var t = null; e !== null; )
    e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
  return t;
}
const ri = Mo(hn, ti);
var bn = c.forwardRef(function(e, t) {
  return c.createElement(rt, Q({}, e, { ref: t, sideCar: ri }));
});
bn.classNames = rt.classNames;
var oi = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, be = /* @__PURE__ */ new WeakMap(), He = /* @__PURE__ */ new WeakMap(), Ve = {}, yt = 0, wn = function(e) {
  return e && (e.host || wn(e.parentNode));
}, ii = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var r = wn(n);
    return r && e.contains(r) ? r : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, ai = function(e, t, n, r) {
  var o = ii(t, Array.isArray(e) ? e : [e]);
  Ve[n] || (Ve[n] = /* @__PURE__ */ new WeakMap());
  var i = Ve[n], l = [], a = /* @__PURE__ */ new Set(), d = new Set(o), v = function(f) {
    !f || a.has(f) || (a.add(f), v(f.parentNode));
  };
  o.forEach(v);
  var h = function(f) {
    !f || d.has(f) || Array.prototype.forEach.call(f.children, function(y) {
      if (a.has(y))
        h(y);
      else
        try {
          var g = y.getAttribute(r), b = g !== null && g !== "false", u = (be.get(y) || 0) + 1, m = (i.get(y) || 0) + 1;
          be.set(y, u), i.set(y, m), l.push(y), u === 1 && b && He.set(y, !0), m === 1 && y.setAttribute(n, "true"), b || y.setAttribute(r, "true");
        } catch (C) {
          console.error("aria-hidden: cannot operate on ", y, C);
        }
    });
  };
  return h(t), a.clear(), yt++, function() {
    l.forEach(function(f) {
      var y = be.get(f) - 1, g = i.get(f) - 1;
      be.set(f, y), i.set(f, g), y || (He.has(f) || f.removeAttribute(r), He.delete(f)), g || f.removeAttribute(n);
    }), yt--, yt || (be = /* @__PURE__ */ new WeakMap(), be = /* @__PURE__ */ new WeakMap(), He = /* @__PURE__ */ new WeakMap(), Ve = {});
  };
}, si = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var r = Array.from(Array.isArray(e) ? e : [e]), o = oi(e);
  return o ? (r.push.apply(r, Array.from(o.querySelectorAll("[aria-live], script"))), ai(r, o, n, "aria-hidden")) : function() {
    return null;
  };
}, ot = "Dialog", [Sn] = Ar(ot), [ci, Y] = Sn(ot), En = (e) => {
  const {
    __scopeDialog: t,
    children: n,
    open: r,
    defaultOpen: o,
    onOpenChange: i,
    modal: l = !0
  } = e, a = c.useRef(null), d = c.useRef(null), [v, h] = Br({
    prop: r,
    defaultProp: o ?? !1,
    onChange: i,
    caller: ot
  });
  return /* @__PURE__ */ s(
    ci,
    {
      scope: t,
      triggerRef: a,
      contentRef: d,
      contentId: ut(),
      titleId: ut(),
      descriptionId: ut(),
      open: v,
      onOpenChange: h,
      onOpenToggle: c.useCallback(() => h((f) => !f), [h]),
      modal: l,
      children: n
    }
  );
};
En.displayName = ot;
var Cn = "DialogTrigger", li = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = Y(Cn, n), i = de(t, o.triggerRef);
    return /* @__PURE__ */ s(
      ee.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": o.open,
        "aria-controls": o.open ? o.contentId : void 0,
        "data-state": Dt(o.open),
        ...r,
        ref: i,
        onClick: ie(e.onClick, o.onOpenToggle)
      }
    );
  }
);
li.displayName = Cn;
var Pt = "DialogPortal", [ui, kn] = Sn(Pt, {
  forceMount: void 0
}), xn = (e) => {
  const { __scopeDialog: t, forceMount: n, children: r, container: o } = e, i = Y(Pt, t);
  return /* @__PURE__ */ s(ui, { scope: t, forceMount: n, children: c.Children.map(r, (l) => /* @__PURE__ */ s(nt, { present: n || i.open, children: /* @__PURE__ */ s(dn, { asChild: !0, container: o, children: l }) })) });
};
xn.displayName = Pt;
var Qe = "DialogOverlay", Rn = c.forwardRef(
  (e, t) => {
    const n = kn(Qe, e.__scopeDialog), { forceMount: r = n.forceMount, ...o } = e, i = Y(Qe, e.__scopeDialog);
    return i.modal ? /* @__PURE__ */ s(nt, { present: r || i.open, children: /* @__PURE__ */ s(fi, { ...o, ref: t }) }) : null;
  }
);
Rn.displayName = Qe;
var di = /* @__PURE__ */ an("DialogOverlay.RemoveScroll"), fi = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = Y(Qe, n), i = io(), l = de(t, i);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ s(bn, { as: di, allowPinchZoom: !0, shards: [o.contentRef], children: /* @__PURE__ */ s(
        ee.div,
        {
          "data-state": Dt(o.open),
          ...r,
          ref: l,
          style: { pointerEvents: "auto", ...r.style }
        }
      ) })
    );
  }
), Ce = "DialogContent", Pn = c.forwardRef(
  (e, t) => {
    const n = kn(Ce, e.__scopeDialog), { forceMount: r = n.forceMount, ...o } = e, i = Y(Ce, e.__scopeDialog);
    return /* @__PURE__ */ s(nt, { present: r || i.open, children: i.modal ? /* @__PURE__ */ s(pi, { ...o, ref: t }) : /* @__PURE__ */ s(hi, { ...o, ref: t }) });
  }
);
Pn.displayName = Ce;
var pi = c.forwardRef(
  (e, t) => {
    const n = Y(Ce, e.__scopeDialog), r = c.useRef(null), o = de(t, n.contentRef, r);
    return c.useEffect(() => {
      const i = r.current;
      if (i) return si(i);
    }, []), /* @__PURE__ */ s(
      Dn,
      {
        ...e,
        ref: o,
        trapFocus: n.open,
        disableOutsidePointerEvents: n.open,
        onCloseAutoFocus: ie(e.onCloseAutoFocus, (i) => {
          var l;
          i.preventDefault(), (l = n.triggerRef.current) == null || l.focus();
        }),
        onPointerDownOutside: ie(e.onPointerDownOutside, (i) => {
          const l = i.detail.originalEvent, a = l.button === 0 && l.ctrlKey === !0;
          (l.button === 2 || a) && i.preventDefault();
        }),
        onFocusOutside: ie(
          e.onFocusOutside,
          (i) => i.preventDefault()
        )
      }
    );
  }
), hi = c.forwardRef(
  (e, t) => {
    const n = Y(Ce, e.__scopeDialog), r = c.useRef(!1), o = c.useRef(!1);
    return /* @__PURE__ */ s(
      Dn,
      {
        ...e,
        ref: t,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (i) => {
          var l, a;
          (l = e.onCloseAutoFocus) == null || l.call(e, i), i.defaultPrevented || (r.current || (a = n.triggerRef.current) == null || a.focus(), i.preventDefault()), r.current = !1, o.current = !1;
        },
        onInteractOutside: (i) => {
          var d, v;
          (d = e.onInteractOutside) == null || d.call(e, i), i.defaultPrevented || (r.current = !0, i.detail.originalEvent.type === "pointerdown" && (o.current = !0));
          const l = i.target;
          ((v = n.triggerRef.current) == null ? void 0 : v.contains(l)) && i.preventDefault(), i.detail.originalEvent.type === "focusin" && o.current && i.preventDefault();
        }
      }
    );
  }
), Dn = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, trapFocus: r, onOpenAutoFocus: o, onCloseAutoFocus: i, ...l } = e, a = Y(Ce, n);
    return So(), /* @__PURE__ */ s(Ke, { children: /* @__PURE__ */ s(
      ln,
      {
        asChild: !0,
        loop: !0,
        trapped: r,
        onMountAutoFocus: o,
        onUnmountAutoFocus: i,
        children: /* @__PURE__ */ s(
          sn,
          {
            role: "dialog",
            id: a.contentId,
            "aria-describedby": a.descriptionId,
            "aria-labelledby": a.titleId,
            "data-state": Dt(a.open),
            ...l,
            ref: t,
            deferPointerDownOutside: !0,
            onDismiss: () => a.onOpenChange(!1)
          }
        )
      }
    ) });
  }
), In = "DialogTitle", On = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = Y(In, n);
    return /* @__PURE__ */ s(ee.h2, { id: o.titleId, ...r, ref: t });
  }
);
On.displayName = In;
var Mn = "DialogDescription", vi = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = Y(Mn, n);
    return /* @__PURE__ */ s(ee.p, { id: o.descriptionId, ...r, ref: t });
  }
);
vi.displayName = Mn;
var Tn = "DialogClose", Ln = c.forwardRef(
  (e, t) => {
    const { __scopeDialog: n, ...r } = e, o = Y(Tn, n);
    return /* @__PURE__ */ s(
      ee.button,
      {
        type: "button",
        ...r,
        ref: t,
        onClick: ie(e.onClick, () => o.onOpenChange(!1))
      }
    );
  }
);
Ln.displayName = Tn;
function Dt(e) {
  return e ? "open" : "closed";
}
async function An(e, t = {}, n) {
  return window.__TAURI_INTERNALS__.invoke(e, t, n);
}
async function yi(e = {}) {
  return typeof e == "object" && Object.freeze(e), await An("plugin:dialog|open", { options: e });
}
async function gi(e = {}) {
  return typeof e == "object" && Object.freeze(e), await An("plugin:dialog|save", { options: e });
}
const Yt = 8, ae = 256, mi = /[^a-zA-Z0-9\s]/;
function Nn(e) {
  const t = e.length;
  if (t < Yt)
    return { valid: !1, error: `密码长度不能少于 ${Yt} 个字符` };
  if (t > ae)
    return { valid: !1, error: `密码长度不能超过 ${ae} 个字符` };
  const n = /[a-zA-Z]/.test(e), r = /[0-9]/.test(e);
  if (!n || !r)
    return {
      valid: !1,
      error: "密码必须同时包含字母和数字",
      strength: "weak"
    };
  const o = mi.test(e);
  let i;
  return t >= 16 || t >= 12 && n && r && o ? i = "strong" : t >= 12 && n && r ? i = "medium" : i = "weak", { valid: !0, strength: i };
}
function _n(e) {
  switch (e) {
    case "weak":
      return "弱";
    case "medium":
      return "中";
    case "strong":
      return "强";
  }
}
function et(e) {
  switch (e) {
    case "weak":
      return "#ef4444";
    case "medium":
      return "#f59e0b";
    case "strong":
      return "#22c55e";
  }
}
const bi = 500, Zt = "tree-expanded-ids", zn = [1, 5, 15, 30, 0], gt = 15, wi = 15e3, Si = {
  copyPath: !1,
  openLocation: !1,
  openHistory: !1,
  showFilePath: !1,
  externalChangeWarning: !1,
  conflictIndicator: !1
};
function Ei(e) {
  const { invokeBackend: t, getSetting: n, setSetting: r, pluginId: o, events: i } = e, l = $(t);
  l.current = t;
  const a = $(n);
  a.current = n;
  const [d, v] = M("locked"), h = $(d);
  h.current = d;
  const [f, y] = M(!0), [g, b] = M([]), u = $(/* @__PURE__ */ new Map()), m = $(/* @__PURE__ */ new Map()), [C, E] = M(0), k = $(!1), S = $(null), P = $(null), [F, W] = M(!1), [H, N] = M(!1), [K, I] = M(!1), [A, j] = M(null), [O, z] = M(""), [se, fe] = M(!1), [te, q] = M(gt), ne = $(gt), pe = $(Date.now()), ke = V(async () => {
    try {
      if (!await l.current("is_initialized")) {
        v("uninitialized"), y(!1);
        return;
      }
      const T = await l.current("is_unlocked");
      if (v(T ? "unlocked" : "locked"), y(!1), T) {
        const _ = await l.current("list_children", { parentId: null });
        for (const U of _)
          m.current.set(U.id, null);
        u.current.set(null, _), b(_);
      }
    } catch (w) {
      console.error("[secret-disk] 检查状态失败:", w), y(!1);
    }
  }, []);
  J(() => {
    a.current("requirePasswordEveryTime").then((w) => {
      k.current = w === !0, W(w === !0);
    }), a.current("autoLockMinutes").then((w) => {
      const T = typeof w == "number" && zn.includes(w) ? w : gt;
      ne.current = T, q(T);
    });
  }, []), J(() => {
    ke();
  }, [ke]);
  const xe = $(null), [Le, Z] = M(null);
  J(() => {
    const w = (_) => {
      const U = `plugin://${o}/`;
      if (_.path.startsWith(U)) {
        const ce = _.path.slice(U.length);
        xe.current = ce, Z(ce);
      } else
        xe.current = null, Z(null);
    };
    return i.on("note:open", w);
  }, [i, o]);
  const X = V(async () => {
    if (P.current && (clearTimeout(P.current), P.current = null), S.current) {
      const w = S.current;
      S.current = null, await w();
    }
  }, []);
  J(() => () => {
    var w;
    P.current && (clearTimeout(P.current), (w = S.current) == null || w.call(S)), k.current && l.current("lock").catch(() => {
    }).finally(() => {
      Ot(o);
    });
  }, []);
  const he = V(async () => {
    v("unlocked");
    try {
      const w = await t("list_children", { parentId: null });
      for (const T of w)
        m.current.set(T.id, null);
      u.current.set(null, w), b(w);
    } catch (w) {
      console.error("[secret-disk] 加载根级失败:", w);
    }
  }, [t]), it = V(
    async (w) => {
      try {
        const T = await t("list_children", { parentId: w });
        for (const _ of T)
          m.current.set(_.id, w);
        return u.current.set(w, T), w === null && b(T), E((_) => _ + 1), T;
      } catch (T) {
        return console.error("[secret-disk] 刷新子项失败:", T), [];
      }
    },
    [t]
  ), Re = V(
    async (w) => {
      await X();
      try {
        const T = await t("get_note", { id: w.id }), _ = (ce) => {
          P.current && clearTimeout(P.current), S.current = async () => {
            try {
              await t("update_note", { id: w.id, content: ce });
            } catch (ye) {
              console.error("[secret-disk] 保存失败:", ye);
            }
          }, P.current = setTimeout(() => {
            var ye;
            (ye = S.current) == null || ye.call(S), P.current = null;
          }, bi);
        }, U = {
          id: w.id,
          name: w.title,
          icon: /* @__PURE__ */ s(Me, { size: 14 }),
          content: T.content,
          onChange: _,
          toolbarConfig: Si
        };
        Jn(o, U);
      } catch (T) {
        console.error("[secret-disk] 加载笔记失败:", T);
      }
    },
    [t, o, X]
  ), re = V(async () => {
    await X();
    try {
      await t("lock"), u.current.clear(), b([]), v("locked"), Ot(o);
    } catch (w) {
      console.error("[secret-disk] 锁定失败:", w);
    }
  }, [t, X, o]), ve = $(re);
  ve.current = re, J(() => {
    const w = () => {
      pe.current = Date.now();
    }, T = ["pointerdown", "keydown", "wheel"];
    for (const U of T)
      window.addEventListener(U, w, { passive: !0 });
    const _ = setInterval(() => {
      if (h.current !== "unlocked") return;
      const U = ne.current;
      U <= 0 || Date.now() - pe.current >= U * 6e4 && ve.current();
    }, wi);
    return () => {
      for (const U of T)
        window.removeEventListener(U, w);
      clearInterval(_);
    };
  }, []);
  const at = V(
    async (w) => {
      W(w), k.current = w, await r("requirePasswordEveryTime", w);
    },
    [r]
  ), Ae = V(
    async (w) => {
      q(w), ne.current = w, pe.current = Date.now(), await r("autoLockMinutes", w);
    },
    [r]
  ), st = V(async () => {
    const w = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replace(/-/g, ""), T = await gi({
      defaultPath: `secret-backup-${w}.swl`,
      filters: [{ name: "密盘数据库", extensions: ["swl"] }]
    });
    if (T)
      try {
        await t("backup", { targetPath: T }), alert("备份成功");
      } catch (_) {
        alert(`备份失败：${_ instanceof Error ? _.message : String(_)}`);
      }
  }, [t]), Ne = V(async () => {
    const w = await yi({
      multiple: !1,
      filters: [{ name: "密盘数据库", extensions: ["swl"] }]
    });
    typeof w == "string" && (j(w), z(""), I(!0));
  }, []), _e = V(async () => {
    if (!(!A || !O))
      try {
        await t("import_db", {
          sourcePath: A,
          password: O
        }), alert("导入成功");
        const w = await t("list_children", { parentId: null });
        u.current.set(null, w), b(w);
      } catch (w) {
        alert(`导入失败，已恢复原数据库：${w instanceof Error ? w.message : String(w)}`);
      } finally {
        I(!1), j(null), z("");
      }
  }, [t, A, O]), ct = V(() => {
    N(!1);
  }, []);
  return f ? /* @__PURE__ */ s("div", { style: { padding: 16, color: "var(--text-secondary, #666)", fontSize: 13 }, children: "加载中…" }) : d === "uninitialized" ? /* @__PURE__ */ s(
    Xt,
    {
      mode: "init",
      invokeBackend: t,
      onSuccess: he
    }
  ) : d === "locked" ? /* @__PURE__ */ s(
    Xt,
    {
      mode: "unlock",
      invokeBackend: t,
      onSuccess: he
    }
  ) : /* @__PURE__ */ s(
    Ci,
    {
      rootItems: g,
      treeCache: u.current,
      treeVersion: C,
      pluginId: o,
      invokeBackend: t,
      refreshChildren: it,
      onSelectNote: Re,
      onLock: re,
      showSettings: se,
      onSettingsOpenChange: fe,
      requirePassword: F,
      onToggleRequirePassword: at,
      autoLockMinutes: te,
      onAutoLockChange: Ae,
      showChangePassword: H,
      onShowChangePassword: N,
      onBackup: st,
      onImportSelectFile: Ne,
      importing: K,
      importSourcePath: A,
      importPassword: O,
      onImportPasswordChange: z,
      onConfirmImport: _e,
      onCancelImport: () => {
        I(!1), j(null), z("");
      },
      onChangePasswordSuccess: ct,
      activeNoteId: Le,
      parentMap: m.current
    }
  );
}
function Xt({ mode: e, invokeBackend: t, onSuccess: n }) {
  const [r, o] = M(""), [i, l] = M(""), [a, d] = M(!1), [v, h] = M(""), [f, y] = M(!1), g = e === "init", b = g ? Nn(r) : null, u = f ? !1 : e === "unlock" ? r.length > 0 : (b == null ? void 0 : b.valid) === !0 && r === i, m = async () => {
    if (u) {
      y(!0), h("");
      try {
        e === "init" ? await t("init", { password: r }) : await t("unlock", { password: r }), n();
      } catch (k) {
        h(k instanceof Error ? k.message : String(k));
      } finally {
        y(!1);
      }
    }
  }, C = (k) => {
    k.key === "Enter" && u && m();
  }, E = a ? "text" : "password";
  return /* @__PURE__ */ x("div", { style: xi, onKeyDown: C, children: [
    /* @__PURE__ */ x("div", { style: Ri, children: [
      /* @__PURE__ */ s(Me, { size: 20 }),
      /* @__PURE__ */ s("span", { style: { fontWeight: 600, fontSize: 14 }, children: e === "init" ? "设置密盘密码" : "解锁密盘" })
    ] }),
    /* @__PURE__ */ x("div", { style: Ie, children: [
      /* @__PURE__ */ s("label", { style: Oe, children: "密码" }),
      /* @__PURE__ */ x("div", { style: { position: "relative" }, children: [
        /* @__PURE__ */ s(
          "input",
          {
            type: E,
            style: { ...Gt, paddingRight: 36 },
            value: r,
            onChange: (k) => o(k.target.value),
            placeholder: e === "init" ? "设置密码（至少 8 位，含字母和数字）" : "输入密码",
            maxLength: ae,
            autoFocus: !0
          }
        ),
        /* @__PURE__ */ s(
          "button",
          {
            type: "button",
            style: Bn,
            onClick: () => d(!a),
            "aria-label": a ? "隐藏密码" : "显示密码",
            children: a ? /* @__PURE__ */ s(nn, { size: 16 }) : /* @__PURE__ */ s(rn, { size: 16 })
          }
        )
      ] }),
      g && r.length > 0 && b && /* @__PURE__ */ x("div", { style: $n, children: [
        /* @__PURE__ */ s(
          "div",
          {
            style: {
              ...Un,
              width: b.strength === "weak" ? "33%" : b.strength === "medium" ? "66%" : "100%",
              backgroundColor: et(b.strength)
            }
          }
        ),
        /* @__PURE__ */ s("span", { style: { fontSize: 11, color: et(b.strength) }, children: _n(b.strength) }),
        b.error && /* @__PURE__ */ s("span", { style: { fontSize: 11, color: "#ef4444", marginLeft: 8 }, children: b.error })
      ] })
    ] }),
    e === "init" && /* @__PURE__ */ x("div", { style: Ie, children: [
      /* @__PURE__ */ s("label", { style: Oe, children: "确认密码" }),
      /* @__PURE__ */ s(
        "input",
        {
          type: E,
          style: Gt,
          value: i,
          onChange: (k) => l(k.target.value),
          placeholder: "再次输入密码",
          maxLength: ae
        }
      ),
      i.length > 0 && r !== i && /* @__PURE__ */ s("span", { style: { fontSize: 11, color: "#ef4444", marginTop: 4, display: "block" }, children: "两次输入的密码不一致" })
    ] }),
    v && /* @__PURE__ */ s("div", { style: Hn, children: v }),
    /* @__PURE__ */ s(
      "button",
      {
        style: { ...Pi, opacity: u ? 1 : 0.5, cursor: u ? "pointer" : "not-allowed" },
        onClick: m,
        disabled: !u,
        children: f ? "处理中…" : e === "init" ? "创建密盘" : "解锁"
      }
    )
  ] });
}
function Ci({
  rootItems: e,
  treeCache: t,
  treeVersion: n,
  pluginId: r,
  invokeBackend: o,
  refreshChildren: i,
  onSelectNote: l,
  onLock: a,
  showSettings: d,
  onSettingsOpenChange: v,
  requirePassword: h,
  onToggleRequirePassword: f,
  autoLockMinutes: y,
  onAutoLockChange: g,
  showChangePassword: b,
  onShowChangePassword: u,
  onBackup: m,
  onImportSelectFile: C,
  importing: E,
  importSourcePath: k,
  importPassword: S,
  onImportPasswordChange: P,
  onConfirmImport: F,
  onCancelImport: W,
  onChangePasswordSuccess: H,
  activeNoteId: N,
  parentMap: K
}) {
  const [I, A] = M(/* @__PURE__ */ new Set()), [j, O] = M(null), [z, se] = M(null), [fe, te] = M(""), [q, ne] = M(null), [pe, ke] = M(!1), xe = $(Xn(r)), Le = $(i);
  Le.current = i, J(() => {
    xe.current.get(Zt).then(async (p) => {
      if (p && p.length > 0) {
        A(new Set(p));
        for (const R of p)
          t.has(R) || await Le.current(R);
      }
    });
  }, []), J(() => {
    xe.current.set(Zt, Array.from(I));
  }, [I]), J(() => {
    if (N) {
      O(N);
      const p = [];
      let R = N;
      for (; R; ) {
        const D = K.get(R);
        if (D != null)
          p.push(D), R = D;
        else
          break;
      }
      if (p.length > 0) {
        A((D) => {
          const L = new Set(D);
          for (const le of p)
            L.add(le);
          return L;
        });
        for (const D of p)
          t.has(D) || i(D);
      }
      requestAnimationFrame(() => {
        const D = document.querySelector(`[data-note-id="${N}"]`);
        D && D.scrollIntoView({ behavior: "smooth", block: "nearest" });
      });
    } else
      O(null);
  }, [N, K, i, t]);
  const [Z, X] = M(null), he = $(null), [it, Re] = M(null), re = $(null), ve = $(null);
  J(() => {
    var p;
    (z || q) && ((p = ve.current) == null || p.focus());
  }, [z, q]), J(() => {
    if (!Z) return;
    const p = (L) => {
      he.current && !he.current.contains(L.target) && X(null);
    }, R = (L) => {
      L.key === "Escape" && X(null);
    }, D = () => X(null);
    return document.addEventListener("mousedown", p, !0), document.addEventListener("keydown", R), document.addEventListener("scroll", D, !0), () => {
      document.removeEventListener("mousedown", p, !0), document.removeEventListener("keydown", R), document.removeEventListener("scroll", D, !0);
    };
  }, [Z]);
  const at = async (p) => {
    const R = new Set(I);
    R.has(p.id) ? R.delete(p.id) : (R.add(p.id), t.has(p.id) || await i(p.id)), A(R);
  }, Ae = async () => {
    if (!z || !fe.trim()) {
      se(null), te("");
      return;
    }
    try {
      await o("create_item", {
        parentId: z.parentId,
        title: fe.trim(),
        type: z.type
      }), await i(z.parentId), z.parentId && A((p) => /* @__PURE__ */ new Set([...p, z.parentId]));
    } catch (p) {
      console.error("[secret-disk] 创建失败:", p);
    }
    se(null), te("");
  }, st = async () => {
    if (!q || !q.value.trim()) {
      ne(null);
      return;
    }
    try {
      await o("rename_item", { id: q.id, title: q.value.trim() }), await i(q.parentId);
    } catch (p) {
      console.error("[secret-disk] 重命名失败:", p);
    }
    ne(null);
  }, Ne = V(async (p) => {
    const R = await o("list_children", { parentId: p }), D = [];
    for (const L of R)
      L.type === "file" ? D.push(L.id) : D.push(...await Ne(L.id));
    return D;
  }, [o]), _e = async (p) => {
    if (confirm(`确定删除「${p.title}」？${p.type === "folder" ? "文件夹内的所有内容将被递归删除。" : ""}`))
      try {
        const R = p.type === "file" ? [p.id] : await Ne(p.id);
        await o("delete_item", { id: p.id }), await i(p.parentId);
        for (const D of R)
          Qn(r, D);
      } catch (R) {
        console.error("[secret-disk] 删除失败:", R);
      }
  }, ct = (p) => {
    var R;
    (R = navigator.clipboard) == null || R.writeText(p.title).catch(() => {
    });
  }, w = async () => {
    if (!pe) {
      ke(!0);
      try {
        t.clear(), await i(null);
        const p = Array.from(I);
        await Promise.all(p.map((R) => i(R)));
      } catch (p) {
        console.error("[secret-disk] 刷新失败:", p);
      } finally {
        ke(!1);
      }
    }
  }, T = (p, R) => {
    re.current = R.id, p.dataTransfer.effectAllowed = "move";
  }, _ = (p, R) => {
    R.type === "folder" && re.current !== R.id && (p.preventDefault(), p.dataTransfer.dropEffect = "move", Re(R.id));
  }, U = async (p, R) => {
    p.preventDefault();
    const D = re.current;
    if (Re(null), re.current = null, !(!D || D === R.id || R.type !== "folder"))
      try {
        await o("move_item", { id: D, newParentId: R.id }), t.clear(), await i(null);
        const L = Array.from(I);
        await Promise.all(L.map((le) => i(le)));
      } catch (L) {
        console.error("[secret-disk] 移动失败:", L);
      }
  }, ce = (p, R, D) => {
    p.preventDefault(), p.stopPropagation(), X({ x: p.clientX, y: p.clientY, item: R, parentId: D });
  }, ye = V((p) => {
    const R = (D) => {
      for (const L of D) {
        if (L.id === p) return L;
        if (L.type === "folder") {
          const le = t.get(L.id) ?? [], Pe = R(le);
          if (Pe) return Pe;
        }
      }
    };
    return R(e);
  }, [e, t]), ze = (p, R) => {
    let D = p;
    if (D) {
      const L = ye(D);
      (L == null ? void 0 : L.type) === "folder" ? (A((le) => {
        const Pe = new Set(le);
        return Pe.add(D), Pe;
      }), t.has(D) || i(D)) : D = (L == null ? void 0 : L.parentId) ?? null;
    }
    se({ parentId: D, type: R }), te("");
  };
  return /* @__PURE__ */ x("div", { style: Di, children: [
    /* @__PURE__ */ x("div", { style: Ii, children: [
      /* @__PURE__ */ s("span", { style: { fontSize: 13, fontWeight: 500 }, children: "密盘" }),
      /* @__PURE__ */ x("div", { style: { display: "flex", gap: 2 }, children: [
        /* @__PURE__ */ s(
          "button",
          {
            style: De,
            onClick: () => ze(j, "file"),
            title: "新建笔记",
            children: /* @__PURE__ */ s(kr, { size: 14 })
          }
        ),
        /* @__PURE__ */ s(
          "button",
          {
            style: De,
            onClick: () => ze(j, "folder"),
            title: "新建文件夹",
            children: /* @__PURE__ */ s(Rr, { size: 14 })
          }
        ),
        /* @__PURE__ */ s("button", { style: De, onClick: w, disabled: pe, title: "刷新", children: /* @__PURE__ */ s(Dr, { size: 14 }) }),
        /* @__PURE__ */ s("button", { style: De, onClick: a, title: "锁定密盘", children: /* @__PURE__ */ s(Me, { size: 14 }) }),
        /* @__PURE__ */ s("button", { style: De, onClick: () => v(!0), title: "设置", children: /* @__PURE__ */ s(Ir, { size: 14 }) })
      ] })
    ] }),
    /* @__PURE__ */ x(
      "div",
      {
        style: { flex: 1, overflow: "auto", padding: "4px 0" },
        onContextMenu: (p) => ce(p, null, null),
        children: [
          (z == null ? void 0 : z.parentId) === null && /* @__PURE__ */ s(
            Wn,
            {
              ref: ve,
              type: z.type,
              value: fe,
              onChange: te,
              onSubmit: Ae,
              onCancel: () => {
                se(null), te("");
              },
              depth: 0
            }
          ),
          e.length === 0 && !z && /* @__PURE__ */ s("div", { style: { padding: "24px 16px", textAlign: "center", color: "var(--text-secondary, #666)", fontSize: 12 }, children: "空白密盘，点击上方按钮新建笔记或文件夹" }),
          e.map((p) => /* @__PURE__ */ s(
            Fn,
            {
              item: p,
              depth: 0,
              expanded: I,
              treeCache: t,
              treeVersion: n,
              invokeBackend: o,
              refreshChildren: i,
              onSelectNote: l,
              onToggle: at,
              selectedId: j,
              setSelectedId: O,
              renaming: q,
              setRenaming: ne,
              onRename: st,
              onDelete: _e,
              onContextMenu: ce,
              onCreate: se,
              creating: z,
              newName: fe,
              setNewName: te,
              handleCreate: Ae,
              inputRef: ve,
              dragOverId: it,
              onDragStart: T,
              onDragOver: _,
              onDrop: U,
              onDragEnd: () => Re(null)
            },
            p.id
          ))
        ]
      }
    ),
    Z && /* @__PURE__ */ s(
      ki,
      {
        ref: he,
        x: Z.x,
        y: Z.y,
        item: Z.item,
        parentId: Z.parentId,
        onNewFile: (p) => ze(p, "file"),
        onNewFolder: (p) => ze(p, "folder"),
        onRename: (p) => ne({ id: p.id, parentId: p.parentId, value: p.title }),
        onDelete: _e,
        onCopyTitle: ct,
        onClose: () => X(null)
      }
    ),
    /* @__PURE__ */ s(En, { open: d, onOpenChange: v, children: /* @__PURE__ */ x(xn, { children: [
      /* @__PURE__ */ s(Rn, { style: zi }),
      /* @__PURE__ */ x(Pn, { style: Fi, children: [
        /* @__PURE__ */ s(On, { style: Wi, children: "密盘设置" }),
        /* @__PURE__ */ x("div", { style: je, children: [
          /* @__PURE__ */ x("label", { style: Jt, children: [
            /* @__PURE__ */ s(
              "input",
              {
                type: "checkbox",
                checked: h,
                onChange: (p) => void f(p.target.checked),
                style: Bi
              }
            ),
            /* @__PURE__ */ s("span", { children: "每次打开需要密码" })
          ] }),
          /* @__PURE__ */ s("p", { style: Qt, children: "勾选后，每次打开密盘面板都需要输入密码。关闭面板时自动锁定数据库。" }),
          /* @__PURE__ */ x("label", { style: Jt, children: [
            /* @__PURE__ */ s("span", { children: "空闲自动锁定" }),
            /* @__PURE__ */ s(
              "select",
              {
                value: y,
                onChange: (p) => void g(Number(p.target.value)),
                style: $i,
                children: zn.map((p) => /* @__PURE__ */ s("option", { value: p, children: p === 0 ? "永不" : `${p} 分钟` }, p))
              }
            )
          ] }),
          /* @__PURE__ */ s("p", { style: Qt, children: "无操作达到设定时长后自动锁定密盘。" })
        ] }),
        /* @__PURE__ */ s("div", { style: wt }),
        /* @__PURE__ */ x("div", { style: je, children: [
          /* @__PURE__ */ x("div", { style: xt, children: [
            /* @__PURE__ */ s(Er, { size: 14 }),
            /* @__PURE__ */ s("span", { children: "数据库管理" })
          ] }),
          /* @__PURE__ */ x("button", { style: St, onClick: m, children: [
            /* @__PURE__ */ s(Cr, { size: 14 }),
            /* @__PURE__ */ s("span", { children: "备份数据库" })
          ] }),
          /* @__PURE__ */ x("button", { style: St, onClick: C, children: [
            /* @__PURE__ */ s(Mr, { size: 14 }),
            /* @__PURE__ */ s("span", { children: "导入数据库" })
          ] })
        ] }),
        /* @__PURE__ */ s("div", { style: wt }),
        /* @__PURE__ */ s("div", { style: je, children: b ? /* @__PURE__ */ s(
          Hi,
          {
            invokeBackend: o,
            onSuccess: H,
            onCancel: () => u(!1)
          }
        ) : /* @__PURE__ */ x("button", { style: St, onClick: () => u(!0), children: [
          /* @__PURE__ */ s(on, { size: 14 }),
          /* @__PURE__ */ s("span", { children: "修改密码" })
        ] }) }),
        /* @__PURE__ */ s("div", { style: wt }),
        E && k && /* @__PURE__ */ x("div", { style: je, children: [
          /* @__PURE__ */ x("div", { style: xt, children: [
            /* @__PURE__ */ s(Me, { size: 14 }),
            /* @__PURE__ */ s("span", { children: "输入导入数据库的密码" })
          ] }),
          /* @__PURE__ */ s(
            "input",
            {
              type: "password",
              style: Ze,
              autoFocus: !0,
              value: S,
              onChange: (p) => P(p.target.value),
              onKeyDown: (p) => {
                p.key === "Enter" && F(), p.key === "Escape" && W();
              },
              placeholder: "密码",
              maxLength: ae
            }
          ),
          /* @__PURE__ */ x("div", { style: { fontSize: 11, color: "var(--text-secondary, #666)", wordBreak: "break-all" }, children: [
            "文件：",
            k
          ] }),
          /* @__PURE__ */ x("div", { style: Vn, children: [
            /* @__PURE__ */ s(
              "button",
              {
                style: jn,
                onClick: W,
                children: "取消"
              }
            ),
            /* @__PURE__ */ s(
              "button",
              {
                style: { ...Kn, opacity: S ? 1 : 0.5, cursor: S ? "pointer" : "not-allowed" },
                onClick: F,
                disabled: !S,
                children: "确认导入"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ s(Ln, { asChild: !0, children: /* @__PURE__ */ s("button", { style: Ui, children: "关闭" }) })
      ] })
    ] }) })
  ] });
}
function Fn(e) {
  const {
    item: t,
    depth: n,
    expanded: r,
    treeCache: o,
    onSelectNote: i,
    onToggle: l,
    selectedId: a,
    setSelectedId: d,
    renaming: v,
    setRenaming: h,
    onRename: f,
    onContextMenu: y,
    onCreate: g,
    creating: b,
    newName: u,
    setNewName: m,
    handleCreate: C,
    inputRef: E,
    dragOverId: k,
    onDragStart: S,
    onDragOver: P,
    onDrop: F,
    onDragEnd: W
  } = e, H = r.has(t.id), N = (v == null ? void 0 : v.id) === t.id, K = a === t.id, I = k === t.id, A = o.get(t.id) ?? [], j = () => {
    N || (d(t.id), t.type === "folder" ? l(t) : i(t));
  };
  return /* @__PURE__ */ x(
    "div",
    {
      draggable: !N,
      onDragStart: (O) => S(O, t),
      onDragOver: (O) => P(O, t),
      onDrop: (O) => F(O, t),
      onDragEnd: W,
      children: [
        /* @__PURE__ */ x(
          "div",
          {
            style: {
              ...Oi,
              paddingLeft: 8 + n * 14,
              backgroundColor: N ? "rgba(59, 130, 246, 0.08)" : I ? "rgba(59, 130, 246, 0.15)" : K ? "rgba(59, 130, 246, 0.05)" : "transparent"
            },
            "data-note-id": t.id,
            onClick: j,
            onContextMenu: (O) => y(O, t, null),
            children: [
              t.type === "folder" ? /* @__PURE__ */ s(
                "button",
                {
                  style: Mi,
                  onClick: (O) => {
                    O.stopPropagation(), l(t);
                  },
                  "aria-label": H ? "折叠" : "展开",
                  children: /* @__PURE__ */ s(
                    wr,
                    {
                      size: 12,
                      style: { transition: "transform 0.15s", transform: H ? "rotate(90deg)" : "none" }
                    }
                  )
                }
              ) : /* @__PURE__ */ s("span", { style: { width: 14, display: "inline-block", flexShrink: 0 } }),
              t.type === "folder" ? H ? /* @__PURE__ */ s(xr, { size: 14, style: mt }) : /* @__PURE__ */ s(Ge, { size: 14, style: mt }) : /* @__PURE__ */ s(Xe, { size: 14, style: mt }),
              N ? /* @__PURE__ */ s(
                "input",
                {
                  ref: E,
                  style: Li,
                  value: v.value,
                  onChange: (O) => h({ ...v, value: O.target.value }),
                  onBlur: f,
                  onKeyDown: (O) => {
                    O.key === "Enter" && (O.preventDefault(), f()), O.key === "Escape" && h(null);
                  },
                  onClick: (O) => O.stopPropagation()
                }
              ) : /* @__PURE__ */ s("span", { style: Ti, children: t.title })
            ]
          }
        ),
        (b == null ? void 0 : b.parentId) === t.id && t.type === "folder" && /* @__PURE__ */ s(
          Wn,
          {
            ref: E,
            type: b.type,
            value: u,
            onChange: m,
            onSubmit: C,
            onCancel: () => {
              g(null), m("");
            },
            depth: n + 1
          }
        ),
        H && A.length > 0 && /* @__PURE__ */ s("div", { children: A.map((O) => /* @__PURE__ */ s(Fn, { ...e, item: O, depth: n + 1 }, O.id)) })
      ]
    }
  );
}
const Wn = tt(function({ type: t, value: n, onChange: r, onSubmit: o, onCancel: i, depth: l }, a) {
  return /* @__PURE__ */ x("div", { style: { ...Ai, paddingLeft: 8 + l * 14 }, children: [
    t === "folder" ? /* @__PURE__ */ s(Ge, { size: 14 }) : /* @__PURE__ */ s(Xe, { size: 14 }),
    /* @__PURE__ */ s(
      "input",
      {
        ref: a,
        style: Ni,
        value: n,
        onChange: (d) => r(d.target.value),
        onBlur: o,
        onKeyDown: (d) => {
          d.key === "Enter" && (d.preventDefault(), o()), d.key === "Escape" && i();
        },
        placeholder: t === "folder" ? "文件夹名称" : "笔记名称"
      }
    )
  ] });
}), ki = tt(function({ x: t, y: n, item: r, parentId: o, onNewFile: i, onNewFolder: l, onRename: a, onDelete: d, onCopyTitle: v, onClose: h }, f) {
  const y = (C) => (E) => {
    E.stopPropagation(), C(), h();
  }, g = typeof window < "u" ? window.innerWidth - 180 : t, b = typeof window < "u" ? window.innerHeight - 240 : n, u = Math.min(t, g), m = Math.min(n, b);
  return /* @__PURE__ */ x(
    "div",
    {
      ref: f,
      style: {
        ..._i,
        left: u,
        top: m
      },
      onClick: (C) => C.stopPropagation(),
      onContextMenu: (C) => {
        C.preventDefault(), C.stopPropagation();
      },
      children: [
        (r == null ? void 0 : r.type) === "folder" && /* @__PURE__ */ x(Ke, { children: [
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => i(r.id)), children: [
            /* @__PURE__ */ s(Xe, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "新建笔记" })
          ] }),
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => l(r.id)), children: [
            /* @__PURE__ */ s(Ge, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "新建文件夹" })
          ] }),
          /* @__PURE__ */ s("div", { style: bt })
        ] }),
        !r && /* @__PURE__ */ x(Ke, { children: [
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => i(null)), children: [
            /* @__PURE__ */ s(Xe, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "新建笔记" })
          ] }),
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => l(null)), children: [
            /* @__PURE__ */ s(Ge, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "新建文件夹" })
          ] }),
          /* @__PURE__ */ s("div", { style: bt })
        ] }),
        r && /* @__PURE__ */ x(Ke, { children: [
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => a(r)), children: [
            /* @__PURE__ */ s(Pr, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "重命名" })
          ] }),
          /* @__PURE__ */ x("button", { style: ue, onClick: y(() => v(r)), children: [
            /* @__PURE__ */ s(Sr, { size: 12 }),
            " ",
            /* @__PURE__ */ s("span", { children: "复制标题" })
          ] }),
          /* @__PURE__ */ s("div", { style: bt }),
          /* @__PURE__ */ x(
            "button",
            {
              style: { ...ue, color: "#ef4444" },
              onClick: y(() => d(r)),
              children: [
                /* @__PURE__ */ s(Or, { size: 12 }),
                " ",
                /* @__PURE__ */ s("span", { children: "删除" })
              ]
            }
          )
        ] })
      ]
    }
  );
}), xi = {
  padding: 24,
  display: "flex",
  flexDirection: "column",
  gap: 14,
  boxSizing: "border-box",
  overflow: "auto"
}, Ri = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  marginBottom: 8,
  color: "var(--text-primary, #1f1f1f)"
}, Ie = {
  display: "flex",
  flexDirection: "column",
  gap: 4
}, Oe = {
  fontSize: 12,
  color: "var(--text-secondary, #666)",
  fontWeight: 500
}, Gt = {
  width: "100%",
  padding: "8px 12px",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  fontSize: 14,
  backgroundColor: "var(--bg-primary, #EDEFF2)",
  color: "var(--text-primary, #1f1f1f)",
  outline: "none",
  boxSizing: "border-box",
  minHeight: 36
}, Bn = {
  position: "absolute",
  right: 8,
  top: "50%",
  transform: "translateY(-50%)",
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 4,
  color: "var(--text-secondary, #666)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  width: 28,
  height: 28,
  borderRadius: 4
}, $n = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  marginTop: 4
}, Un = {
  height: 4,
  borderRadius: 2,
  transition: "width 0.2s, background-color 0.2s"
}, Hn = {
  padding: "8px 12px",
  backgroundColor: "rgba(239, 68, 68, 0.1)",
  color: "#ef4444",
  fontSize: 12,
  borderRadius: 6,
  border: "1px solid rgba(239, 68, 68, 0.2)"
}, Pi = {
  padding: "10px 16px",
  border: "none",
  borderRadius: 6,
  backgroundColor: "#3b82f6",
  background: "var(--theme-color, #3b82f6)",
  color: "#ffffff",
  fontSize: 14,
  fontWeight: 500,
  width: "100%",
  boxSizing: "border-box",
  minHeight: 40,
  cursor: "pointer",
  marginTop: 8
}, Di = {
  display: "flex",
  flexDirection: "column",
  height: "100%"
}, Ii = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  height: 40,
  padding: "0 12px",
  borderBottom: "1px solid var(--border-color, #e5e5e5)",
  flexShrink: 0
}, De = {
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  width: 24,
  height: 24,
  border: "none",
  borderRadius: 4,
  background: "transparent",
  cursor: "pointer",
  color: "var(--text-secondary, #666)",
  padding: 0
}, Oi = {
  display: "flex",
  alignItems: "center",
  gap: 4,
  height: 24,
  fontSize: 13,
  whiteSpace: "nowrap",
  cursor: "default",
  userSelect: "none"
}, Mi = {
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 0,
  display: "flex",
  alignItems: "center",
  color: "var(--text-secondary, #666)",
  flexShrink: 0
}, mt = {
  flexShrink: 0,
  color: "var(--text-secondary, #666)"
}, Ti = {
  flex: 1,
  overflow: "hidden",
  textOverflow: "ellipsis",
  color: "var(--text-primary, #1f1f1f)"
}, Li = {
  flex: 1,
  padding: "2px 4px",
  border: "1px solid var(--theme-color, #3b82f6)",
  borderRadius: 3,
  fontSize: 13,
  backgroundColor: "var(--bg-secondary, #ffffff)",
  color: "var(--text-primary, #1f1f1f)",
  outline: "none",
  minWidth: 80
}, Ai = {
  display: "flex",
  alignItems: "center",
  gap: 4,
  height: 24,
  color: "var(--text-secondary, #666)"
}, Ni = {
  flex: 1,
  padding: "2px 4px",
  border: "1px solid var(--theme-color, #3b82f6)",
  borderRadius: 3,
  fontSize: 13,
  backgroundColor: "var(--bg-secondary, #ffffff)",
  color: "var(--text-primary, #1f1f1f)",
  outline: "none",
  minWidth: 80,
  marginRight: 8
}, _i = {
  position: "fixed",
  minWidth: 160,
  padding: 4,
  backgroundColor: "var(--bg-primary, #EDEFF2)",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  boxShadow: "0 4px 16px rgba(0, 0, 0, 0.15)",
  zIndex: 1e4,
  display: "flex",
  flexDirection: "column",
  gap: 0
}, ue = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  padding: "6px 10px",
  border: "none",
  background: "transparent",
  cursor: "pointer",
  fontSize: 13,
  color: "var(--text-primary, #1f1f1f)",
  textAlign: "left",
  borderRadius: 4
}, bt = {
  height: 1,
  backgroundColor: "var(--border-color, #e5e5e5)",
  margin: "4px 0"
}, zi = {
  position: "fixed",
  inset: 0,
  backgroundColor: "rgba(0, 0, 0, 0.5)",
  zIndex: 1e4
}, Fi = {
  position: "fixed",
  left: "50%",
  top: "50%",
  transform: "translate(-50%, -50%)",
  width: "100%",
  maxWidth: 400,
  backgroundColor: "var(--bg-primary, #EDEFF2)",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 8,
  padding: 16,
  zIndex: 10001,
  boxShadow: "0 8px 32px rgba(0, 0, 0, 0.2)"
}, Wi = {
  fontSize: 16,
  fontWeight: 600,
  margin: "0 0 16px 0",
  color: "var(--text-primary, #1f1f1f)"
}, je = {
  display: "flex",
  flexDirection: "column",
  gap: 8
}, Jt = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  cursor: "pointer",
  fontSize: 13,
  color: "var(--text-primary, #1f1f1f)"
}, Bi = {
  cursor: "pointer"
}, $i = {
  padding: "4px 8px",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  fontSize: 12,
  backgroundColor: "var(--bg-secondary, #ffffff)",
  color: "var(--text-primary, #1f1f1f)",
  cursor: "pointer",
  outline: "none"
}, Qt = {
  fontSize: 11,
  color: "var(--text-secondary, #666)",
  margin: 0,
  lineHeight: 1.5
}, wt = {
  height: 1,
  backgroundColor: "var(--border-color, #e5e5e5)",
  margin: "12px 0"
}, xt = {
  display: "flex",
  alignItems: "center",
  gap: 6,
  fontSize: 12,
  fontWeight: 600,
  color: "var(--text-secondary, #666)",
  marginBottom: 4
}, St = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  padding: "8px 12px",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  background: "var(--bg-secondary, #ffffff)",
  cursor: "pointer",
  fontSize: 13,
  color: "var(--text-primary, #1f1f1f)"
}, Ze = {
  width: "100%",
  padding: "8px 12px",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  fontSize: 14,
  backgroundColor: "var(--bg-secondary, #ffffff)",
  color: "var(--text-primary, #1f1f1f)",
  outline: "none",
  boxSizing: "border-box"
}, Vn = {
  display: "flex",
  justifyContent: "flex-end",
  gap: 8,
  marginTop: 4
}, jn = {
  padding: "6px 12px",
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  background: "transparent",
  cursor: "pointer",
  fontSize: 13,
  color: "var(--text-primary, #1f1f1f)"
}, Kn = {
  padding: "6px 12px",
  border: "none",
  borderRadius: 6,
  background: "var(--theme-color, #3b82f6)",
  color: "#fff",
  cursor: "pointer",
  fontSize: 13,
  fontWeight: 500
}, Ui = {
  marginTop: 16,
  padding: "8px 16px",
  border: "none",
  borderRadius: 6,
  background: "var(--theme-color, #3b82f6)",
  color: "#fff",
  cursor: "pointer",
  fontSize: 13,
  fontWeight: 500,
  width: "100%"
};
function Hi({ invokeBackend: e, onSuccess: t, onCancel: n }) {
  const [r, o] = M(""), [i, l] = M(""), [a, d] = M(""), [v, h] = M(!1), [f, y] = M(""), [g, b] = M(!1), u = Nn(i), m = g ? !1 : r.length > 0 && (u == null ? void 0 : u.valid) === !0 && i === a, C = async () => {
    if (m) {
      b(!0), y("");
      try {
        await e("change_password", {
          currentPassword: r,
          newPassword: i
        }), t();
      } catch (S) {
        y(S instanceof Error ? S.message : String(S));
      } finally {
        b(!1);
      }
    }
  }, E = (S) => {
    S.key === "Enter" && m ? C() : S.key === "Escape" && n();
  }, k = v ? "text" : "password";
  return /* @__PURE__ */ x("div", { style: Vi, onKeyDown: E, children: [
    /* @__PURE__ */ x("div", { style: xt, children: [
      /* @__PURE__ */ s(on, { size: 14 }),
      /* @__PURE__ */ s("span", { children: "修改密码" })
    ] }),
    /* @__PURE__ */ x("div", { style: Ie, children: [
      /* @__PURE__ */ s("label", { style: Oe, children: "当前密码" }),
      /* @__PURE__ */ s(
        "input",
        {
          type: k,
          style: Ze,
          value: r,
          onChange: (S) => o(S.target.value),
          placeholder: "输入当前密码",
          maxLength: ae,
          autoFocus: !0
        }
      )
    ] }),
    /* @__PURE__ */ x("div", { style: Ie, children: [
      /* @__PURE__ */ s("label", { style: Oe, children: "新密码" }),
      /* @__PURE__ */ x("div", { style: { position: "relative" }, children: [
        /* @__PURE__ */ s(
          "input",
          {
            type: k,
            style: { ...Ze, paddingRight: 36 },
            value: i,
            onChange: (S) => l(S.target.value),
            placeholder: "输入新密码（至少 8 位，含字母和数字）",
            maxLength: ae
          }
        ),
        /* @__PURE__ */ s(
          "button",
          {
            type: "button",
            style: Bn,
            onClick: () => h(!v),
            "aria-label": v ? "隐藏密码" : "显示密码",
            children: v ? /* @__PURE__ */ s(nn, { size: 16 }) : /* @__PURE__ */ s(rn, { size: 16 })
          }
        )
      ] }),
      i.length > 0 && u && /* @__PURE__ */ x("div", { style: $n, children: [
        /* @__PURE__ */ s(
          "div",
          {
            style: {
              ...Un,
              width: u.strength === "weak" ? "33%" : u.strength === "medium" ? "66%" : "100%",
              backgroundColor: et(u.strength)
            }
          }
        ),
        /* @__PURE__ */ s("span", { style: { fontSize: 11, color: et(u.strength) }, children: _n(u.strength) }),
        u.error && /* @__PURE__ */ s("span", { style: { fontSize: 11, color: "#ef4444", marginLeft: 8 }, children: u.error })
      ] })
    ] }),
    /* @__PURE__ */ x("div", { style: Ie, children: [
      /* @__PURE__ */ s("label", { style: Oe, children: "确认新密码" }),
      /* @__PURE__ */ s(
        "input",
        {
          type: k,
          style: Ze,
          value: a,
          onChange: (S) => d(S.target.value),
          placeholder: "再次输入新密码",
          maxLength: ae
        }
      ),
      a.length > 0 && i !== a && /* @__PURE__ */ s("span", { style: { fontSize: 11, color: "#ef4444", marginTop: 4, display: "block" }, children: "两次输入的密码不一致" })
    ] }),
    f && /* @__PURE__ */ s("div", { style: Hn, children: f }),
    /* @__PURE__ */ x("div", { style: Vn, children: [
      /* @__PURE__ */ s("button", { style: jn, onClick: n, disabled: g, children: "取消" }),
      /* @__PURE__ */ s(
        "button",
        {
          style: { ...Kn, opacity: m ? 1 : 0.5, cursor: m ? "pointer" : "not-allowed" },
          onClick: C,
          disabled: !m,
          children: g ? "处理中…" : "确认修改"
        }
      )
    ] })
  ] });
}
const Vi = {
  display: "flex",
  flexDirection: "column",
  gap: 10,
  padding: 12,
  border: "1px solid var(--border-color, #e5e5e5)",
  borderRadius: 6,
  backgroundColor: "var(--bg-secondary, #ffffff)"
}, Yi = qn(yr, {
  icon: Tr,
  panel: Ei,
  onLoad: () => {
  }
});
export {
  Yi as default,
  qi as setHost
};
